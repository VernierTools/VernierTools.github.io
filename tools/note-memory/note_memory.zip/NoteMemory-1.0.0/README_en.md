# Note Memory (v1.0.0, unofficial)

A script for Fender Studio Pro 8. In the piano roll, **notes you place by clicking (or double-clicking) get the same length and velocity as the last note you touched.**

Normally a clicked note always gets the piano roll's "Note Length" setting (1/16 etc.) and the default velocity. With this script, Studio Pro remembers the length and velocity of the note you last selected or drew, and applies them to the next note you place by clicking. Odd lengths (dotted, or stretched by dragging) are carried over as they are.

> ⚠️ **Unofficial, no warranty.** It uses internal scripting features that Fender (formerly PreSonus) has not published. Use at your own risk.

---

## Behavior

| You do | Note Memory does |
|---|---|
| **Select** one note / **draw** one by dragging / **change** its length or velocity | **Remembers** that note's length and velocity. |
| **Click (double-click)** in the piano roll to place a note | **Rewrites** the new note to the remembered length and velocity. |
| **Cmd+Z once** on such a note | The note **disappears** (the click and the rewrite are undone together). |
| Then **Cmd+Shift+Z once** | The note **comes back, rewritten**. |

- A note is rewritten only when **exactly one note was added and its length equals the piano roll's Note Length setting**. Notes drawn by dragging are left alone and become the new remembered note.
- The rewrite happens right after placing (about 0.03 s), so the original length may flash briefly.
- When you place several notes in a row, each Cmd+Z / Cmd+Shift+Z still handles **one note per press**.
- Only length and velocity are carried over. Pitch and position stay where you clicked.

## Commands

They appear under the category **"Note Memory"** in the keyboard shortcut settings.

| Command | What it does |
|---|---|
| **Toggle Note Memory** | Turns Note Memory on/off (on at startup) and shows the new state in a dialog. |
| Note Memory Status | Diagnostics: shows the remembered length/velocity and activity counters. Use it for bug reports. |
| Note Memory Check | **Used internally. Don't assign a key to it.** |

## Tested with

- Fender Studio Pro **8.2.0** (Build 114903)
- macOS (Apple Silicon)

**Not tested**: Studio One 6 / 7, Windows, Intel Macs, the drum editor.

---

## Installation (macOS)

1. **Quit Studio Pro.**
2. In Finder choose Go → Go to Folder… (Cmd+Shift+G), paste this path and press Enter:
   ```
   ~/Library/Application Support/Fender/Studio Pro 8/Extensions/
   ```
3. Copy the **`local.notememory.mac` folder** from this ZIP into that folder as it is. It should look like this:
   ```
   Extensions/
     local.notememory.mac/
       metainfo.xml
       installdata.xml
       Scripts/
         note-memory.package
   ```
4. Start Studio Pro. Note Memory starts working right away.
5. Optionally, search for "Note Memory" in the keyboard shortcut settings and assign **Toggle Note Memory** to a key.

To update, quit Studio Pro and replace the whole `local.notememory.mac` folder.

### ⛔ Don't

- **Never put anything inside `Studio Pro 8.app` (e.g. `Contents/Scripts`).** It can break the app's signature; macOS then reports the app as "damaged" and **it won't start** until you reinstall Studio Pro.
- "Install from File" **does not work** (this is not a signed `.install` package). Copy the folder as described above.

## Uninstall

Quit Studio Pro and **delete the `local.notememory.mac` folder** from `~/Library/Application Support/Fender/Studio Pro 8/Extensions/`.

---

## Known limitations

- If you press **Cmd+Z very quickly twice (within ~0.2 s)**, that note may need two presses. Earlier notes are not affected.
- The one-press undo/redo helper tracks the **last 50 rewritten notes**. Switching songs resets it. Older notes need two presses.
- On Cmd+Shift+Z the note may flash at its original length for 0.1–0.2 s.
- While Note Memory is off, the undo/redo helper is off too.
- A note drawn by dragging that happens to be exactly the Note Length setting is treated as clicked and gets rewritten.
- If the length can't be worked out from the Note Length setting (unusual tuplets), nothing happens.
- **A Fender update may break it.** It uses unpublished APIs, and unsigned extensions might stop loading in the future. Studio Pro itself would keep working; the script would just not load.

## Troubleshooting

- "Note Memory" doesn't appear in the shortcut settings
  → Check the folder layout (especially the `Scripts` subfolder) and that you restarted Studio Pro.
- Clicked notes are not rewritten
  → Check that Note Memory isn't off ("Toggle Note Memory"). Select one note first so there is something to remember.
- Still not working
  → Run **Note Memory Status** and send what it shows to the author.

---

## Safety

- This script is **not signed**. Unsigned extensions run with the same permissions as Studio Pro.
- The package is a ZIP file, so **you can inspect it before installing**: duplicate `Scripts/note-memory.package`, rename it to `.zip`, and read `main.js`. The same files are in the `source/` folder.
- All it does is **read the piano roll's notes and settings, change note length and velocity, run the Undo / Redo commands, and show dialogs**. It does not read or write files and does not use the network.
- Don't use modified copies from unknown sources.

## Contents

```
NoteMemory-1.0.0/
  README_ja.md / README_en.md  … this guide
  LICENSE                      … license (full CC0 1.0 text)
  local.notememory.mac/        … the folder to install
  source/                      … contents of the .package (for review)
    classfactory.xml  … command and service registration
    metainfo.xml      … package info
    main.js           … the script
```

## Changelog

- **1.0.0**: First public release.

## License

**CC0 1.0 Universal (public domain dedication)**

To the extent possible under law, the author has waived all copyright and related rights to this script. You may use, modify and redistribute it for any purpose, commercial or not, without permission or attribution. Where such a waiver isn't possible, it is licensed unconditionally with the same freedoms. See `LICENSE` for the legal text.

Provided without warranty of any kind.

Fender, Studio Pro and Studio One are trademarks of their respective owners. This script is not affiliated with Fender or PreSonus.

## Reference

- Unofficial Scripting API reference (community): https://github.com/CSources/Studio-Pro-Scripting-API-Reference

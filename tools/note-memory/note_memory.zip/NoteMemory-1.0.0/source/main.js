// Note Memory v1.0.0 (unofficial) - Fender Studio Pro 8 script
// License: CC0 1.0 Universal (public domain dedication)
//
// Notes added with a single/double click in the piano roll get the length and velocity of
// the last note you touched (selected, drew by dragging, resized...).
// One Cmd+Z removes such a note, and one Cmd+Shift+Z brings it back.
//
// How it works:
//  - "Note Memory Service" (background) listens for "selectionChanged" from the edit
//    environment and then runs the "Note Memory Check" command.
//  - "Note Memory Check" (piano roll command) counts the notes of the part. If exactly one
//    note was added, it is the only selected note, and its length equals the piano roll's
//    insert length (placed by clicking, not drawn by dragging), it is resized and given the
//    remembered velocity. Otherwise the single selected note becomes the remembered note.
//  - The click and the rewrite are two undo steps. The service watches the rewritten notes
//    and, when Cmd+Z / Cmd+Shift+Z handled only one of the two, runs Undo / Redo once more.
// Commands: "Toggle Note Memory" (on/off), "Note Memory Status" (diagnostics).
// "Note Memory Check" is used internally; don't assign a key to it.

var kCh = "local.notememory";
var kCat = "Note Memory";
var kBase = "://hostapp/DocumentManager/ActiveDocument/";

// shared state (also used to check whether globals survive between commands)
var NM = { enabled: true, last: null, undoList: [], redoList: [], counts: {}, calls: 0, applied: 0, info: "-", events: 0,
           undoneSeen: 0, autoUndos: 0, autoRedos: 0, scan: "-" };

function prop(o, p) { try { return o[p]; } catch (e) { return undefined; } }
function has(o, m) { try { return o !== null && o !== undefined && typeof o[m] === "function"; } catch (e) { return false; } }
function approx(a, b) { return Math.abs(a - b) < 1e-4; }
function param(o, name) {
    if (!has(o, "findParameter")) return null;
    try { return o.findParameter(name); } catch (e) { return null; }
}
function typeFactor(s) {
    s = String(s || "").toLowerCase();
    if (s.indexOf("straight") >= 0 || s === "") return 1;
    if (s.indexOf("triplet") >= 0) return 2 / 3;
    if (s.indexOf("quintuplet") >= 0) return 4 / 5;
    if (s.indexOf("septuplet") >= 0) return 4 / 7;
    return null;
}

// insert length of the piano roll, in beats (null if unknown)
function insertLength() {
    var me = null;
    try { me = Host.Objects.getObjectByUrl(kBase + "Editor/MusicEditor"); } catch (e) {}
    if (!me || !has(me, "find")) return null;
    var nl = null; try { nl = me.find("NoteLength"); } catch (e) {}
    if (!nl) return null;
    var follow = param(nl, "followQuantize");
    if (follow && prop(follow, "value")) {
        var q = null; try { q = me.find("Quantize"); } catch (e) {}
        var qb = param(q, "base"), qt = param(q, "type");
        if (!qb) return null;
        var f = typeFactor(qt ? prop(qt, "string") : "");
        return f === null ? null : Number(prop(qb, "value")) * f;
    }
    var b = param(nl, "base"), d = param(nl, "dotted"), t = param(nl, "type");
    if (!b) return null;
    var beats = 4 / Math.pow(2, Number(prop(b, "value")));       // index 0 = 1/1 ... 6 = 1/64
    if (d && prop(d, "value")) beats *= 1.5;
    var ft = typeFactor(t ? prop(t, "string") : "");
    return ft === null ? null : beats * ft;
}

function CheckTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        NM.calls++;
        var it = prop(context, "iterator");
        if (!it) return Host.Results.kResultOk;
        var sel = [];
        if (has(it, "done")) { while (!it.done()) { var n = it.next(); if (n) sel.push(n); } }

        // (Undo of a rewrite is detected by the service, which polls the part; see rewriteUndone.)
        if (sel.length === 0) return Host.Results.kResultOk;

        var region = prop(sel[0], "region");
        var count = 0;
        if (region && has(region, "createSequenceIterator")) {
            var all = region.createSequenceIterator();
            while (!all.done()) { all.next(); count++; }
        }
        var rkey = String(prop(region, "name")) + "|" + String(prop(region, "start"));
        var prev = NM.counts.hasOwnProperty(rkey) ? NM.counts[rkey] : undefined;
        NM.counts[rkey] = count;
        if (sel.length !== 1) return Host.Results.kResultOk;

        var note = sel[0], len = prop(note, "length"), vel = prop(note, "velocity");
        var start = prop(note, "start"), pitch = prop(note, "pitch");
        var ins = insertLength();
        var added = (prev !== undefined && count === prev + 1);
        // the note we last rewrote, back at the insert length = its rewrite was undone (Cmd+Z)
        // (or our auto undo was just redone halfway): don't learn that insert-length note
        function sameNote(w) { return w && w.rkey === rkey && w.pitch === pitch && approx(w.start, start) &&
            ins !== null && approx(len, ins) && count === w.count; }
        var undone = false, li = NM.undoList.concat(NM.redoList);
        for (var u = 0; u < li.length; u++) if (sameNote(li[u])) undone = true;
        if (NM.enabled && added && ins !== null && approx(len, ins) && NM.last &&
            (!approx(len, NM.last.len) || !approx(vel, NM.last.vel))) {
            var fn = prop(context, "functions");
            if (has(fn, "resizeEvent")) fn.resizeEvent(note, NM.last.len);
            if (has(fn, "modifyVelocity")) fn.modifyVelocity(note, NM.last.vel);
            NM.applied++;
            for (var d = NM.undoList.length - 1; d >= 0; d--) {        // an older entry for the same spot is stale
                var o = NM.undoList[d];
                if (o.rkey === rkey && o.pitch === pitch && approx(o.start, start)) NM.undoList.splice(d, 1);
            }
            NM.undoList.push({ rkey: rkey, pitch: pitch, start: start, count: count, region: region, ins: ins });
            if (NM.undoList.length > kMaxList) NM.undoList.shift();
            NM.redoList = [];   // a new edit clears the redo history
            NM.info = "applied len=" + NM.last.len + " vel=" + NM.last.vel;
        } else if (undone) {
            // Cmd+Z removed our rewrite (the service normally catches this first and undoes
            // the insert too). Just don't learn the undone insert-length note.
            NM.info = "undone rewrite seen by check (memory kept)";
        } else {
            NM.last = { len: len, vel: vel };
            NM.info = "remembered len=" + len + " vel=" + vel + " (added=" + added + ", insert=" + ins + ")";
        }
        return Host.Results.kResultOk;
    };
}

// Every note Note Memory rewrote is kept in undoList (oldest first). Studio Pro's history is
// linear and our rewrite always comes right after the click that added the note, so:
//  - a listed note back at the insert length, with the part holding the same number of notes as
//    right after the click, means Cmd+Z just undid that rewrite -> undo once more (the click);
//  - after that it moves to redoList; the note coming back at the insert length again means
//    Cmd+Shift+Z just redid the click -> redo once more (the rewrite).
var kPollMs = 100, kMaxList = 50;

// Which entry of the list is in that state? Returns its index, -1 for none.
// Entries whose part can't be read any more are dropped.
function findAtInsertLength(list, what) {
    var cache = {}, found = -1;
    for (var i = list.length - 1; i >= 0; i--) {
        var e = list[i];
        var c = cache[e.rkey];
        if (c === undefined) {
            c = null;
            if (e.region && has(e.region, "createSequenceIterator")) {
                try {
                    var seq = e.region.createSequenceIterator();
                    if (seq && has(seq, "done") && has(seq, "next")) {
                        c = { total: 0, notes: [] };
                        while (!seq.done()) {
                            var x = seq.next(); c.total++;
                            if (x) c.notes.push([prop(x, "pitch"), prop(x, "start"), prop(x, "length")]);
                        }
                    }
                } catch (err) { c = null; }
            }
            cache[e.rkey] = c;
        }
        if (c === null) { list.splice(i, 1); continue; }
        if (found >= 0 || e.ins === null || c.total !== e.count) continue;
        for (var k = 0; k < c.notes.length; k++) {
            var n = c.notes[k];
            if (n[0] === e.pitch && approx(n[1], e.start) && approx(n[2], e.ins)) {
                found = i; NM.scan = what + ": entry " + (i + 1) + "/" + list.length + ", total=" + c.total; break;
            }
        }
    }
    return found;
}

function Service() {
    var self = this;
    this.interfaces = [Host.Interfaces.IComponent, Host.Interfaces.IObserver];
    this.watched = null;
    this.docKey = null;
    this.pending = false;
    this.polling = false;
    this.redoSeen = -1;
    this.undoSeen = -1;

    this.initialize = function () {
        try { Host.Signals.advise(kCh, this); } catch (e) {}
        Host.Signals.postMessage(this, 1000, "tick");
        return Host.Results.kResultOk;
    };
    this.terminate = function () {
        try { Host.Signals.unadvise(kCh, this); } catch (e) {}
        if (this.watched) { try { Host.Signals.unadvise(this.watched, this); } catch (e) {} }
        return Host.Results.kResultOk;
    };
    // (re)subscribe to the active song's edit environment
    this.ensureWatching = function () {
        var d = null;
        try { d = Host.Objects.getObjectByUrl(kBase.replace(/\/$/, "")); } catch (e) {}
        var key = d ? String(prop(d, "title")) + "|" + String(prop(d, "name")) : null;
        if (key === this.docKey && this.watched) return;
        if (this.watched) { try { Host.Signals.unadvise(this.watched, this); } catch (e) {} this.watched = null; }
        this.docKey = key;
        if (!d) return;
        var env = null;
        try { env = Host.Objects.getObjectByUrl(kBase + "EditEnvironment"); } catch (e) {}
        if (env) { try { Host.Signals.advise(env, this); this.watched = env; } catch (e) {} }
        NM.counts = {};
        NM.undoList = [];
        NM.redoList = [];
    };
    this.startPolling = function () {
        if (!self.polling) { self.polling = true; Host.Signals.postMessage(self, kPollMs, "poll"); }
    };
    this.poll = function () {
        self.polling = false;
        var i, moved;
        if (NM.undoList.length) {
            i = findAtInsertLength(NM.undoList, "undo");
            // also seen on two polls in a row, so a fresh click that Note Memory is about to
            // rewrite (~30 ms) is never taken for an undo
            if (i >= 0 && self.undoSeen !== i) { self.undoSeen = i; i = -2; }
            else if (i < 0) self.undoSeen = -1;
            if (i >= 0) {
                self.undoSeen = -1;
                // newer entries above it were undone too (e.g. Cmd+Z pressed very fast): they go
                // to the redo list first, deeper than this one
                moved = NM.undoList.splice(i, NM.undoList.length - i);
                var hit = moved[0];
                for (var j = moved.length - 1; j >= 1; j--) NM.redoList.push(moved[j]);
                NM.undoneSeen++;
                if (NM.enabled) {
                    try {
                        Host.GUI.Commands.interpretCommand("Edit", "Undo"); NM.autoUndos++;
                        NM.info = "rewrite was undone -> auto undo done";
                        NM.counts[hit.rkey] = hit.count - 1;           // the clicked note is gone now
                        NM.redoList.push(hit);
                    } catch (e) { NM.info = "auto undo failed: " + e; }
                } else NM.info = "rewrite was undone (Note Memory OFF, no auto undo)";
                if (NM.redoList.length > kMaxList) NM.redoList.shift();
                self.redoSeen = -1;
            }
        }
        if (NM.redoList.length && !(i >= 0)) {
            var r = findAtInsertLength(NM.redoList, "redo");
            // must be seen on two polls in a row (>= 100 ms): a fresh click at the same spot is
            // rewritten by Note Memory within ~30 ms and is not mistaken for a redo
            if (r >= 0 && self.redoSeen === r) {
                self.redoSeen = -1;
                moved = NM.redoList.splice(r, NM.redoList.length - r);
                var hr = moved[0];
                for (var m = moved.length - 1; m >= 1; m--) NM.undoList.push(moved[m]);
                if (NM.enabled) {
                    try {
                        Host.GUI.Commands.interpretCommand("Edit", "Redo"); NM.autoRedos++;
                        NM.info = "click was redone -> auto redo done";
                        NM.counts[hr.rkey] = hr.count;
                        NM.undoList.push(hr);                            // Cmd+Z works again
                    } catch (e) { NM.info = "auto redo failed: " + e; }
                }
                if (NM.undoList.length > kMaxList) NM.undoList.shift();
            } else self.redoSeen = r;
        }
        if (NM.undoList.length || NM.redoList.length) self.startPolling();
    };
    this.notify = function (subject, msg) {
        var id = msg ? String(prop(msg, "id")) : "";
        if (id === "tick") { self.ensureWatching(); Host.Signals.postMessage(self, 1000, "tick"); return; }
        if (id === "selectionChanged") {
            NM.events++;
            if (NM.enabled && !self.pending) { self.pending = true; Host.Signals.postMessage(self, 30, "check"); }
            return;
        }
        if (id === "check") {
            self.pending = false;
            try { Host.GUI.Commands.interpretCommand(kCat, "Note Memory Check"); } catch (e) { NM.info = "check failed: " + e; }
            if (NM.undoList.length || NM.redoList.length) self.startPolling();
            return;
        }
        if (id === "poll") { self.poll(); return; }
        if (id === "toggle") { NM.enabled = !NM.enabled; Host.GUI.alert("Note Memory: " + (NM.enabled ? "ON" : "OFF")); return; }
        if (id === "status") {
            Host.GUI.alert("Note Memory: " + (NM.enabled ? "ON" : "OFF") +
                "\nselectionChanged events: " + NM.events + "\ncheck runs: " + NM.calls + "\napplied: " + NM.applied +
                "\nundone rewrites seen: " + NM.undoneSeen + "\nauto undos: " + NM.autoUndos + "\nauto redos: " + NM.autoRedos +
                "\nrewrites tracked for undo: " + NM.undoList.length + "\nfor redo: " + NM.redoList.length +
                "\nlast scan: " + NM.scan +
                "\nremembered: " + (NM.last ? "len=" + NM.last.len + " vel=" + NM.last.vel : "-") +
                "\ninsert length now: " + insertLength() + "\nlast: " + NM.info + "\nwatching: " + (self.watched ? "yes" : "no"));
        }
    };
}

function SignalCmd(id) {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function () { return Host.Results.kResultOk; };
    this.performEdit = function () { Host.Signals.signal(kCh, id, ""); return Host.Results.kResultOk; };
}

function createService() { return new Service(); }
function createCheck() { return new CheckTask(); }
function createToggle() { return new SignalCmd("toggle"); }
function createStatus() { return new SignalCmd("status"); }

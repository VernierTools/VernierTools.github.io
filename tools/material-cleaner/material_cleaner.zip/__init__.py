# SPDX-License-Identifier: GPL-3.0-or-later
"""
Material Cleaner
Two buttons: merge materials whose contents are identical, and remove
materials nobody uses.

"Identical" is judged strictly: every node, every node setting, every
unlinked socket value, every link and the main material settings must
match. Anything that can't be read reliably makes the material
ineligible, so a merge never loses a difference.
"""

import bpy
from bpy.types import Operator, Panel


# ─────────────────────────────────────────────────────────────────────────────
# Fingerprint
# ─────────────────────────────────────────────────────────────────────────────

class _Unsure(Exception):
    """Raised when a value can't be compared reliably."""


# Properties that never affect how a material looks.
_SKIP = {"rna_type", "select"}

# Material settings outside the node tree. Missing ones (other Blender
# versions) are simply ignored.
_MATERIAL_SETTINGS = (
    "diffuse_color", "metallic", "roughness",
    "specular_intensity", "specular_color",
    "use_backface_culling", "use_backface_culling_shadow",
    "use_backface_culling_lightprobe_volume",
    "surface_render_method", "blend_method", "displacement_method",
    "use_transparent_shadow", "use_screen_refraction",
    "use_raytrace_refraction", "refraction_depth", "thickness_mode",
    "use_thickness_from_shadow", "alpha_threshold", "pass_index",
    "volume_intersection_method", "max_vertex_displacement",
    "line_color", "line_priority",
)

_DEPTH = 4


def _ser(value, depth=_DEPTH):
    """Turn an RNA value into a hashable, comparable tuple."""
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return round(value, 5)
    if isinstance(value, bpy.types.ID):
        return ("ID", type(value).__name__, value.name_full)
    if isinstance(value, bpy.types.bpy_struct):
        if depth <= 0:
            raise _Unsure
        return tuple(
            (p.identifier, _ser(getattr(value, p.identifier), depth - 1))
            for p in value.bl_rna.properties
            if p.identifier not in _SKIP
        )
    if isinstance(value, set):
        return tuple(sorted(value))
    try:
        return tuple(_ser(v, depth) for v in value)
    except TypeError:
        raise _Unsure


def _socket_values(sockets, skip_linked):
    out = []
    for s in sockets:
        if (skip_linked and s.is_linked) or not hasattr(s, "default_value"):
            out.append((s.identifier, None))
        else:
            out.append((s.identifier, _ser(s.default_value)))
    return tuple(out)


def _node_signature(node, base_props):
    props = tuple(
        (p.identifier, _ser(getattr(node, p.identifier)))
        for p in node.bl_rna.properties
        if p.identifier not in base_props and p.identifier not in _SKIP
    )
    return (
        node.name, node.bl_idname, node.mute, props,
        # A linked input's own value is ignored by Blender, so skip it.
        _socket_values(node.inputs, skip_linked=True),
        # Value / RGB nodes keep their value on the output socket, and it
        # matters precisely when the output is linked.
        _socket_values(node.outputs, skip_linked=False),
    )


def _fingerprint(mat):
    """Full content signature of a material, or None if not comparable."""
    if mat.animation_data:
        return None
    tree = mat.node_tree
    if tree is not None and tree.animation_data:
        return None

    try:
        settings = tuple(
            (name, _ser(getattr(mat, name)))
            for name in _MATERIAL_SETTINGS
            if hasattr(mat, name)
        )
        cycles = _ser(mat.cycles, 1) if hasattr(mat, "cycles") else None

        if tree is None:
            return (settings, cycles, None)

        base_props = {p.identifier for p in bpy.types.Node.bl_rna.properties}
        nodes = tuple(sorted(
            (_node_signature(n, base_props) for n in tree.nodes),
            key=repr,
        ))
        links = tuple(sorted(
            (l.from_node.name, l.from_socket.identifier,
             l.to_node.name, l.to_socket.identifier,
             getattr(l, "is_muted", False))
            for l in tree.links
        ))
        return (settings, cycles, nodes, links)
    except (_Unsure, AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _is_numbered(name):
    head, dot, tail = name.rpartition(".")
    return bool(dot) and tail.isdigit()


# ─────────────────────────────────────────────────────────────────────────────
# Operators
# ─────────────────────────────────────────────────────────────────────────────

class MC_OT_merge_identical(Operator):
    bl_idname = "mc.merge_identical"
    bl_label = "Merge Identical"
    bl_description = (
        "Find materials whose nodes and settings are exactly the same and "
        "replace the copies with one of them"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        groups = {}
        for mat in bpy.data.materials:
            # Leave alone anything the user protected or can't edit here.
            if (mat.library or mat.override_library or mat.use_fake_user
                    or getattr(mat, "is_grease_pencil", False)):
                continue
            fp = _fingerprint(mat)
            if fp is not None:
                groups.setdefault(fp, []).append(mat)

        merged = 0
        for group in groups.values():
            if len(group) < 2:
                continue
            # Keep the most used one; on a tie prefer "Wood" over "Wood.001".
            group.sort(key=lambda m: (-m.users, _is_numbered(m.name), m.name))
            keep = group[0]
            for dup in group[1:]:
                dup.user_remap(keep)
                if dup.users == 0:
                    bpy.data.materials.remove(dup)
                merged += 1

        if merged:
            self.report({'INFO'}, f"Merged {merged} material(s)")
        else:
            self.report({'INFO'}, "No identical materials found")
        return {'FINISHED'}


class MC_OT_remove_unused(Operator):
    bl_idname = "mc.remove_unused"
    bl_label = "Remove Unused"
    bl_description = (
        "Delete materials that no object uses. "
        "Materials with Fake User are kept"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        unused = [
            m for m in bpy.data.materials
            if m.users == 0 and not m.use_fake_user
        ]
        for mat in unused:
            bpy.data.materials.remove(mat)

        if unused:
            self.report({'INFO'}, f"Removed {len(unused)} material(s)")
        else:
            self.report({'INFO'}, "No unused materials found")
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Panel
# ─────────────────────────────────────────────────────────────────────────────

class MC_PT_main(Panel):
    bl_label = "Material Cleaner"
    bl_idname = "MC_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Mat Cleaner"

    def draw(self, context):
        col = self.layout.column(align=True)
        col.scale_y = 1.4
        col.operator("mc.merge_identical", icon='MATERIAL')
        col.operator("mc.remove_unused", icon='TRASH')


# ─────────────────────────────────────────────────────────────────────────────
# Registration
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    MC_OT_merge_identical,
    MC_OT_remove_unused,
    MC_PT_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

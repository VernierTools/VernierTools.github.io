import bpy
import bmesh
import numpy as np
from mathutils import Vector
from mathutils.geometry import delaunay_2d_cdt
from bpy.props import FloatProperty, IntProperty, BoolProperty
from bpy.types import Operator, Panel


# ===========================================================================
# Resolving the alpha texture for each material
# ===========================================================================

def iter_nodes_recursive(node_tree, depth=0, seen=None):
    """Walk a node tree recursively, descending into node groups."""
    if node_tree is None or depth > 8:
        return
    if seen is None:
        seen = set()
    if node_tree.as_pointer() in seen:
        return
    seen.add(node_tree.as_pointer())

    for node in node_tree.nodes:
        yield node
        if node.type == 'GROUP' and node.node_tree is not None:
            for inner in iter_nodes_recursive(node.node_tree, depth + 1, seen):
                yield inner


def trace_to_image(socket, depth=0):
    """Walk backwards from an input socket to find an Image Texture.
    Follows reroutes, node groups and intermediate nodes."""
    if socket is None or not socket.is_linked or depth > 12:
        return None
    link = socket.links[0]
    node = link.from_node
    from_sock = link.from_socket

    if node.type == 'TEX_IMAGE':
        return node.image

    if node.type == 'REROUTE':
        if node.inputs:
            return trace_to_image(node.inputs[0], depth + 1)
        return None

    if node.type == 'GROUP' and node.node_tree is not None:
        # Continue from the matching socket on the group's Group Output node
        for inner in node.node_tree.nodes:
            if inner.type == 'GROUP_OUTPUT':
                s = inner.inputs.get(from_sock.name)
                if s is not None:
                    img = trace_to_image(s, depth + 1)
                    if img is not None:
                        return img
        return None

    if node.type == 'GROUP_INPUT':
        return None

    for inp in node.inputs:
        img = trace_to_image(inp, depth + 1)
        if img is not None:
            return img
    return None


# Input sockets that plausibly receive an alpha value
ALPHA_SOCKET_HINTS = (
    ('BSDF_PRINCIPLED', 'Alpha'),
    ('MIX_SHADER', 'Fac'),
    ('BSDF_TRANSLUCENT', 'Color'),
    ('EMISSION', 'Strength'),
)


def find_alpha_image(mat, strict):
    """Find the alpha image for a material. Returns (image, reason)."""
    if mat is None:
        return None, "Empty slot"
    if not mat.use_nodes or mat.node_tree is None:
        return None, "Material does not use nodes"

    nodes = list(iter_nodes_recursive(mat.node_tree))

    # 1. Trace back from Principled Alpha / Mix Shader Fac
    for node in nodes:
        if node.type == 'BSDF_PRINCIPLED':
            s = node.inputs.get('Alpha')
            if s is not None:
                img = trace_to_image(s)
                if img is not None:
                    return img, "Alpha input"
    for node in nodes:
        if node.type == 'MIX_SHADER':
            s = node.inputs.get('Fac')
            if s is not None:
                img = trace_to_image(s)
                if img is not None:
                    return img, "Mix Shader Fac"

    # 2. An image node whose Alpha output is linked somewhere
    for node in nodes:
        if node.type == 'TEX_IMAGE' and node.image is not None:
            out = node.outputs.get('Alpha')
            if out is not None and out.is_linked:
                return node.image, "Alpha output is linked"

    if strict:
        return None, "No image reachable from Alpha"

    # 3. Non-strict: the first image node found
    for node in nodes:
        if node.type == 'TEX_IMAGE' and node.image is not None:
            return node.image, "Fallback (first image)"

    return None, "No image texture found"


def get_alpha_array(image):
    """Read an image's alpha channel as an (h, w) array. Returns (array, reason)."""
    if image is None:
        return None, "No image"

    w, h = image.size
    if w == 0 or h == 0:
        try:
            image.reload()
        except Exception:
            pass
        w, h = image.size
    if w == 0 or h == 0:
        return None, "Image is not loaded"

    try:
        buf = np.empty(w * h * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
    except Exception:
        return None, "Cannot read pixels"

    a = buf.reshape((h, w, 4))[:, :, 3].copy()
    amin = float(a.min())

    if amin >= 0.999:
        if getattr(image, "alpha_mode", "") == 'NONE':
            return None, "Image Alpha Mode is 'None' (change it in Image settings)"
        return None, "Alpha is fully opaque"

    return a, f"OK (min {amin:.2f})"


def build_material_alpha_map(obj, strict):
    """Return a dict of material slot index -> alpha array, plus diagnostics.
    Faces using a slot without an alpha texture are left completely untouched."""
    alpha_map = {}
    info = []
    image_cache = {}

    slots = obj.material_slots
    if len(slots) == 0:
        info.append((0, "(no material)", None, "No material slots"))
        return alpha_map, info

    for idx, slot in enumerate(slots):
        mat = slot.material
        name = mat.name if mat else "(empty slot)"
        img, reason = find_alpha_image(mat, strict)

        if img is None:
            info.append((idx, name, None, reason))
            continue

        key = img.name_full
        if key not in image_cache:
            image_cache[key] = get_alpha_array(img)
        arr, arr_reason = image_cache[key]

        if arr is None:
            info.append((idx, name, img.name, arr_reason))
            continue

        alpha_map[idx] = arr
        info.append((idx, name, img.name, f"{reason} / {arr_reason}"))

    return alpha_map, info


# ===========================================================================
# Image sampling
# ===========================================================================

def sample_alpha_array(alpha, us, vs):
    h, w = alpha.shape
    u = np.mod(np.asarray(us, dtype=np.float64), 1.0)
    v = np.mod(np.asarray(vs, dtype=np.float64), 1.0)
    x = u * (w - 1)
    y = v * (h - 1)
    x0 = np.floor(x).astype(np.int32)
    y0 = np.floor(y).astype(np.int32)
    x1 = np.minimum(x0 + 1, w - 1)
    y1 = np.minimum(y0 + 1, h - 1)
    fx = x - x0
    fy = y - y0
    a0 = alpha[y0, x0] * (1.0 - fx) + alpha[y0, x1] * fx
    a1 = alpha[y1, x0] * (1.0 - fx) + alpha[y1, x1] * fx
    return a0 * (1.0 - fy) + a1 * fy


def sample_alpha(alpha, u, v):
    return float(sample_alpha_array(alpha, np.array([u]), np.array([v]))[0])


# ===========================================================================
# Contour extraction
# ===========================================================================

def marching_squares(alpha, u_min, u_max, v_min, v_max, threshold, res):
    gu = np.linspace(u_min, u_max, res + 1)
    gv = np.linspace(v_min, v_max, res + 1)
    U, V = np.meshgrid(gu, gv)
    G = sample_alpha_array(alpha, U, V) - threshold

    du = (u_max - u_min) / res
    dv = (v_max - v_min) / res
    segments = []

    for j in range(res):
        for i in range(res):
            a = float(G[j, i])
            b = float(G[j, i + 1])
            c = float(G[j + 1, i + 1])
            d = float(G[j + 1, i])
            if (a >= 0) == (b >= 0) == (c >= 0) == (d >= 0):
                continue

            pts = []
            if a * b < 0:
                t = a / (a - b)
                pts.append((u_min + (i + t) * du, v_min + j * dv))
            if b * c < 0:
                t = b / (b - c)
                pts.append((u_min + (i + 1) * du, v_min + (j + t) * dv))
            if c * d < 0:
                t = c / (c - d)
                pts.append((u_min + (i + 1 - t) * du, v_min + (j + 1) * dv))
            if d * a < 0:
                t = d / (d - a)
                pts.append((u_min + i * du, v_min + (j + 1 - t) * dv))

            if len(pts) == 2:
                segments.append((pts[0], pts[1]))
            elif len(pts) == 4:
                segments.append((pts[0], pts[1]))
                segments.append((pts[2], pts[3]))
    return segments


def chain_segments(segments, tol):
    pts = []
    key_to_idx = {}

    def add(p):
        k = (int(round(p[0] / tol)), int(round(p[1] / tol)))
        idx = key_to_idx.get(k)
        if idx is not None:
            return idx
        idx = len(pts)
        pts.append(p)
        key_to_idx[k] = idx
        return idx

    adj = {}
    for p, q in segments:
        i = add(p)
        j = add(q)
        if i == j:
            continue
        adj.setdefault(i, set()).add(j)
        adj.setdefault(j, set()).add(i)

    used = set()
    lines = []

    def walk(start):
        line = [start]
        cur, prev = start, None
        while True:
            nxt = None
            for cand in adj.get(cur, ()):
                if frozenset((cur, cand)) in used:
                    continue
                if cand == prev and len(adj[cur]) > 1:
                    continue
                nxt = cand
                break
            if nxt is None:
                break
            used.add(frozenset((cur, nxt)))
            line.append(nxt)
            prev, cur = cur, nxt
            if cur == start:
                break
        return line

    for i in sorted(adj.keys()):
        if len(adj[i]) == 1:
            ln = walk(i)
            if len(ln) > 1:
                lines.append(ln)
    for i in sorted(adj.keys()):
        ln = walk(i)
        if len(ln) > 1:
            lines.append(ln)

    return pts, lines


def rdp(points, eps):
    if len(points) < 3 or eps <= 0.0:
        return points

    keep = [False] * len(points)
    keep[0] = True
    keep[-1] = True
    stack = [(0, len(points) - 1)]

    while stack:
        first, last = stack.pop()
        if last <= first + 1:
            continue
        ax, ay = points[first]
        bx, by = points[last]
        dx, dy = bx - ax, by - ay
        norm = (dx * dx + dy * dy) ** 0.5

        max_d, max_i = -1.0, -1
        for i in range(first + 1, last):
            px, py = points[i]
            if norm < 1e-12:
                d = ((px - ax) ** 2 + (py - ay) ** 2) ** 0.5
            else:
                d = abs(dy * px - dx * py + bx * ay - by * ax) / norm
            if d > max_d:
                max_d, max_i = d, i

        if max_d > eps and max_i > 0:
            keep[max_i] = True
            stack.append((first, max_i))
            stack.append((max_i, last))

    return [p for p, k in zip(points, keep) if k]


def extract_contour(alpha, u_min, u_max, v_min, v_max, threshold, res, simplify):
    segs = marching_squares(alpha, u_min, u_max, v_min, v_max, threshold, res)
    if not segs:
        return []

    cell = min((u_max - u_min), (v_max - v_min)) / max(res, 1)
    tol = max(cell * 0.25, 1e-9)
    pts, lines = chain_segments(segs, tol)

    out = []
    span = max(u_max - u_min, v_max - v_min)
    eps = simplify * span

    for ln in lines:
        closed = len(ln) > 2 and ln[0] == ln[-1]
        coords = [pts[i] for i in ln]
        if eps > 0.0:
            simp = rdp(coords, eps)
            if closed and len(simp) < 4:
                simp = coords
        else:
            simp = coords
        for k in range(len(simp) - 1):
            out.append((simp[k], simp[k + 1]))
    return out


# ===========================================================================
# Shape key helpers
# ===========================================================================

def snapshot_shapes(verts, shape_layers):
    """Copy each vertex's position in every shape key.
    Returns a list (per shape layer) of lists (per vertex) of Vectors."""
    if not shape_layers:
        return None
    return [[v[sl].copy() for v in verts] for sl in shape_layers]


def assign_blended_shapes(vert, shape_layers, raw_weights, poly_shapes):
    """Interpolate every shape key position onto a newly created vertex.

    Verts made by bm.verts.new() have all shape layers zeroed, i.e. they sit
    at the object origin in every shape key, so any key with a non-zero
    value drags them there. raw_weights sum to 1 and reproduce the basis
    position exactly, so this stays consistent with the vertex's `co`.
    """
    if not shape_layers or poly_shapes is None:
        return False
    for sl, cos in zip(shape_layers, poly_shapes):
        p = Vector((0.0, 0.0, 0.0))
        for w, c in zip(raw_weights, cos):
            p += c * w
        vert[sl] = p
    return True


# ===========================================================================
# Edge splitting (judged per face, using that face's own material)
# ===========================================================================

def find_edge_crossings(alpha, uv0, uv1, threshold, coarse_steps, refine_steps):
    ts = np.linspace(0.0, 1.0, coarse_steps + 1)
    us = uv0.x + (uv1.x - uv0.x) * ts
    vs = uv0.y + (uv1.y - uv0.y) * ts
    vals = sample_alpha_array(alpha, us, vs) - threshold

    crossings = []
    for i in range(coarse_steps):
        a, b = float(vals[i]), float(vals[i + 1])
        if a == 0.0 or a * b >= 0.0:
            continue
        lo, hi = float(ts[i]), float(ts[i + 1])
        a_lo = a
        for _ in range(refine_steps):
            mid = (lo + hi) * 0.5
            uv_m = uv0.lerp(uv1, mid)
            a_mid = sample_alpha(alpha, uv_m.x, uv_m.y) - threshold
            if a_mid == 0.0:
                lo = hi = mid
                break
            if a_mid * a_lo < 0.0:
                hi = mid
            else:
                lo = mid
                a_lo = a_mid
        crossings.append((lo + hi) * 0.5)
    return crossings


def merge_close(values, tol):
    if not values:
        return []
    values = sorted(values)
    out = [values[0]]
    for v in values[1:]:
        if v - out[-1] > tol:
            out.append(v)
    return out


def split_boundary_edges(bm, uv_layer, alpha_map, threshold,
                         coarse_steps, refine_steps, shape_layers=None):
    """Split only the edges the alpha boundary actually crosses, at the crossing.
    Each face is judged using its own material's alpha.
    If the two sides of an edge use different materials, crossings are merged."""
    edge_ts = {}

    for f in bm.faces:
        alpha = alpha_map.get(f.material_index)
        if alpha is None:
            continue
        for l in f.loops:
            e = l.edge
            uv_a = l[uv_layer].uv.copy()
            uv_b = l.link_loop_next[uv_layer].uv.copy()
            ts = find_edge_crossings(alpha, uv_a, uv_b, threshold,
                                     coarse_steps, refine_steps)
            if not ts:
                continue
            # Normalise t to the edge.verts[0] -> edge.verts[1] direction
            if l.vert is e.verts[0]:
                oriented = ts
            else:
                oriented = [1.0 - t for t in ts]
            edge_ts.setdefault(e, []).extend(oriented)

    count = 0
    for e, ts in edge_ts.items():
        if not e.is_valid:
            continue
        ts = merge_close(ts, 1e-4)
        ts = [t for t in ts if 1e-5 < t < 1.0 - 1e-5]
        if not ts:
            continue
        # Blender interpolates custom data on edge_split already, but set the
        # shape key positions explicitly so they are exactly on the edge in
        # every key, independent of Blender version.
        shapes_ends = None
        if shape_layers:
            va, vb = e.verts[0], e.verts[1]
            shapes_ends = [(va[sl].copy(), vb[sl].copy()) for sl in shape_layers]
        cur_edge, cur_vert, prev_t = e, e.verts[0], 0.0
        for t in ts:
            denom = 1.0 - prev_t
            if denom <= 1e-9:
                break
            local_t = min(max((t - prev_t) / denom, 1e-6), 1.0 - 1e-6)
            try:
                new_edge, new_vert = bmesh.utils.edge_split(cur_edge, cur_vert, local_t)
            except Exception:
                break
            count += 1
            if shapes_ends is not None:
                for sl, (sa, sb) in zip(shape_layers, shapes_ends):
                    new_vert[sl] = sa.lerp(sb, t)
            cur_edge, cur_vert, prev_t = new_edge, new_vert, t
    return count


# ===========================================================================
# Face reconstruction
# ===========================================================================

def barycentric_2d(p, a, b, c):
    """Barycentric coordinates of p inside triangle (a, b, c) in 2D.
    Returns (wa, wb, wc), or None if the triangle is degenerate."""
    v0x, v0y = b.x - a.x, b.y - a.y
    v1x, v1y = c.x - a.x, c.y - a.y
    v2x, v2y = p[0] - a.x, p[1] - a.y

    d00 = v0x * v0x + v0y * v0y
    d01 = v0x * v1x + v0y * v1y
    d11 = v1x * v1x + v1y * v1y
    d20 = v2x * v0x + v2y * v0y
    d21 = v2x * v1x + v2y * v1y

    denom = d00 * d11 - d01 * d01
    if abs(denom) < 1e-18:
        return None

    wb = (d11 * d20 - d01 * d21) / denom
    wc = (d00 * d21 - d01 * d20) / denom
    return (1.0 - wb - wc, wb, wc)


def build_uv_interpolator(poly_uv, poly_co):
    """Build f(uv) -> (co, corner_weights, raw_weights).

    corner_weights is a list aligned with poly_uv / poly_co, giving how much
    each original corner contributes to the sampled point. The same weights
    drive both the 3D position and the vertex-group interpolation, so the two
    can never disagree.

    raw_weights are the same shares before negative values are clamped. They
    always sum to 1 and reproduce `co` exactly, so they are the right weights
    for interpolating other positions (shape keys). corner_weights are only
    for vertex-group weights, where negative shares make no sense.
    """
    n = len(poly_uv)

    c_uv = Vector((0.0, 0.0))
    for uv in poly_uv:
        c_uv = c_uv + uv
    c_uv /= n

    c_co = Vector((0.0, 0.0, 0.0))
    for co in poly_co:
        c_co = c_co + co
    c_co /= n

    fan = [(i, (i + 1) % n) for i in range(n)]

    def corner_weights(i, j, bary):
        # The fan centroid is the mean of all corners, so its share is spread
        # evenly back across every corner.
        wc0, wi, wj = bary
        out = [wc0 / n] * n
        out[i] += wi
        out[j] += wj
        return out

    def position(i, j, bary):
        wc0, wi, wj = bary
        return c_co * wc0 + poly_co[i] * wi + poly_co[j] * wj

    def nearest_corner(p):
        best_i, best_d = 0, None
        for i, uv in enumerate(poly_uv):
            d = (uv.x - p[0]) ** 2 + (uv.y - p[1]) ** 2
            if best_d is None or d < best_d:
                best_d, best_i = d, i
        return best_i

    def evaluate(uv):
        p = (uv[0], uv[1])
        best = None  # (score, i, j, bary) for the least-bad triangle

        for (i, j) in fan:
            bary = barycentric_2d(p, c_uv, poly_uv[i], poly_uv[j])
            if bary is None:
                continue
            if min(bary) >= -1e-9:
                ws = corner_weights(i, j, bary)
                return position(i, j, bary), ws, list(ws)
            score = min(bary)
            if best is None or score > best[0]:
                best = (score, i, j, bary)

        if best is None:
            # Fully degenerate face: fall back to the nearest original corner.
            k = nearest_corner(p)
            ws = [0.0] * n
            ws[k] = 1.0
            return poly_co[k].copy(), ws, list(ws)

        _, i, j, bary = best
        co = position(i, j, bary)
        ws = corner_weights(i, j, bary)
        raw = list(ws)

        # Extrapolated point: negative shares are meaningless for weights.
        ws = [w if w > 0.0 else 0.0 for w in ws]
        total = sum(ws)
        if total > 1e-12:
            ws = [w / total for w in ws]
        else:
            k = nearest_corner(p)
            ws = [0.0] * n
            ws[k] = 1.0
        return co, ws, raw

    return evaluate


def snapshot_weights(verts, deform_layer):
    """Copy each vertex's vertex-group weights into a plain dict."""
    if deform_layer is None:
        return None
    out = []
    for v in verts:
        try:
            out.append({g: w for g, w in v[deform_layer].items()})
        except Exception:
            out.append({})
    return out


def assign_blended_weights(vert, deform_layer, corner_weights, poly_weights):
    """Interpolate vertex-group weights onto a newly created vertex.

    Without this, verts made by bm.verts.new() carry no deform data at all,
    so an armature leaves them behind at the object origin.
    """
    if deform_layer is None or poly_weights is None:
        return False

    acc = {}
    for share, weights in zip(corner_weights, poly_weights):
        if share <= 1e-9 or not weights:
            continue
        for group, w in weights.items():
            acc[group] = acc.get(group, 0.0) + w * share

    try:
        dvert = vert[deform_layer]
        dvert.clear()
        for group, w in acc.items():
            if w > 1e-6:
                dvert[group] = w if w < 1.0 else 1.0
    except Exception:
        return False
    return True


def copy_weights_from(vert, deform_layer, weights):
    """Fallback: copy one original vertex's weights verbatim."""
    if deform_layer is None or not weights:
        return False
    try:
        dvert = vert[deform_layer]
        dvert.clear()
        for group, w in weights.items():
            dvert[group] = w
    except Exception:
        return False
    return True


def retriangulate_face(bm, uv_layer, deform_layer, shape_layers, alpha, face,
                       threshold, contour_res, simplify, epsilon):
    loops = list(face.loops)
    n = len(loops)
    if n < 3:
        return [], set(), False, 0, 0

    poly_uv = [l[uv_layer].uv.copy() for l in loops]
    poly_co = [l.vert.co.copy() for l in loops]
    poly_verts = [l.vert for l in loops]
    poly_weights = snapshot_weights(poly_verts, deform_layer)
    poly_shapes = snapshot_shapes(poly_verts, shape_layers)
    orig_normal = face.normal.copy()
    orig_mat = face.material_index
    orig_smooth = face.smooth

    us = [uv.x for uv in poly_uv]
    vs = [uv.y for uv in poly_uv]
    u_min, u_max = min(us), max(us)
    v_min, v_max = min(vs), max(vs)
    if (u_max - u_min) < 1e-9 or (v_max - v_min) < 1e-9:
        return [], set(), False, 0, 0

    pad_u = (u_max - u_min) * 0.02 + 1e-6
    pad_v = (v_max - v_min) * 0.02 + 1e-6

    segments = extract_contour(
        alpha, u_min - pad_u, u_max + pad_u, v_min - pad_v, v_max + pad_v,
        threshold, contour_res, simplify,
    )
    if not segments:
        return [], set(), False, 0, 0

    cdt_verts = [Vector((uv.x, uv.y)) for uv in poly_uv]
    cdt_edges = [(i, (i + 1) % n) for i in range(n)]
    cdt_faces = [list(range(n))]

    for (p, q) in segments:
        i0 = len(cdt_verts)
        cdt_verts.append(Vector(p))
        cdt_verts.append(Vector(q))
        cdt_edges.append((i0, i0 + 1))

    try:
        out_verts, out_edges, out_faces, orig_v, orig_e, orig_f = delaunay_2d_cdt(
            cdt_verts, cdt_edges, cdt_faces, 1, epsilon
        )
    except Exception:
        return [], set(), False, 0, 0

    if not out_faces:
        return [], set(), False, 0, 0

    interpolate = build_uv_interpolator(poly_uv, poly_co)
    bverts = []
    n_weighted = 0
    n_shaped = 0

    for idx, ov in enumerate(out_verts):
        reused = None
        for src in orig_v[idx]:
            if src < n:
                reused = poly_verts[src]
                break

        if reused is not None:
            # An original corner: it already carries its own weights.
            bverts.append(reused)
            continue

        co, corner_ws, raw_ws = interpolate(ov)
        bv = bm.verts.new(co)

        if assign_blended_shapes(bv, shape_layers, raw_ws, poly_shapes):
            n_shaped += 1

        if deform_layer is not None:
            ok = assign_blended_weights(bv, deform_layer, corner_ws, poly_weights)
            if not ok and poly_weights:
                # Fallback: copy the nearest original corner's weights verbatim.
                best_i, best_d = 0, None
                for i, uv in enumerate(poly_uv):
                    d = (uv.x - ov[0]) ** 2 + (uv.y - ov[1]) ** 2
                    if best_d is None or d < best_d:
                        best_d, best_i = d, i
                ok = copy_weights_from(bv, deform_layer, poly_weights[best_i])
            if ok:
                n_weighted += 1

        bverts.append(bv)

    vert_index = {}
    for i, bv in enumerate(bverts):
        vert_index.setdefault(bv, i)

    keep_keys = set()
    for i, (a, b) in enumerate(out_edges):
        if orig_e[i]:
            va, vb = bverts[a], bverts[b]
            if va is not vb:
                keep_keys.add(frozenset((va, vb)))

    bmesh.ops.delete(bm, geom=[face], context='FACES_ONLY')

    new_faces = []
    for tri in out_faces:
        vs_tri = [bverts[i] for i in tri]
        if len(set(vs_tri)) < 3:
            continue
        try:
            nf = bm.faces.new(vs_tri)
        except ValueError:
            continue
        nf.material_index = orig_mat
        nf.smooth = orig_smooth
        for l in nf.loops:
            i = vert_index.get(l.vert)
            if i is not None:
                ov = out_verts[i]
                l[uv_layer].uv = Vector((ov.x, ov.y))
        nf.normal_update()
        if nf.normal.dot(orig_normal) < 0.0:
            nf.normal_flip()
        new_faces.append(nf)

    return new_faces, keep_keys, True, n_weighted, n_shaped


# ===========================================================================
# Operator
# ===========================================================================

class MESH_OT_alpha_cutout_knife(Operator):
    bl_idname = "mesh.alpha_cutout_knife"
    bl_label = "Alpha Cutout Knife"
    bl_description = "Cut the mesh along the texture's alpha boundary and delete the transparent side"
    bl_options = {'REGISTER', 'UNDO'}

    threshold: FloatProperty(
        name="Alpha Threshold",
        description="Regions with alpha below this value are cut out and deleted",
        default=0.5, min=0.0, max=1.0,
    )
    strict_alpha: BoolProperty(
        name="Strict Alpha Detection",
        description=(
            "Only use textures reachable from an Alpha input. "
            "When off, falls back to the first image texture found, "
            "which easily misfires on multi-material meshes"
        ),
        default=True,
    )
    contour_res: IntProperty(
        name="Contour Resolution",
        description="Grid resolution used to trace the alpha contour",
        default=64, min=4, max=256,
    )
    simplify: FloatProperty(
        name="Simplify Contour",
        description="How aggressively to decimate the cut line. 0 disables decimation",
        default=0.004, min=0.0, max=0.1, precision=4,
    )
    edge_coarse_steps: IntProperty(
        name="Edge Scan Steps",
        description="Number of coarse samples taken along each edge",
        default=16, min=2, max=128,
    )
    refine_steps: IntProperty(
        name="Refine Steps",
        description="Binary search iterations used to pin down each crossing point",
        default=16, min=4, max=32,
    )
    preserve_weights: BoolProperty(
        name="Preserve Vertex Weights",
        description=(
            "Interpolate vertex group weights onto newly created vertices. "
            "Without this, new verts have zero weight and an armature will "
            "leave them stranded at the object origin"
        ),
        default=True,
    )
    preserve_shape_keys: BoolProperty(
        name="Preserve Shape Keys",
        description=(
            "Interpolate every shape key position onto newly created vertices. "
            "Without this, new verts sit at the object origin in every shape "
            "key and get dragged there whenever a key is active"
        ),
        default=True,
    )
    dissolve_helpers: BoolProperty(
        name="Dissolve Helper Edges",
        description="Dissolve triangulation helper edges, leaving only the cut line and original edges",
        default=True,
    )
    epsilon: FloatProperty(
        name="Merge Epsilon",
        description="Distance below which triangulation merges nearby points",
        default=0.00001, min=0.00000001, max=0.01, precision=8,
    )
    cleanup: BoolProperty(
        name="Cleanup",
        description="Remove loose vertices and degenerate edges afterwards",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        mesh = obj.data

        if not mesh.uv_layers:
            self.report({'ERROR'}, "No UV map found")
            return {'CANCELLED'}

        alpha_map, info = build_material_alpha_map(obj, self.strict_alpha)
        if not alpha_map:
            details = " / ".join(f"[{i}] {n}: {r}" for i, n, _, r in info)
            self.report({'ERROR'}, f"No usable alpha texture - {details}")
            return {'CANCELLED'}

        threshold = self.threshold
        was_edit = obj.mode == 'EDIT'
        has_keys = mesh.shape_keys is not None and len(mesh.shape_keys.key_blocks) > 0

        # In Edit Mode, BMesh vertex positions are those of the *active* shape
        # key. Cutting while a non-Basis key is active would build the new
        # geometry from that key's pose, so refuse instead of guessing.
        if was_edit and has_keys and obj.active_shape_key_index != 0:
            self.report(
                {'ERROR'},
                "A shape key other than Basis is active. Select Basis in the "
                "Shape Keys list (or run this in Object Mode) and try again",
            )
            return {'CANCELLED'}

        if was_edit:
            bm = bmesh.from_edit_mesh(mesh)
        else:
            bm = bmesh.new()
            if has_keys:
                # Load Basis positions explicitly so `co` is always the Basis.
                bm.from_mesh(mesh, use_shape_key=True, shape_key_index=0)
            else:
                bm.from_mesh(mesh)

        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            self.report({'ERROR'}, "No active UV layer found")
            if not was_edit:
                bm.free()
            return {'CANCELLED'}

        # Vertex-group (deform) layer. Absent on meshes with no weights, in
        # which case weight transfer is simply skipped.
        deform_layer = None
        if self.preserve_weights:
            try:
                deform_layer = bm.verts.layers.deform.active
                if deform_layer is None and len(obj.vertex_groups) > 0:
                    deform_layer = bm.verts.layers.deform.verify()
            except Exception:
                deform_layer = None

        # Shape key layers (one per key, Basis included).
        shape_layers = []
        if self.preserve_shape_keys and has_keys:
            try:
                shape_layers = list(bm.verts.layers.shape.values())
            except Exception:
                shape_layers = []

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # --- Split only edges crossed by the boundary ---
        n_splits = split_boundary_edges(
            bm, uv_layer, alpha_map, threshold,
            self.edge_coarse_steps, self.refine_steps, shape_layers,
        )
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # --- Rebuild only the faces the contour passes through ---
        rebuilt_faces = []
        keep_keys = set()
        untouched = []
        n_rebuilt = 0
        n_skipped = 0
        n_weighted = 0
        n_shaped = 0

        for f in list(bm.faces):
            if not f.is_valid:
                continue
            alpha = alpha_map.get(f.material_index)
            if alpha is None:
                # Faces without an alpha texture are strictly off-limits
                n_skipped += 1
                continue
            new_faces, keys, ok, weighted, shaped = retriangulate_face(
                bm, uv_layer, deform_layer, shape_layers, alpha, f, threshold,
                self.contour_res, self.simplify, self.epsilon,
            )
            if ok:
                n_rebuilt += 1
                n_weighted += weighted
                n_shaped += shaped
                rebuilt_faces.extend(new_faces)
                keep_keys |= keys
            else:
                untouched.append(f)

        # --- Delete faces on the transparent side ---
        def face_center_alpha(f):
            alpha = alpha_map.get(f.material_index)
            if alpha is None:
                return None
            c = Vector((0.0, 0.0))
            for l in f.loops:
                c = c + l[uv_layer].uv
            c /= len(f.loops)
            return sample_alpha(alpha, c.x, c.y)

        to_delete = []
        for f in untouched + rebuilt_faces:
            if not f.is_valid:
                continue
            a = face_center_alpha(f)
            if a is not None and a < threshold:
                to_delete.append(f)

        if to_delete:
            bmesh.ops.delete(bm, geom=list(set(to_delete)), context='FACES')

        # --- Dissolve helper edges ---
        n_dissolved = 0
        if self.dissolve_helpers:
            dissolve = set()
            for f in rebuilt_faces:
                if not f.is_valid:
                    continue
                for e in f.edges:
                    if not e.is_valid or len(e.link_faces) != 2:
                        continue
                    # Keep edges that sit on a material boundary
                    fa, fb = e.link_faces
                    if fa.material_index != fb.material_index:
                        continue
                    key = frozenset((e.verts[0], e.verts[1]))
                    if key not in keep_keys:
                        dissolve.add(e)
            dissolve = [e for e in dissolve if e.is_valid]
            if dissolve:
                n_dissolved = len(dissolve)
                try:
                    bmesh.ops.dissolve_edges(
                        bm, edges=dissolve, use_verts=False, use_face_split=False
                    )
                except Exception:
                    n_dissolved = 0

        # --- Cleanup ---
        if self.cleanup:
            loose = [v for v in bm.verts if v.is_valid and len(v.link_faces) == 0]
            if loose:
                bmesh.ops.delete(bm, geom=loose, context='VERTS')
            edges = [e for e in bm.edges if e.is_valid]
            if edges:
                bmesh.ops.dissolve_degenerate(bm, dist=self.epsilon, edges=edges)

        if was_edit:
            bmesh.update_edit_mesh(mesh)
        else:
            bm.to_mesh(mesh)
            mesh.update()
            bm.free()

        self.report(
            {'INFO'},
            f"Edges split: {n_splits} | Faces rebuilt: {n_rebuilt} | "
            f"Faces deleted: {len(set(to_delete))} | Helpers dissolved: {n_dissolved} | "
            f"Faces skipped: {n_skipped} | Verts weighted: {n_weighted}"
            + ("" if deform_layer is not None else " (no vertex groups)")
            + (f" | Verts shaped: {n_shaped} ({len(shape_layers)} keys)"
               if shape_layers else ""),
        )
        return {'FINISHED'}


# ===========================================================================
# UI
# ===========================================================================

class VIEW3D_PT_alpha_cutout_knife(Panel):
    bl_label = "Alpha Cutout Knife"
    bl_idname = "VIEW3D_PT_alpha_cutout_knife"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Alpha Cut"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        col = layout.column()
        col.label(text="Cut and delete mesh along")
        col.label(text="the texture alpha boundary")
        col.separator()

        if obj is None or obj.type != 'MESH':
            col.label(text="Select a mesh object", icon='ERROR')
            return

        # Only resolve which image each slot uses here. Reading the pixels
        # (build_material_alpha_map) copies the whole image on every redraw,
        # which stalls the UI with large textures; the operator checks the
        # alpha itself when it runs.
        box = col.box()
        box.label(text="Material slots:", icon='MATERIAL')
        found = False
        if len(obj.material_slots) == 0:
            box.label(text="No material slots", icon='DOT')
        for idx, slot in enumerate(obj.material_slots):
            mat = slot.material
            img, reason = find_alpha_image(mat, True)
            found = found or img is not None
            sub = box.column(align=True)
            sub.label(
                text=f"{idx}: {mat.name if mat else '(empty slot)'}",
                icon='IMAGE_DATA' if img is not None else 'DOT',
            )
            if img is not None:
                sub.label(text=f"    Image: {img.name}")
            sub.label(text=f"    {reason}")

        if not found:
            col.label(text="No image reachable from Alpha", icon='ERROR')

        col.separator()
        if len(obj.vertex_groups) > 0:
            col.label(
                text=f"Vertex groups: {len(obj.vertex_groups)} (weights preserved)",
                icon='GROUP_VERTEX',
            )
        keys = obj.data.shape_keys
        if keys is not None and len(keys.key_blocks) > 0:
            col.label(
                text=f"Shape keys: {len(keys.key_blocks)} (positions preserved)",
                icon='SHAPEKEY_DATA',
            )
            if obj.mode == 'EDIT' and obj.active_shape_key_index != 0:
                col.label(text="Select Basis before cutting", icon='ERROR')
        col.operator("mesh.alpha_cutout_knife", icon='MOD_BOOLEAN')
        if not found:
            # A cancelled run has no redo panel, so offer the loose mode here.
            op = col.operator("mesh.alpha_cutout_knife",
                              text="Cut Using First Image Found", icon='MOD_BOOLEAN')
            op.strict_alpha = False


classes = (
    MESH_OT_alpha_cutout_knife,
    VIEW3D_PT_alpha_cutout_knife,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

"""Outliner Visibility Checker.

Adds a button to the Outliner header that counts objects whose own
viewport visibility (eye) and render visibility (camera) disagree, and a
popover that lists them with one-click fixes.

Only the object's own toggles are compared: visibility inherited from
collections is ignored.

Blender does not allow writing to ID data while drawing, so everything the
header and popover show is computed on the fly from the view layer and
nothing is stored on the scene.
"""

import bpy

# Rows shown per list before the rest is summarised as "+N more".
MAX_ROWS = 20

# obj.type -> Outliner icon. "OUTLINER_OB_" + obj.type is not a valid icon
# for every type (e.g. GREASEPENCIL, LIGHT_PROBE), so map them explicitly.
_OBJECT_TYPE_ICON = {
    'MESH': 'OUTLINER_OB_MESH',
    'CURVE': 'OUTLINER_OB_CURVE',
    'SURFACE': 'OUTLINER_OB_SURFACE',
    'META': 'OUTLINER_OB_META',
    'FONT': 'OUTLINER_OB_FONT',
    'CURVES': 'OUTLINER_OB_CURVES',
    'POINTCLOUD': 'OUTLINER_OB_POINTCLOUD',
    'VOLUME': 'OUTLINER_OB_VOLUME',
    'GPENCIL': 'OUTLINER_OB_GREASEPENCIL',
    'GREASEPENCIL': 'OUTLINER_OB_GREASEPENCIL',
    'ARMATURE': 'OUTLINER_OB_ARMATURE',
    'LATTICE': 'OUTLINER_OB_LATTICE',
    'EMPTY': 'OUTLINER_OB_EMPTY',
    'LIGHT': 'OUTLINER_OB_LIGHT',
    'LIGHT_PROBE': 'OUTLINER_OB_LIGHTPROBE',
    'CAMERA': 'OUTLINER_OB_CAMERA',
    'SPEAKER': 'OUTLINER_OB_SPEAKER',
}


def get_object_icon(obj):
    return _OBJECT_TYPE_ICON.get(obj.type, 'OBJECT_DATA')


def find_mismatches(view_layer):
    """Return (viewport_hidden, render_hidden) lists of objects.

    viewport_hidden: eye off, camera on (renders but you can't see it).
    render_hidden:   eye on, camera off (visible but won't render).
    """
    viewport_hidden = []
    render_hidden = []
    for obj in view_layer.objects:
        eye_off = obj.hide_get(view_layer=view_layer)
        if eye_off and not obj.hide_render:
            viewport_hidden.append(obj)
        elif not eye_off and obj.hide_render:
            render_hidden.append(obj)
    return viewport_hidden, render_hidden


def _get_object(context, name):
    return context.view_layer.objects.get(name) if context.view_layer else None


# ============================================================
# Operators
# ============================================================

class OUTLINER_VC_OT_select(bpy.types.Operator):
    bl_idname = "outliner_vc.select"
    bl_label = "Select Object"
    bl_description = "Select this object and make it active"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty()

    def execute(self, context):
        obj = _get_object(context, self.name)
        if obj is None:
            self.report({'WARNING'}, "Object not found: %s" % self.name)
            return {'CANCELLED'}
        if not obj.visible_get(view_layer=context.view_layer):
            self.report({'WARNING'}, "%s is hidden in the viewport and can't be selected" % obj.name)
            return {'CANCELLED'}
        for o in context.view_layer.objects:
            if o.select_get():
                o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {'FINISHED'}


class OUTLINER_VC_OT_match(bpy.types.Operator):
    bl_idname = "outliner_vc.match"
    bl_label = "Match Visibility"
    bl_description = "Make the viewport and render visibility of this object agree"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty()
    mode: bpy.props.EnumProperty(
        items=(
            ('SHOW_VIEWPORT', "Show in Viewport", "Turn the eye on"),
            ('HIDE_RENDER', "Hide in Render", "Turn the camera off"),
            ('SHOW_RENDER', "Show in Render", "Turn the camera on"),
            ('HIDE_VIEWPORT', "Hide in Viewport", "Turn the eye off"),
        ),
    )

    @classmethod
    def description(cls, context, properties):
        return {
            'SHOW_VIEWPORT': "Turn the eye on (show in the viewport)",
            'HIDE_VIEWPORT': "Turn the eye off (hide in the viewport)",
            'HIDE_RENDER': "Turn the camera off (exclude from renders)",
            'SHOW_RENDER': "Turn the camera on (include in renders)",
        }[properties.mode]

    def execute(self, context):
        obj = _get_object(context, self.name)
        if obj is None:
            self.report({'WARNING'}, "Object not found: %s" % self.name)
            return {'CANCELLED'}
        vl = context.view_layer
        if self.mode == 'SHOW_VIEWPORT':
            obj.hide_set(False, view_layer=vl)
        elif self.mode == 'HIDE_VIEWPORT':
            obj.hide_set(True, view_layer=vl)
        elif self.mode == 'HIDE_RENDER':
            obj.hide_render = True
        else:
            obj.hide_render = False
        return {'FINISHED'}


# ============================================================
# Popover
# ============================================================

def _draw_list(layout, title, icon, objects, fixes):
    box = layout.box()
    box.label(text="%s (%d)" % (title, len(objects)), icon=icon)
    if not objects:
        box.label(text="None", icon='CHECKMARK')
        return
    col = box.column(align=True)
    for obj in objects[:MAX_ROWS]:
        row = col.row(align=True)
        name = row.row()
        name.alignment = 'LEFT'
        op = name.operator("outliner_vc.select", text=obj.name,
                           icon=get_object_icon(obj), emboss=False)
        op.name = obj.name
        buttons = row.row(align=True)
        buttons.alignment = 'RIGHT'
        for mode, fix_icon in fixes:
            op = buttons.operator("outliner_vc.match", text="", icon=fix_icon)
            op.name = obj.name
            op.mode = mode
    rest = len(objects) - MAX_ROWS
    if rest > 0:
        col.label(text="+%d more" % rest)


class OUTLINER_PT_visibility_diff(bpy.types.Panel):
    bl_idname = "OUTLINER_PT_visibility_diff"
    bl_label = "Visibility Mismatch"
    bl_space_type = 'OUTLINER'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 14

    def draw(self, context):
        layout = self.layout
        if context.view_layer is None:
            return
        viewport_hidden, render_hidden = find_mismatches(context.view_layer)
        _draw_list(
            layout, "Hidden in Viewport, Rendered", 'HIDE_ON', viewport_hidden,
            (('SHOW_VIEWPORT', 'HIDE_OFF'), ('HIDE_RENDER', 'RESTRICT_RENDER_ON')),
        )
        _draw_list(
            layout, "Visible in Viewport, Not Rendered", 'RESTRICT_RENDER_ON', render_hidden,
            (('SHOW_RENDER', 'RESTRICT_RENDER_OFF'), ('HIDE_VIEWPORT', 'HIDE_ON')),
        )


# ============================================================
# Outliner header
# ============================================================

def outliner_header_draw(self, context):
    if context.view_layer is None:
        return
    viewport_hidden, render_hidden = find_mismatches(context.view_layer)
    total = len(viewport_hidden) + len(render_hidden)

    # prepend() puts this before the built-in header items, so it stays
    # visible in a narrow Outliner instead of falling into the overflow.
    row = self.layout.row(align=True)
    row.alert = total > 0
    row.popover(
        panel=OUTLINER_PT_visibility_diff.bl_idname,
        text=str(total),
        icon='INFO' if total else 'CHECKMARK',
    )
    self.layout.separator()


# ============================================================
# Keep the header count current
# ============================================================

# Header regions are not redrawn when an object's visibility changes, so the
# count would go stale. Redraw Outliner headers after every depsgraph update.
def _tag_outliner_headers():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == 'OUTLINER':
                for region in area.regions:
                    if region.type == 'HEADER':
                        region.tag_redraw()


@bpy.app.handlers.persistent
def _on_depsgraph_update(scene, depsgraph):
    _tag_outliner_headers()


# ============================================================
# Register
# ============================================================

classes = (
    OUTLINER_VC_OT_select,
    OUTLINER_VC_OT_match,
    OUTLINER_PT_visibility_diff,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.OUTLINER_HT_header.prepend(outliner_header_draw)
    bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)


def unregister():
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    bpy.types.OUTLINER_HT_header.remove(outliner_header_draw)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

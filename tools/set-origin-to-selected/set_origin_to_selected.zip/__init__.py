# SPDX-License-Identifier: GPL-2.0-or-later
"""
Set Origin to Selected (Edit Mode)

Adds a "Set Origin" button to the 3D Viewport header that is only visible
while in Mesh Edit Mode. Clicking it moves the active object's origin to the
median point of the currently selected vertices / edges / faces.

Works with single or multiple selected elements (vertices, edges and faces),
similar to the "Quick Origin to Selected" tool from the Interactive Tools addon.

Compatible with Blender 4.5 LTS and Blender 5.x.
"""

import bpy
import bmesh
from mathutils import Vector


class MESH_OT_origin_to_selected(bpy.types.Operator):
    """Set the object's origin to the median of the selected vertices/edges/faces"""
    bl_idname = "mesh.origin_to_selected"
    bl_label = "Set Origin to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.edit_object
        return (
            context.mode == 'EDIT_MESH'
            and obj is not None
            and obj.type == 'MESH'
        )

    def execute(self, context):
        obj = context.edit_object
        mesh = obj.data

        # Gather the selected vertices of the ACTIVE object only.
        bm = bmesh.from_edit_mesh(mesh)
        selected_verts = [v for v in bm.verts if v.select]

        if not selected_verts:
            self.report({'WARNING'}, "No vertices/edges/faces selected")
            return {'CANCELLED'}

        # Median of the selection in the object's local space.
        median_local = Vector((0.0, 0.0, 0.0))
        for v in selected_verts:
            median_local += v.co
        median_local /= len(selected_verts)

        # Convert to world space (this is where the new origin should land).
        target_world = obj.matrix_world @ median_local

        scene = context.scene
        cursor = scene.cursor

        # --- Save state we are about to change ---------------------------------
        saved_cursor = cursor.location.copy()
        saved_active = context.view_layer.objects.active
        saved_selection = list(context.selected_objects)

        # Place the 3D cursor at the target point; origin_set(ORIGIN_CURSOR)
        # snaps the origin there while keeping the geometry in place.
        cursor.location = target_world

        # origin_set runs in Object Mode and affects every selected object,
        # so we temporarily isolate the active object to avoid moving the
        # origins of other objects that share multi-object edit mode.
        bpy.ops.object.mode_set(mode='OBJECT')
        try:
            for o in saved_selection:
                if o is not obj:
                    o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj

            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        finally:
            # --- Restore everything --------------------------------------------
            for o in saved_selection:
                o.select_set(True)
            context.view_layer.objects.active = saved_active
            bpy.ops.object.mode_set(mode='EDIT')
            cursor.location = saved_cursor

        self.report({'INFO'}, "Origin set to selection (%d vertices)" % len(selected_verts))
        return {'FINISHED'}


def draw_header_button(self, context):
    # Only show the button while editing a mesh.
    if context.mode == 'EDIT_MESH':
        layout = self.layout
        layout.operator(
            MESH_OT_origin_to_selected.bl_idname,
            text="Set Origin",
            icon='OBJECT_ORIGIN',
        )


classes = (
    MESH_OT_origin_to_selected,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_HT_header.append(draw_header_button)


def unregister():
    bpy.types.VIEW3D_HT_header.remove(draw_header_button)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

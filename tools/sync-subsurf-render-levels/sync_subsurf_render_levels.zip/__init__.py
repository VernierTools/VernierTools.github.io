"""Sync Subsurf Render Levels.

Set the render subdivision level (render_levels) equal to the viewport
subdivision level (levels) for every Subdivision Surface modifier on all
objects (or only selected objects).

Adds a "Subsurf" tab to the 3D Viewport sidebar (N panel).

Extension format. Works on Blender 4.2 and later (verified on 4.5 / 5.x).
Version metadata lives in blender_manifest.toml, so no bl_info here.
"""

import bpy


class OBJECT_OT_sync_subsurf_render_levels(bpy.types.Operator):
    """Set render levels equal to viewport levels for Subdivision Surface modifiers"""

    bl_idname = "object.sync_subsurf_render_levels"
    bl_label = "Sync Render Levels"
    bl_description = (
        "Set the render subdivision level equal to the viewport level "
        "for every Subdivision Surface modifier"
    )
    bl_options = {'REGISTER', 'UNDO'}

    selected_only: bpy.props.BoolProperty(
        name="Selected Objects Only",
        description="Affect only selected objects instead of all objects",
        default=False,
    )  # type: ignore[valid-type]

    def execute(self, context):
        if self.selected_only:
            objects = context.selected_objects
        else:
            objects = bpy.data.objects

        changed = 0
        for obj in objects:
            for mod in obj.modifiers:
                if mod.type == 'SUBSURF':
                    if mod.render_levels != mod.levels:
                        mod.render_levels = mod.levels
                        changed += 1

        self.report(
            {'INFO'},
            "Updated {0} Subdivision Surface modifier(s)".format(changed),
        )
        return {'FINISHED'}


class VIEW3D_PT_sync_subsurf_render_levels(bpy.types.Panel):
    """Sidebar (N panel) tab: Subsurf"""

    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Subsurf"
    bl_label = "Sync Render Levels"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "sync_subsurf_selected_only", text="Selected Only")

        op = layout.operator(
            OBJECT_OT_sync_subsurf_render_levels.bl_idname,
            text="Sync Render Levels",
            icon='FILE_REFRESH',
        )
        op.selected_only = scene.sync_subsurf_selected_only


classes = (
    OBJECT_OT_sync_subsurf_render_levels,
    VIEW3D_PT_sync_subsurf_render_levels,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sync_subsurf_selected_only = bpy.props.BoolProperty(
        name="Selected Objects Only",
        description="Affect only selected objects instead of all objects",
        default=False,
    )


def unregister():
    del bpy.types.Scene.sync_subsurf_selected_only
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

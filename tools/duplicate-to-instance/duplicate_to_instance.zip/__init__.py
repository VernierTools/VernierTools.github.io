"""Duplicate to Instance.

Find mesh objects whose mesh data is identical and make them share one mesh
(linked duplicates).
This reduces memory usage and file size without changing how the scene looks.

Works as a Blender Extension on Blender 4.2+ (tested target: 4.5 LTS / 5.2).
"""

import hashlib

import bpy
import numpy as np
from bpy.props import EnumProperty
from bpy.types import Operator, Panel


def _rounded_bytes(collection, attr, count, width, ndigits=6):
    buf = np.empty(count * width, dtype=np.float64)
    collection.foreach_get(attr, buf)
    return np.round(buf, ndigits).tobytes()


def mesh_hash(obj):
    """Return a hash identifying a mesh object's data, or None to skip it.

    Two meshes count as duplicates only when they match in vertex positions
    (rounded to 6 decimals), face topology, UV maps, material slots and
    vertex-group weights, so swapping one for the other cannot change how the
    object looks or deforms. Meshes with shape keys are skipped.
    """
    mesh = obj.data
    if mesh.shape_keys is not None:
        return None

    h = hashlib.md5()
    nv, np_, nl = len(mesh.vertices), len(mesh.polygons), len(mesh.loops)
    h.update(str((nv, len(mesh.edges), np_, nl)).encode())
    h.update(_rounded_bytes(mesh.vertices, "co", nv, 3))

    loop_verts = np.empty(nl, dtype=np.int32)
    mesh.loops.foreach_get("vertex_index", loop_verts)
    loop_totals = np.empty(np_, dtype=np.int32)
    mesh.polygons.foreach_get("loop_total", loop_totals)
    h.update(loop_verts.tobytes())
    h.update(loop_totals.tobytes())

    for uv in mesh.uv_layers:
        h.update(uv.name.encode())
        h.update(_rounded_bytes(uv.uv, "vector", nl, 2))

    h.update(str(tuple(m.name if m else None for m in mesh.materials)).encode())

    names = [g.name for g in obj.vertex_groups]
    weights = tuple(
        tuple(sorted((names[g.group], round(g.weight, 6)) for g in v.groups
                     if g.group < len(names)))
        for v in mesh.vertices
    )
    h.update(str(weights).encode())
    return h.hexdigest()


def replace_with_instances(objects, context):
    """Make duplicate mesh objects in *objects* share one mesh.

    The first object of each unique mesh is the reference; every later
    duplicate is switched to the reference's mesh data. Only the data is
    swapped, so each object keeps its name, transform, modifiers, parent,
    collections, animation and custom properties. Returns the number of
    objects changed.
    """
    seen = {}
    replaced = 0
    for obj in objects:
        if obj.type != 'MESH':
            continue
        key = mesh_hash(obj)
        if key is None:
            continue
        ref = seen.setdefault(key, obj)
        if ref is obj or obj.data == ref.data:
            continue
        old = obj.data
        obj.data = ref.data
        if old.users == 0:
            bpy.data.meshes.remove(old)
        replaced += 1
    return replaced


class OBJECT_OT_duplicate_to_instance(Operator):
    bl_idname = "object.duplicate_to_instance"
    bl_label = "Duplicate to Instance"
    bl_description = ("Find mesh objects with identical mesh data and make "
                      "them share one mesh (linked duplicates)")
    bl_options = {'REGISTER', 'UNDO'}

    scope: EnumProperty(
        name="Scope",
        description="Which objects to process",
        items=(
            ('SELECTED', "Selected", "Only process selected objects"),
            ('ALL', "All Objects", "Process every object in the .blend file"),
        ),
        default='SELECTED',
    )

    def execute(self, context):
        if self.scope == 'SELECTED':
            objects = [o for o in context.selected_objects if o.type == 'MESH']
        else:
            objects = [o for o in bpy.data.objects if o.type == 'MESH']

        if not objects:
            self.report({'WARNING'}, "No mesh objects to process")
            return {'CANCELLED'}

        replaced = replace_with_instances(objects, context)
        self.report({'INFO'}, "Replaced %d object(s) with instances" % replaced)
        return {'FINISHED'}


class VIEW3D_PT_duplicate_to_instance(Panel):
    bl_label = "Duplicate to Instance"
    bl_idname = "VIEW3D_PT_duplicate_to_instance"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Instance"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        op = col.operator(OBJECT_OT_duplicate_to_instance.bl_idname,
                          text="Selected to Instances", icon='LINKED')
        op.scope = 'SELECTED'
        op = col.operator(OBJECT_OT_duplicate_to_instance.bl_idname,
                          text="All Objects to Instances", icon='LINKED')
        op.scope = 'ALL'


def menu_func(self, context):
    self.layout.operator(OBJECT_OT_duplicate_to_instance.bl_idname,
                         icon='LINKED')


classes = (
    OBJECT_OT_duplicate_to_instance,
    VIEW3D_PT_duplicate_to_instance,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

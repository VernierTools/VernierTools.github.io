# SPDX-License-Identifier: GPL-3.0-or-later
"""
Material Users
Shows, in the Shader Editor header, how many objects use the material
being edited. Clicking the number opens a list of those objects; clicking
an object makes it active with the same material shown.
"""

import bpy
from bpy.app.handlers import persistent
from bpy.props import StringProperty
from bpy.types import Operator, Panel


# ─────────────────────────────────────────────────────────────────────────────
# Users lookup (cached, rebuilt after any scene change)
# ─────────────────────────────────────────────────────────────────────────────

# {material key: [object key, ...]}. Keys are (name, library path) so no
# Python references to IDs survive an undo.
_cache = None


def _key(id_):
    return (id_.name, id_.library.filepath if id_.library else None)


def _lookup(collection, key):
    name, lib = key
    if lib is None:
        return collection.get(name)
    for item in collection:
        if item.name == name and item.library and item.library.filepath == lib:
            return item
    return None


def _users_map():
    global _cache
    if _cache is None:
        cache = {}
        for ob in bpy.data.objects:
            seen = set()
            for slot in ob.material_slots:
                mat = slot.material
                if mat is None:
                    continue
                k = _key(mat)
                if k not in seen:
                    seen.add(k)
                    cache.setdefault(k, []).append(_key(ob))
        for users in cache.values():
            users.sort(key=lambda k: k[0].lower())
        _cache = cache
    return _cache


@persistent
def _invalidate(*_args):
    global _cache
    _cache = None


_HANDLERS = (
    bpy.app.handlers.depsgraph_update_post,
    bpy.app.handlers.undo_post,
    bpy.app.handlers.redo_post,
    bpy.app.handlers.load_post,
)


def _editing_material(context):
    """The material whose node tree the Shader Editor is showing."""
    space = context.space_data
    if (space is None or space.type != 'NODE_EDITOR'
            or space.tree_type != 'ShaderNodeTree'
            or space.shader_type != 'OBJECT'):
        return None
    tree = space.node_tree
    if tree is None:
        return None
    ob = context.active_object
    if ob is not None and ob.active_material and ob.active_material.node_tree == tree:
        return ob.active_material
    # Pinned or otherwise unusual: find the owner of the tree.
    for mat in bpy.data.materials:
        if mat.node_tree == tree:
            return mat
    return None


def _material_users(mat):
    return [ob for ob in (_lookup(bpy.data.objects, k)
                          for k in _users_map().get(_key(mat), ()))
            if ob is not None]


# ─────────────────────────────────────────────────────────────────────────────
# Operator
# ─────────────────────────────────────────────────────────────────────────────

class MU_OT_go_to_user(Operator):
    bl_idname = "mu.go_to_user"
    bl_label = "Go to Object"
    bl_description = "Make this object active, showing the same material"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty()
    object_lib: StringProperty()
    material_name: StringProperty()
    material_lib: StringProperty()

    def execute(self, context):
        ob = _lookup(bpy.data.objects, (self.object_name, self.object_lib or None))
        mat = _lookup(bpy.data.materials, (self.material_name, self.material_lib or None))
        if ob is None or mat is None:
            return {'CANCELLED'}

        view_layer = context.view_layer
        if ob.name not in view_layer.objects or view_layer.objects[ob.name] != ob:
            self.report({'WARNING'}, f'"{ob.name}" is not in this view layer')
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, "Switch to Object Mode first")
            return {'CANCELLED'}

        for other in context.selected_objects:
            other.select_set(False)
        ob.select_set(True)
        view_layer.objects.active = ob

        # Without this the editor could jump to a different material of ob.
        for i, slot in enumerate(ob.material_slots):
            if slot.material == mat:
                ob.active_material_index = i
                break
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
# Header button + popover list
# ─────────────────────────────────────────────────────────────────────────────

class MU_PT_users(Panel):
    bl_label = "Material Users"
    bl_idname = "MU_PT_users"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 12

    def draw(self, context):
        layout = self.layout
        mat = _editing_material(context)
        if mat is None:
            layout.label(text="No material")
            return

        users = _material_users(mat)
        layout.label(text=f'"{mat.name}"  {len(users)} object(s)', icon='MATERIAL')
        if not users:
            return

        active = context.active_object
        view_layer = context.view_layer
        mat_lib = mat.library.filepath if mat.library else ""
        col = layout.column(align=True)
        for ob in users:
            in_layer = (ob.name in view_layer.objects
                        and view_layer.objects[ob.name] == ob)
            row = col.row(align=True)
            op = row.operator(
                MU_OT_go_to_user.bl_idname,
                text=ob.name,
                icon='OUTLINER_OB_' + ob.type
                if ob.type in _TYPE_ICONS else 'OBJECT_DATA',
                emboss=(ob == active),
                depress=(ob == active),
            )
            op.object_name = ob.name
            op.object_lib = ob.library.filepath if ob.library else ""
            op.material_name = mat.name
            op.material_lib = mat_lib
            if not in_layer:
                row.label(text="", icon='SCENE_DATA')
            elif not ob.visible_get():
                row.label(text="", icon='HIDE_ON')


_TYPE_ICONS = {
    'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES', 'POINTCLOUD',
    'VOLUME', 'GREASEPENCIL',
}


def draw_header(self, context):
    mat = _editing_material(context)
    if mat is None:
        return
    count = len(_users_map().get(_key(mat), ()))
    self.layout.popover(panel=MU_PT_users.bl_idname, text=str(count),
                        icon='COMMUNITY')


# ─────────────────────────────────────────────────────────────────────────────
# Registration
# ─────────────────────────────────────────────────────────────────────────────

classes = (
    MU_OT_go_to_user,
    MU_PT_users,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.NODE_HT_header.append(draw_header)
    for handlers in _HANDLERS:
        handlers.append(_invalidate)


def unregister():
    for handlers in _HANDLERS:
        if _invalidate in handlers:
            handlers.remove(_invalidate)
    bpy.types.NODE_HT_header.remove(draw_header)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _invalidate()

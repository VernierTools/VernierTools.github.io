# Instrument Channel Mute (v0.5.0, unofficial)

A script for Fender Studio Pro 8 that makes **muting an instrument track actually silence its sound**.

By default, the M button of an instrument track mutes **only the MIDI**; the instrument's audio (its channel in the Console) keeps playing. With this script installed you get:

1. **Mute Link (automatic):** the track's M and the instrument channel's M in the Console are kept in sync.
2. **Toggle Instrument Channel Mute (command):** mutes/unmutes the instrument channel of the selected track(s) no matter which view has focus. Assign it to a key, e.g. on the numeric keypad.

> ⚠️ **Unofficial, no warranty.** It uses Studio Pro's internal, undocumented scripting API. Use at your own risk.

---

## How Mute Link behaves

It starts with Studio Pro, runs in the background and checks mute states every 0.1 seconds.

| Case | Behavior |
|---|---|
| **One track ↔ one instrument** | **Two-way sync.** Clicking the track's M mutes/unmutes the instrument channel, and clicking the instrument channel's M in the Console mutes/unmutes the track. |
| **One instrument played by several tracks** (e.g. three tracks driving the same bass instrument) | Muting one track leaves the others sounding (only that track's MIDI is muted). **The instrument channel is muted only when all of its tracks are muted**, and unmuted as soon as any of them is unmuted.<br>**Muting the instrument channel in the Console mutes all tracks that play it.** Unmuting it restores each track's previous state. |
| **Extra outputs of multi-output instruments** (e.g. outputs that appear as "Stereo 2", "Stereo 3") | **Not linked.** The track's M only affects the main output. Mute extra outputs individually in the Console as usual. |
| Tracks not connected to an instrument (Chord Track etc.) | Ignored. |

- Tracks and instruments are matched by their **actual connection**, not by name. Renamed tracks and shared instruments are handled.
- Syncing starts with the next M click after Studio Pro has seen the current state. If a track and its instrument channel differ when a song is opened, the script does not force them to match.
- Changes are applied with up to ~0.1 s delay.
- **To pause the link**, use the "**Toggle Instrument Mute Link**" command (it is ON at startup).

## Commands

Added to the **"Instrument Channel Mute"** category in Keyboard Shortcuts.

| Command | What it does |
|---|---|
| **Toggle Instrument Channel Mute** | Toggles mute on the instrument channel of the selected instrument track(s), the same way whether the Arrange view or the Console has focus. With several tracks selected: if any is unmuted, all get muted; if all are muted, all get unmuted. For audio tracks, it mutes the track's own channel. |
| **Toggle Instrument Mute Link** | Turns Mute Link on/off and shows the new state in a dialog. |
| Instrument Channel Mute Probe | Diagnostic. Shows information about the selected tracks and channels in a dialog. Use it when reporting a problem. |

## Tested with

- Fender Studio Pro **8.2.0** (Build 114903)
- macOS (Apple Silicon)

**Not tested:** Studio One 6 / 7, Windows, Intel Macs.

---

## Install (macOS)

1. **Quit Studio Pro.**
2. In Finder choose Go → Go to Folder… (⌘⇧G), paste this path and press Return:
   ```
   ~/Library/Application Support/Fender/Studio Pro 8/Extensions/
   ```
3. Copy the **`local.instrumentchannelmute.mac` folder** from this ZIP into that folder, as is.
   You should end up with:
   ```
   Extensions/
     local.instrumentchannelmute.mac/
       metainfo.xml
       installdata.xml
       Scripts/
         instrument-channel-mute.package
   ```
4. Start Studio Pro. Mute Link starts running.
5. In Keyboard Shortcuts, search for "Instrument Channel Mute" and assign **Toggle Instrument Channel Mute** to a key (e.g. the numeric keypad).

To update from an older version, quit Studio Pro and replace the whole `local.instrumentchannelmute.mac` folder.

### ⛔ Do not

- **Never put anything inside `Studio Pro 8.app` (e.g. `Contents/Scripts`).** That can break the app's code signature; macOS then reports it as "damaged and can't be opened" and **Studio Pro may not start** until you reinstall it.
- **"Install from File" won't work** (this is not a signed `.install` package, so it fails). Copy the folder manually as described above.

## Uninstall

Quit Studio Pro and delete the **`local.instrumentchannelmute.mac` folder** from `~/Library/Application Support/Fender/Studio Pro 8/Extensions/`.

---

## Known limitations

- Extra outputs of multi-output instruments are not linked (see the table above).
- Behavior together with Undo (⌘Z) has not been tested yet.
- **A Studio Pro update may break it.** The API is undocumented, and unsigned extensions might stop being loaded in the future. In that case Studio Pro itself is not affected; the script simply won't load.

## Troubleshooting

- "Instrument Channel Mute" doesn't appear in Keyboard Shortcuts
  → Check the folder layout (especially the `Scripts` subfolder), and make sure you restarted Studio Pro.
- Clicking a track's M doesn't affect the instrument channel
  → Make sure Mute Link isn't switched off: run "Toggle Instrument Mute Link" (it shows ON/OFF).
- "No matching instrument channel found" appears
  → Select the track, run **Probe**, and send the dialog's contents to the author.

---

## Safety

- This script is **not signed**. Unsigned extensions run with the same permissions as Studio Pro.
- The package is a ZIP file, so **you can inspect it before installing**: duplicate `Scripts/instrument-channel-mute.package`, rename the copy to `.zip`, and read `main.js`. The same files are also in the `source/` folder.
- The script only **reads track and mixer-channel information, changes mute states, and shows dialogs**. It does not read or write files and makes no network connections.
- Don't use modified copies from unknown sources.

## Contents

```
InstrumentChannelMute-0.5.0/
  README_ja.md / README_en.md       … this guide
  LICENSE                           … license (full CC0 1.0 text)
  local.instrumentchannelmute.mac/  … the folder to install
  source/                           … contents of the .package (for review)
    classfactory.xml  … command and service registration
    metainfo.xml      … package info
    main.js           … the script
```

## Changelog

- **0.5.0:** Added Mute Link (automatic sync). Tracks and instruments are now matched by their actual connection; shared instruments are supported.
- **0.1.0:** First version (Toggle Instrument Channel Mute command).

## License

**CC0 1.0 Universal (public domain dedication)**

To the extent possible under law, the author has waived all copyright and related or neighboring rights to this script. You may use, modify and redistribute it for any purpose, commercial or not, without asking permission and without attribution. Where such a waiver is not legally possible, it applies as an unconditional license granting the same freedoms. See `LICENSE` for the full legal text.

Provided as is, without warranty of any kind.

Fender, Studio Pro and Studio One are trademarks of their respective owners. This script is not affiliated with Fender or PreSonus.

## Reference

- Unofficial, community-made scripting API reference: https://github.com/CSources/Studio-Pro-Scripting-API-Reference

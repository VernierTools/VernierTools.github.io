// Instrument Channel Mute v0.5.0 (unofficial) - Fender Studio Pro 8 script
// License: CC0 1.0 Universal (public domain dedication)
// Commands:
//  - "Toggle Instrument Channel Mute": toggles mute on the instrument (audio) channel
//    of the selected instrument track(s), regardless of keyboard focus.
//  - "Toggle Instrument Mute Link": turns the automatic mute link on/off.
//  - "Instrument Channel Mute Probe": shows what the script can see (for bug reports).
// Background service "Instrument Mute Link Service": keeps track mute and
// instrument channel mute in sync (see the Mute Link section below).

function safe(fn, fallback) {
    try { return fn(); } catch (e) { return fallback; }
}

function getMixer(context) {
    return safe(function () { return context.functions.root.environment.find("MixerConsole"); }, null);
}

// All normal mixer channels of a given type
function getChannels(mixer, type) {
    var out = [];
    var list = safe(function () { return mixer.getChannelList(1); }, null);
    if (!list) return out;
    for (var i = 0; i < list.numChannels; i++) {
        var ch = list.getChannel(i);
        if (!type || ch.channelType === type) out.push(ch);
    }
    return out;
}

function getSelectedChannels(mixer) {
    var out = [];
    var list = safe(function () { return mixer.getChannelList(1); }, null);
    if (!list) return out;
    var n = safe(function () { return list.numSelectedChannels; }, 0);
    for (var i = 0; i < n; i++) out.push(list.getSelectedChannel(i));
    return out;
}

function getSelectedTracks(context) {
    var out = [];
    var tl = context.mainTrackList;
    for (var i = 0; i < tl.numSelectedTracks; i++) out.push(tl.getSelectedTrack(i));
    return out;
}

function norm(s) { return String(s || "").replace(/\s+/g, " ").trim().toLowerCase(); }

// Find instrument (AudioSynth) channels belonging to a selected instrument track.
// Strategy 1: match by name (track name / its note channel title vs. synth channel title).
function findSynthChannelsForTrack(track, synths) {
    var names = [norm(track.name), norm(safe(function () { return track.channel.title; }, ""))];
    var hits = [];
    for (var i = 0; i < synths.length; i++) {
        var t = norm(synths[i].title);
        if (t && (names[0] === t || names[1] === t)) hits.push(synths[i]);
    }
    return hits;
}

function ProbeTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        var lines = [];
        var tracks = getSelectedTracks(context);
        lines.push("Selected tracks: " + tracks.length);
        for (var i = 0; i < tracks.length; i++) {
            var t = tracks[i];
            var ch = safe(function () { return t.channel; }, null);
            lines.push("  [" + i + "] name=" + t.name + " media=" + t.mediaType +
                " | channel.title=" + safe(function () { return ch.title; }, "?") +
                " type=" + safe(function () { return ch.channelType; }, "?") +
                " mute=" + safe(function () { return ch.mute; }, "?"));
        }
        var mixer = getMixer(context);
        if (!mixer) {
            lines.push("MixerConsole: NOT FOUND");
        } else {
            var sel = getSelectedChannels(mixer);
            lines.push("Selected mixer channels: " + sel.length);
            for (var j = 0; j < sel.length; j++)
                lines.push("  * " + sel[j].title + " (" + sel[j].channelType + ") mute=" + sel[j].mute);
            var synths = getChannels(mixer, "AudioSynth");
            lines.push("Instrument (AudioSynth) channels: " + synths.length);
            for (var k = 0; k < synths.length && k < 20; k++)
                lines.push("  - " + synths[k].title + " / name=" + synths[k].name + " mute=" + synths[k].mute);
        }
        Host.GUI.alert(lines.join("\n"));
        return Host.Results.kResultOk;
    };
}

function ToggleTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        var mixer = getMixer(context);
        if (!mixer) { Host.GUI.alert("MixerConsole not found."); return Host.Results.kResultOk; }

        var targets = [];

        // 0) Exact: each selected instrument track's "InstrumentOutput"
        var selTracks = getSelectedTracks(context);
        for (var z = 0; z < selTracks.length; z++) {
            if (selTracks[z].mediaType !== "Music") continue;
            var tch = prop(selTracks[z], "channel"), io = null;
            if (has(tch, "find")) { try { io = tch.find("InstrumentOutput"); } catch (x) {} }
            if (io && prop(io, "channelType") === "AudioSynth") {
                var dup = false;
                for (var q = 0; q < targets.length; q++) if (targets[q].name === io.name) dup = true;
                if (!dup) targets.push(io);
            }
        }

        // 1) Selected instrument channels in the mixer (works if track selection follows into the console)
        var sel = targets.length ? [] : getSelectedChannels(mixer);
        for (var i = 0; i < sel.length; i++)
            if (sel[i].channelType === "AudioSynth") targets.push(sel[i]);

        // 2) Fallback: match selected instrument tracks to instrument channels by name
        if (targets.length === 0) {
            var synths = getChannels(mixer, "AudioSynth");
            var tracks = getSelectedTracks(context);
            for (var j = 0; j < tracks.length; j++) {
                if (tracks[j].mediaType !== "Music") continue;
                var hits = findSynthChannelsForTrack(tracks[j], synths);
                for (var h = 0; h < hits.length; h++)
                    if (targets.indexOf(hits[h]) < 0) targets.push(hits[h]);
            }
        }

        // 3) Audio tracks: their own channel is the audio channel
        if (targets.length === 0) {
            var tr = getSelectedTracks(context);
            for (var a = 0; a < tr.length; a++)
                if (tr[a].mediaType === "Audio" && tr[a].channel) targets.push(tr[a].channel);
        }

        if (targets.length === 0) {
            Host.GUI.alert("No matching instrument channel found.\nRun 'Instrument Channel Mute Probe' and send the result.");
            return Host.Results.kResultOk;
        }

        // Toggle as a group: if any target is unmuted, mute all; otherwise unmute all
        var anyUnmuted = false;
        for (var m = 0; m < targets.length; m++) if (!targets[m].mute) anyUnmuted = true;
        for (var n = 0; n < targets.length; n++) targets[n].mute = anyUnmuted ? 1 : 0;
        return Host.Results.kResultOk;
    };
}

// ---------------------------------------------------------------------------
// Mute Link (background service)
// Watches instrument tracks' mute (MusicTrack channels in the console) and their
// instrument audio channels (AudioSynth). For clear 1:1 pairs it keeps both in
// sync in both directions: clicking either M updates the other one.
//
// Pairing MusicTrack -> AudioSynth:
//   1) the track channel's "InstrumentOutput" child (undocumented, found by probing)
//   2) learned: when exactly one MusicTrack and one AudioSynth are selected in
//      the console (happens when you select an instrument track), remember them
//   3) fallback: an AudioSynth channel with the same title as the track
// Several tracks playing one instrument: the instrument channel is muted only
// while all of those tracks are muted; muting the channel in the console mutes
// all of them, and unmuting it restores their previous states.
// Extra outputs of multi-output instruments are not linked.
// ---------------------------------------------------------------------------

var kLinkChannel = "local.instrumentchannelmute.link";
var kLinkTickMs = 100;
var kConsoleUrl = "://hostapp/DocumentManager/ActiveDocument/Environment/MixerConsole";
var kDocUrl = "://hostapp/DocumentManager/ActiveDocument";

function LinkService() {
    var self = this;
    this.interfaces = [Host.Interfaces.IComponent, Host.Interfaces.IObserver];
    this.enabled = true;
    this.running = false;
    this.docKey = null;
    this.prev = {};     // pair key -> {t: track mute, s: instrument channel mute} last seen
    this.learned = {};  // MusicTrack internal name -> AudioSynth internal name

    this.initialize = function (ctx) {
        try { Host.Signals.advise(kLinkChannel, this); } catch (e) {}
        this.running = true;
        Host.Signals.postMessage(this, kLinkTickMs, "tick");
        return Host.Results.kResultOk;
    };

    this.terminate = function () {
        this.running = false;
        try { Host.Signals.unadvise(kLinkChannel, this); } catch (e) {}
        return Host.Results.kResultOk;
    };

    this.poll = function () {
        var mixer = safe(function () { return Host.Objects.getObjectByUrl(kConsoleUrl); }, null);
        if (!mixer) { this.docKey = null; return; }
        // another song became active: start fresh (compare by document title, since
        // host object wrappers may not be identical between calls)
        var docKey = safe(function () {
            var d = Host.Objects.getObjectByUrl(kDocUrl);
            return String(d.title) + "|" + String(d.name);
        }, "?");
        if (docKey !== this.docKey) { this.docKey = docKey; this.prev = {}; this.learned = {}; }
        var list = mixer.getChannelList(1);
        var tracks = [], synthsByName = {}, synthsByTitle = {};
        for (var i = 0; i < list.numChannels; i++) {
            var ch = list.getChannel(i);
            if (ch.channelType === "MusicTrack") tracks.push(ch);
            else if (ch.channelType === "AudioSynth") {
                synthsByName[ch.name] = ch;
                var t = norm(ch.title);
                (synthsByTitle[t] = synthsByTitle[t] || []).push(ch);
            }
        }

        // learn pairing from the current console selection
        var selTrack = null, selSynth = null, nT = 0, nS = 0;
        var n = safe(function () { return list.numSelectedChannels; }, 0);
        for (var s = 0; s < n; s++) {
            var sc = list.getSelectedChannel(s);
            if (sc.channelType === "MusicTrack") { selTrack = sc; nT++; }
            else if (sc.channelType === "AudioSynth") { selSynth = sc; nS++; }
        }
        if (nT === 1 && nS === 1) this.learned[selTrack.name] = selSynth.name;

        // resolve each track's instrument channel:
        //   1) the track channel's "InstrumentOutput" child (exact, also for shared instruments)
        //   2) fallback: learned from selection, then same title
        var groups = {}, order = [];
        for (var k = 0; k < tracks.length; k++) {
            var tr = tracks[k], synth = null;
            if (has(tr, "find")) {
                var io = null;
                try { io = tr.find("InstrumentOutput"); } catch (x) {}
                if (io && prop(io, "channelType") === "AudioSynth") synth = synthsByName[io.name] || io;
            }
            if (!synth && this.learned[tr.name] && synthsByName[this.learned[tr.name]])
                synth = synthsByName[this.learned[tr.name]];
            if (!synth) {
                var cands = synthsByTitle[norm(tr.title)];
                if (cands && cands.length === 1) synth = cands[0];
            }
            if (!synth) continue;
            if (!groups[synth.name]) { groups[synth.name] = { synth: synth, tracks: [] }; order.push(synth.name); }
            groups[synth.name].tracks.push(tr);
        }

        // 1 track  <-> 1 instrument channel : both ways
        // N tracks <-> 1 instrument channel : channel muted only while ALL its tracks are muted;
        //   muting the channel in the console mutes all its tracks, unmuting restores them
        var seen = {};
        for (var g = 0; g < order.length; g++) {
            var grp = groups[order[g]], S = grp.synth, s = S.mute;
            var key = "S>" + S.name + "|" + grp.tracks.map(function (x) { return x.name + "|" + x.title; }).join(",");
            seen[key] = true;
            var last = this.prev[key];
            var restore = last ? last.restore : null;
            var ts = [], allMuted = 1;
            for (var j = 0; j < grp.tracks.length; j++) { ts.push(grp.tracks[j].mute); if (!grp.tracks[j].mute) allMuted = 0; }

            if (last && this.enabled) {
                var tChanged = false;
                for (var c = 0; c < ts.length; c++) if (ts[c] !== last.ts[c]) tChanged = true;
                var sChanged = (s !== last.s);
                if (grp.tracks.length === 1) {
                    var T = grp.tracks[0], t = ts[0];
                    if (tChanged && !sChanged && s !== t) { S.mute = t; s = t; }
                    else if (sChanged && !tChanged && t !== s) { T.mute = s; ts[0] = s; }
                } else if (tChanged && !sChanged) {
                    if (s !== allMuted) { S.mute = allMuted; s = allMuted; }
                    restore = null;   // tracks were edited directly: forget the saved states
                } else if (sChanged && !tChanged) {
                    // instrument channel muted/unmuted in the console -> all its tracks follow;
                    // on unmute, restore the per-track states from before the console mute
                    if (s) {
                        restore = ts.slice();
                        for (var m1 = 0; m1 < grp.tracks.length; m1++) if (!ts[m1]) { grp.tracks[m1].mute = 1; ts[m1] = 1; }
                    } else {
                        var back = (last.restore && last.restore.length === ts.length) ? last.restore : null;
                        for (var m2 = 0; m2 < grp.tracks.length; m2++) {
                            var want = back ? back[m2] : 0;
                            if (ts[m2] !== want) { grp.tracks[m2].mute = want; ts[m2] = want; }
                        }
                        restore = null;
                    }
                }
            }
            this.prev[key] = { ts: ts, s: s, restore: restore };
        }
        for (var old in this.prev) if (this.prev.hasOwnProperty(old) && !seen[old]) delete this.prev[old];
    };

    this.notify = function (subject, msg) {
        if (!msg) return;
        if (msg.id === "tick") {
            if (!self.running) return;
            try { self.poll(); } catch (e) {}
            Host.Signals.postMessage(self, kLinkTickMs, "tick");
        } else if (msg.id === "toggle") {
            self.enabled = !self.enabled;
            Host.GUI.alert("Instrument Mute Link: " + (self.enabled ? "ON" : "OFF"));
        }
    };
}

function LinkToggleTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        Host.Signals.signal(kLinkChannel, "toggle", "");
        return Host.Results.kResultOk;
    };
}


// The host shows an error dialog for every failed native call, even inside
// try/catch, so only call methods that exist (typeof check first).
function has(o, m) {
    try { return o !== null && o !== undefined && typeof o[m] === "function"; } catch (e) { return false; }
}
function prop(o, p) {
    try { var v = o[p]; return (v === undefined) ? undefined : v; } catch (e) { return undefined; }
}

function createProbe() { return new ProbeTask(); }
function createToggle() { return new ToggleTask(); }
function createLinkService() { return new LinkService(); }
function createLinkToggle() { return new LinkToggleTask(); }

# Instrument Channel Mute (v0.1.0, unofficial)

A script for Fender Studio Pro 8 that adds a command to **mute/unmute the audio side of instrument tracks** (the instrument's channel in the Console).

The built-in track mute (M), when the Arrange view has focus, only mutes the MIDI of an instrument track, so the instrument keeps sounding. This command mutes the instrument channel of the selected track(s) **no matter which view has focus**.

> ⚠️ **Unofficial, no warranty.** It uses Studio Pro's internal, undocumented scripting API. Use at your own risk.

---

## Commands

Added to the **"Instrument Channel Mute"** category in Keyboard Shortcuts.

| Command | What it does |
|---|---|
| **Toggle Instrument Channel Mute** | Toggles mute on the instrument channel of the selected instrument track(s). With several tracks selected: if any is unmuted, all get muted; if all are muted, all get unmuted. For audio tracks, it mutes the track's own channel. |
| Instrument Channel Mute Probe | Diagnostic. Shows information about the selected tracks and channels in a dialog. Use it when reporting a problem. |

## Tested with

- Fender Studio Pro **8.2.0** (Build 114903)
- macOS (Apple Silicon)

**Not tested:** Studio One 6 / 7, Windows, Intel Macs.

---

## Install (macOS)

1. **Quit Studio Pro.**
2. In Finder choose Go → Go to Folder… (⌘⇧G), paste this path and press Return:
   ```
   ~/Library/Application Support/Fender/Studio Pro 8/Extensions/
   ```
3. Copy the **`local.instrumentchannelmute.mac` folder** from this ZIP into that folder, as is.
   You should end up with:
   ```
   Extensions/
     local.instrumentchannelmute.mac/
       metainfo.xml
       installdata.xml
       Scripts/
         instrument-channel-mute.package
   ```
4. Start Studio Pro.
5. In Keyboard Shortcuts, search for "Instrument Channel Mute" and assign **Toggle Instrument Channel Mute** to a key.

### ⛔ Do not

- **Never put anything inside `Studio Pro 8.app` (e.g. `Contents/Scripts`).** That breaks the app's code signature, macOS reports it as "damaged and can't be opened", and **Studio Pro will not start** until you reinstall it.
- **"Install from File" won't work** (this is not a signed `.install` package, so it fails). Copy the folder manually as described above.

## Uninstall

Quit Studio Pro and delete the **`local.instrumentchannelmute.mac` folder** from `~/Library/Application Support/Fender/Studio Pro 8/Extensions/`.

---

## How it works

- When you select an instrument track in the Arrange view, Studio Pro also selects its instrument channel in the Console. The command relies on that.
- The track's M button in the Arrange view (MIDI) is left alone. The M on the instrument channel in the Console lights up.

## Known limitations / untested cases

- **Multi-output instruments** (one instrument feeding several channels): not tested which channels get muted.
- **One instrument shared by several tracks:** muting its channel silences all tracks that play it.
- If selecting an instrument track does not select its instrument channel, the script falls back to finding an instrument channel whose name matches the track name. If none is found, it shows a message.
- **A Studio Pro update may break it.** The API is undocumented, and unsigned extensions might stop being loaded in the future.

## Troubleshooting

- "Instrument Channel Mute" doesn't appear in Keyboard Shortcuts
  → Check the folder layout (especially the `Scripts` subfolder), and make sure you restarted Studio Pro.
- "No matching instrument channel found" appears
  → Select the track, run **Probe**, and send the dialog's contents to the author.

---

## Safety

- This script is **not signed**. Unsigned extensions run with the same permissions as Studio Pro (file access, etc.).
- The package is a ZIP file, so **you can inspect it before installing**: duplicate `Scripts/instrument-channel-mute.package`, rename the copy to `.zip`, and read `main.js`. The same files are also in the `source/` folder.
- The script only **reads and writes the mute state of mixer channels and shows dialogs**. It does not read or write files and makes no network connections.
- Don't use modified copies from unknown sources.

## Contents

```
InstrumentChannelMute-0.1.0/
  README_ja.md / README_en.md     … this guide
  LICENSE                           … license (full CC0 1.0 text)
  local.instrumentchannelmute.mac/  … the folder to install
  source/                           … contents of the .package (for review)
    classfactory.xml  … command registration
    metainfo.xml      … package info
    main.js           … the script
```

## License

**CC0 1.0 Universal (public domain dedication)**

To the extent possible under law, the author has waived all copyright and related or neighboring rights to this script. You may use, modify and redistribute it for any purpose, commercial or not, without asking permission and without attribution. Where such a waiver is not legally possible, it applies as an unconditional license granting the same freedoms. See `LICENSE` for the full legal text.

Provided as is, without warranty of any kind.

Fender, Studio Pro and Studio One are trademarks of their respective owners. This script is not affiliated with Fender or PreSonus.

## Reference

- Unofficial, community-made scripting API reference: https://github.com/CSources/Studio-Pro-Scripting-API-Reference

// Instrument Channel Mute (v0.1, experimental)
// Two commands:
//  - "Instrument Channel Mute Probe": shows what the script can see (for debugging)
//  - "Toggle Instrument Channel Mute": toggles mute on the mixer (audio) channel
//    of the selected instrument track(s), regardless of keyboard focus.

function safe(fn, fallback) {
    try { return fn(); } catch (e) { return fallback; }
}

function getMixer(context) {
    return safe(function () { return context.functions.root.environment.find("MixerConsole"); }, null);
}

// All normal mixer channels of a given type
function getChannels(mixer, type) {
    var out = [];
    var list = safe(function () { return mixer.getChannelList(1); }, null);
    if (!list) return out;
    for (var i = 0; i < list.numChannels; i++) {
        var ch = list.getChannel(i);
        if (!type || ch.channelType === type) out.push(ch);
    }
    return out;
}

function getSelectedChannels(mixer) {
    var out = [];
    var list = safe(function () { return mixer.getChannelList(1); }, null);
    if (!list) return out;
    var n = safe(function () { return list.numSelectedChannels; }, 0);
    for (var i = 0; i < n; i++) out.push(list.getSelectedChannel(i));
    return out;
}

function getSelectedTracks(context) {
    var out = [];
    var tl = context.mainTrackList;
    for (var i = 0; i < tl.numSelectedTracks; i++) out.push(tl.getSelectedTrack(i));
    return out;
}

function norm(s) { return String(s || "").replace(/\s+/g, " ").trim().toLowerCase(); }

// Find instrument (AudioSynth) channels belonging to a selected instrument track.
// Strategy 1: match by name (track name / its note channel title vs. synth channel title).
function findSynthChannelsForTrack(track, synths) {
    var names = [norm(track.name), norm(safe(function () { return track.channel.title; }, ""))];
    var hits = [];
    for (var i = 0; i < synths.length; i++) {
        var t = norm(synths[i].title);
        if (t && (names[0] === t || names[1] === t)) hits.push(synths[i]);
    }
    return hits;
}

function ProbeTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        var lines = [];
        var tracks = getSelectedTracks(context);
        lines.push("Selected tracks: " + tracks.length);
        for (var i = 0; i < tracks.length; i++) {
            var t = tracks[i];
            var ch = safe(function () { return t.channel; }, null);
            lines.push("  [" + i + "] name=" + t.name + " media=" + t.mediaType +
                " | channel.title=" + safe(function () { return ch.title; }, "?") +
                " type=" + safe(function () { return ch.channelType; }, "?") +
                " mute=" + safe(function () { return ch.mute; }, "?"));
        }
        var mixer = getMixer(context);
        if (!mixer) {
            lines.push("MixerConsole: NOT FOUND");
        } else {
            var sel = getSelectedChannels(mixer);
            lines.push("Selected mixer channels: " + sel.length);
            for (var j = 0; j < sel.length; j++)
                lines.push("  * " + sel[j].title + " (" + sel[j].channelType + ") mute=" + sel[j].mute);
            var synths = getChannels(mixer, "AudioSynth");
            lines.push("Instrument (AudioSynth) channels: " + synths.length);
            for (var k = 0; k < synths.length && k < 20; k++)
                lines.push("  - " + synths[k].title + " / name=" + synths[k].name + " mute=" + synths[k].mute);
        }
        Host.GUI.alert(lines.join("\n"));
        return Host.Results.kResultOk;
    };
}

function ToggleTask() {
    this.interfaces = [Host.Interfaces.IEditTask];
    this.prepareEdit = function (context) { return Host.Results.kResultOk; };
    this.performEdit = function (context) {
        var mixer = getMixer(context);
        if (!mixer) { Host.GUI.alert("MixerConsole not found."); return Host.Results.kResultOk; }

        var targets = [];

        // 1) Selected instrument channels in the mixer (works if track selection follows into the console)
        var sel = getSelectedChannels(mixer);
        for (var i = 0; i < sel.length; i++)
            if (sel[i].channelType === "AudioSynth") targets.push(sel[i]);

        // 2) Fallback: match selected instrument tracks to instrument channels by name
        if (targets.length === 0) {
            var synths = getChannels(mixer, "AudioSynth");
            var tracks = getSelectedTracks(context);
            for (var j = 0; j < tracks.length; j++) {
                if (tracks[j].mediaType !== "Music") continue;
                var hits = findSynthChannelsForTrack(tracks[j], synths);
                for (var h = 0; h < hits.length; h++)
                    if (targets.indexOf(hits[h]) < 0) targets.push(hits[h]);
            }
        }

        // 3) Audio tracks: their own channel is the audio channel
        if (targets.length === 0) {
            var tr = getSelectedTracks(context);
            for (var a = 0; a < tr.length; a++)
                if (tr[a].mediaType === "Audio" && tr[a].channel) targets.push(tr[a].channel);
        }

        if (targets.length === 0) {
            Host.GUI.alert("No matching instrument channel found.\nRun 'Instrument Channel Mute Probe' and send the result.");
            return Host.Results.kResultOk;
        }

        // Toggle as a group: if any target is unmuted, mute all; otherwise unmute all
        var anyUnmuted = false;
        for (var m = 0; m < targets.length; m++) if (!targets[m].mute) anyUnmuted = true;
        for (var n = 0; n < targets.length; n++) targets[n].mute = anyUnmuted ? 1 : 0;
        return Host.Results.kResultOk;
    };
}

function createProbe() { return new ProbeTask(); }
function createToggle() { return new ToggleTask(); }

# Instrument Channel Mute（v0.1.0・非公式）

Fender Studio Pro 8 で、**インストゥルメントトラックの「音声側」（コンソールの音源チャンネル）をミュート／解除するコマンド**を追加するスクリプトです。

標準のトラックミュート（M）は、アレンジ画面にフォーカスがあるとき、インストゥルメントトラックの MIDI だけをミュートし、音源の音は止まりません。このコマンドは、**どこにフォーカスがあっても**、選択中のトラックの音源チャンネルをミュートします。

> ⚠️ **非公式・無保証です。** Fender（旧 PreSonus）が公開していない内部のスクリプト機能を使っています。自己責任でお使いください。

---

## 追加されるコマンド

キーボードショートカットの設定画面の、カテゴリ **「Instrument Channel Mute」** に追加されます。

| コマンド | 内容 |
|---|---|
| **Toggle Instrument Channel Mute** | 選択中のインストゥルメントトラックの音源チャンネルのミュートを切り替えます。複数のトラックを選んでいる場合、1つでもミュートされていないものがあれば全部ミュート、全部ミュート済みなら全部解除します。音声トラックを選んでいる場合は、そのトラックのチャンネルをミュートします。 |
| Instrument Channel Mute Probe | 調査用です。選択中のトラックやチャンネルの情報をダイアログに表示します。不具合を報告するときに使います。 |

## 動作確認済みの環境

- Fender Studio Pro **8.2.0**（Build 114903）
- macOS（Apple Silicon）

次の環境では**試していません**：Studio One 6 / 7、Windows、Intel Mac。

---

## インストール方法（macOS）

1. **Studio Pro を終了します。**
2. Finder のメニューから「移動」→「フォルダへ移動…」（⌘ + ⇧ + G）を開き、次のパスを貼り付けて Enter を押します。
   ```
   ~/Library/Application Support/Fender/Studio Pro 8/Extensions/
   ```
3. この ZIP に入っている **`local.instrumentchannelmute.mac` フォルダ**を、開いたフォルダの中にそのままコピーします。
   コピー後は、次の構成になっていれば OK です。
   ```
   Extensions/
     local.instrumentchannelmute.mac/
       metainfo.xml
       installdata.xml
       Scripts/
         instrument-channel-mute.package
   ```
4. Studio Pro を起動します。
5. キーボードショートカットの設定画面で「Instrument Channel Mute」を検索し、**Toggle Instrument Channel Mute** を好きなキーに割り当てます。

### ⛔ やってはいけないこと

- **`Studio Pro 8.app` の中（`Contents/Scripts` など）には絶対に入れないでください。** アプリの署名が壊れて、「壊れているため開けません」と表示されて**起動できなくなります**。その場合は、Studio Pro の再インストールが必要になります。
- 「Install from File」では**インストールできません**（署名付きの `.install` 形式ではないため、エラーになります）。上のフォルダに直接コピーしてください。

## アンインストール方法

Studio Pro を終了してから、`~/Library/Application Support/Fender/Studio Pro 8/Extensions/` の中の **`local.instrumentchannelmute.mac` フォルダを削除**します。

---

## 使い方のポイント

- アレンジ画面でインストゥルメントトラックを選ぶと、コンソール側でも対応する音源チャンネルが自動で選択されます。このコマンドはその仕組みを利用しています。
- アレンジ画面のトラックの M ボタン（MIDI 側）は変わりません。コンソールの音源チャンネルの M が点灯します。

## 既知の制限・未検証のケース

- **マルチアウトの音源**（1つの音源が複数のチャンネルに出力するもの）では、どのチャンネルがミュートされるか確認していません。
- **1つの音源を複数のトラックで共有**している場合、その音源チャンネルがミュートされるので、共有しているトラックすべての音が止まります。
- インストゥルメントトラックを選んでも音源チャンネルが選択されない場合は、トラック名と音源チャンネル名が一致するものを探します。見つからなければ、メッセージが表示されます。
- **Fender のアップデートで動かなくなる可能性があります。** 公開されていない API を使っているほか、署名のない拡張機能が今後読み込まれなくなる可能性もあります。

## うまく動かないとき

- 「Instrument Channel Mute」がショートカット設定に出てこない
  → フォルダの構成（特に `Scripts` サブフォルダ）と、Studio Pro を再起動したかを確認してください。
- 「No matching instrument channel found」と表示される
  → 対象のトラックを選んだ状態で **Probe** を実行し、表示された内容を作者に送ってください。

---

## 安全性について

- このスクリプトは**署名されていません**。署名のない拡張機能は、Studio Pro と同じ権限（ファイルの読み書きなど）で動きます。
- 中身は ZIP ファイルなので、**入れる前に確認できます**。`Scripts/instrument-channel-mute.package` を複製して拡張子を `.zip` に変えると、中の `main.js` を読めます。同じものを `source/` フォルダにも入れてあります。
- このスクリプトがやっているのは、**ミキサーチャンネルのミュート状態の読み書きと、ダイアログの表示だけ**です。ファイルの読み書きやネットワーク通信はしていません。
- 出どころの分からない改変版は使わないでください。

## 同梱ファイル

```
InstrumentChannelMute-0.1.0/
  README_ja.md / README_en.md    … この説明書
  LICENSE                           … ライセンス（CC0 1.0 全文）
  local.instrumentchannelmute.mac/  … インストールするフォルダ
  source/                           … .package の中身（確認用）
    classfactory.xml  … コマンドの登録
    metainfo.xml      … パッケージ情報
    main.js           … 本体
```

## ライセンス

**CC0 1.0 Universal（パブリックドメイン提供）**

作者は、法律で認められる最大限の範囲で、このスクリプトに関する著作権と関連する権利をすべて放棄します。商用・非商用を問わず、許可も作者名の表示も不要で、自由に使用・改変・再配布できます。権利の放棄が認められない国や地域では、同じ自由を与える無条件のライセンスとして扱われます。正式な条文は `LICENSE` を参照してください。

本ソフトウェアは無保証で提供されます。

Fender、Studio Pro、Studio One は各社の商標です。このスクリプトは Fender／PreSonus とは無関係です。

## 参考

- 非公式のスクリプト API リファレンス（コミュニティ作成）: https://github.com/CSources/Studio-Pro-Scripting-API-Reference

# SPDX-License-Identifier: GPL-3.0-or-later
"""Modifier Guard：重すぎるモディファイアでBlenderが固まる前に止める。"""

from . import guard, prefs, ui


def register():
    guard.register()
    prefs.register()
    ui.register()


def unregister():
    ui.unregister()
    prefs.unregister()
    guard.unregister()

# SPDX-License-Identifier: GPL-3.0-or-later
"""アドオンのプリファレンス。値は guard モジュールの変数に写して使う。"""

import json

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty

from . import calibrate, estimate, guard

# ガード対象にできる種類（面数を増やしうるもの）。デシメートは減らすだけなので含めない
GUARDABLE = (
    ('SUBSURF', "Subdivision Surface"),
    ('MULTIRES', "Multiresolution"),
    ('REMESH', "Remesh"),
    ('ARRAY', "Array"),
    ('MIRROR', "Mirror"),
    ('SCREW', "Screw"),
    ('SOLIDIFY', "Solidify"),
    ('BEVEL', "Bevel"),
    ('TRIANGULATE', "Triangulate"),
    ('WIREFRAME', "Wireframe"),
    ('SKIN', "Skin"),
    ('BOOLEAN', "Boolean"),
    ('NODES', "Geometry Nodes"),
)


def _key(t):
    return "guard_" + t.lower()


def get():
    """このアドオンのプリファレンス。アドオンとして有効になっていなければ None。"""
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def apply(p):
    """プリファレンスの値を guard に写す。"""
    guard.ENABLED = p.enabled
    guard.LIMIT = p.limit
    guard.AUTO_RESUME = p.auto_resume
    guard.NODES_POLICY = p.nodes_policy
    guard.GUARDED_TYPES = {t for t, _ in GUARDABLE if getattr(p, _key(t))}
    estimate.COST_FACTORS = load_factors(p.cost_factors)


FACTOR_LABELS = (
    ('SUBSURF_IN', "Subdivision (dense input)"), ('BEVEL', "Bevel"), ('REMESH', "Remesh"),
    ('WIREFRAME', "Wireframe"), ('TRIANGULATE', "Triangulate"), ('BOOLEAN_EXACT', "Boolean Exact"),
    ('BOOLEAN_FLOAT', "Boolean Float"), ('SKIN', "Skin"),
)


def load_factors(text):
    """プリファレンスに保存した補正倍率（JSON）を読む。壊れていれば空（＝補正なし）。"""
    try:
        data = json.loads(text) if text else {}
        return {k: float(v) for k, v in data.items() if isinstance(v, (int, float)) and v > 0}
    except (ValueError, TypeError, AttributeError):
        return {}


def _update(self, context):
    apply(self)
    guard.run_check(context.scene)  # 上限を下げた・種類を外したなどを、すぐ反映する


def is_calibrated(p):
    """待ち時間に直せる測定結果があるか（1.2 以前の Calibrate は秒あたりの値を残していない）。"""
    return p is not None and p.sec_per_load > 0


def limit_for_wait(p):
    """今の待てる時間に合う上限 (上限, 時間だけで決まる上限)。Calibrate していなければ None。"""
    if not is_calibrated(p):
        return None
    return calibrate.limit_for(p.target_time, p.base_redraw, p.sec_per_load, p.memory_limit)


def seconds_for(p, load):
    """負荷を待ち時間の目安（秒）に直す。Calibrate していなければ None。"""
    if not is_calibrated(p):
        return None
    return calibrate.seconds_for(load, p.base_redraw, p.sec_per_load)


def _wait_update(self, context):
    # 待てる時間が主な設定。測定結果があれば、測り直さずに上限を合わせる（limit の update で検査も走る）
    fit = limit_for_wait(self)
    if fit is not None and fit[0] != self.limit:
        self.limit = fit[0]


def _get_limit_m(self):
    return self.limit / 1e6


def _set_limit_m(self, value):
    self.limit = max(int(round(value * 1e6)), 10_000)


class ModifierGuardPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    enabled: BoolProperty(
        name="Enable Guard", default=True, update=_update,
        description="Check modifier stacks before every viewport evaluation")
    limit: IntProperty(
        name="Load Limit", default=8_000_000, min=10_000, soft_max=100_000_000, step=100_000,
        update=_update,
        description="Turn a modifier's viewport display off when its estimated load would exceed this. "
                    "Load is measured in Subdivision-equivalent faces: one face of Subdivision output counts as 1, "
                    "slower work (Bevel, Remesh, Exact Boolean, dense input meshes) counts as more. "
                    "Use Calibrate to fit it to this computer")
    limit_m: FloatProperty(
        name="Load Limit", min=0.01, soft_max=100.0, precision=2, step=10,
        get=_get_limit_m, set=_set_limit_m,
        description="The Load Limit in millions of Subdivision-equivalent faces. "
                    "Normally set from Acceptable Wait after Calibrate; edit it to override")
    target_time: FloatProperty(
        name="Acceptable Wait", default=2.0, min=0.2, max=30.0, subtype='TIME_ABSOLUTE', unit='TIME_ABSOLUTE',
        update=_wait_update,
        description="The longest you are willing to wait for one modifier to show up (slow modifier types included). "
                    "After Calibrate, changing this updates the Load Limit right away")
    cost_factors: StringProperty(
        name="Cost Factors", default="",
        description="Per-type load weights measured by Calibrate on this computer (JSON)")
    calibration_note: StringProperty(
        name="Last Calibration", default="",
        description="Result of the last calibration")
    # Calibrate の測定結果（待てる時間から上限を出し直すのと、負荷を秒で見せるのに使う）
    sec_per_load: FloatProperty(name="Seconds per Load", default=0.0, min=0.0, precision=12,
                                description="Measured by Calibrate: seconds per unit of load (0 = not calibrated)")
    base_redraw: FloatProperty(name="Scene Redraw", default=0.0, min=0.0,
                               description="Measured by Calibrate: seconds to redraw the scene")
    memory_limit: IntProperty(name="Memory Limit", default=0, min=0,
                              description="Measured by Calibrate: the most load that fits in the memory budget")
    calibrated_scene: StringProperty(name="Calibrated Scene", default="",
                                     description="The scene that was open during the last calibration")
    auto_resume: BoolProperty(
        name="Re-enable Automatically", default=True, update=_update,
        description="Turn stopped modifiers back on once their settings are back within the limit")
    show_debug: BoolProperty(
        name="Show Estimate Details", default=False,
        description="Show per-modifier estimates next to the actual face count in the sidebar (for checking accuracy)")
    nodes_policy: EnumProperty(
        name="Geometry Nodes", default='MEASURED', update=_update,
        items=(
            ('MEASURED', "Use Last Result",
             "Scale by the face count measured at the last evaluation, adjusted when integer inputs "
             "such as Count change. Catches heavy modifiers after the node group and growing input, "
             "but not changes inside the node tree itself"),
            ('PASS', "Ignore",
             "Treat Geometry Nodes as not changing the face count"),
        ),
        description="How to estimate Geometry Nodes modifiers, whose output can't be predicted")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        col = layout.column()
        col.prop(self, "enabled", text="Enable Guard", translate=False)
        sub = col.column()
        sub.active = self.enabled
        from . import ui  # ui は prefs を読み込むので、ここで読む
        ui.draw_limit(sub, context, self)
        factors = load_factors(getattr(self, "cost_factors", ""))
        if factors:
            box = sub.box()
            box.label(text="Load weights for this computer (×1 = the reference machine)", translate=False)
            grid = box.grid_flow(columns=2, even_columns=True)
            for key, label in FACTOR_LABELS:
                if key in factors:
                    grid.label(text=f"{label}: ×{factors[key]:.2f}", translate=False)
        sub.prop(self, "auto_resume", text="Re-enable Automatically", translate=False)
        sub.prop(self, "nodes_policy", text="Geometry Nodes", translate=False)
        col.prop(self, "show_debug", text="Show Estimate Details", translate=False)

        box = layout.box()
        box.active = self.enabled
        box.label(text="Modifier types to guard", translate=False)
        grid = box.grid_flow(columns=3, even_columns=True)
        for t, label in GUARDABLE:
            grid.prop(self, _key(t), text=label, translate=False)


for _t, _label in GUARDABLE:
    ModifierGuardPreferences.__annotations__[_key(_t)] = BoolProperty(
        name=_label, default=True, update=_update,
        description=f"Let the guard stop {_label} modifiers")


def register():
    if not ModifierGuardPreferences.is_registered:
        bpy.utils.register_class(ModifierGuardPreferences)
    p = get()
    if p is not None:
        apply(p)


def unregister():
    if ModifierGuardPreferences.is_registered:
        bpy.utils.unregister_class(ModifierGuardPreferences)

# SPDX-License-Identifier: GPL-3.0-or-later
"""モディファイアスタックの評価後ポリゴン数を、評価せずに推定する。

スタックを上から順にたどり、「面・ループ（頂点の角）・辺・頂点・表面積・
境界辺・寸法」の概算値を持ち回りながら、各モディファイアの効果を掛け合わせる。
値はすべてオブジェクトのローカル座標（スケール適用前）。
"""

import math
from dataclasses import dataclass, replace

import bmesh
import numpy as np
from mathutils import Vector


@dataclass
class MeshState:
    faces: float
    loops: float
    edges: float
    verts: float
    area: float = 0.0       # 表面積（リメッシュ用。必要なときだけ計算）
    boundary: float = 0.0   # 境界辺の数（厚み付け・ベベル用。必要なときだけ計算）
    sharp: float = 0.0      # ベベルの角度制限を超える辺の数
    weighted: float = 0.0   # ベベルウェイトが付いた辺の数
    junctions: float = 0.0  # 辺が3本以上集まる頂点の数（スキンの重さ用。必要なときだけ計算）
    approx: bool = False    # 高速推定（境界辺などが上限値）。上限値を引き算に使うと過小になるので区別する
    dims: Vector = None     # ローカルのバウンディングボックス寸法
    base: bool = True       # まだ元メッシュのままか（面の角度など、元メッシュから数えた値が使えるか）
    work: float = 0.0       # この段の処理の重さ（負荷。デシメートが設定し、_cost が読む）


# 推定の対象外（面数がほぼ変わらない or 予測不能）なものは ×1 として素通しする。
# ここに無い種類も ×1。
UNPREDICTABLE = {'NODES'}

NEEDS_AREA = {'REMESH'}
NEEDS_BOUNDARY = {'SOLIDIFY', 'BEVEL'}

# 曲面では等値面がボクセルを斜めに横切るぶん面が増えるので、過小評価しないよう補正
REMESH_FACTOR = 1.35


# ---------------------------------------------------------------- 元メッシュ

def _needs_dims(mods):
    for m in mods:
        if m.type == 'REMESH' and m.mode != 'VOXEL':
            return True
        if m.type == 'ARRAY' and m.fit_type != 'FIXED_COUNT':
            return True
    return False


def _base_state(obj, mods, exact):
    """元メッシュの状態を作る。

    exact=False のときは重い数え上げ（境界辺・鋭い辺）をせず、
    必ず実際以上になる上限値で代用する（＝過大側の高速推定）。
    表面積と寸法は上限値を作れないので、必要なときは常に計算する。
    """
    me = obj.data
    if obj.mode == 'EDIT' and me.is_editmode:
        # 編集モード中は obj.data が古いので、数だけ BMesh から取る
        bm = bmesh.from_edit_mesh(me)
        f, e, v = len(bm.faces), len(bm.edges), len(bm.verts)
        # 角の数は古いデータの「1面あたりの角数」から概算
        per_face = len(me.loops) / len(me.polygons) if len(me.polygons) else 4.0
        l = f * per_face
    else:
        f, l, e, v = len(me.polygons), len(me.loops), len(me.edges), len(me.vertices)

    st = MeshState(faces=f, loops=l, edges=e, verts=v)
    types = {m.type for m in mods}

    if 'SKIN' in types:
        # スキンは分岐点の数で重さが決まる。上限値（全頂点）だと大きすぎるので常に数える（辺だけの小さいメッシュが普通）。
        # 編集モード中も bm.verts の要素には触らず、古い obj.data で数える。BMesh の要素を Python から
        # 初めて触るとポインタ用のレイヤーが足され（BMesh を手放すと消され）、全頂点のデータブロックが
        # 確保し直される。Skin Resize（Ctrl+A）などのトランスフォームは頂点の CustomData を直接指しているので、
        # depsgraph のハンドラでこれをやると解放済みのメモリに書き込まれて Blender が落ちた
        if len(me.edges):
            ev = np.empty(len(me.edges) * 2, dtype=np.int32)
            me.edges.foreach_get('vertices', ev)
            st.junctions = float(np.count_nonzero(np.bincount(ev, minlength=len(me.vertices)) >= 3))

    if types & NEEDS_AREA and len(me.polygons):
        a = np.empty(len(me.polygons), dtype=np.float32)
        me.polygons.foreach_get('area', a)
        st.area = float(a.sum())

    if _needs_dims(mods) and len(me.vertices):
        co = np.empty(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get('co', co)
        co = co.reshape(-1, 3)
        st.dims = Vector((co.max(0) - co.min(0)).tolist())
    else:
        st.dims = Vector((0.0, 0.0, 0.0))

    bevel = next((m for m in mods if m.type == 'BEVEL'), None)
    if not exact:
        st.approx = True
        # 上限値：境界辺・鋭い辺・ウェイト辺はどれも「全辺」を超えない
        if types & NEEDS_BOUNDARY:
            st.boundary = e
        if bevel is not None:
            st.sharp = st.weighted = e
        return st

    # 境界辺・鋭い辺の数え上げは重いので、メッシュの構成が変わるまで使い回す
    key = (me.as_pointer(), len(me.polygons), len(me.loops), len(me.edges),
           len(me.vertices), round(bevel.angle_limit, 4) if bevel else None)
    cached = _exact_cache.get(key)
    if cached is None:
        boundary = sharp = weighted = 0.0
        if len(me.loops):
            ei = _corner_edges(me)
            counts = np.bincount(ei, minlength=len(me.edges))
            boundary = float(np.count_nonzero(counts == 1))
            if bevel is not None:
                sharp, weighted = _bevel_edges(me, bevel)
        if len(_exact_cache) > 256:
            _exact_cache.clear()
        cached = _exact_cache[key] = (boundary, sharp, weighted)
    st.boundary, st.sharp, st.weighted = cached
    return st


_exact_cache = {}


def _corner_edges(me):
    """角（ループ）ごとの辺の番号。内部の属性から直接読む（me.loops 経由の約 3 倍速い。100 万面 0.12 秒）。"""
    ei = np.empty(len(me.loops), dtype=np.int32)
    attr = me.attributes.get('.corner_edge')
    if attr is not None and attr.domain == 'CORNER' and attr.data_type == 'INT':
        attr.data.foreach_get('value', ei)
    else:
        me.loops.foreach_get('edge_index', ei)
    return ei


def _manifold_faces(me):
    """面がちょうど 2 枚の辺の番号と、その両側の面の番号、面の法線を返す。"""
    ei = _corner_edges(me)
    totals = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get('loop_total', totals)
    poly_of_loop = np.repeat(np.arange(len(me.polygons), dtype=np.int32), totals)
    normals = np.empty(len(me.polygons) * 3, dtype=np.float32)
    me.polygons.foreach_get('normal', normals)
    normals = normals.reshape(-1, 3)

    order = np.argsort(ei)  # 辺ごとに 2 枚の面が取れればよいので、安定ソートでなくてよい（2.5 倍速い）
    p_sorted = poly_of_loop[order]
    counts = np.bincount(ei, minlength=len(me.edges))
    starts = np.concatenate(([0], np.cumsum(counts)[:-1]))
    manifold = np.nonzero(counts == 2)[0]
    f1 = p_sorted[starts[manifold]]
    f2 = p_sorted[starts[manifold] + 1]
    return manifold, f1, f2, normals


def _bevel_edges(me, m):
    """元メッシュで、角度制限を超える辺とウェイト付きの辺を数える。"""
    manifold, f1, f2, normals = _manifold_faces(me)
    dots = np.einsum('ij,ij->i', normals[f1], normals[f2])
    sharp = float(np.count_nonzero(dots < math.cos(m.angle_limit)))

    weighted = 0.0
    attr = me.attributes.get('bevel_weight_edge')
    if attr is not None and attr.domain == 'EDGE':
        w = np.empty(len(me.edges), dtype=np.float32)
        attr.data.foreach_get('value', w)
        weighted = float(np.count_nonzero(w[manifold] > 0))
    return sharp, weighted


def _components(n, a, b):
    """面 n 枚を、辺 (a[i], b[i]) でつながった塊に分けたときの、面ごとの塊の番号。

    小さい番号へのつなぎ替えと、親のたどり直しを、つながりが変わらなくなるまで繰り返す
    （numpy だけで 100 万面 約 0.1 秒）。
    """
    parent = np.arange(n, dtype=np.int32)
    while True:
        pa, pb = parent[a], parent[b]
        m = pa != pb
        if not m.any():
            return parent
        a, b, pa, pb = a[m], b[m], pa[m], pb[m]
        parent[np.maximum(pa, pb)] = np.minimum(pa, pb)
        while True:
            pp = parent[parent]
            if np.array_equal(pp, parent):
                break
            parent = pp


def _dissolve_clusters(me, angle_limit):
    """平面（Limited Dissolve）で溶かされる辺の割合と、溶けてつながる面の塊の大きさの Σ 塊^2.5。

    両側の面の角度が制限より小さい辺を溶かすものとして数える（溶かした後の面の向きの変化や、
    区切り（Delimit）は見ないので、塊は実際以上＝過大側）。メッシュの構成と角度が変わるまで使い回す。
    """
    key = (me.as_pointer(), len(me.polygons), len(me.loops), len(me.edges), round(angle_limit, 4))
    cached = _dissolve_cache.get(key)
    if cached is not None:
        return cached
    p, s = 0.0, 0.0
    if len(me.polygons) and len(me.edges):
        manifold, f1, f2, normals = _manifold_faces(me)
        dots = np.einsum('ij,ij->i', normals[f1], normals[f2])
        flat = dots > math.cos(angle_limit)
        p = float(np.count_nonzero(flat)) / len(me.edges)
        sizes = np.bincount(_components(len(me.polygons), f1[flat], f2[flat])).astype(np.float64)
        s = float(np.sum(sizes ** 2.5))
    if len(_dissolve_cache) > 256:
        _dissolve_cache.clear()
    cached = _dissolve_cache[key] = (p, s)
    return cached


_dissolve_cache = {}


# ------------------------------------------------------------ 各モディファイア

def _quadify(st, levels):
    """サブディビジョン系：1段目で n 角形 → n 個の四角形、以降は ×4。"""
    if levels <= 0:
        return st
    f1 = st.loops
    e1 = 2 * st.edges + st.loops
    v1 = st.verts + st.edges + st.faces
    b1 = 2 * st.boundary
    k = 4 ** (levels - 1)
    f = f1 * k
    # 2段目以降は四角形メッシュなので 辺≈2F、頂点≈F（境界の分は無視できる）
    if levels == 1:
        e, v = e1, v1
    else:
        e, v = 2 * f + st.boundary * 2 ** levels, f + st.boundary * 2 ** levels
    # 細分化で角は丸まるので、角度制限ベベルの対象は元の鋭い辺に沿う分だけ残す
    return replace(st, faces=f, loops=4 * f, edges=e, verts=v, junctions=v,
                   boundary=b1 * 2 ** (levels - 1),
                   sharp=st.sharp * 0.5, weighted=st.weighted * 2 ** levels)


def _scale(st, k):
    return replace(st, faces=st.faces * k, loops=st.loops * k, edges=st.edges * k,
                   verts=st.verts * k, area=st.area * k, boundary=st.boundary * k,
                   sharp=st.sharp * k, weighted=st.weighted * k, junctions=st.junctions * k)


def _quad_grid(st, faces):
    """面数だけ分かっている四角形メッシュを作る（リメッシュ等の結果）。"""
    # 形状が作り直されるので、角度制限ベベルの対象は辺の1割と仮定
    return replace(st, faces=faces, loops=4 * faces, edges=2 * faces,
                   verts=faces, boundary=0.0, sharp=0.2 * faces, weighted=0.0, junctions=faces)


def _subsurf(obj, m, st):
    return _quadify(st, m.levels)


def _multires(obj, m, st):
    lv = m.sculpt_levels if obj.mode == 'SCULPT' else m.levels
    return _quadify(st, lv)


def _remesh(obj, m, st):
    if m.mode == 'VOXEL':
        vs = max(m.voxel_size, 1e-6)
        # 等値面は一辺 voxel_size の四角形でおおむね覆われる
        faces = REMESH_FACTOR * st.area / (vs * vs)
        if m.adaptivity > 0:
            faces *= max(0.05, 1.0 - m.adaptivity)  # 適応度で減る分（控えめ）
        return _quad_grid(st, faces)
    # BLOCKS / SMOOTH / SHARP：最大寸法を 2^depth * scale で割った格子
    maxd = max(st.dims)
    if maxd <= 0:
        return st
    cell = maxd / ((2 ** m.octree_depth) * max(m.scale, 1e-3))
    faces = REMESH_FACTOR * st.area / (cell * cell) if st.area else 6 * (2 ** m.octree_depth) ** 2
    return _quad_grid(st, faces)


def _array_count(obj, m, st):
    if m.fit_type == 'FIXED_COUNT':
        return max(m.count, 1)
    step = Vector((0.0, 0.0, 0.0))
    if m.use_relative_offset:
        step += Vector(tuple(a * b for a, b in zip(m.relative_offset_displace, st.dims)))
    if m.use_constant_offset:
        step += Vector(m.constant_offset_displace)
    length = step.length
    if length < 1e-6:
        return max(m.count, 1)
    if m.fit_type == 'FIT_LENGTH':
        target = m.fit_length
    else:  # FIT_CURVE：カーブの寸法の対角を長さの上限として使う（過大側）
        target = m.curve.dimensions.length if m.curve else 0.0
    return max(int(target / length) + 1, 1)


def _array(obj, m, st):
    n = _array_count(obj, m, st)
    out = _scale(st, n)
    for cap in (m.start_cap, m.end_cap):
        if cap is not None and cap.type == 'MESH':
            out.faces += len(cap.data.polygons)
            out.loops += len(cap.data.loops)
    return out


def _mirror(obj, m, st):
    k = 2 ** sum(1 for a in m.use_axis if a)
    return _scale(st, k)


def _screw(obj, m, st):
    k = max(m.steps, 1) * max(m.iterations, 1)
    faces = st.edges * k
    return _quad_grid(st, faces)


def _solidify(obj, m, st):
    rim = st.boundary if m.use_rim else 0.0
    if m.use_rim_only:
        faces = rim
    else:
        faces = 2 * st.faces + rim
    return replace(st, faces=faces, loops=2 * st.loops + 4 * rim,
                   edges=2 * st.edges + st.boundary * 2, verts=2 * st.verts,
                   area=st.area * 2, boundary=0.0 if m.use_rim else st.boundary * 2,
                   sharp=2 * st.sharp + 2 * rim, weighted=2 * st.weighted)


def _bevel(obj, m, st):
    s = max(m.segments, 1)
    if m.affect == 'VERTICES':
        add = st.verts * s * s
    else:
        if m.limit_method == 'ANGLE':
            eb = st.sharp
        elif m.limit_method == 'WEIGHT':
            eb = st.weighted
        elif st.approx:
            eb = st.edges  # 高速推定の boundary は上限値なので引かない（引くと過小になる）
        else:  # NONE / VGROUP（頂点グループは中身を見ないので全辺扱い＝過大側）
            eb = max(st.edges - st.boundary, 0.0)
        # 辺ごとに s 枚、角の継ぎ目に (価数 * s^2 / 4) 枚 → 合計 eb * s^2 / 2
        add = eb * s + eb * s * s / 2
    return replace(st, faces=st.faces + add, loops=st.loops + 4 * add,
                   edges=st.edges + 2 * add, verts=st.verts + add,
                   sharp=0.0, weighted=0.0)


def _decimate(obj, m, st):
    """面数は減るが、処理そのものが重い（1 スレッドで動く）。重さは work に入れて _cost で使う。

    重さの式は tests/bench_decimate.py の実測（i7-13700F、Blender 5.2.0）から。
    単位は COST_WEIGHTS と同じくサブディビジョンの出力 1 面（このマシンで約 33ns）。
    1 面あたりの重さは面数とともに少しずつ増える（メモリに収まらなくなる）ので、100 万面を基準に補正する。
    """
    n = max(st.faces, 1.0)
    size = n / 1e6
    if m.decimate_type == 'COLLAPSE':
        r = min(max(m.ratio, 0.0), 1.0)
        if r >= 1.0:
            return replace(st, base=False, work=0.0)  # 比率 1 は何もしない
        # 比率は三角形の数に掛かる（四角形 1 枚は 2 枚と数える）。実測：比率 0.1 → 面数 0.19
        tris = max(st.loops - 2 * st.faces, st.faces)
        out = _scale(st, min(r * tris / n, 1.0))
        # 実測（100 万面）：比率 0.9 → 62、0.5 → 145、0.1 → 225、0.01 → 245（入力 1 面あたり）
        work = n * (40.0 + 210.0 * (1.0 - r)) * size ** 0.18 * _f('DECIMATE_COLLAPSE')
        return replace(out, base=False, work=work)
    if m.decimate_type == 'UNSUBDIV':
        it = max(m.iterations, 0)
        if it == 0:
            return replace(st, base=False, work=0.0)
        # 細分化で作ったメッシュなら 1 回で 1/4 になるが、普通のメッシュは 1/2 ずつしか減らない
        out = _scale(st, min(1.4 * 0.5 ** it, 1.0))
        # 実測（100 万面）：1 回 → 29、2 回 → 38、5 回 → 49（2 回目以降は半分ずつの面数を処理する）
        work = n * 31.0 * (2.0 - 0.5 ** (it - 1)) * size ** 0.1 * _f('DECIMATE_UNSUBDIV')
        return replace(out, base=False, work=work)
    # DISSOLVE（平面）：減る量は読めないので面数は ×1。
    # Blender は角度の小さい辺から順に面をつなぎ、つないだ面の辺をすべて計算し直す。つながって大きくなった
    # 面ほど 1 回が重くなるので、溶けてつながる塊が大きいと 塊^2 以上で重くなる（実測で ^2.5 前後）。
    # 平らな面の集まり（CAD）・凹凸やノイズのある面（スキャン・スカルプト）で起きる。6 万面で 13〜44 秒、
    # 25 万面で何分も固まった。溶かす辺が 3 割ほどまでなら塊がつながらず、面数にほぼ比例（25 万面 0.3 秒）。
    # なめらかな曲面だけは大きな塊でもほぼ比例（25 万面 1.2 秒）だが、見分けられないので重い側に倒す
    lim = m.angle_limit
    if lim <= 0.0:
        return replace(st, base=False, work=0.0)
    if st.base and not st.approx:
        p, clusters = _dissolve_clusters(obj.data, lim)
    else:
        # 前のモディファイアで形が変わっている・高速推定：全部が 1 つの塊になるとみなす（上限値）
        p, clusters = 1.0, n ** 2.5
    # 比例する分の実測（25 万面）：溶かす辺 11% → 36、23% → 80、100% → 125〜148（入力 1 面あたり）
    linear = n * (5.0 + 250.0 * size ** 0.45 * p ** 0.4)
    work = (linear + PLANAR_CLUSTER_COST * clusters) * _f('DECIMATE_PLANAR')
    return replace(st, base=False, work=work)


# 平面の、溶けてつながる塊の Σ 塊^2.5 に掛ける重さ。実測で 平らな格子 4e-4〜1.5e-3（つなぐ順番しだいで
# 何倍も変わる）、凹凸のある球 1e-4〜1e-3、細かいノイズの面 2e-3〜1.5e-2、なめらかな曲面 1e-6。
# ノイズの強いものは軽めに見積もるが、なめらかなものを止めすぎないよう間を取る
# （待てる時間 2 秒・上限 3,000 万なら、1 つの塊が 1.2 万面ほどで止まる）
PLANAR_CLUSTER_COST = 2e-3


def _triangulate(obj, m, st):
    tris = st.loops - 2 * st.faces
    return replace(st, faces=tris, loops=3 * tris, edges=st.edges + (tris - st.faces))


def _wireframe(obj, m, st):
    faces = 4 * st.edges + (0 if m.use_replace else st.faces)
    return _quad_grid(st, faces)


def _skin(obj, m, st):
    return _quad_grid(st, 8 * st.verts)


def _boolean(obj, m, st):
    add = 0
    if m.operand_type == 'OBJECT':
        if m.object is not None and m.object.type == 'MESH':
            add = len(m.object.data.polygons)
    elif m.collection is not None:
        add = sum(len(o.data.polygons) for o in m.collection.all_objects if o.type == 'MESH')
    return replace(st, faces=st.faces + add, loops=st.loops + 4 * add,
                   edges=st.edges + 2 * add, verts=st.verts + add)


ESTIMATORS = {
    'SUBSURF': _subsurf,
    'MULTIRES': _multires,
    'REMESH': _remesh,
    'ARRAY': _array,
    'MIRROR': _mirror,
    'SCREW': _screw,
    'SOLIDIFY': _solidify,
    'BEVEL': _bevel,
    'DECIMATE': _decimate,
    'TRIANGULATE': _triangulate,
    'WIREFRAME': _wireframe,
    'SKIN': _skin,
    'BOOLEAN': _boolean,
}

# 評価の重さ（「負荷」）の重み。単位はサブディビジョンの出力 1 面の評価時間（実測 約 58ns）。
# 負荷 = max(出力面数, 入力の重み × 入力面数 + 出力の重み × 出力面数)。
# 出力面数を下限にするのは、描画とメモリの分は種類によらずかかるため（軽い種類も 1 未満にしない）。
# ここに無い種類（ミラー・配列・厚み付け・スクリューなど、実測で ×1 前後）は負荷 = 出力面数。
# 値は tests/bench_cost.py の実測（Apple Silicon 10 コア、bpy 5.2.2）から。
COST_WEIGHTS = {
    'SUBSURF': (20.0, 1.0),     # 密な入力は細分化の下準備が重い（入力 1 面 約 0.7〜1.5µs）
    'MULTIRES': (20.0, 1.0),
    'BEVEL': (6.0, 20.0),       # 出力 1 面 約 0.8〜1.2µs
    'REMESH': (12.0, 4.0),
    'WIREFRAME': (0.0, 4.0),
    'TRIANGULATE': (8.0, 0.0),
}
BOOLEAN_COST = {'EXACT': 130.0, 'FLOAT': 13.0, 'MANIFOLD': 1.5}  # 出力 1 面あたり（ソルバーで大きく違う）
SKIN_JUNCTION_COST = 400.0  # 分岐点数の 2 乗あたり（格子で実測。辺の連なりはほぼ 0）


# マシンごとの補正倍率（Calibrate が測ってプリファレンスに保存し、prefs.apply で入れる）。
# 上の重みは 10 スレッドのマシンで測った値。並列にならない種類（ベベル・ワイヤーフレーム・三角化・
# ブーリアン）はコア数で基準のサブディビジョンとの比が大きく変わる（1 スレッドだと 1/3〜1/4）ので補正する。
# キー: 'SUBSURF_IN'（サブディビジョン・マルチレゾの入力分だけ）、'BEVEL'、'REMESH'、'WIREFRAME'、
#       'TRIANGULATE'、'BOOLEAN_EXACT'、'BOOLEAN_FLOAT'、'SKIN'、
#       'DECIMATE_COLLAPSE'、'DECIMATE_UNSUBDIV'、'DECIMATE_PLANAR'（この 3 つの基準は i7-13700F）。無いものは 1。
COST_FACTORS = {}


def _f(key):
    return COST_FACTORS.get(key, 1.0)


def heavy_while_reducing(m, before_faces, cost):
    """面数を減らす（増やさない）のに、処理そのものが重い段か（ガードが止める対象にするか）。"""
    return m.type == 'DECIMATE' and cost > before_faces


def _cost(m, before, after):
    """1 段の負荷（サブディビジョン換算の面数）。before / after は MeshState。"""
    t = m.type
    if t == 'SKIN':
        return max(after.faces, SKIN_JUNCTION_COST * _f('SKIN') * before.junctions ** 2)
    if t == 'BOOLEAN':
        solver = getattr(m, 'solver', 'EXACT')
        w = BOOLEAN_COST.get(solver, 130.0) * _f('BOOLEAN_' + solver)
        return max(after.faces, w * after.faces)
    if t == 'DECIMATE':
        return max(after.faces, after.work)
    w = COST_WEIGHTS.get(t)
    if w is None:
        return after.faces
    if t in {'SUBSURF', 'MULTIRES'}:
        wi, wo = w[0] * _f('SUBSURF_IN'), w[1]  # 出力 1 面は基準そのものなので補正しない
    else:
        k = _f(t)
        wi, wo = w[0] * k, w[1] * k
    return max(after.faces, wi * before.faces + wo * after.faces)


# 面数に効く設定（各推定式が読んでいるもののうち、数値・列挙・真偽値）。
# 「戻す」で止まる直前の値に戻すときに使う。オブジェクト参照（配列のキャップ、
# ブーリアンの相手など）は Undo で無効になるので含めない。
SETTINGS_PROPS = {
    'SUBSURF': ('levels',),
    'MULTIRES': ('levels', 'sculpt_levels'),
    'REMESH': ('mode', 'voxel_size', 'adaptivity', 'octree_depth', 'scale'),
    'ARRAY': ('fit_type', 'count', 'fit_length', 'use_relative_offset',
              'relative_offset_displace', 'use_constant_offset', 'constant_offset_displace'),
    'MIRROR': ('use_axis',),
    'SCREW': ('steps', 'iterations'),
    'SOLIDIFY': ('use_rim', 'use_rim_only'),
    'BEVEL': ('affect', 'segments', 'limit_method', 'angle_limit'),
    'DECIMATE': ('decimate_type', 'ratio', 'iterations', 'angle_limit'),
    'WIREFRAME': ('use_replace',),
    'BOOLEAN': ('operand_type',),
}


# ------------------------------------------------------------------- 公開 API

def is_active_in_viewport(obj, m):
    if not m.show_viewport:
        return False
    if obj.mode == 'EDIT' and not m.show_in_editmode:
        return False
    return True


def would_be_active(obj, m):
    """ビューポート表示をオンにしたら評価されるか（編集モード表示の設定を見る）。"""
    return not (obj.mode == 'EDIT' and not m.show_in_editmode)


class Overridden:
    """一部のプロパティだけ別の値に見せるモディファイアの代理（アニメーション・ドライバー用）。

    読み出しは overrides を優先し、それ以外と書き込みは本物のモディファイアに回す。
    """
    __slots__ = ('modifier', 'values')

    def __init__(self, modifier, values):
        object.__setattr__(self, 'modifier', modifier)
        object.__setattr__(self, 'values', values)

    def __getattr__(self, name):
        values = object.__getattribute__(self, 'values')
        if name in values:
            return values[name]
        return getattr(object.__getattribute__(self, 'modifier'), name)

    def __setattr__(self, name, value):
        setattr(self.modifier, name, value)


def estimate_stack(obj, skip=(), exact=True, extra=(), nodes_factor=1.0, overrides=None):
    """有効なモディファイアごとの (modifier, 適用前の面数, 適用後の面数, 負荷) を返す。

    skip に入っている名前のモディファイアは無いものとして計算する。
    extra に入っている名前のモディファイアは、表示がオフでもオンとして計算する。
    exact=False なら重い数え上げを省いた過大側の高速推定。
    nodes_factor は最初のジオメトリノードに掛ける倍率（前回の評価で実測したもの。既定は ×1）。
    overrides（{モディファイア名: {プロパティ: 値}}）があれば、その値で推定する。
    """
    mods = [m for m in obj.modifiers
            if (is_active_in_viewport(obj, m) or (m.name in extra and would_be_active(obj, m)))
            and m.name not in skip]
    if overrides:
        mods = [Overridden(m, overrides[m.name]) if m.name in overrides else m for m in mods]
    nodes = nodes_factor != 1.0 and any(m.type == 'NODES' for m in mods)
    if not nodes and not any(m.type in ESTIMATORS for m in mods):
        return []  # 面数を変えるモディファイアが無ければ何もしない
    st = _base_state(obj, mods, exact)
    steps = []
    for m in mods:
        prev = st
        fn = ESTIMATORS.get(m.type)
        if m.type == 'NODES' and nodes:
            st = _scale(st, nodes_factor)
            nodes = False  # 実測倍率はスタック全体のジオメトリノードの分なので1回だけ
        elif fn is not None:
            try:
                st = fn(obj, m, st)
            except Exception:  # 想定外の設定でも推定全体は止めない
                pass
        steps.append((m, prev.faces, st.faces, _cost(m, prev, st)))
        if st.base or st.work:
            # 変形だけのモディファイアでも面の角度は変わるので、どれかを通ったら元メッシュの値は使わない
            st = replace(st, base=False, work=0.0)
    return steps


def read_settings(m):
    """面数に効く設定を {プロパティ名: 値} で返す（配列系はタプルにする）。"""
    out = {}
    for p in SETTINGS_PROPS.get(m.type, ()):
        v = getattr(m, p, None)
        if v is None:
            continue
        if not isinstance(v, (int, float, str, bool)):
            v = tuple(v)
        out[p] = v
    return out


def apply_settings(m, settings):
    """read_settings で取った値を書き戻す。書けなかった項目名のリストを返す。"""
    failed = []
    for p, v in settings.items():
        try:
            setattr(m, p, v)
        except (AttributeError, TypeError, ValueError, RuntimeError):
            failed.append(p)
    return failed


def estimate_faces(obj, exact=True):
    steps = estimate_stack(obj, exact=exact)
    if steps:
        return steps[-1][2]
    return len(obj.data.polygons)

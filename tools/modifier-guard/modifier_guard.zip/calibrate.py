# SPDX-License-Identifier: GPL-3.0-or-later
"""負荷の上限（Load Limit）の自動調整：このマシンと今のシーンで、待てる時間に収まる面数を測る。

1. 今のシーンを再描画する時間（＝シーンの重さ）を測る
2. 一時的なテスト用オブジェクト（モンキー＋サブディビジョン）をシーンに入れ、レベルを上げながら
   「評価の時間」と「追加の描画時間」を分けて測る（1段が STEP_BUDGET 秒を超えたらそこで止める）。
   同じオブジェクトでレベルを上げると細分化の下準備が使い回されて速く出る（実測 16 vs 47 ns/面）ので、
   段ごとに新しいオブジェクトを作る（estimate.COST_WEIGHTS を測った条件と揃える）
3. 上限 L は  シーンの再描画 + L × (評価/面 + 描画/面) ≦ 待てる時間
   と、メモリの残り（搭載メモリの RAM_FRACTION − 今のシーンの面数）の小さい方

上限の単位は「サブディビジョン換算の面数」（負荷）。種類による評価時間の違いはガード側の
estimate.COST_WEIGHTS で負荷に換算済みなので、ここではサブディビジョンで測った値をそのまま使う。
負荷 ≧ 出力面数なので、描画の分も L × 描画/面 で抑えられる。

測定は measure_steps で 1 段ずつ進める（段の合間に画面を更新して進捗を出し、Esc で止められるように）。

4. 種類ごとの補正（PROBES）：重みは 10 スレッドのマシンで測ったもので、並列にならない種類は
   コア数で比が大きく変わる。各種類を固定サイズで 1 回ずつ評価し（描画はしない）、
   このマシンでの負荷 ÷ 基準のマシンでの負荷（PROBE_REF）× PROBE_MARGIN を estimate.COST_FACTORS に入れる。
"""

import math
import subprocess
import sys
import time
from dataclasses import dataclass

import bmesh
import bpy
import numpy as np

from . import estimate, guard

BYTES_PER_FACE = 300     # 評価後メッシュ＋描画用バッファの 1 面あたりのメモリ（概算）
RAM_FRACTION = 0.25      # シーン全体で使ってよい搭載メモリの割合
STEP_BUDGET = 0.5        # 測定 1 段の上限（秒）。これを超えたらレベルを上げない
LEVELS = (3, 4, 5, 6, 7)  # 測定するサブディビジョンのレベル（7 で約 806 万面）
PROBE_MARGIN = 1.1       # 測定のぶれに対する余裕（重めに見積もる。重みの表にも余裕がある）
FACTOR_RANGE = (0.1, 10.0)
MIN_LIMIT = 100_000
MAX_LIMIT = 100_000_000

TEST_NAME = "Modifier Guard Calibration"


@dataclass
class Result:
    limit: int
    base: float            # シーンの再描画（秒）
    eval_per_face: float   # 秒/面（サブディビジョン）
    draw_per_face: float   # 秒/面
    scene_faces: int
    by_time: int
    by_memory: int
    factors: dict = None   # 種類ごとの補正倍率（estimate.COST_FACTORS に入れる）

    @property
    def sec_per_load(self):
        """負荷 1 あたりの秒数（評価＋描画）。負荷を待ち時間に直すのに使う。"""
        return self.eval_per_face + self.draw_per_face


def _round_down(n):
    """有効数字 2 桁に切り捨て（1,234,567 → 1,200,000）。"""
    if n <= 0:
        return 0
    p = 10 ** max(int(math.log10(n)) - 1, 0)
    return int(n // p * p)


def limit_for(target, base, sec_per_load, by_memory):
    """待てる時間に収まる上限と、時間だけで決まる上限 (上限, by_time) を返す。

    Calibrate の結果を残しておけば、待てる時間を変えたときに測り直さずに上限を出し直せる。
    """
    by_time = (target - base) / sec_per_load
    limit = _round_down(min(by_time, by_memory))
    return int(min(max(limit, MIN_LIMIT), MAX_LIMIT)), int(max(by_time, 0))


def seconds_for(load, base, sec_per_load):
    """負荷 load のモディファイアを表示したときの待ち時間の目安（秒）。シーンの再描画を含む。"""
    return base + load * sec_per_load


def compute_limit(base, samples, scene_faces, ram_bytes, target):
    """測定値から上限を決める。samples は [(面数, 評価秒, 追加の描画秒)]（面数の昇順）。"""
    faces, e, d = max(samples, key=lambda s: s[0])
    # 一番大きい測定で 1 面あたりを出す（小さいと固定のオーバーヘッドが効いて過大になる＝安全側）
    k_eval = max(e, 1e-6) / faces
    k_draw = max(d, 0.0) / faces
    by_memory = int(max(ram_bytes * RAM_FRACTION / BYTES_PER_FACE - scene_faces, 0))
    limit, by_time = limit_for(target, base, k_eval + k_draw, by_memory)
    return Result(limit=limit, base=base,
                  eval_per_face=k_eval, draw_per_face=k_draw, scene_faces=int(scene_faces),
                  by_time=by_time, by_memory=by_memory)


def ram_bytes():
    """搭載メモリ（バイト）。macOS は sysctl、Windows は GlobalMemoryStatusEx、Linux は sysconf。"""
    try:
        if sys.platform == 'darwin':
            return int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], timeout=2))
        if sys.platform == 'win32':
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
                return int(stat.ullTotalPhys)
        else:
            import os
            return os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
    except Exception:
        pass
    return 8 * 2 ** 30  # 分からなければ 8GB とみなす


def scene_faces(context):
    """今表示しているメッシュの面数の合計。GPU サブディビジョンが最後のものは推定値を使う。"""
    dg = context.evaluated_depsgraph_get()
    gpu_subdiv = context.preferences.system.use_gpu_subdivision
    total = 0
    for ob in context.view_layer.objects:
        if ob.type != 'MESH' or not ob.visible_get():
            continue
        active = [m for m in ob.modifiers if m.show_viewport]
        if gpu_subdiv and active and active[-1].type in {'SUBSURF', 'MULTIRES'}:
            total += int(estimate.estimate_faces(ob))  # 数えると CPU で細分化が走る
        else:
            total += len(ob.evaluated_get(dg).data.polygons)
    return total


def redraw_time(context):
    """ウィンドウ全体を 1 回再描画する時間（秒）。テストではこの関数を差し替える。"""
    t = time.perf_counter()
    bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    return time.perf_counter() - t


def _make_test_object(context, level):
    me = bpy.data.meshes.new(TEST_NAME)
    bm = bmesh.new()
    bm.loops.layers.uv.new("UVMap")  # 実際のモデルと同じく UV 付き（UV の補間も評価時間に効く）
    bmesh.ops.create_monkey(bm, calc_uvs=True)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(TEST_NAME, me)
    ob.location = context.scene.cursor.location
    context.scene.collection.objects.link(ob)
    sub = ob.modifiers.new("Subdivision", 'SUBSURF')
    sub.levels = level
    # 最後に軽いモディファイアを置いて GPU サブディビジョンを通らないようにする（CPU の評価を測る）
    disp = ob.modifiers.new("Keep CPU", 'DISPLACE')
    disp.strength = 0.0
    return ob


def _remove(ob):
    me = ob.data
    bpy.data.objects.remove(ob)
    if me.users == 0:
        bpy.data.meshes.remove(me)


def measure_steps(target):
    """測定を 1 段ずつ進めるジェネレーター。(進み具合 0〜1, これから測るものの説明) を yield し、
    最後に Result を返す（StopIteration.value）。テスト用オブジェクトは段の中で必ず消す。

    段の合間に呼び出し側（モーダルオペレーター）へ戻るので、そのあいだに画面が更新される。
    オペレーターの context は呼び出しの間しか使えないので、段ごとに bpy.context から取り直す。
    """
    total = 1 + len(LEVELS) + len(PROBES)
    yield 0.0, "Measuring the scene redraw"
    context = bpy.context
    ram = ram_bytes()
    faces_now = scene_faces(context)
    base = min(redraw_time(context) for _ in range(2))
    samples = []
    for i, level in enumerate(LEVELS):
        yield (1 + i) / total, f"Measuring Subdivision (level {level})"
        context = bpy.context
        with guard.paused():
            ob = _make_test_object(context, level)
            try:
                t = time.perf_counter()
                dg = context.evaluated_depsgraph_get()
                faces = len(ob.evaluated_get(dg).data.polygons)
                e = time.perf_counter() - t
                d = max(redraw_time(context) - base, 0.0)
            finally:
                _remove(ob)
                context.evaluated_depsgraph_get()  # テスト用オブジェクトを消した状態で段を終える
        samples.append((faces, e, d))
        # 次の段は約4倍の面数。STEP_BUDGET を超えそう、またはメモリが足りなければ止める
        if (e + d) * 4 > STEP_BUDGET or (faces_now + faces * 4) * BYTES_PER_FACE > ram * RAM_FRACTION:
            break
    res = compute_limit(base, samples, faces_now, ram, target)
    res.factors = {}
    for i, probe in enumerate(PROBES):
        yield (1 + len(LEVELS) + i) / total, f"Measuring {PROBE_LABELS.get(probe[0], probe[0])}"
        context = bpy.context
        with guard.paused():
            try:
                f = _probe_factor(context, probe, res.eval_per_face)
            finally:
                context.evaluated_depsgraph_get()
        if f is not None:
            res.factors[probe[0]] = f
    return res


def measure(context, target):
    """測定して Result を返す（一度に最後まで。context は bpy.context と同じ文脈で呼ぶこと）。"""
    steps = measure_steps(target)
    while True:
        try:
            next(steps)
        except StopIteration as done:
            return done.value


# --------------------------------------------------------- 種類ごとの補正

# 測定用メッシュは numpy で頂点と面を直接作る（bmesh.ops.create_uvsphere は細かいと押し出しを何百回も
# 繰り返して 1 分以上かかった）

def _new_mesh(co, loops, sizes):
    me = bpy.data.meshes.new(TEST_NAME)
    me.vertices.add(len(co))
    me.vertices.foreach_set('co', np.asarray(co, dtype=np.float32).ravel())
    me.loops.add(len(loops))
    me.loops.foreach_set('vertex_index', np.asarray(loops, dtype=np.int32))
    me.polygons.add(len(sizes))
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1])).astype(np.int32)
    me.polygons.foreach_set('loop_start', starts)
    me.update(calc_edges=True)
    return me


def _grid(n, uvs=False):
    """n × n 面の平面グリッド（一辺 2）。"""
    t = np.linspace(-1.0, 1.0, n + 1)
    x, y = np.meshgrid(t, t)
    co = np.stack([x.ravel(), y.ravel(), np.zeros(x.size)], axis=1)
    idx = np.arange((n + 1) ** 2).reshape(n + 1, n + 1)
    quads = np.stack([idx[:-1, :-1], idx[:-1, 1:], idx[1:, 1:], idx[1:, :-1]], axis=-1).reshape(-1, 4)
    me = _new_mesh(co, quads.ravel(), np.full(len(quads), 4))
    if uvs:
        uv = me.uv_layers.new(name="UVMap")
        uv.data.foreach_set('uv', ((co[quads.ravel(), :2] + 1.0) / 2.0).astype(np.float32).ravel())
    return me


def _sphere(seg):
    """経線 seg 本・緯線 seg/2 本の UV 球（半径 1）。"""
    u, v = seg, max(seg // 2, 3)
    theta = np.linspace(0, np.pi, v + 1)[1:-1]
    phi = np.linspace(0, 2 * np.pi, u, endpoint=False)
    th, ph = np.meshgrid(theta, phi, indexing='ij')
    ring = np.stack([np.sin(th) * np.cos(ph), np.sin(th) * np.sin(ph), np.cos(th)], axis=-1).reshape(-1, 3)
    co = np.vstack([ring, [[0, 0, 1], [0, 0, -1]]])
    top, bottom = len(ring), len(ring) + 1
    idx = np.arange(len(ring)).reshape(v - 1, u)
    nxt = np.roll(idx, -1, axis=1)
    quads = np.stack([idx[:-1], nxt[:-1], nxt[1:], idx[1:]], axis=-1).reshape(-1, 4)
    tris_top = np.stack([np.full(u, top), nxt[0], idx[0]], axis=-1)
    tris_bot = np.stack([np.full(u, bottom), idx[-1], nxt[-1]], axis=-1)
    loops = np.concatenate([quads.ravel(), tris_top.ravel(), tris_bot.ravel()])
    sizes = np.concatenate([np.full(len(quads), 4), np.full(2 * u, 3)])
    return _new_mesh(co, loops, sizes)


def _edge_grid(n):
    """面の無い、辺だけの n × n グリッド（スキン用。内側の頂点はすべて分岐点）。"""
    t = np.linspace(-1.0, 1.0, n + 1)
    x, y = np.meshgrid(t, t)
    co = np.stack([x.ravel(), y.ravel(), np.zeros(x.size)], axis=1)
    idx = np.arange((n + 1) ** 2).reshape(n + 1, n + 1)
    edges = np.vstack([np.stack([idx[:, :-1].ravel(), idx[:, 1:].ravel()], axis=1),
                       np.stack([idx[:-1, :].ravel(), idx[1:, :].ravel()], axis=1)])
    me = bpy.data.meshes.new(TEST_NAME)
    me.vertices.add(len(co))
    me.vertices.foreach_set('co', co.astype(np.float32).ravel())
    me.edges.add(len(edges))
    me.edges.foreach_set('vertices', edges.astype(np.int32).ravel())
    me.update()
    return me


def _junctions(me):
    ev = np.empty(len(me.edges) * 2, dtype=np.int32)
    me.edges.foreach_get('vertices', ev)
    return int(np.count_nonzero(np.bincount(ev, minlength=len(me.vertices)) >= 3))


def _boolean(solver):
    def setup(context, ob):
        cutter_me = bpy.data.meshes.new(TEST_NAME + " Cutter")
        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.2)
        bmesh.ops.translate(bm, verts=bm.verts, vec=(0.6, 0.0, 0.0))
        bm.to_mesh(cutter_me)
        bm.free()
        cutter = bpy.data.objects.new(TEST_NAME + " Cutter", cutter_me)
        context.scene.collection.objects.link(cutter)
        cutter.hide_viewport = True
        m = ob.modifiers.new("Probe", 'BOOLEAN')
        m.object = cutter
        m.solver = solver
        return [cutter]
    return setup


def _mod(type_, **props):
    def setup(context, ob):
        m = ob.modifiers.new("Probe", type_)
        for k, v in props.items():
            setattr(m, k, v)
        return []
    return setup


# (キー, メッシュを作る関数, サイズ, モディファイアを付ける関数)。サイズは基準のマシンで約 0.1〜0.15 秒になる固定値。
# 小さいメッシュほど 1 面あたりが速く出る（キャッシュに収まる）ので、サイズを変えずに基準のマシンと比べる
PROBES = (
    ('SUBSURF_IN', lambda n: _grid(n, uvs=True), 400, _mod('SUBSURF', levels=1)),
    ('BEVEL', _grid, 100, _mod('BEVEL', segments=4, limit_method='NONE')),
    ('REMESH', lambda n: _sphere(32), 0.005, None),
    ('WIREFRAME', _grid, 400, _mod('WIREFRAME')),
    ('TRIANGULATE', _grid, 800, _mod('TRIANGULATE')),
    ('BOOLEAN_EXACT', _sphere, 384, _boolean('EXACT')),
    ('BOOLEAN_FLOAT', _sphere, 768, _boolean('FLOAT')),
    ('SKIN', _edge_grid, 9, _mod('SKIN')),
)

PROBE_LABELS = {
    'SUBSURF_IN': "Subdivision (dense input)", 'BEVEL': "Bevel", 'REMESH': "Remesh",
    'WIREFRAME': "Wireframe", 'TRIANGULATE': "Triangulate", 'BOOLEAN_EXACT': "Boolean (Exact)",
    'BOOLEAN_FLOAT': "Boolean (Float)", 'SKIN': "Skin",
}

# 基準のマシン（estimate.COST_WEIGHTS を測った Apple Silicon 10 コア）での各プローブの負荷
# （評価時間 ÷ サブディビジョン出力 1 面の時間。SUBSURF_IN は出力の分を引いた入力の分）。
# tests/calibrate_reference.py で測り直せる
# 電源接続・発熱なしの状態で 5 回（別プロセス）の中央値。ばらつきは ±10% 程度
# （発熱で性能が落ちると全体が 2 倍近く遅く出る。測り直すときは冷えた状態で）
PROBE_REF = {
    'SUBSURF_IN': 2017686,
    'BEVEL': 2444011,
    'REMESH': 2603398,
    'WIREFRAME': 3261354,
    'TRIANGULATE': 3331553,
    'BOOLEAN_EXACT': 3382703,
    'BOOLEAN_FLOAT': 2026625,
    'SKIN': 2070721,
}


def _probe_once(context, make_mesh, size, setup):
    me = make_mesh(size)
    ob = bpy.data.objects.new(TEST_NAME, me)
    context.scene.collection.objects.link(ob)
    extra = []
    try:
        if setup is None:  # リメッシュ：size はボクセルサイズ
            m = ob.modifiers.new("Probe", 'REMESH')
            m.mode = 'VOXEL'
            m.voxel_size = size
        else:
            extra = setup(context, ob)
        disp = ob.modifiers.new("Keep CPU", 'DISPLACE')
        disp.strength = 0.0
        faces_in = len(me.polygons)
        junctions = _junctions(me) if len(me.edges) else 0
        context.evaluated_depsgraph_get()  # 補助オブジェクトなどの準備を測定から外すため、先に一度…
        ob.modifiers["Probe"].show_viewport = False
        context.evaluated_depsgraph_get()  # …モディファイア無しで評価しておく
        ob.modifiers["Probe"].show_viewport = True
        t = time.perf_counter()
        dg = context.evaluated_depsgraph_get()
        faces_out = len(ob.evaluated_get(dg).data.polygons)
        dt = time.perf_counter() - t
    finally:
        for o in [ob] + extra:
            _remove(o)
    return dt, faces_in, faces_out, junctions


def _probe_units(context, probe, unit):
    """1 つのプローブの負荷（サブディビジョン換算）。unit はサブディビジョンの出力 1 面の評価時間（秒）。"""
    key, make_mesh, size, setup = probe
    dt, fi, fo, j = _probe_once(context, make_mesh, size, setup)
    units = dt / max(unit, 1e-12)
    if key == 'SUBSURF_IN':
        units -= fo  # 出力 1 面 = 1 の分を除いた入力の分
    return max(units, 0.0)


def _probe_factor(context, probe, unit):
    """1 つのプローブの補正倍率 = このマシンでの負荷 ÷ 基準のマシンでの負荷 × 余裕。基準が無ければ None。"""
    ref = PROBE_REF.get(probe[0])
    if not ref:
        return None
    f = _probe_units(context, probe, unit) / ref * PROBE_MARGIN
    return round(min(max(f, FACTOR_RANGE[0]), FACTOR_RANGE[1]), 3)


def probe_units(context, unit):
    """各プローブの負荷（サブディビジョン換算）{キー: 負荷}。unit はサブディビジョンの出力 1 面の評価時間（秒）。"""
    return {probe[0]: _probe_units(context, probe, unit) for probe in PROBES}


def measure_factors(context, unit):
    """種類ごとの補正倍率 {キー: 倍率}。"""
    factors = {}
    for probe in PROBES:
        f = _probe_factor(context, probe, unit)
        if f is not None:
            factors[probe[0]] = f
    return factors


def find_view3d_window(context):
    """3D ビューを含むウィンドウ（プリファレンスのウィンドウから押されたときのため）。"""
    wins = [context.window] if context.window else []
    wins += [w for w in context.window_manager.windows if w not in wins]
    for w in wins:
        if any(a.type == 'VIEW_3D' for a in w.screen.areas):
            return w
    return None

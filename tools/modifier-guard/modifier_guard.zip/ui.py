# SPDX-License-Identifier: GPL-3.0-or-later
"""停止の通知（ステータスバー＋3Dビューのバナー）と、サイドバーの管理パネル。"""

import json
import time

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.props import BoolProperty, IntProperty, StringProperty

from . import calibrate, estimate, guard, prefs


def _changes(obj, name):
    """「戻す」で変わる設定を 'levels 8 → 5' の形で返す。"""
    m = obj.modifiers.get(name) if obj else None
    snap = guard.restore_settings(obj, name) if obj else None
    if m is None or snap is None:
        return []
    out = []
    for p, v in snap.items():
        cur = getattr(m, p, None)
        if cur is not None and not isinstance(cur, (int, float, str, bool)):
            cur = tuple(cur)
        if cur != v:
            out.append(f"{p} {_fmt(cur)} → {_fmt(v)}")
    return out


def _fmt(v):
    if isinstance(v, float):
        return f"{v:.4g}"
    if isinstance(v, tuple):
        return "(" + ", ".join(_fmt(x) for x in v) + ")"
    return str(v)


# ------------------------------------------------------------- 負荷の表示
# 負荷（サブディビジョン換算の面数）は数字だけだと重さが伝わらないので、Calibrate の結果があれば
# 「表示に何秒かかるか」に直して見せる。無ければ 12.3M のように短くして見せる。

def short_count(n):
    """12,345,678 → '12.3M'、850,000 → '850K'。"""
    n = int(n)
    if n >= 10 ** 9:
        return f"{n / 1e9:.1f}B"
    if n >= 10 ** 7:
        return f"{n / 1e6:.0f}M"
    if n >= 10 ** 6:
        return f"{n / 1e6:.1f}M"
    if n >= 10 ** 4:
        return f"{n / 1e3:.0f}K"
    return f"{n:,}"


def short_seconds(s):
    if s >= 3600:
        return "over 1 h"
    if s >= 60:
        return f"{s / 60:.0f} min"
    if s >= 10:
        return f"{s:.0f} s"
    return f"{s:.1f} s"


def load_text(load):
    """一覧などの短い表示：'≈ 6.2 s' か 'load 12M'。記録の上限で頭打ちにした値は「+」を付ける。"""
    capped = load >= guard.RECORD_MAX
    secs = prefs.seconds_for(prefs.get(), load)
    if secs is not None:
        return ("> " if capped else "≈ ") + short_seconds(secs)
    return f"load {short_count(load)}" + ("+" if capped else "")


def load_phrase(load):
    """文の中で使う表示：'would take about 6.2 s' か 'estimated load 12M'。"""
    secs = prefs.seconds_for(prefs.get(), load)
    if secs is not None:
        return f"would take about {short_seconds(secs)} to show"
    return f"estimated load {short_count(load)}"


def _redraw(wm):
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES', 'PREFERENCES'}:
                area.tag_redraw()


# ------------------------------------------------------------------- 通知

def _message(items):
    obj_name, mod_name, faces, ok = items[0]
    if ok:
        msg = (f"Modifier Guard: stopped \"{mod_name}\" on {obj_name} ({load_phrase(faces)}). "
               "Revert it from the Modifier Guard tab in the sidebar")
    else:
        msg = (f"Modifier Guard: \"{mod_name}\" on {obj_name} is heavy ({load_phrase(faces)}), "
               "but it is linked data and cannot be stopped")
    if len(items) > 1:
        msg += f" (+{len(items) - 1} more)"
    return msg


# ---------------------------------------------------------------- バナー
# 3Dビューの上部中央に重ねて出す。操作は奪わない。BANNER_SECONDS で消える（最後の1秒でフェード）。
# 止めたものが「戻す」「今回だけ許可」などで片付いたら、その時点で消す。
# Calibrate の間は、代わりに進み具合を出す。

BANNER_SECONDS = 8.0
BANNER_TOP = 64  # 3D ビューの上端からの距離（UI スケール 1 のピクセル）。上の方は BlenderKit などのボタンと重なる

_banner = None      # {"items": [(オブジェクト名, モディファイア名, 負荷, 止めたか, オブジェクトの uid, モディファイアの uid)], "until": 時刻}
_draw_handle = None


def banner_lines():
    """バナーの (1行目, 2行目, 止められたか)。出すものが無ければ None。"""
    global _banner
    if _banner is None:
        return None
    if time.time() >= _banner["until"] or not _banner_pending():
        _banner = None
        return None
    items = _banner["items"]
    obj_name, mod_name, faces, ok = items[0][:4]
    if ok:
        line1 = f"Modifier Guard: stopped \"{mod_name}\" on {obj_name} ({load_phrase(faces)})"
        line2 = "Revert or Allow it from the Modifier Guard tab in the sidebar (N)"
    else:
        line1 = f"Modifier Guard: cannot stop \"{mod_name}\" on {obj_name} ({load_phrase(faces)})"
        line2 = "It is linked data and cannot be edited. Make a library override to let the guard stop it"
    if len(items) > 1:
        line1 += f" (+{len(items) - 1} more)"
    return line1, line2, ok


def _banner_pending():
    """まだ止めたままのもの（または止められなかった警告）が残っているか。名前を変えても追える。"""
    scene = bpy.context.scene
    for _obj_name, _mod_name, _faces, ok, obj_uid, mod_uid in _banner["items"]:
        if not ok:
            return True
        obj = guard.find_object(scene, obj_uid) if scene and obj_uid is not None else None
        if obj is not None and mod_uid in guard.read_record(obj):
            return True
    return False


def clear_banner():
    global _banner
    _banner = None


def _show_banner(items):
    global _banner
    scene = bpy.context.scene
    resolved = []
    for obj_name, mod_name, faces, ok in items:
        # 止めた直後なので名前で引ける。以降は uid で追う（名前を変えてもバナーが消えないように）
        obj = scene.objects.get(obj_name) if scene else None
        m = obj.modifiers.get(mod_name) if obj else None
        resolved.append((obj_name, mod_name, faces, ok,
                         obj.session_uid if obj else None, m.persistent_uid if m else None))
    _banner = {"items": resolved, "until": time.time() + BANNER_SECONDS}
    _start_tick()


def _start_tick():
    if not bpy.app.timers.is_registered(_banner_tick):
        bpy.app.timers.register(_banner_tick, first_interval=0.0)


def _banner_tick():
    """フェードと自動で消すための再描画。消えたらタイマーも終わる。"""
    wm = bpy.context.window_manager
    for win in (wm.windows if wm else ()):
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    if _banner is None:
        return None
    left = _banner["until"] - time.time()
    if left <= -0.1:
        return None
    return 0.05 if left < 1.2 else min(0.5, left - 1.0)


def _rect(shader, x0, y0, x1, y1, color):
    batch = batch_for_shader(shader, 'TRIS', {"pos": ((x0, y0), (x1, y0), (x0, y1), (x1, y1))},
                             indices=((0, 1, 2), (2, 1, 3)))
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_banner():
    try:
        region = bpy.context.region
        if region is None:
            return
        if _progress is not None:
            frac, text = _progress
            _draw((f"Modifier Guard: calibrating… {frac * 100:.0f}%", f"{text}   ·   Esc to cancel", True),
                  region.width, region.height, 1.0, progress=frac)
            return
        lines = banner_lines()
        if lines is None:
            return
        alpha = min(1.0, max(0.0, _banner["until"] - time.time()))
        _draw(lines, region.width, region.height, alpha)
    except Exception as ex:  # 描画の失敗で 3D ビューを壊さない
        print(f"[Modifier Guard] Banner draw error: {ex!r}")


def _draw(lines, width, height, alpha, progress=None):
    line1, line2, ok = lines
    ui = bpy.context.preferences.system.ui_scale or 1.0
    font = 0
    blf.size(font, 14 * ui)
    w1, h = blf.dimensions(font, line1)
    blf.size(font, 12 * ui)
    w2, _ = blf.dimensions(font, line2)
    pad, gap, bar = 12 * ui, 6 * ui, 5 * ui
    track = 4 * ui if progress is not None else 0.0  # 進捗バーの太さ
    bw = max(w1, w2, 260 * ui if progress is not None else 0.0) + pad * 2 + bar
    bh = h * 2 + gap + pad * 2 + (track + gap if track else 0.0)
    x0 = max((width - bw) / 2, 8 * ui)
    y1 = height - BANNER_TOP * ui
    y0 = y1 - bh

    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    _rect(shader, x0, y0, x0 + bw, y1, (0.08, 0.08, 0.08, 0.88 * alpha))
    if progress is not None:
        accent = (0.3, 0.55, 1.0, alpha)
    else:
        accent = (1.0, 0.62, 0.1, alpha) if ok else (0.95, 0.25, 0.2, alpha)
    _rect(shader, x0, y0, x0 + bar, y1, accent)
    tx = x0 + bar + pad
    if track:
        tw = bw - bar - pad * 2
        _rect(shader, tx, y0 + pad, tx + tw, y0 + pad + track, (1.0, 1.0, 1.0, 0.15 * alpha))
        _rect(shader, tx, y0 + pad, tx + tw * max(0.0, min(progress, 1.0)), y0 + pad + track, accent)
    gpu.state.blend_set('NONE')

    blf.size(font, 14 * ui)
    blf.color(font, 1.0, 1.0, 1.0, alpha)
    blf.position(font, tx, y1 - pad - h, 0)
    blf.draw(font, line1)
    blf.size(font, 12 * ui)
    blf.color(font, 0.78, 0.78, 0.78, alpha)
    blf.position(font, tx, y0 + pad + (track + gap if track else 0.0), 0)
    blf.draw(font, line2)


def show_resumed(items):
    """自動で表示を戻したことをステータスバーに出す（バナーは片付いた時点で消える）。"""
    obj_name, mod_name = items[0]
    msg = f"Modifier Guard: \"{mod_name}\" on {obj_name} is back within the limit and was turned back on"
    if len(items) > 1:
        msg += f" (+{len(items) - 1} more)"
    _report(msg, 'INFO')


def _report(message, level):
    wm = bpy.context.window_manager
    win = bpy.context.window or (wm.windows[0] if wm and wm.windows else None)
    if win is None:
        return  # ウィンドウが無い（バックグラウンド実行）ときはコンソール出力だけ
    with bpy.context.temp_override(window=win, screen=win.screen):
        bpy.ops.modifier_guard.notify(message=message, level=level)
    _redraw(wm)


def show_notice(items):
    """タイマーから呼ばれる。バナーとステータスバー（情報ログ）に出し、パネルを再描画する。"""
    _show_banner(items)
    _report(_message(items), 'WARNING')


class MODIFIER_GUARD_OT_notify(bpy.types.Operator):
    bl_idname = "modifier_guard.notify"
    bl_label = "Modifier Guard Notice"
    bl_options = {'INTERNAL'}

    message: StringProperty(options={'SKIP_SAVE'})
    level: StringProperty(default='WARNING', options={'SKIP_SAVE'})

    def execute(self, context):
        # ERROR だと Python 側で例外になるので、止められなかった警告も WARNING で出す
        self.report({'INFO' if self.level == 'INFO' else 'WARNING'}, self.message)
        return {'FINISHED'}


# --------------------------------------------------------- パネルの操作
# 対象はオブジェクトの session_uid とモディファイアの persistent_uid で指す（名前は変わりうる）

class _Target:
    object_uid: IntProperty(options={'SKIP_SAVE', 'HIDDEN'})
    modifier_uid: IntProperty(options={'SKIP_SAVE', 'HIDDEN'})

    def target(self, context):
        obj = guard.find_object(context.scene, self.object_uid)
        return obj, (guard.find_modifier(obj, self.modifier_uid) if obj else None)


def _set(op, obj, m=None):
    op.object_uid = obj.session_uid
    if m is not None:
        op.modifier_uid = m.persistent_uid


class MODIFIER_GUARD_OT_restore(_Target, bpy.types.Operator):
    bl_idname = "modifier_guard.restore"
    bl_label = "Revert"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    @classmethod
    def description(cls, context, props):
        obj = guard.find_object(context.scene, props.object_uid)
        m = guard.find_modifier(obj, props.modifier_uid) if obj else None
        text = "Restore the last settings that were within the limit and turn the viewport display back on"
        if m is None:
            return text
        ch = _changes(obj, m.name)
        if ch:
            text += "\n" + "\n".join(ch)
        elif guard.restore_settings(obj, m.name) is None:
            text += "\n(Not available when the previous settings are unknown, e.g. it was stopped before the file was opened)"
        return text

    def execute(self, context):
        obj, m = self.target(context)
        if m is None:
            self.report({'WARNING'}, "Modifier not found")
            return {'CANCELLED'}
        try:
            failed = guard.restore(obj, m.name)
        except KeyError:
            self.report({'WARNING'}, "Cannot revert: the previous settings are unknown")
            return {'CANCELLED'}
        if failed:
            self.report({'WARNING'}, f"Could not restore: {', '.join(failed)}")
        return {'FINISHED'}


class MODIFIER_GUARD_OT_allow(_Target, bpy.types.Operator):
    bl_idname = "modifier_guard.allow"
    bl_label = "Allow for Session"
    bl_description = ("Allow for this session: turn the viewport display back on with the current settings. "
                      "The guard won't stop it again while this file is open, unless it gets heavier")
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def invoke(self, context, event):
        obj, m = self.target(context)
        if m is None:
            return self.execute(context)
        faces = guard.read_record(obj).get(m.persistent_uid, 0)
        secs = prefs.seconds_for(prefs.get(), faces)
        if secs is not None:
            message = (f"\"{m.name}\" will be evaluated. Blender may freeze for about "
                       f"{short_seconds(secs)}")
        else:
            message = (f"\"{m.name}\" (estimated load {short_count(faces)}) will be evaluated. "
                       "Blender may be unresponsive for a while")
        return context.window_manager.invoke_confirm(
            self, event, title="Allow for Session", message=message,
            confirm_text="Allow and Show", icon='WARNING', translate=False)

    def execute(self, context):
        obj, m = self.target(context)
        if m is None:
            self.report({'WARNING'}, "Modifier not found")
            return {'CANCELLED'}
        guard.allow(obj, m.name)
        return {'FINISHED'}


class MODIFIER_GUARD_OT_revoke(_Target, bpy.types.Operator):
    bl_idname = "modifier_guard.revoke"
    bl_label = "Revoke Permission"
    bl_description = "Revoke the permission. If it is over the limit, the guard turns its viewport display off right away"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        obj, m = self.target(context)
        if m is None:
            return {'CANCELLED'}
        guard.revoke(obj, m.name)
        return {'FINISHED'}


class MODIFIER_GUARD_OT_select(_Target, bpy.types.Operator):
    bl_idname = "modifier_guard.select"
    bl_label = "Select Object"
    bl_description = "Select this object, make it active, and switch the Properties editor to the Modifiers tab"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    def execute(self, context):
        obj, _m = self.target(context)
        if obj is None:
            return {'CANCELLED'}
        try:
            for o in context.selected_objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except (RuntimeError, AttributeError):
            self.report({'WARNING'}, "This object can't be selected (hidden or in another view layer)")
            return {'CANCELLED'}
        for area in context.screen.areas if context.screen else ():
            if area.type == 'PROPERTIES':
                try:
                    area.spaces.active.context = 'MODIFIER'
                except TypeError:
                    pass
        return {'FINISHED'}


class MODIFIER_GUARD_OT_match_wait(bpy.types.Operator):
    bl_idname = "modifier_guard.match_wait"
    bl_label = "Match Acceptable Wait"
    bl_description = "Discard the manually edited Load Limit and set it from Acceptable Wait again"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        p = prefs.get()
        fit = prefs.limit_for_wait(p)
        if fit is None:
            return {'CANCELLED'}
        p.limit = fit[0]
        _redraw(context.window_manager)
        return {'FINISHED'}


# ------------------------------------------------------------ Calibrate
# 測定は calibrate.measure_steps で 1 段ずつ進める。モーダルにして段の合間に画面を更新し、
# サイドバー・プリファレンス・3D ビューのバナーに進み具合を出す。測定中はほかの操作を受け付けない（Esc で中止）。

_progress = None    # 測定中は (進み具合 0〜1, 今測っているもの)


def calibration_progress():
    return _progress


class MODIFIER_GUARD_OT_calibrate(bpy.types.Operator):
    bl_idname = "modifier_guard.calibrate"
    bl_label = "Calibrate"
    bl_description = ("Measure this computer and the current scene, then set the Load Limit so that "
                      "a modifier at the limit shows up within the Acceptable Wait. "
                      "Takes a few seconds; a test object appears in the viewport for a moment")
    bl_options = {'REGISTER', 'INTERNAL'}

    # True ならモーダルで少しずつ測る（ボタンから）。False なら一度に測る（スクリプト・テストから）
    modal: BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _progress is None

    def invoke(self, context, event):
        self.modal = True
        p = prefs.get()
        wait = p.target_time if p is not None else 2.0
        return context.window_manager.invoke_confirm(
            self, event, title="Calibrate Load Limit",
            message=(f"Measures this computer with the current scene open and fits the limit to a "
                     f"{wait:g} s wait. Takes a few seconds; a test object appears briefly. Esc cancels"),
            confirm_text="Calibrate", icon='INFO', translate=False)

    def execute(self, context):
        p = prefs.get()
        target = p.target_time if p is not None else 2.0
        win = calibrate.find_view3d_window(context)
        if win is None:
            self.report({'WARNING'}, "Open a 3D Viewport to calibrate")
            return {'CANCELLED'}
        if context.screen is not None and context.screen.is_temporary:
            # プリファレンスのウィンドウ（一時的なスクリーン）からは別のウィンドウに文脈を切り替えられない
            # ので、タイマーでメインウィンドウから実行し直す。進み具合はプリファレンスにも出る
            _calibrate_later(self.modal)
            return {'FINISHED'}
        if not self.modal:
            return self._run_blocking(context, win, target)

        global _progress
        self._steps = calibrate.measure_steps(target)
        self._win = win
        _progress = (0.0, "Starting")
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        win.cursor_modal_set('WAIT')
        _redraw(wm)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _progress
        if event.type == 'ESC' and event.value == 'PRESS':
            self._steps.close()  # 段の合間なのでテスト用オブジェクトは残っていない
            self._end(context)
            self.report({'INFO'}, "Modifier Guard: calibration cancelled. The Load Limit was not changed")
            return {'CANCELLED'}
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}  # 測定中の操作は受け付けない（シーンを変えると測定が狂う）
        try:
            _progress = next(self._steps)
        except StopIteration as done:
            self._end(context)
            _finish(self, context, done.value)
            return {'FINISHED'}
        except Exception as ex:
            self._end(context)
            self.report({'WARNING'}, f"Calibration failed: {ex}")
            return {'CANCELLED'}
        _redraw(context.window_manager)
        return {'RUNNING_MODAL'}

    def _end(self, context):
        global _progress
        _progress = None
        context.window_manager.event_timer_remove(self._timer)
        try:
            self._win.cursor_modal_restore()
        except ReferenceError:
            pass
        _redraw(context.window_manager)

    def _run_blocking(self, context, win, target):
        win.cursor_modal_set('WAIT')
        try:
            if context.window == win:
                res = calibrate.measure(context, target)
            else:
                with context.temp_override(window=win, screen=win.screen):
                    res = calibrate.measure(bpy.context, target)
        except Exception as ex:
            self.report({'WARNING'}, f"Calibration failed: {ex}")
            return {'CANCELLED'}
        finally:
            win.cursor_modal_restore()
        _finish(self, context, res)
        return {'FINISHED'}


def _finish(op, context, res):
    """測定結果をプリファレンスに入れて、上限を変える。"""
    p = prefs.get()
    note = (f"Calibrated: {res.limit:,} "
            f"(scene: {res.scene_faces:,} faces, redraw {res.base * 1000:.0f} ms)")
    if p is not None:
        p.calibration_note = note
        p.cost_factors = json.dumps(res.factors or {})
        p.sec_per_load = res.sec_per_load
        p.base_redraw = res.base
        p.memory_limit = min(res.by_memory, 2 ** 31 - 1)
        p.calibrated_scene = context.scene.name if context.scene else ""
        p.limit = res.limit  # update で apply（重みの補正も）と検査が走る
        prefs.apply(p)       # 上限が前と同じ値だと update が走らないので、重みは明示的に入れる
        guard.run_check(context.scene)
    else:
        guard.LIMIT = res.limit
        estimate.COST_FACTORS = dict(res.factors or {})
        guard.run_check(context.scene)
    if res.by_time <= calibrate.MIN_LIMIT:
        op.report({'WARNING'}, f"Modifier Guard: the current scene alone takes {res.base:.1f} s to redraw. "
                               f"Load Limit set to the minimum ({res.limit:,})")
    else:
        op.report({'INFO'}, f"Modifier Guard: Load Limit set to {res.limit:,}")
    _redraw(context.window_manager)


def _calibrate_later(modal):
    def run():
        """タイマーから：3D ビューのあるウィンドウで Calibrate を実行する。"""
        win = calibrate.find_view3d_window(bpy.context)
        if win is not None:
            try:
                with bpy.context.temp_override(window=win, screen=win.screen):
                    bpy.ops.modifier_guard.calibrate('EXEC_DEFAULT', modal=modal)
            except Exception as ex:
                print(f"[Modifier Guard] Calibration failed: {ex!r}")
        return None
    bpy.app.timers.register(run, first_interval=0.05)


# ------------------------------------------------------------------ パネル

def draw_limit(layout, context, p):
    """待てる時間・Calibrate・上限の欄（サイドバーとプリファレンスで共通）。"""
    col = layout.column()
    prog = _progress
    if prog is not None:
        col.progress(factor=prog[0], type='BAR', text=f"{prog[1]}…  {prog[0] * 100:.0f}%", translate=False)
        col.label(text="Press Esc to cancel", icon='INFO', translate=False)
        return

    col.prop(p, "target_time", text="Acceptable Wait", translate=False)
    calibrated = prefs.is_calibrated(p)
    row = col.row()
    row.alert = not calibrated and not p.calibration_note
    row.operator(MODIFIER_GUARD_OT_calibrate.bl_idname,
                 text="Recalibrate" if calibrated else "Calibrate", icon='TIME', translate=False)

    info = col.column(align=True)
    if calibrated:
        fit = prefs.limit_for_wait(p)
        secs = prefs.seconds_for(p, p.limit)
        info.label(text=f"Limit: {short_count(p.limit)} load (≈ {short_seconds(secs)})", icon='CHECKMARK',
                   translate=False)
        sub = info.column(align=True)
        sub.active = False
        if p.calibrated_scene:
            sub.label(text=f"Measured in “{p.calibrated_scene}”", translate=False)
        if fit is not None and fit[0] != p.limit:
            row = info.row(align=True)
            row.label(text="Load Limit edited manually", icon='GREASEPENCIL', translate=False)
            row.operator(MODIFIER_GUARD_OT_match_wait.bl_idname, text="", icon='LOOP_BACK')
        elif fit is not None and fit[1] > p.memory_limit and fit[0] < calibrate.MAX_LIMIT:
            sub.label(text="Capped by available memory, not by the wait", translate=False)
    elif p.calibration_note:
        info.label(text="Calibrated with an older version", icon='INFO', translate=False)
        sub = info.column(align=True)
        sub.active = False
        sub.label(text="Recalibrate to see loads as wait times", translate=False)
    else:
        info.label(text="Not calibrated yet", icon='ERROR', translate=False)
        sub = info.column(align=True)
        sub.active = False
        sub.label(text=f"Using the default limit ({short_count(p.limit)} load)", translate=False)

    header, body = col.panel("modifier_guard_manual_limit", default_closed=True)
    header.label(text="Manual Limit", translate=False)
    if body is not None:
        body.prop(p, "limit_m", text="Load Limit (millions)", translate=False)
        sub = body.column(align=True)
        sub.active = False
        sub.label(text="Load = Subdivision-equivalent faces", translate=False)


class VIEW3D_PT_modifier_guard(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Modifier Guard"
    bl_label = "Modifier Guard"

    def draw_header(self, context):
        p = prefs.get()
        if p is not None:
            self.layout.prop(p, "enabled", text="")

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        p = prefs.get()
        if p is None:
            layout.label(text=f"Load Limit: {guard.LIMIT:,}", translate=False)
        if not guard.ENABLED:
            layout.label(text="Off: heavy modifiers won't be stopped", icon='ERROR', translate=False)

        stopped = guard.stopped_items(scene)
        if not stopped:
            row = layout.row()
            row.active = guard.ENABLED
            row.label(text="No modifiers stopped", icon='CHECKMARK', translate=False)
        by_obj = {}
        for obj, name, faces, can_restore in stopped:
            by_obj.setdefault(obj.session_uid, (obj, []))[1].append((name, faces, can_restore))
        for obj, mods in by_obj.values():
            box = layout.box()
            _set(box.operator(MODIFIER_GUARD_OT_select.bl_idname, text=obj.name,
                              icon='OBJECT_DATA', emboss=False, translate=False), obj)
            for name, faces, can_restore in mods:
                m = obj.modifiers.get(name)
                col = box.column(align=True)
                split = col.split(factor=0.6)
                split.label(text=name, icon='MODIFIER_OFF', translate=False)
                right = split.row()
                right.alignment = 'RIGHT'
                right.label(text=load_text(faces), translate=False)
                row = col.row(align=True)
                sub = row.row(align=True)
                sub.enabled = can_restore
                _set(sub.operator(MODIFIER_GUARD_OT_restore.bl_idname, text="Revert", icon='LOOP_BACK',
                                  translate=False), obj, m)
                _set(row.operator(MODIFIER_GUARD_OT_allow.bl_idname, text="Allow",
                                  icon='PLAY', translate=False), obj, m)
                if not can_restore:
                    note = col.row()
                    note.active = False
                    note.label(text="Earlier settings unknown", icon='INFO', translate=False)

        allowed = guard.allowed_items(scene)
        if allowed:
            layout.separator()
            layout.label(text="Allowed for this session", icon='UNLOCKED', translate=False)
            box = layout.box()
            for obj, name, faces in allowed:
                col = box.column(align=True)
                row = col.row(align=True)
                row.label(text=f"{obj.name} / {name}", translate=False)
                _set(row.operator(MODIFIER_GUARD_OT_revoke.bl_idname, text="", icon='X', emboss=False),
                     obj, obj.modifiers.get(name))
                note = col.row()
                note.active = False
                note.label(text=f"Stopped again if heavier than {load_text(faces * guard.ALLOW_MARGIN)}",
                           translate=False)

        linked = []
        for _t, obj_name, name, faces, ok in reversed(guard.recent_events):
            if not ok and (obj_name, name) not in {(o, n) for o, n, _ in linked}:
                linked.append((obj_name, name, faces))
        if linked:
            layout.separator()
            layout.label(text="Could not stop (linked data)", icon='ERROR', translate=False)
            box = layout.box()
            for obj_name, name, faces in linked:
                split = box.split(factor=0.6)
                split.label(text=f"{obj_name} / {name}", translate=False)
                right = split.row()
                right.alignment = 'RIGHT'
                right.label(text=load_text(faces), translate=False)
            box.label(text="Make a library override to let the guard stop it", icon='INFO', translate=False)


class VIEW3D_PT_modifier_guard_limit(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Modifier Guard"
    bl_label = "Limit"
    bl_parent_id = "VIEW3D_PT_modifier_guard"

    @classmethod
    def poll(cls, context):
        return prefs.get() is not None

    def draw(self, context):
        self.layout.active = guard.ENABLED
        draw_limit(self.layout, context, prefs.get())


class VIEW3D_PT_modifier_guard_debug(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Modifier Guard"
    bl_label = "Estimate Details"
    bl_parent_id = "VIEW3D_PT_modifier_guard"

    @classmethod
    def poll(cls, context):
        p = prefs.get()
        return p is not None and p.show_debug

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            layout.label(text="Select a mesh object", icon='INFO', translate=False)
            return
        layout.label(text=obj.name, icon='OBJECT_DATA', translate=False)
        steps, fast, overrides, factor = guard.debug_info(obj)
        col = layout.column(align=True)
        if not steps:
            col.label(text="No modifiers that change the face count", translate=False)
        for m, before, after, cost in steps:
            row = col.row(align=True)
            over = cost > guard.LIMIT and after > before
            icon = 'ERROR' if over else ('ANIM' if m.name in overrides else 'MODIFIER')
            split = row.split(factor=0.45)
            split.label(text=m.name, icon=icon, translate=False)
            text = f"{int(before):,} → {int(after):,}"
            if int(cost) != int(after):
                text += f"  (load {int(cost):,})"
            split.label(text=text, translate=False)
        off = [m.name for m in obj.modifiers if not m.show_viewport]
        if off:
            col.label(text="Off: " + ", ".join(off), icon='HIDE_ON', translate=False)

        box = layout.box()
        est = steps[-1][2] if steps else len(obj.data.polygons)
        box.label(text=f"Estimated: {int(est):,}", translate=False)
        if fast is not None and int(fast) != int(est):
            box.label(text=f"Fast estimate (upper bound): {int(fast):,}", translate=False)
        if factor is not None:
            box.label(text=f"Geometry Nodes: ×{factor:.2f} (measured, adjusted for input changes)", translate=False)
        actual = _actual_faces(context, obj)
        if actual is None:
            box.label(text="Actual: not available (GPU subdivision)", translate=False)
        else:
            ratio = f" (estimate ×{est / actual:.2f})" if actual else ""
            box.label(text=f"Actual: {actual:,}{ratio}", translate=False)


def _actual_faces(context, obj):
    """評価済みの面数。最後が GPU サブディビジョンだと数えるだけで CPU 細分化が走るので None。"""
    active = [m for m in obj.modifiers if m.show_viewport]
    if active and active[-1].type in {'SUBSURF', 'MULTIRES'} and context.preferences.system.use_gpu_subdivision:
        return None
    ev = obj.evaluated_get(context.view_layer.depsgraph)
    return len(ev.data.polygons) if ev.data else None


classes = (
    MODIFIER_GUARD_OT_notify,
    MODIFIER_GUARD_OT_restore,
    MODIFIER_GUARD_OT_allow,
    MODIFIER_GUARD_OT_revoke,
    MODIFIER_GUARD_OT_select,
    MODIFIER_GUARD_OT_match_wait,
    MODIFIER_GUARD_OT_calibrate,
    VIEW3D_PT_modifier_guard,
    VIEW3D_PT_modifier_guard_limit,
    VIEW3D_PT_modifier_guard_debug,
)


def register():
    global _draw_handle
    for c in classes:
        if not c.is_registered:
            bpy.utils.register_class(c)
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(draw_banner, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _draw_handle, _banner, _progress
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, 'WINDOW')
        _draw_handle = None
    _banner = None
    _progress = None
    if bpy.app.timers.is_registered(_banner_tick):
        bpy.app.timers.unregister(_banner_tick)
    for c in reversed(classes):
        if c.is_registered:
            bpy.utils.unregister_class(c)

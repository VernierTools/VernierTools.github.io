# SPDX-License-Identifier: GPL-3.0-or-later
"""評価の直前に割り込み、重すぎるモディファイアのビューポート表示を切る。"""

import time

import bpy
from bpy.app.handlers import persistent

from . import animated, estimate

# 設定（プリファレンスから prefs.apply で写される。テストでは直接書き換える）
ENABLED = True
LIMIT = 8_000_000           # 負荷の上限（サブディビジョン換算の面数。estimate.COST_WEIGHTS）
AUTO_RESUME = True          # 上限内に戻ったら自動で表示を戻す
GUARDED_TYPES = None        # 止めてよい種類の集合（None ならすべて）
NODES_POLICY = 'MEASURED'   # ジオメトリノード：'MEASURED'（前回の実測倍率）か 'PASS'（×1）

# 止めたモディファイアの記録（オブジェクトのカスタムプロパティ）{str(モディファイアの persistent_uid): 負荷}。
# 1.2 までは名前をキーにしていた（LEGACY_KEY）が、モディファイアの名前を変えると記録が消えて
# パネルの一覧から外れ、自動で戻らなくなった。古い記録は読むときは両方見て、書き込むときに移す
RECORD_KEY = "modifier_guard_stopped_uid"
LEGACY_KEY = "modifier_guard_stopped"
# カスタムプロパティの整数は 32 ビット。超えたまま書くと OverflowError で記録が残らず、止めたものが
# 自動で戻らなかった。1.3 までは頭打ちにしていたが、平面デシメートはすぐ何兆にもなり、一覧の待ち時間が
# 頭打ちの値（この値 ≈ 数分）で出てバナーと食い違ったので、1.4 からは超えたら小数（倍精度）で書く。
# 1.3 までに頭打ちで書いた記録は、ちょうどこの値なので「これ以上」として表示する
RECORD_MAX = 2 ** 31 - 1


def _record_value(load):
    """記録に書く値。32 ビットに収まれば整数、収まらなければ小数。"""
    load = int(load)
    return load if load <= RECORD_MAX else float(load)

# 「今回だけ許可」したものは、許可した時点の推定面数のこの倍までは止めない
ALLOW_MARGIN = 1.25

# 直近に止めた内容（パネルのリンクデータ警告で使う）
recent_events = []

# 以下はセッション中だけの状態（ファイルには保存しない。読み込み時に空にする）
# キーはオブジェクトの session_uid とモディファイアの persistent_uid。名前だと、名前を変えると許可が
# 外れて止め直され、消したオブジェクトと同じ名前で作った別のオブジェクトが許可や「戻す」先を
# 引き継いでしまった（session_uid は名前の変更・Undo で変わらず、複製や新規作成では別の値になる）
# 許可リスト {オブジェクトの uid: {モディファイアの uid: 許可した推定面数}}
_allowed = {}
# 上限内だった最後の設定 {(オブジェクトの uid, モディファイアの uid): 設定}
_safe = {}
# 止めたものを「戻す」ときの設定 {(オブジェクトの uid, モディファイアの uid): 設定}
_restore = {}
# ジオメトリノードの実測倍率 {オブジェクトの uid: (実際の面数 / ×1 とみなした推定, 測ったときの整数入力)}
# 整数入力（Count など）は、測った後に値が変わったら倍率をその比で補正するために覚えておく（_gn_factor）
_nodes_factor = {}
# まだ通知していない停止 [(オブジェクト名, モディファイア名, 推定面数, 止められたか)]
pending_notices = []
# まだ通知していない自動復帰 [(オブジェクト名, モディファイア名)]
pending_resumed = []

_busy = False
_warned = set()  # 止められなかった警告は同じ内容を繰り返さない


def _can_edit(obj):
    return obj.library is None or obj.override_library is not None


def _uid(m):
    return m.persistent_uid


def _key(obj, m):
    return (obj.session_uid, m.persistent_uid)


def find_modifier(obj, uid):
    for m in obj.modifiers:
        if m.persistent_uid == uid:
            return m
    return None


def find_object(scene, session_uid):
    for obj in scene.objects:
        if obj.session_uid == session_uid:
            return obj
    return None


def has_record(obj):
    return RECORD_KEY in obj or LEGACY_KEY in obj


def read_record(obj):
    """止めたものの記録 {モディファイアの uid: 負荷}。古い名前キーの記録も含める（書き込みはしない）。"""
    out = {}
    legacy = obj.get(LEGACY_KEY)
    if legacy is not None:
        for name, load in legacy.to_dict().items():
            m = obj.modifiers.get(name)
            if m is not None:
                out[_uid(m)] = int(load)
    rec = obj.get(RECORD_KEY)
    if rec is not None:
        for k, load in rec.to_dict().items():
            try:
                out[int(k)] = int(load)
            except ValueError:
                continue
    return out


def _find_culprit(steps, limit, allowed=None):
    """上限を超えさせた最初のモディファイア（面数を増やしたもの・処理が重いもの）と、その重さを返す。

    重さは estimate.step_cost（サブディビジョン換算の面数。ベベル等の遅い種類は大きくなる）。
    allowed（{モディファイアの uid: 許可した重さ}）に入っていて、その重さの範囲内なら見逃す。
    面数を増やさないもの（重いものの後ろに付いているだけ）は原因にしない。ただしデシメートは面数を
    減らすが処理そのものが重い（平面は数十万面で何分も固まる）ので、重さが入力の面数を超えたら原因にする。
    """
    for m, before, after, cost in steps:
        if after <= before and not estimate.heavy_while_reducing(m, before, cost):
            continue
        if cost > limit:
            if GUARDED_TYPES is not None and m.type not in GUARDED_TYPES:
                continue
            if allowed and cost <= allowed.get(_uid(m), 0) * ALLOW_MARGIN:
                continue
            return m, cost
    return None


def _gn_ints(obj):
    """ジオメトリノードのモディファイアの整数入力 {(モディファイアの uid, 入力の識別子): 値}。

    Count・Resolution・Levels のように、整数の入力はたいてい要素の数を決めるので、倍率の補正に使う。
    Seed は数を変えないので除く。小数の入力（距離・角度など）は面数との関係が読めないので見ない。
    """
    out = {}
    for m in obj.modifiers:
        if m.type != 'NODES' or m.node_group is None:
            continue
        try:
            inputs = m.properties.inputs
            for item in m.node_group.interface.items_tree:
                if (getattr(item, 'in_out', None) != 'INPUT' or item.socket_type != 'NodeSocketInt'
                        or 'seed' in item.name.lower()):
                    continue
                sock = getattr(inputs, item.identifier, None)
                if getattr(sock, 'type', 'VALUE') != 'VALUE':
                    continue  # 属性から読む入力は値が決まらない
                v = getattr(sock, 'value', None)
                if isinstance(v, int) and not isinstance(v, bool):
                    out[(m.persistent_uid, item.identifier)] = v
        except (AttributeError, TypeError, RuntimeError):
            continue
    return out


def _gn_factor(obj):
    """ジオメトリノードに掛ける倍率。前回の実測倍率を、そのあと変わった整数入力の比で補正する。

    実測は評価されたときにしか更新されないので、補正しないと Count を大きくして止められたあと
    Count を戻しても大きい倍率のままで、二度と表示に戻せなかった。逆に Count を増やしたときも、
    評価して固まる前に止められる。補正しても ×1 未満にはしない（減る方向は信用しない）。
    """
    entry = _nodes_factor.get(obj.session_uid)
    if entry is None:
        return 1.0
    factor, measured = entry
    if not measured:
        return factor
    now = _gn_ints(obj)
    for key, old in measured.items():
        new = now.get(key)
        if new is None or new == old:
            continue
        factor *= max(new, 0) / max(old, 1)
    return max(1.0, factor)


def _stack(obj, skip=(), exact=True, extra=(), overrides=None):
    """ジオメトリノードの方針と、アニメーション・ドライバーの値を反映した estimate_stack。"""
    f = _gn_factor(obj) if NODES_POLICY == 'MEASURED' else 1.0
    return estimate.estimate_stack(obj, skip, exact=exact, extra=extra, nodes_factor=f,
                                   overrides=overrides)


def _expire_allowed(obj, allowed, steps, limit):
    """許可の後始末。消えたもの・上限内まで軽くなったものは許可を終える。"""
    cost_of = {_uid(m): cost for m, _, _, cost in steps}
    for uid in list(allowed):
        if find_modifier(obj, uid) is None:
            del allowed[uid]
        elif uid in cost_of and cost_of[uid] <= limit:
            del allowed[uid]  # steps は過大側なので、これで上限内なら確実に軽い
    if not allowed:
        _allowed.pop(obj.session_uid, None)


def _remember_safe(obj, steps, allowed):
    """上限内だったときの設定を覚えておく（止めたときに「戻す」先になる）。"""
    for m, *_ in steps:
        if m.type in estimate.SETTINGS_PROPS and not (allowed and _uid(m) in allowed):
            _safe[_key(obj, m)] = estimate.read_settings(m)


def check_object(obj, limit=None, overrides=None):
    """1オブジェクトを検査して、止めたモディファイアの [(名前, 推定面数, 止められたか)] を返す。

    overrides はアニメーション・ドライバーでこれから書き込まれる値（animated.modifier_overrides）。
    """
    if obj.type != 'MESH' or not obj.modifiers:
        return []
    limit = LIMIT if limit is None else limit
    allowed = _allowed.get(obj.session_uid)
    result = []
    skip = set()
    # まず高速推定（過大側）で判定し、超えそうなときだけ精密に計算する
    steps = _stack(obj, exact=False, overrides=overrides)
    if allowed:
        _expire_allowed(obj, allowed, steps, limit)
        allowed = _allowed.get(obj.session_uid)
    if _find_culprit(steps, limit, allowed) is None:
        _remember_safe(obj, steps, allowed)
        return []
    # 1つ止めたら、それを除いたスタックで推定し直す（後ろにも重いものがあれば続けて止める）
    for _ in range(len(obj.modifiers)):
        steps = _stack(obj, skip, overrides=overrides)
        found = _find_culprit(steps, limit, allowed)
        if found is None:
            if not result:
                _remember_safe(obj, steps, allowed)
            break
        m, faces = found
        if allowed and _uid(m) in allowed:
            del allowed[_uid(m)]  # 許可した重さを超えたので許可は終わり
        ok = False
        if _can_edit(obj):
            try:
                m.show_viewport = False
                ok = True
            except (AttributeError, RuntimeError, TypeError):
                ok = False
        if ok:
            snap = _safe.get(_key(obj, m))
            if snap is not None:
                _restore[_key(obj, m)] = snap
        skip.add(m.name)
        result.append((m.name, int(faces), ok))
    if allowed is not None and not allowed:
        _allowed.pop(obj.session_uid, None)
    return result


def _try_resume(obj, limit, just_stopped, overrides=None):
    """止めたものが、設定を下げるなどして上限内に収まるようになったら表示を戻す。

    記録にあるもの（ガードが止めたもの）だけが対象。スタックの上から順に、
    「それをオンにしてもどれも上限を超えない」ものを戻す。戻した名前のリストを返す。
    """
    rec = read_record(obj)
    if not rec or not _can_edit(obj):
        return []
    allowed = _allowed.get(obj.session_uid)
    resumed = []
    for m in obj.modifiers:
        if _uid(m) not in rec or m.show_viewport or m.name in just_stopped:
            continue
        if not estimate.would_be_active(obj, m):
            continue  # 編集モードで評価されないだけなので、まだ戻さない
        extra = (m.name,)
        if _find_culprit(_stack(obj, exact=False, extra=extra, overrides=overrides), limit, allowed) is not None:
            if _find_culprit(_stack(obj, extra=extra, overrides=overrides), limit, allowed) is not None:
                continue
        try:
            m.show_viewport = True
        except (AttributeError, RuntimeError, TypeError):
            continue
        resumed.append(m.name)
    return resumed


def _update_record(obj, stopped):
    """記録を更新する。止めたものを追加し、表示が戻った・消えたものを片付ける。古い形の記録は移す。"""
    if not _can_edit(obj):
        return
    try:
        old = obj.get(RECORD_KEY)
        rec = {str(k): _record_value(v) for k, v in read_record(obj).items()}
        for name, faces, ok in stopped:
            m = obj.modifiers.get(name) if ok else None
            if m is not None:
                rec[str(_uid(m))] = _record_value(faces)
        for k in list(rec):
            m = find_modifier(obj, int(k))
            if m is None or m.show_viewport:
                del rec[k]
                _restore.pop((obj.session_uid, int(k)), None)
        if LEGACY_KEY in obj:
            del obj[LEGACY_KEY]
        if rec:
            if old is None or rec != old.to_dict():
                obj[RECORD_KEY] = rec
        elif old is not None:
            del obj[RECORD_KEY]
    except (AttributeError, RuntimeError, TypeError, OverflowError, ValueError) as ex:
        print(f"[Modifier Guard] Could not update the record on {obj.name}: {ex!r}")


def _resume_object(obj, scene, limit, just_stopped=(), overrides=None):
    """記録のあるオブジェクトの自動復帰。"""
    if obj.animation_data and overrides is None:
        overrides = animated.modifier_overrides(obj, scene)
    for name in _try_resume(obj, limit, just_stopped, overrides):
        print(f"[Modifier Guard] {obj.name} / {name}: back within the limit -> viewport display turned on")
        pending_resumed.append((obj.name, name))


def check_scene(scene, limit=None):
    limit = LIMIT if limit is None else limit
    events = []
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        try:
            overrides = animated.modifier_overrides(obj, scene) if obj.animation_data else None
            stopped = check_object(obj, limit, overrides)
            if AUTO_RESUME and has_record(obj):
                _resume_object(obj, scene, limit, {n for n, _, _ in stopped}, overrides)
            if stopped or has_record(obj):
                _update_record(obj, stopped)
        except Exception as ex:  # 1 つのオブジェクトの不具合で、ほかの検査を止めない
            print(f"[Modifier Guard] Error on {obj.name}: {ex!r}")
            continue
        for name, faces, ok in stopped:
            events.append((obj.name, name, faces, ok))
    new = []
    for obj_name, mod_name, faces, ok in events:
        if not ok:
            key = (obj_name, mod_name, faces)
            if key in _warned:
                continue
            _warned.add(key)
        state = "viewport display turned off" if ok else "linked data, cannot be stopped"
        print(f"[Modifier Guard] {obj_name} / {mod_name}: estimated load {faces:,} -> {state}")
        recent_events.append((time.time(), obj_name, mod_name, faces, ok))
        new.append((obj_name, mod_name, faces, ok))
    del recent_events[:-50]
    if new:
        pending_notices.extend(new)
    if new or pending_resumed:
        _request_notice()
    return events


# ------------------------------------------------------------------- 通知

def _request_notice():
    """ハンドラ内からは UI を出せないので、タイマーで評価の後に通知する。"""
    try:
        if not bpy.app.timers.is_registered(flush_notices):
            bpy.app.timers.register(flush_notices, first_interval=0.0)
    except Exception as ex:
        print(f"[Modifier Guard] Failed to schedule notice: {ex!r}")


def flush_notices():
    items = pending_notices[:]
    resumed = pending_resumed[:]
    pending_notices.clear()
    pending_resumed.clear()
    try:
        from . import ui
        if resumed:
            ui.show_resumed(resumed)
        if items:
            ui.show_notice(items)
    except Exception as ex:  # 通知の失敗で操作を邪魔しない
        print(f"[Modifier Guard] Notice error: {ex!r}")
    return None  # 1回きり


# ------------------------------------------------------- パネルからの操作

def stopped_items(scene):
    """止めているものの一覧 [(オブジェクト, モディファイア名, 推定面数, 戻せるか)]。"""
    out = []
    for obj in scene.objects:
        if obj.type != 'MESH' or not has_record(obj):
            continue
        for uid, faces in read_record(obj).items():
            m = find_modifier(obj, uid)
            if m is None:
                continue
            out.append((obj, m.name, int(faces), (obj.session_uid, uid) in _restore))
    return out


def allowed_items(scene):
    """許可中のものの一覧 [(オブジェクト, モディファイア名, 許可した推定面数)]。"""
    out = []
    if not _allowed:
        return out
    for obj in scene.objects:
        mods = _allowed.get(obj.session_uid)
        if not mods:
            continue
        for uid, faces in mods.items():
            m = find_modifier(obj, uid)
            if m is not None:
                out.append((obj, m.name, int(faces)))
    return out


def debug_info(obj):
    """デバッグ表示用：(精密推定の steps, 高速推定の最終面数, overrides, GN の実測倍率)。"""
    overrides = animated.modifier_overrides(obj, bpy.context.scene) if obj.animation_data else None
    steps = _stack(obj, overrides=overrides)
    fast = _stack(obj, exact=False, overrides=overrides)
    factor = _gn_factor(obj) if NODES_POLICY == 'MEASURED' and obj.session_uid in _nodes_factor else None
    return steps, (fast[-1][2] if fast else None), overrides or {}, factor


def restore_settings(obj, name):
    """止める直前の設定（面数に効くもの）を返す。無ければ None。"""
    m = obj.modifiers.get(name)
    return _restore.get(_key(obj, m)) if m is not None else None


def _forget(obj, m):
    _restore.pop(_key(obj, m), None)
    for key, k in ((RECORD_KEY, str(_uid(m))), (LEGACY_KEY, m.name)):
        try:
            rec = obj.get(key)
            if rec is not None and k in rec:
                del rec[k]
                if not rec:
                    del obj[key]
        except (AttributeError, RuntimeError, TypeError, KeyError):
            pass


def restore(obj, name):
    """止める直前の設定に戻して表示をオンにする。戻せなかった項目名のリストを返す。"""
    m = obj.modifiers.get(name)
    snap = _restore.get(_key(obj, m)) if m is not None else None
    if m is None or snap is None:
        raise KeyError(name)
    failed = estimate.apply_settings(m, snap)
    m.show_viewport = True
    _forget(obj, m)
    return failed


def allow(obj, name):
    """今の重さのまま表示をオンにし、その重さまではガードが止めないようにする。"""
    m = obj.modifiers.get(name)
    if m is None:
        raise KeyError(name)
    faces = read_record(obj).get(_uid(m), 0)
    m.show_viewport = True
    overrides = animated.modifier_overrides(obj, bpy.context.scene) if obj.animation_data else None
    for sm, _, _, cost in _stack(obj, overrides=overrides):
        if sm.name == name:
            faces = max(faces, cost)
    _allowed.setdefault(obj.session_uid, {})[_uid(m)] = faces
    _forget(obj, m)
    return faces


def revoke(obj, name):
    """許可を取り消す。まだ重ければ次の更新でガードが止める。"""
    m = obj.modifiers.get(name)
    mods = _allowed.get(obj.session_uid)
    if mods is not None and m is not None:
        mods.pop(_uid(m), None)
        if not mods:
            del _allowed[obj.session_uid]
    obj.update_tag()


# ------------------------------------------------------------- ハンドラ

class paused:
    """with guard.paused(): の間はガードを止める（Face Limit の測定用）。"""

    def __enter__(self):
        global _busy
        self._was = _busy
        _busy = True
        return self

    def __exit__(self, *exc):
        global _busy
        _busy = self._was
        return False


def run_check(scene):
    """ハンドラ以外（設定の変更、ファイル読み込み直後）から検査する。"""
    global _busy
    if _busy or not ENABLED or scene is None:
        return
    _busy = True
    try:
        check_scene(scene)
    except Exception as ex:  # ガードの不具合で Blender の操作を邪魔しない
        print(f"[Modifier Guard] Error: {ex!r}")
    finally:
        _busy = False


@persistent
def on_depsgraph_update_pre(scene, depsgraph=None):
    if depsgraph is not None and depsgraph.mode != 'VIEWPORT':
        return
    run_check(scene)


@persistent
def on_frame_change_pre(scene, depsgraph=None):
    """フレームが変わったとき。評価の直前ハンドラは呼ばれないので、ここで検査する。"""
    if depsgraph is not None and depsgraph.mode != 'VIEWPORT':
        return
    if bpy.app.is_job_running('RENDER'):
        return
    run_check(scene)


# ジオメトリノードの実測をした時点の状態 {オブジェクトの uid: 署名}。署名が同じなら測り直さない
_nodes_sig = {}


def _nodes_signature(orig, mods, evaluated_faces):
    """実測倍率に効くものをまとめた値。変わっていなければ estimate_stack を回さずに済ませる。"""
    return (len(orig.data.polygons), evaluated_faces,
            tuple((m.persistent_uid, tuple(sorted(estimate.read_settings(m).items()))) for m in mods),
            tuple(sorted(_gn_ints(orig).items())))


def _measure_nodes(orig, depsgraph):
    """元のオブジェクトと、その評価済みの面数から、ジオメトリノードの実測倍率を更新する。"""
    uid = orig.session_uid
    if not any(m.type == 'NODES' for m in orig.modifiers):
        _nodes_factor.pop(uid, None)
        _nodes_sig.pop(uid, None)
        return
    mods = [m for m in orig.modifiers if estimate.is_active_in_viewport(orig, m)]
    if not any(m.type == 'NODES' for m in mods):
        return  # 止めている間は前回の倍率を残す（自動復帰の判定に使う）
    if mods[-1].type in {'SUBSURF', 'MULTIRES'}:
        return  # GPU サブディビジョンだと面を数えるだけで CPU で細分化が走るので測らない
    ev = orig.evaluated_get(depsgraph)
    if ev is None or not ev.is_evaluated or ev.data is None:
        return  # まだ評価されていない（追加した直後など）
    sig = _nodes_signature(orig, mods, len(ev.data.polygons))
    if _nodes_sig.get(uid) == sig:
        return
    steps = estimate.estimate_stack(orig)  # ジオメトリノードを ×1 とみなした推定
    base = steps[-1][2] if steps else len(orig.data.polygons)
    if base > 0:
        # 減る方向は信用しない（設定次第でまた増えるので、過大側に倒す）
        _nodes_factor[uid] = (max(1.0, sig[1] / base), _gn_ints(orig))
        _nodes_sig[uid] = sig


def measure_nodes(scene, view_layer):
    """シーンにある、ジオメトリノードを持つメッシュの実測倍率を更新する。

    評価済みは view_layer.depsgraph から取る（評価を新たに走らせない）。オブジェクトは scene.objects から
    たどる（view_layer.objects は、消した直後でまだ評価していないと None が混じった）。
    """
    depsgraph = view_layer.depsgraph
    if depsgraph is None:
        return
    for obj in scene.objects:
        if obj is None or obj.type != 'MESH' or not obj.modifiers:
            continue
        if not any(m.type == 'NODES' for m in obj.modifiers) and obj.session_uid not in _nodes_factor:
            continue
        try:
            _measure_nodes(obj, depsgraph)
        except Exception as ex:  # 1 つのオブジェクトの不具合で、ほかの実測を止めない
            print(f"[Modifier Guard] Error measuring {obj.name}: {ex!r}")


def _measure_timer():
    """評価が終わった後（次のイベント処理の前）に、開いているウィンドウのビューレイヤーを実測する。"""
    if not ENABLED or NODES_POLICY != 'MEASURED' or _busy:
        return None
    try:
        wm = bpy.context.window_manager
        seen = set()
        for win in (wm.windows if wm else ()):
            scene, vl = win.scene, win.view_layer
            if scene is None or vl is None or vl.as_pointer() in seen:
                continue
            seen.add(vl.as_pointer())
            measure_nodes(scene, vl)
    except Exception as ex:
        print(f"[Modifier Guard] Error: {ex!r}")
    return None  # 1回きり


@persistent
def on_depsgraph_update_post(scene, depsgraph=None):
    """評価が終わったら、ジオメトリノードの実測をタイマーに頼む。

    ここでは depsgraph.updates を回さない（u.id を読まない）。オブジェクトを消した直後に
    解放済みの ID が残っていることがあり、u.id で Python の参照を作るだけで Blender ごと落ちた
    （1.3.0、Windows。例外ではないので try では防げない）。評価の外で、シーンにある
    オブジェクトから引き直して測る。
    """
    if not ENABLED or NODES_POLICY != 'MEASURED' or depsgraph is None:
        return
    try:
        if depsgraph.mode != 'VIEWPORT':
            return
        if not bpy.app.timers.is_registered(_measure_timer):
            bpy.app.timers.register(_measure_timer, first_interval=0.0)
    except Exception as ex:
        print(f"[Modifier Guard] Error: {ex!r}")


def reset_session():
    """ファイルが変わったらセッション中の状態を捨てる（許可は「今回だけ」）。"""
    _allowed.clear()
    _safe.clear()
    _restore.clear()
    _nodes_factor.clear()
    _nodes_sig.clear()
    pending_notices.clear()
    pending_resumed.clear()
    recent_events.clear()
    _warned.clear()
    from . import ui
    ui.clear_banner()


@persistent
def on_load_pre(*_args):
    reset_session()


@persistent
def on_load_post(*_args):
    """読み込み直後、最初のビューポート評価より先に検査する（重いファイル対策）。"""
    scenes = {w.scene for w in bpy.context.window_manager.windows} if bpy.context.window_manager else set()
    scenes.add(bpy.context.scene)
    for scene in scenes:
        run_check(scene)


_HANDLERS = (
    (bpy.app.handlers.depsgraph_update_pre, on_depsgraph_update_pre),
    (bpy.app.handlers.depsgraph_update_post, on_depsgraph_update_post),
    (bpy.app.handlers.frame_change_pre, on_frame_change_pre),
    (bpy.app.handlers.load_pre, on_load_pre),
    (bpy.app.handlers.load_post, on_load_post),
)


def register():
    for handlers, fn in _HANDLERS:
        if fn not in handlers:
            handlers.append(fn)


def unregister():
    for handlers, fn in _HANDLERS:
        if fn in handlers:
            handlers.remove(fn)
    for timer in (flush_notices, _measure_timer):
        try:
            if bpy.app.timers.is_registered(timer):
                bpy.app.timers.unregister(timer)
        except Exception:
            pass
    reset_session()

# SPDX-License-Identifier: GPL-3.0-or-later
"""アニメーションとドライバーで、これから書き込まれるモディファイアの値を先に求める。

どちらも depsgraph の評価中に値を書き込むので、評価直前のハンドラから見える元データは
前回の値のまま。ここで同じ値を計算して、推定に使う（estimate_stack の overrides）。

- アニメーション：アクティブなアクションと、そのフレームにかかる NLA ストリップの f カーブを評価。
  複数あるときは大きい方を使う（ほとんどの項目で過大側。ボクセルサイズなど小さいほど重いものは逆）。
  ブレンドやインフルエンスは見ない。
- ドライバー：SINGLE_PROP / TRANSFORMS / LOC_DIFF の変数と、AVERAGE・SUM・MIN・MAX・
  単純な式（is_simple_expression）だけを評価する。それ以外は前回の値（元データ）のまま。
  変数が見る値も元データの今の値なので、制約やアニメーションで動く相手は1テンポ遅れる。
"""

import math
import re

import bpy
from bpy_extras import anim_utils
from mathutils import Vector

_PATH = re.compile(r'^modifiers\["((?:[^"\\]|\\.)*)"\]\.(\w+)$')

# 単純な式で使える名前（Blender の simple expression と同じ範囲）
_SIMPLE_NS = {
    name: getattr(math, name) for name in (
        'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2', 'floor', 'ceil', 'trunc',
        'sqrt', 'exp', 'log', 'pi', 'radians', 'degrees', 'hypot', 'fmod', 'copysign')
}
_SIMPLE_NS.update(min=min, max=max, abs=abs, round=round, int=int, float=float, pow=pow,
                  smoothstep=lambda a, b, x: 0.0 if x <= a else 1.0 if x >= b else
                  (lambda t: t * t * (3 - 2 * t))((x - a) / (b - a)),
                  lerp=lambda a, b, t: a + (b - a) * t,
                  clamp=lambda x, lo=0.0, hi=1.0: max(lo, min(hi, x)))


def _parse(path):
    m = _PATH.match(path)
    if m is None:
        return None
    return m.group(1).replace('\\"', '"').replace('\\\\', '\\'), m.group(2)


def _fcurves(action, slot):
    if action is None:
        return ()
    try:
        cb = anim_utils.action_get_channelbag_for_slot(action, slot)
    except Exception:
        return ()
    return cb.fcurves if cb is not None else ()


def _strip_frame(strip, frame):
    """NLA ストリップがそのフレームにかかっていれば、アクション内のフレームを返す。"""
    if strip.mute or not (strip.frame_start <= frame <= strip.frame_end):
        return None
    length = max(strip.action_frame_end - strip.action_frame_start, 1e-6)
    local = (frame - strip.frame_start) / max(strip.scale, 1e-6)
    if strip.repeat > 1.0:
        local = math.fmod(local, length) if local < length * strip.repeat else length
    return strip.action_frame_start + min(local, length)


def _sources(ad, frame):
    """(f カーブの列, 評価するフレーム) の列。"""
    if ad.action is not None:
        yield _fcurves(ad.action, ad.action_slot), frame
    if ad.use_nla:
        for track in ad.nla_tracks:
            if track.mute:
                continue
            for strip in track.strips:
                f = _strip_frame(strip, frame)
                if f is not None and strip.action is not None:
                    yield _fcurves(strip.action, strip.action_slot), f


# ------------------------------------------------------------- ドライバー

def _object_transform(ob, bone_name, ttype, space):
    if ob is None or ob.type is None:
        return None
    if bone_name and ob.type == 'ARMATURE':
        pb = ob.pose.bones.get(bone_name)
        if pb is None:
            return None
        if space == 'TRANSFORM_SPACE':
            loc, rot, scale = pb.location, pb.rotation_euler, pb.scale
        else:
            mat = ob.matrix_world @ pb.matrix if space == 'WORLD_SPACE' else pb.matrix
            loc, q, scale = mat.decompose()
            rot = q.to_euler()
    elif space == 'TRANSFORM_SPACE':
        loc, rot, scale = ob.location, ob.rotation_euler, ob.scale
    else:
        mat = ob.matrix_world if space == 'WORLD_SPACE' else ob.matrix_local
        loc, q, scale = mat.decompose()
        rot = q.to_euler()
    kind, axis = ttype.split('_')
    if kind == 'SCALE' and axis == 'AVG':
        return (scale[0] + scale[1] + scale[2]) / 3
    i = 'XYZW'.index(axis)
    if kind == 'LOC':
        return loc[i]
    if kind == 'ROT':
        return rot[i] if i < 3 else None
    return scale[i]


def _world_location(t):
    ob = t.id
    if ob is None or not isinstance(ob, bpy.types.Object):
        return None
    if t.bone_target and ob.type == 'ARMATURE':
        pb = ob.pose.bones.get(t.bone_target)
        if pb is None:
            return None
        return (ob.matrix_world @ pb.matrix).translation
    return ob.matrix_world.translation


def _variable(var):
    t = var.targets
    if var.type == 'SINGLE_PROP':
        if t[0].id is None:
            return None
        try:
            v = t[0].id.path_resolve(t[0].data_path)
        except (ValueError, TypeError):
            return None
        return float(v) if isinstance(v, (int, float, bool)) else None
    if var.type == 'TRANSFORMS':
        return _object_transform(t[0].id, t[0].bone_target, t[0].transform_type, t[0].transform_space)
    if var.type == 'LOC_DIFF':
        a, b = _world_location(t[0]), _world_location(t[1])
        return None if a is None or b is None else (Vector(a) - Vector(b)).length
    return None  # ROTATION_DIFF / CONTEXT_PROP などは扱わない


def _driver(fc, frame):
    d = fc.driver
    if d is None or not d.is_valid:
        return None
    values = {}
    for var in d.variables:
        x = _variable(var)
        if x is None:
            return None
        values[var.name] = x
    xs = list(values.values())
    if d.type == 'AVERAGE':
        r = sum(xs) / len(xs) if xs else 0.0
    elif d.type == 'SUM':
        r = sum(xs)
    elif d.type == 'MIN':
        r = min(xs) if xs else 0.0
    elif d.type == 'MAX':
        r = max(xs) if xs else 0.0
    elif d.type == 'SCRIPTED' and d.is_simple_expression:
        ns = dict(_SIMPLE_NS, frame=frame, **values)
        try:
            r = float(eval(d.expression, {"__builtins__": {}}, ns))  # 単純な式だけなので安全
        except Exception:
            return None
    else:
        return None
    if len(fc.keyframe_points) or len(fc.modifiers):
        r = fc.evaluate(r)  # ドライバーの値 → f カーブで対応付け
    return r


# ------------------------------------------------------------- 公開 API

def _coerce(m, prop, index, value, out):
    cur = out.get(prop)
    if cur is None:
        cur = getattr(m, prop, None)
    if cur is None:
        return
    if isinstance(cur, bool):
        out[prop] = value >= 0.5
    elif isinstance(cur, int):
        out[prop] = int(value)  # Blender と同じく切り捨て
    elif isinstance(cur, float):
        out[prop] = float(value)
    elif isinstance(cur, str):
        return  # 列挙型のアニメーションは扱わない
    else:
        seq = list(cur)
        if not 0 <= index < len(seq):
            return
        seq[index] = (value >= 0.5) if isinstance(seq[index], bool) else type(seq[index])(value)
        out[prop] = tuple(seq)


def modifier_overrides(obj, scene):
    """評価で書き込まれるモディファイアの値 {モディファイア名: {プロパティ: 値}}。無ければ None。"""
    ad = obj.animation_data
    if ad is None:
        return None
    frame = scene.frame_current + scene.frame_subframe
    out = {}
    seen = {}  # (モディファイア, プロパティ, index) → アニメーションの最大値
    for fcurves, f in _sources(ad, frame):
        for fc in fcurves:
            if fc.mute or not fc.data_path.startswith('modifiers['):
                continue
            key = _parse(fc.data_path)
            if key is None:
                continue
            v = fc.evaluate(f)
            k = (key[0], key[1], fc.array_index)
            seen[k] = max(seen.get(k, v), v)
    for fc in ad.drivers:
        if fc.mute or not fc.data_path.startswith('modifiers['):
            continue
        key = _parse(fc.data_path)
        if key is None:
            continue
        v = _driver(fc, frame)
        if v is not None:
            seen[(key[0], key[1], fc.array_index)] = v  # ドライバーはアニメーションより後に効く
    for (mod_name, prop, index), v in seen.items():
        m = obj.modifiers.get(mod_name)
        if m is None:
            continue
        _coerce(m, prop, index, v, out.setdefault(mod_name, {}))
    return {k: v for k, v in out.items() if v} or None

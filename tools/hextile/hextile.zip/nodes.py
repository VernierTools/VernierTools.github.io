# SPDX-FileCopyrightText: 2026 mikat
# SPDX-FileCopyrightText: 2022 mmikk (hex-tiling math ported from hextile-demo, MIT License,
#                          see LICENSE-hextile-demo.txt)
# SPDX-License-Identifier: GPL-3.0-or-later

"""Hex-Tiling node groups for Blender 5.2 (Shader Editor, EEVEE and Cycles).

A node-only port of "Practical Real-Time Hex-Tiling" (Morten S. Mikkelsen,
JCGT 2022) following the reference code in
https://github.com/mmikk/hextile-demo (hextiling.h, MIT License).

The HexTile add-on calls ensure_groups() to add these groups to the file:

    HexTile Coordinates   UV -> three rotated/offset UVs + triangle weights
    HexTile Blend Color   three color samples -> blended color (+ final weights)
    HexTile Blend Normal  three tangent-space normal map samples -> blended normal map color
    HexTile Blend Data    three samples (roughness, height, ...) blended with given weights

Shader node groups cannot take an image as input, so each map needs three
Image Texture nodes fed by UV 1/2/3 (see README.md).
"""

import math

import bpy

SQRT3 = math.sqrt(3.0)
GRID_SCALE = 2.0 * SQRT3          # st *= 2*sqrt(3) in TriangleGrid()
SKEW_A = -0.57735027              # gridToSkewedGrid
SKEW_B = 1.15470054
LUMA = (0.299, 0.587, 0.114)

# Defaults of the reference demo (hextile-demo.cpp / hextiling.h).
DEFAULT_COLOR_CONTRAST = 0.7      # g_ColorFakeContrast
DEFAULT_NORMAL_CONTRAST = 0.5     # g_NormalFakeContrast
DEFAULT_FALLOFF_CONTRAST = 0.6    # g_fallOffContrast
DEFAULT_EXP = 7.0                 # g_exp

NAME_COORDS = "HexTile Coordinates"
NAME_COLOR = "HexTile Blend Color"
NAME_NORMAL = "HexTile Blend Normal"
NAME_DATA = "HexTile Blend Data"
NAME_WEIGHTS = ".HexTile Weights"
# Bump when the groups change so files made with an older add-on get rebuilt.
GROUP_VERSION = 2
VERSION_KEY = "hextile_version"
NAME_GAIN = ".HexTile Gain"


# ---------------------------------------------------------------------------
# Small graph builder: every helper returns an output socket.
# ---------------------------------------------------------------------------

class Builder:
    X_STEP = 190
    Y_STEP = 175

    def __init__(self, ng):
        self.ng = ng
        self.nodes = ng.nodes
        self.links = ng.links
        self.level = {}
        self.col_y = {}
        self.gi = self.nodes.new("NodeGroupInput")
        self.gi.location = (-self.X_STEP, 0)
        self.level[self.gi] = 0

    def _put(self, node, args):
        lv = 1
        for a in args:
            if isinstance(a, bpy.types.NodeSocket):
                lv = max(lv, self.level.get(a.node, 0) + 1)
        self.level[node] = lv
        y = self.col_y.get(lv, 0)
        node.location = (lv * self.X_STEP, y)
        self.col_y[lv] = y - self.Y_STEP

    def set(self, value, sock):
        if isinstance(value, bpy.types.NodeSocket):
            self.links.new(value, sock)
        elif value is not None:
            sock.default_value = value

    def inp(self, name):
        return self.gi.outputs[name]

    def output(self, pairs):
        go = self.nodes.new("NodeGroupOutput")
        go.location = ((max(self.level.values()) + 1) * self.X_STEP, 0)
        for name, sock in pairs:
            self.links.new(sock, go.inputs[name])
        return go

    # scalar math --------------------------------------------------------
    def math(self, op, a, b=None, c=None):
        n = self.nodes.new("ShaderNodeMath")
        n.operation = op
        self._put(n, (a, b, c))
        self.set(a, n.inputs[0])
        self.set(b, n.inputs[1])
        self.set(c, n.inputs[2])
        return n.outputs[0]

    def add(self, a, b): return self.math("ADD", a, b)
    def sub(self, a, b): return self.math("SUBTRACT", a, b)
    def mul(self, a, b): return self.math("MULTIPLY", a, b)
    def div(self, a, b): return self.math("DIVIDE", a, b)
    def madd(self, a, b, c): return self.math("MULTIPLY_ADD", a, b, c)  # a*b + c

    # vectors ----------------------------------------------------------------
    def vmath(self, op, a, b=None, c=None, scale=None):
        n = self.nodes.new("ShaderNodeVectorMath")
        n.operation = op
        self._put(n, (a, b, c, scale))
        self.set(a, n.inputs[0])
        self.set(b, n.inputs[1])
        self.set(c, n.inputs[2])
        if scale is not None:
            self.set(scale, n.inputs[3])  # "Scale"
        if op in {"DOT_PRODUCT", "LENGTH", "DISTANCE"}:
            return n.outputs["Value"]
        return n.outputs["Vector"]

    def sep(self, v):
        n = self.nodes.new("ShaderNodeSeparateXYZ")
        self._put(n, (v,))
        self.set(v, n.inputs[0])
        return n.outputs[0], n.outputs[1], n.outputs[2]

    def comb(self, x, y, z=0.0):
        n = self.nodes.new("ShaderNodeCombineXYZ")
        self._put(n, (x, y, z))
        self.set(x, n.inputs[0])
        self.set(y, n.inputs[1])
        self.set(z, n.inputs[2])
        return n.outputs[0]

    def group(self, tree, inputs):
        n = self.nodes.new("ShaderNodeGroup")
        n.node_tree = tree
        self._put(n, tuple(inputs.values()))
        for name, value in inputs.items():
            self.set(value, n.inputs[name])
        return n


def _get_group(name, description):
    ng = bpy.data.node_groups.get(name)
    if ng is None:
        ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    else:
        # Rebuild in place so materials keep using the same datablock.
        ng.nodes.clear()
        ng.interface.clear()
    ng.description = description
    return ng


def _in(ng, name, typ, default=None, lo=None, hi=None, hide=False, desc=""):
    s = ng.interface.new_socket(name, in_out="INPUT", socket_type=typ, description=desc)
    if default is not None:
        s.default_value = default
    if lo is not None:
        s.min_value = lo
    if hi is not None:
        s.max_value = hi
    if hide:
        s.hide_value = True
    return s


def _out(ng, name, typ, desc=""):
    return ng.interface.new_socket(name, in_out="OUTPUT", socket_type=typ, description=desc)


# ---------------------------------------------------------------------------
# Groups
# ---------------------------------------------------------------------------

def build_gain():
    """Gain3() for one component: x<0.5 -> 0.5*(2x)^k, else 1-0.5*(2-2x)^k."""
    ng = _get_group(NAME_GAIN, "Hex-tiling helper: contrast gain of one weight")
    _in(ng, "X", "NodeSocketFloat", 0.0)
    _in(ng, "K", "NodeSocketFloat", 1.0)
    _out(ng, "Value", "NodeSocketFloat")
    b = Builder(ng)
    x, k = b.inp("X"), b.inp("K")
    hi = b.math("GREATER_THAN", x, 0.4999999)  # step(0.5, x)
    low = b.mul(b.math("POWER", b.math("MAXIMUM", b.mul(x, 2.0), 0.0), k), 0.5)
    high = b.sub(1.0, b.mul(b.math("POWER", b.math("MAXIMUM", b.madd(x, -2.0, 2.0), 0.0), k), 0.5))
    res = b.madd(hi, b.sub(high, low), low)
    b.output([("Value", res)])
    return ng


def build_weights(gain):
    """Weight sharpening shared by color and normal blending (hextiling.h)."""
    ng = _get_group(NAME_WEIGHTS, "Hex-tiling helper: final blend weights")
    _in(ng, "Weights", "NodeSocketVector", hide=True)
    _in(ng, "Detail", "NodeSocketVector", hide=True)
    _in(ng, "Contrast", "NodeSocketFloat", 0.5, 0.0, 0.999)
    _in(ng, "Falloff Contrast", "NodeSocketFloat", DEFAULT_FALLOFF_CONTRAST, 0.0, 1.0)
    _in(ng, "Exponent", "NodeSocketFloat", DEFAULT_EXP, 1.0, 32.0)
    _out(ng, "Weights", "NodeSocketVector")
    b = Builder(ng)
    w = b.sep(b.inp("Weights"))
    d = b.sep(b.inp("Detail"))
    fall, expo = b.inp("Falloff Contrast"), b.inp("Exponent")
    raw = []
    for wi, di in zip(w, d):
        dw = b.madd(b.sub(di, 1.0), fall, 1.0)                 # lerp(1, Dw, falloff)
        pw = b.math("POWER", b.math("MAXIMUM", wi, 0.0), expo)
        raw.append(b.mul(dw, pw))
    total = b.math("MAXIMUM", b.add(b.add(raw[0], raw[1]), raw[2]), 1e-20)
    norm = [b.div(r, total) for r in raw]
    r = b.math("MINIMUM", b.math("MAXIMUM", b.inp("Contrast"), 0.0), 0.999)
    k = b.math("LOGARITHM", b.sub(1.0, r), 0.5)                 # log(1-r)/log(0.5)
    g = [b.group(gain, {"X": n, "K": k}).outputs[0] for n in norm]
    gtotal = b.math("MAXIMUM", b.add(b.add(g[0], g[1]), g[2]), 1e-20)
    final = b.comb(*[b.div(gi, gtotal) for gi in g])
    b.output([("Weights", final)])
    return ng


def build_coordinates():
    ng = _get_group(NAME_COORDS, "Hex-tiling: three randomized UVs and triangle weights")
    _in(ng, "Vector", "NodeSocketVector", hide=True,
        desc="Texture coordinates (connect UV, optionally through a Mapping node)")
    _in(ng, "Rotation", "NodeSocketFloat", 0.0, 0.0, 25.0,
        desc="Random rotation strength per tile (0 = offset only, as in the reference demo)")
    _in(ng, "Seed", "NodeSocketInt", 0, 0, 100000, desc="Changes the random pattern (0 = reference)")
    for i in (1, 2, 3):
        _out(ng, f"UV {i}", "NodeSocketVector")
    _out(ng, "Weights", "NodeSocketVector",
         "Triangle weights, connect to the Blend groups. R/G/B = the three hex classes, so it doubles as a debug view")
    _out(ng, "Angles", "NodeSocketVector", "Rotation angles, connect to HexTile Blend Normal")

    b = Builder(ng)
    x, y, _ = b.sep(b.inp("Vector"))
    rot, seed = b.inp("Rotation"), b.inp("Seed")

    # TriangleGrid()
    gx, gy = b.mul(x, GRID_SCALE), b.mul(y, GRID_SCALE)
    sx = b.madd(gy, SKEW_A, gx)
    sy = b.mul(gy, SKEW_B)
    bx, by = b.math("FLOOR", sx), b.math("FLOOR", sy)
    fx, fy = b.sub(sx, bx), b.sub(sy, by)
    tz = b.sub(b.sub(1.0, fx), fy)
    s = b.math("LESS_THAN", tz, 0.0)                           # step(0, -temp.z)
    s2 = b.madd(s, 2.0, -1.0)
    ns = b.sub(1.0, s)
    w1 = b.mul(b.mul(tz, s2), -1.0)
    w2 = b.sub(s, b.mul(fy, s2))
    w3 = b.sub(s, b.mul(fx, s2))
    verts = [(b.add(bx, s), b.add(by, s)),
             (b.add(bx, s), b.add(by, ns)),
             (b.add(bx, ns), b.add(by, s))]

    uvs, angles, classes = [], [], []
    for vx, vy in verts:
        # The three hex centers around a triangle always fall in different
        # classes of (x - y) mod 3 (same idea as ProduceHexWeights()).
        classes.append(b.math("FLOORED_MODULO", b.sub(vx, vy), 3.0))
        hx, hy = b.madd(seed, 7.0, vx), b.madd(seed, 13.0, vy)   # seed 0 = reference ids
        # MakeCenST()
        cx = b.div(b.madd(vy, 0.5, vx), GRID_SCALE)
        cy = b.mul(vy, 1.0 / (SKEW_B * GRID_SCALE))
        # LoadRot2x2()
        a = b.add(b.add(b.math("ABSOLUTE", b.mul(hx, hy)), b.math("ABSOLUTE", b.add(hx, hy))), math.pi)
        a = b.math("MODULO", a, 2.0 * math.pi)
        a = b.sub(a, b.mul(b.math("GREATER_THAN", a, math.pi), 2.0 * math.pi))
        a = b.mul(a, rot)
        cs, si = b.math("COSINE", a), b.math("SINE", a)
        # mul(st - cen, rot)
        lx, ly = b.sub(x, cx), b.sub(y, cy)
        rx = b.add(b.mul(lx, cs), b.mul(ly, si))
        ry = b.sub(b.mul(ly, cs), b.mul(lx, si))
        # hash()
        r1 = b.add(b.mul(hx, 127.1), b.mul(hy, 311.7))
        r2 = b.add(b.mul(hx, 269.5), b.mul(hy, 183.3))
        h1 = b.math("FRACT", b.mul(b.math("SINE", r1), 43758.5453))
        h2 = b.math("FRACT", b.mul(b.math("SINE", r2), 43758.5453))
        uvs.append(b.comb(b.add(b.add(rx, cx), h1), b.add(b.add(ry, cy), h2)))
        angles.append(a)

    # Order the three samples by hex class instead of by triangle corner.
    # The blended result is the same, but each output UV now only jumps where
    # its weight is ~0, so EEVEE's mip selection no longer draws lines along
    # the triangle edges (the reference avoids this with SampleGrad()).
    weights = (w1, w2, w3)
    out_uv, out_w, out_a = [], [], []
    for target in (0.0, 1.0, 2.0):
        masks = [b.math("COMPARE", c, target, 0.25) for c in classes]
        uv = b.vmath("ADD", b.vmath("SCALE", uvs[0], scale=masks[0]), b.vmath("SCALE", uvs[1], scale=masks[1]))
        out_uv.append(b.vmath("ADD", uv, b.vmath("SCALE", uvs[2], scale=masks[2])))
        out_w.append(b.madd(weights[2], masks[2], b.madd(weights[1], masks[1], b.mul(weights[0], masks[0]))))
        out_a.append(b.madd(angles[2], masks[2], b.madd(angles[1], masks[1], b.mul(angles[0], masks[0]))))

    b.output([("UV 1", out_uv[0]), ("UV 2", out_uv[1]), ("UV 3", out_uv[2]),
              ("Weights", b.comb(*out_w)), ("Angles", b.comb(*out_a))])
    return ng


def _blend_inputs(ng, prefix, typ, contrast):
    for i in (1, 2, 3):
        _in(ng, f"{prefix} {i}", typ, (0.5, 0.5, 0.5, 1.0) if typ == "NodeSocketColor" else None)
    _in(ng, "Weights", "NodeSocketVector", hide=True, desc="From HexTile Coordinates")
    _in(ng, "Contrast", "NodeSocketFloat", contrast, 0.0, 0.999,
        desc="Border contrast (0.5 = off, higher = sharper transitions)")
    _in(ng, "Falloff Contrast", "NodeSocketFloat", DEFAULT_FALLOFF_CONTRAST, 0.0, 1.0,
        desc="How much brightness/bumpiness decides which tile wins")
    _in(ng, "Exponent", "NodeSocketFloat", DEFAULT_EXP, 1.0, 32.0,
        desc="Sharpness of the triangle weights")


def build_blend_color(weights):
    ng = _get_group(NAME_COLOR, "Hex-tiling: blend three color samples")
    _blend_inputs(ng, "Color", "NodeSocketColor", DEFAULT_COLOR_CONTRAST)
    _out(ng, "Color", "NodeSocketColor")
    _out(ng, "Weights", "NodeSocketVector", "Final weights, reuse for roughness/height (HexTile Blend Data)")
    b = Builder(ng)
    cols = [b.inp(f"Color {i}") for i in (1, 2, 3)]
    lum = [b.vmath("DOT_PRODUCT", c, LUMA) for c in cols]
    wn = b.group(weights, {"Weights": b.inp("Weights"), "Detail": b.comb(*lum),
                           "Contrast": b.inp("Contrast"),
                           "Falloff Contrast": b.inp("Falloff Contrast"),
                           "Exponent": b.inp("Exponent")}).outputs[0]
    w = b.sep(wn)
    acc = b.vmath("ADD", b.vmath("SCALE", cols[0], scale=w[0]), b.vmath("SCALE", cols[1], scale=w[1]))
    acc = b.vmath("ADD", acc, b.vmath("SCALE", cols[2], scale=w[2]))
    b.output([("Color", acc), ("Weights", wn)])
    return ng


def build_blend_data():
    ng = _get_group(NAME_DATA, "Hex-tiling: blend three samples with given weights")
    for i in (1, 2, 3):
        _in(ng, f"Data {i}", "NodeSocketColor", (0.5, 0.5, 0.5, 1.0))
    _in(ng, "Weights", "NodeSocketVector", hide=True,
        desc="Final weights from HexTile Blend Color (or Blend Normal)")
    _out(ng, "Color", "NodeSocketColor")
    _out(ng, "Value", "NodeSocketFloat", "Average of the channels")
    b = Builder(ng)
    w = b.sep(b.inp("Weights"))
    d = [b.inp(f"Data {i}") for i in (1, 2, 3)]
    acc = b.vmath("ADD", b.vmath("SCALE", d[0], scale=w[0]), b.vmath("SCALE", d[1], scale=w[1]))
    acc = b.vmath("ADD", acc, b.vmath("SCALE", d[2], scale=w[2]))
    val = b.vmath("DOT_PRODUCT", acc, (1.0 / 3.0,) * 3)
    b.output([("Color", acc), ("Value", val)])
    return ng


def build_blend_normal(weights):
    ng = _get_group(NAME_NORMAL, "Hex-tiling: blend three tangent-space normal map samples")
    _blend_inputs(ng, "Normal", "NodeSocketColor", DEFAULT_NORMAL_CONTRAST)
    ng.interface.items_tree["Weights"].description = "Weights from HexTile Coordinates"
    angles = _in(ng, "Angles", "NodeSocketVector", hide=True, desc="Angles from HexTile Coordinates")
    ng.interface.move(angles, 4)
    _in(ng, "DirectX", "NodeSocketBool", False,
        desc="Normal maps in DirectX format (green flipped). The output is always OpenGL")
    _out(ng, "Color", "NodeSocketColor", "Connect to a Normal Map node (Tangent Space)")
    _out(ng, "Weights", "NodeSocketVector")
    b = Builder(ng)
    ang = b.sep(b.inp("Angles"))
    ysign = b.madd(b.inp("DirectX"), -2.0, 1.0)                   # DirectX: flip green
    derivs, detail = [], []
    for i, a in zip((1, 2, 3), ang):
        n = b.vmath("MULTIPLY_ADD", b.inp(f"Normal {i}"), (2.0, 2.0, 2.0), (-1.0, -1.0, -1.0))
        nx, ny, nz = b.sep(n)
        ny = b.mul(ny, ysign)
        # TspaceNormalToDerivative()
        zma = b.math("MAXIMUM", b.math("ABSOLUTE", nz),
                     b.mul(b.math("MAXIMUM", b.math("ABSOLUTE", nx), b.math("ABSOLUTE", ny)), 1.0 / 128.0))
        dx, dy = b.div(b.mul(nx, -1.0), zma), b.div(b.mul(ny, -1.0), zma)
        # d = mul(rot, d): undo the per-tile rotation
        cs, si = b.math("COSINE", a), b.math("SINE", a)
        rx = b.sub(b.mul(cs, dx), b.mul(si, dy))
        ry = b.add(b.mul(si, dx), b.mul(cs, dy))
        dd = b.madd(rx, rx, b.mul(ry, ry))
        detail.append(b.math("SQRT", b.div(dd, b.add(dd, 1.0))))   # sqrt(D/(1+D))
        derivs.append((rx, ry))
    wn = b.group(weights, {"Weights": b.inp("Weights"), "Detail": b.comb(*detail),
                           "Contrast": b.inp("Contrast"),
                           "Falloff Contrast": b.inp("Falloff Contrast"),
                           "Exponent": b.inp("Exponent")}).outputs[0]
    w = b.sep(wn)
    sx = b.madd(derivs[2][0], w[2], b.madd(derivs[1][0], w[1], b.mul(derivs[0][0], w[0])))
    sy = b.madd(derivs[2][1], w[2], b.madd(derivs[1][1], w[1], b.mul(derivs[0][1], w[0])))
    nrm = b.vmath("NORMALIZE", b.comb(b.mul(sx, -1.0), b.mul(sy, -1.0), 1.0))
    col = b.vmath("MULTIPLY_ADD", nrm, (0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    b.output([("Color", col), ("Weights", wn)])
    return ng


PUBLIC = {"coords": NAME_COORDS, "color": NAME_COLOR, "normal": NAME_NORMAL, "data": NAME_DATA}
ALL_NAMES = (NAME_GAIN, NAME_WEIGHTS, NAME_COORDS, NAME_COLOR, NAME_NORMAL, NAME_DATA)


def build_all():
    gain = build_gain()
    weights = build_weights(gain)
    groups = {
        "coords": build_coordinates(),
        "color": build_blend_color(weights),
        "normal": build_blend_normal(weights),
        "data": build_blend_data(),
    }
    for name in ALL_NAMES:
        bpy.data.node_groups[name][VERSION_KEY] = GROUP_VERSION
    return groups


def _group_users():
    """Group nodes that use HexTile groups, in materials and in other groups."""
    trees = [m.node_tree for m in bpy.data.materials if m.node_tree]
    # Skip the HexTile groups themselves: their nodes are rebuilt from scratch.
    trees += [g for g in bpy.data.node_groups
              if g.bl_idname == "ShaderNodeTree" and g.name not in ALL_NAMES]
    for tree in trees:
        for node in tree.nodes:
            if node.bl_idname == "ShaderNodeGroup" and node.node_tree and node.node_tree.name in ALL_NAMES:
                yield node


def ensure_groups():
    """Return the public groups, building or upgrading them when needed.

    Rebuilding clears the group interfaces, which resets the values on group
    nodes that already use them, so those values are saved and restored.
    """
    current = all(
        (g := bpy.data.node_groups.get(n)) is not None and g.get(VERSION_KEY, 0) >= GROUP_VERSION
        for n in ALL_NAMES)
    if current:
        return {k: bpy.data.node_groups[n] for k, n in PUBLIC.items()}
    users = list(_group_users())
    is_user = {n.as_pointer() for n in users}
    saved, links, seen = [], [], set()
    for node in users:
        tree = node.id_data
        for sock in node.inputs:
            if hasattr(sock, "default_value"):
                v = sock.default_value
                saved.append((node, sock.name, tuple(v) if hasattr(v, "__len__") else v))
        for link in tree.links:
            if node not in (link.from_node, link.to_node) or link.as_pointer() in seen:
                continue
            seen.add(link.as_pointer())
            # Sockets of HexTile group nodes are recreated, so remember them by
            # name; other nodes keep their sockets.
            src = ((link.from_node, link.from_socket.name)
                   if link.from_node.as_pointer() in is_user else link.from_socket)
            dst = ((link.to_node, link.to_socket.name)
                   if link.to_node.as_pointer() in is_user else link.to_socket)
            links.append((tree, src, dst))
    groups = build_all()
    for node, name, value in saved:
        sock = node.inputs.get(name)
        if sock is not None and hasattr(sock, "default_value"):
            sock.default_value = value
    for tree, src, dst in links:
        if isinstance(src, tuple):
            src = src[0].outputs.get(src[1])
        if isinstance(dst, tuple):
            dst = dst[0].inputs.get(dst[1])
        if src is not None and dst is not None:
            tree.links.new(src, dst)
    # Inputs that did not exist before start at 0 on existing nodes: use the defaults.
    known = {(n.as_pointer(), name) for n, name, _ in saved}
    for node in _group_users():
        for item in node.node_tree.interface.items_tree:
            if getattr(item, "in_out", None) != "INPUT" or not hasattr(item, "default_value"):
                continue
            if (node.as_pointer(), item.name) not in known and item.name in node.inputs:
                v = item.default_value
                node.inputs[item.name].default_value = tuple(v) if hasattr(v, "__len__") else v
    return groups


# ---------------------------------------------------------------------------
# Per-image wrapper (swap mode): a drop-in replacement for one Image Texture
# ---------------------------------------------------------------------------

WRAP_KEY = "hextile_wrap"          # marks wrapper groups: {"role", "interpolation"} + image pointer
WRAP_IMAGE_KEY = "hextile_wrap_image"
PARAM_INPUTS = ("Use Vector", "Use Weights", "Rotation", "Seed", "Contrast", "Falloff Contrast",
                "Exponent", "DirectX")


def _mix_vector(b, fac, a, bvec):
    """fac ? bvec : a (fac is a 0/1 bool)."""
    n = b.nodes.new("ShaderNodeMix")
    n.data_type = "VECTOR"
    b._put(n, (fac, a, bvec))
    b.set(fac, next(s for s in n.inputs if s.identifier == "Factor_Float"))
    b.set(a, next(s for s in n.inputs if s.identifier == "A_Vector"))
    b.set(bvec, next(s for s in n.inputs if s.identifier == "B_Vector"))
    return next(s for s in n.outputs if s.identifier == "Result_Vector")


def build_wrapper(name, image, role, interpolation, groups):
    """Group with Coordinates + 3 Image Textures + blend, shaped like an Image Texture.

    Inputs: Vector (unlinked -> UV, like Image Texture), shared Weights, tiling settings.
    Outputs: Color, Alpha, Weights (to share with the other maps).
    """
    ng = bpy.data.node_groups.get(name)
    if ng is None:
        ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    else:
        ng.nodes.clear()
        ng.interface.clear()
    ng.description = f"HexTile: {image.name}"
    _in(ng, "Vector", "NodeSocketVector", hide=True, desc="Texture coordinates (unused = UV)")
    _in(ng, "Weights", "NodeSocketVector", hide=True, desc="Shared weights from the base color")
    _in(ng, "Use Vector", "NodeSocketBool", False)
    _in(ng, "Use Weights", "NodeSocketBool", False)
    _in(ng, "Rotation", "NodeSocketFloat", 0.0, 0.0, 25.0)
    _in(ng, "Seed", "NodeSocketInt", 0, 0, 100000)
    _in(ng, "Contrast", "NodeSocketFloat",
        DEFAULT_NORMAL_CONTRAST if role == "normal" else DEFAULT_COLOR_CONTRAST, 0.0, 0.999)
    _in(ng, "Falloff Contrast", "NodeSocketFloat", DEFAULT_FALLOFF_CONTRAST, 0.0, 1.0)
    _in(ng, "Exponent", "NodeSocketFloat", DEFAULT_EXP, 1.0, 32.0)
    if role == "normal":
        _in(ng, "DirectX", "NodeSocketBool", False)
    _out(ng, "Color", "NodeSocketColor")
    _out(ng, "Alpha", "NodeSocketFloat")
    _out(ng, "Weights", "NodeSocketVector")

    b = Builder(ng)
    tc = b.nodes.new("ShaderNodeTexCoord")
    b.level[tc] = 0
    tc.location = (-b.X_STEP, -400)
    vec = _mix_vector(b, b.inp("Use Vector"), tc.outputs["UV"], b.inp("Vector"))
    coords = b.group(groups["coords"], {"Vector": vec, "Rotation": b.inp("Rotation"), "Seed": b.inp("Seed")})

    imgs = []
    lv = b.level[coords] + 1
    for i in range(3):
        t = b.nodes.new("ShaderNodeTexImage")
        t.image = image
        t.interpolation = interpolation
        t.extension = "REPEAT"
        t.hide = True
        t.location = (lv * b.X_STEP, -i * 60)
        b.level[t] = lv
        b.links.new(coords.outputs[f"UV {i + 1}"], t.inputs["Vector"])
        imgs.append(t)

    common = {"Contrast": b.inp("Contrast"), "Falloff Contrast": b.inp("Falloff Contrast"),
              "Exponent": b.inp("Exponent")}
    if role == "normal":
        inputs = {f"Normal {i + 1}": t.outputs["Color"] for i, t in enumerate(imgs)}
        inputs.update(common, Weights=coords.outputs["Weights"], Angles=coords.outputs["Angles"],
                      DirectX=b.inp("DirectX"))
        g = b.group(groups["normal"], inputs)
        color, weights = g.outputs["Color"], g.outputs["Weights"]
    else:
        inputs = {f"Color {i + 1}": t.outputs["Color"] for i, t in enumerate(imgs)}
        inputs.update(common, Weights=coords.outputs["Weights"])
        bc = b.group(groups["color"], inputs)
        if role == "color":
            color, weights = bc.outputs["Color"], bc.outputs["Weights"]
        else:
            # Data maps follow the base color's weights when they are shared.
            weights = _mix_vector(b, b.inp("Use Weights"), bc.outputs["Weights"], b.inp("Weights"))
            data = {f"Data {i + 1}": t.outputs["Color"] for i, t in enumerate(imgs)}
            data["Weights"] = weights
            color = b.group(groups["data"], data).outputs["Color"]
    alpha = {f"Data {i + 1}": t.outputs["Alpha"] for i, t in enumerate(imgs)}
    alpha["Weights"] = weights
    alpha_out = b.group(groups["data"], alpha).outputs["Value"]
    b.output([("Color", color), ("Alpha", alpha_out), ("Weights", weights)])

    ng[WRAP_KEY] = {"role": role, "interpolation": interpolation}
    ng[WRAP_IMAGE_KEY] = image
    ng[VERSION_KEY] = GROUP_VERSION
    return ng


def is_wrapper(tree):
    return tree is not None and WRAP_KEY in tree


def get_wrapper(image, role, interpolation, label):
    """Reuse the wrapper for (image, role, interpolation) or build it."""
    groups = ensure_groups()
    for ng in bpy.data.node_groups:
        info = ng.get(WRAP_KEY)
        if info and ng.get(WRAP_IMAGE_KEY) == image and info.get("role") == role \
                and info.get("interpolation") == interpolation:
            if ng.get(VERSION_KEY, 0) < GROUP_VERSION:
                return build_wrapper(ng.name, image, role, interpolation, groups)
            return ng
    return build_wrapper(f"HexTile {label}: {image.name}", image, role, interpolation, groups)


def remove_unused_wrappers():
    for ng in [g for g in bpy.data.node_groups if is_wrapper(g) and g.users == 0]:
        bpy.data.node_groups.remove(ng)

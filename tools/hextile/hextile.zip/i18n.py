# SPDX-FileCopyrightText: 2026 mikat
# SPDX-License-Identifier: GPL-3.0-or-later

"""Translations. English is the source language; Japanese follows Blender's language setting.

UI labels use our own context (CTX) so Blender's built-in translations of
common words ("Revert", "Normal", ...) do not mix in. Tooltips are also
registered in the default context because Blender looks them up there.
"""

import bpy

CTX = "HexTile"
T = bpy.app.translations

# Labels, buttons, notes and reports (looked up in CTX).
UI_JA = {
    # panel
    "Images": "画像",
    "Detect": "自動判定",
    "More": "その他",
    "Apply HexTile": "HexTile にする",
    "Build from Image Files": "画像ファイルから作る",
    "Update": "更新",
    "Mode": "方式",
    "Swap Images": "画像を差し替え",
    "New Node Tree": "新しく組み直す",
    "Revert": "元に戻す",
    "Detect Maps": "自動判定し直す",
    "Open Image": "画像を読み込む",
    "Changes apply on Update": "変更は「更新」で反映",
    "Tiling": "タイル",
    "Scale (repeats)": "大きさ（繰り返しの回数）",
    "Rotation": "回転",
    "Seed": "シード",
    "Color Blending": "カラーの境目",
    "Contrast": "コントラスト",
    "Brightness Priority": "明るさの優先度",
    "Strength": "強さ",
    "Maps and Notes": "使った画像とメモ",
    "DirectX": "DirectX",
    # slot labels
    "Color": "カラー",
    "Normal": "ノーマル",
    "Rough": "ラフネス",
    "Metal": "メタル",
    "Spec": "スペキュラ",
    "Height": "高さ",
    "Gloss": "光沢",
    "Opacity": "不透明",
    "Emit": "放射",
    # map roles (notes, node labels)
    "Base Color": "ベースカラー",
    "Roughness": "ラフネス",
    "Metallic": "メタリック",
    "Specular": "スペキュラー",
    "Emission": "放射",
    # where a map came from
    "slot": "指定",
    "name": "名前",
    "link": "つながり",
    # notes
    "Principled '{name}' had nodes connected; they are not carried over":
        "Principled の「{name}」は元はノードがつながっていましたが、作り直しでは外れています",
    "Original texture coordinates were too complex; rebuilt with UV":
        "元のテクスチャ座標が複雑だったので、UV で作り直しました",
    "No usable images (add Image Texture nodes or pick image files)":
        "使える画像が見つかりませんでした（Image Texture ノードか、画像ファイルを選んでください）",
    "{name}: set to Non-Color": "{name} を Non-Color にしました",
    "No Principled BSDF in the original; created a new one":
        "元のマテリアルに Principled BSDF が無かったので、新しく作りました",
    "AO not used (the original material did not use it)":
        "AO は元のマテリアルでも使われていなかったので、使っていません",
    "Gloss not used (a Roughness map is set)": "ラフネスがあるので、光沢の画像は使っていません",
    "Height not used (the original material did not use it)":
        "高さの画像は元のマテリアルで使われていなかったので、使っていません",
    "Height connected through a Displacement node (Scale 0.05)":
        "高さは Displacement ノード（Scale 0.05）につなぎました",
    "{name}: not used ({why})": "{name} は使っていません（{why}）",
    "unknown map type": "役割が分からない",
    "second {role} map": "{role}が重複",
    # reports
    "All image slots are empty (run Detect or pick images)":
        "画像の欄が空です（自動判定するか、手で選んでください）",
    "HexTile: built with {count} maps": "HexTile: {count} 枚の画像で組みました",
    "No images selected": "画像が選ばれていません",
    "Could not tell what the selected images are": "選んだ画像の役割が分かりませんでした",
    # node labels (new data)
    "HexTile: Original Nodes": "HexTile: 元のノード",
    "HexTile: Original Images": "HexTile: 元の画像",
    # swap mode
    "{name}: not in the material (use New Node Tree to add it)":
        "{name} はマテリアルに無いので使っていません（「新しく組み直す」なら使えます）",
    "{name}: left as is ({why})": "{name} はそのままにしました（{why}）",
    "{name}: not connected (use New Node Tree to use it)":
        "{name} はつながっていないので使っていません（「新しく組み直す」なら使えます）",
    "not set to Repeat": "Repeat ではない",
    "not Flat projection": "Flat 投影ではない",
    "UDIM / tiled image": "UDIM の画像",
    "not a still image": "静止画ではない",
    "No image nodes to swap (use New Node Tree, or pick images in the slots)":
        "差し替える画像ノードがありません（「新しく組み直す」を使うか、欄で画像を選んでください）",
    "1 - Gloss": "1 − 光沢",
}

# Tooltips (registered in both the default context and CTX).
TIPS_JA = {
    "Hex-tile the material with the images in the slots (see Mode)":
        "欄の画像でマテリアルを HexTile にします（方式は下の切り替えで選びます）",
    "Replace only the image nodes; everything after them stays as it is":
        "画像ノードだけを差し替えます。後ろのノードはそのまま使います",
    "Build a new, tidy node tree; the original nodes are kept in a frame":
        "新しく整理したノードを組みます。元のノードはフレームに残します",
    "Random rotation per tile. Keep 0 for directional textures":
        "タイルごとの回転の強さ。向きのある素材は 0 のまま",
    "Fill the image slots again from the Image Texture nodes in the material (overwrites manual choices)":
        "マテリアル内の Image Texture ノードから、欄をもう一度自動で埋めます（手で選んだ分は上書き）",
    "Load an image file into this slot": "この欄に画像ファイルを読み込みます",
    "Pick a set of image files (color, normal, roughness, ...), fill the slots and build with hex-tiling":
        "画像ファイル（カラー・ノーマル・ラフネスなど）をまとめて選び、欄を埋めて HexTile で組みます",
    "Delete the HexTile nodes and put the original nodes back where they were":
        "HexTile で作ったノードを消し、元のノードを元の位置に戻します",
    "The normal map is in DirectX format (green flipped)": "ノーマルマップが DirectX 形式（緑が逆）",
}


def _table():
    ja = {(CTX, k): v for k, v in UI_JA.items()}
    for k, v in TIPS_JA.items():
        ja[("*", k)] = v
        ja[(CTX, k)] = v
    return {"ja_JP": ja}


def iface(msg):
    """Text shown in the UI (labels, notes)."""
    return T.pgettext_iface(msg, CTX)


def rpt(msg):
    """Operator reports."""
    return T.pgettext_rpt(msg, CTX)


def data(msg):
    """Names of new data (node labels), following the "New Data" setting."""
    return T.pgettext_data(msg, CTX)


def register():
    T.register(__package__, _table())


def unregister():
    T.unregister(__package__)

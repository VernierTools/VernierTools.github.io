# SPDX-FileCopyrightText: 2026 mikat
# SPDX-License-Identifier: GPL-3.0-or-later

"""Work out which image is which (base color, normal, roughness, ...).

The file name decides first (it is the most reliable for PBR texture sets);
when it says nothing, the socket the image ends up in decides.
"""

import os
import re
from dataclasses import dataclass, field

import bpy

# Order matters: "color" is last because its keywords are the most generic.
ROLES = ("normal", "roughness", "gloss", "metallic", "specular", "ao", "height", "opacity", "emission", "color")

ROLE_LABELS = {
    "color": "Base Color",
    "normal": "Normal",
    "roughness": "Roughness",
    "gloss": "Gloss",
    "metallic": "Metallic",
    "specular": "Specular",
    "ao": "AO",
    "height": "Height",
    "opacity": "Opacity",
    "emission": "Emission",
}

NON_COLOR_ROLES = {"normal", "roughness", "gloss", "metallic", "specular", "ao", "height", "opacity"}

KEYWORDS = {
    "normal": {"normal", "normals", "nor", "nrm", "nml", "norm", "nrml", "normalgl", "normaldx", "normalmap"},
    "roughness": {"rough", "roughness", "rgh"},
    "gloss": {"gloss", "glossiness", "gls", "smoothness"},
    "metallic": {"metal", "metallic", "metalness", "mtl"},
    "specular": {"spec", "specular", "specularity", "spc", "speclevel", "specularlevel"},
    "ao": {"ao", "ambientocclusion", "occlusion", "occ"},
    "height": {"height", "disp", "displacement", "bump", "hgt", "heightmap"},
    "opacity": {"opacity", "alpha", "transparency", "transparent"},
    "emission": {"emission", "emissive", "emit", "glow"},
    "color": {"diff", "diffuse", "albedo", "basecolor", "color", "colour", "col", "alb", "basecolour"},
}
DX_TOKENS = {"dx", "directx", "normaldx"}
IGNORE_TOKENS = {"preview", "thumb", "thumbnail", "idmap", "id"}

# Principled BSDF input -> role
SOCKET_ROLES = {
    "Base Color": "color",
    "Roughness": "roughness",
    "Metallic": "metallic",
    "Specular IOR Level": "specular",
    "Alpha": "opacity",
    "Emission Color": "emission",
    "Normal": "normal",
}


def _words(name):
    stem = os.path.splitext(os.path.basename(name))[0]
    stem = re.sub(r"([a-z])([A-Z])", r"\1 \2", stem)          # camelCase
    stem = re.sub(r"([A-Za-z])(\d)|(\d)([A-Za-z])",
                  lambda m: " ".join(g for g in m.groups() if g), stem)
    return [w for w in re.split(r"[^A-Za-z0-9]+", stem.lower()) if w]


def tokens(name):
    words = _words(name)
    toks = set(words)
    toks |= {a + b for a, b in zip(words, words[1:])}          # base color -> basecolor
    return toks


def role_from_name(name):
    """Role of the last map keyword in the name.

    Texture sets put the material name first and the map type last
    (Metal047B_2K_Color), so the keyword nearest the end wins.
    """
    words = _words(name)
    found = []   # (end position, length, role)
    for i, w in enumerate(words):
        cands = [(i, 1, w)]
        if i + 1 < len(words):
            cands.append((i + 1, 2, w + words[i + 1]))
        for end, length, tok in cands:
            for role in ROLES:
                if tok in KEYWORDS[role]:
                    found.append((end, length, role))
                    break
    if not found:
        return None
    return max(found)[2]


def is_directx(name):
    return bool(tokens(name) & DX_TOKENS)


@dataclass
class Usage:
    """Where an image ends up in the original material."""
    role: str = None
    socket: str = ""
    normal_map: object = None      # ShaderNodeNormalMap on the way
    bump: object = None            # ShaderNodeBump fed by the image
    displacement: object = None    # ShaderNodeDisplacement fed by the image
    via_mix: object = None         # e.g. AO multiplied into the base color


def trace_usage(node, max_depth=8):
    """Follow links downstream from an image node to the shader it feeds.

    The Color output decides the map type; the Alpha output only counts when
    Color is not used (a base color's alpha often goes to the BSDF Alpha).
    """
    usage = _trace(node, ("Color",), max_depth)
    if usage.role is None and usage.normal_map is None:
        alpha = _trace(node, ("Alpha",), max_depth)
        if alpha.role is not None:
            return alpha
    return usage


def _trace(node, first_outputs, max_depth):
    usage = Usage()
    frontier = [(node, 0)]
    seen = set()
    while frontier:
        cur, depth = frontier.pop(0)
        if cur.as_pointer() in seen or depth > max_depth:
            continue
        seen.add(cur.as_pointer())
        outs = [o for o in cur.outputs if cur != node or o.identifier in first_outputs]
        for out in outs:
            for link in out.links:
                to, sock = link.to_node, link.to_socket
                if to.bl_idname == "ShaderNodeNormalMap":
                    usage.normal_map = to
                elif to.bl_idname == "ShaderNodeBump" and sock.identifier == "Height":
                    usage.bump = to
                    usage.role = usage.role or "height"
                elif to.bl_idname == "ShaderNodeDisplacement" and sock.identifier == "Height":
                    usage.displacement = to
                    usage.role = usage.role or "height"
                elif to.bl_idname in {"ShaderNodeMix", "ShaderNodeMixRGB"} and usage.via_mix is None:
                    usage.via_mix = to
                if to.bl_idname == "ShaderNodeBsdfPrincipled":
                    role = SOCKET_ROLES.get(sock.name)
                    if role and usage.role is None:
                        usage.role = role
                        usage.socket = sock.name
                    continue
                frontier.append((to, depth + 1))
    if usage.normal_map is not None and usage.role in (None, "normal"):
        usage.role = "normal"
    return usage


@dataclass
class MapInfo:
    role: str
    image: object
    node: object = None            # original Image Texture node (None when picked from files)
    usage: Usage = field(default_factory=Usage)
    by_name: bool = False
    directx: bool = False
    source: str = ""               # "name", "link" or "slot" (chosen in the panel)
    forced: bool = False           # use it even if the original material did not

    @property
    def connected(self):
        return self.usage.role is not None


@dataclass
class Detection:
    maps: dict = field(default_factory=dict)       # role -> MapInfo
    ignored: list = field(default_factory=list)    # (image name, reason template, role)
    principled: object = None
    output: object = None
    vector_source: object = None                   # socket feeding the original Vector input


def active_output(nt):
    outs = [n for n in nt.nodes if n.bl_idname == "ShaderNodeOutputMaterial"]
    for n in outs:
        if n.is_active_output:
            return n
    return outs[0] if outs else None


# (where it is connected, what the name says) pairs where the name wins:
# AO is multiplied into the base color and gloss is inverted into roughness.
NAME_OVER_LINK = {("color", "ao"), ("roughness", "gloss")}


def _candidate(img, node):
    name_role = role_from_name(img.filepath or img.name) or role_from_name(img.name)
    usage = trace_usage(node) if node is not None else Usage()
    if (name_role and usage.role and name_role != usage.role
            and (usage.role, name_role) not in NAME_OVER_LINK):
        role = usage.role          # the connection is more trustworthy than a name
    else:
        role = name_role or usage.role
    if role is None:
        return None
    return MapInfo(role=role, image=img, node=node, usage=usage, by_name=role == name_role,
                   directx=role == "normal" and (image_is_directx(img) or _map_is_directx(usage)),
                   source="name" if role == name_role else "link")


def _map_is_directx(usage):
    # Blender 5.2's Normal Map node has its own OpenGL/DirectX switch.
    nm = usage.normal_map
    return nm is not None and getattr(nm, "convention", "OPENGL") == "DIRECTX"


def image_is_directx(img):
    return is_directx(img.filepath or "") or is_directx(img.name)


def _rank(info):
    # Prefer images the original material actually uses, then OpenGL normals.
    return (info.connected, not info.directx)


def detect(mat, images=None):
    """Detect maps in a material, or classify `images` (picked files) instead."""
    det = Detection()
    nt = mat.node_tree
    if nt is not None:
        det.output = active_output(nt)
        if det.output and det.output.inputs["Surface"].is_linked:
            shader = det.output.inputs["Surface"].links[0].from_node
            if shader.bl_idname == "ShaderNodeBsdfPrincipled":
                det.principled = shader
        if det.principled is None:
            det.principled = next((n for n in nt.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)

    if images is not None:
        pairs = [(img, None) for img in images]
    else:
        pairs = [(n.image, n) for n in (nt.nodes if nt else [])
                 if n.bl_idname == "ShaderNodeTexImage" and n.image is not None
                 and not n.get("hextile_generated")]

    candidates = []
    for img, node in pairs:
        info = _candidate(img, node)
        if info is None:
            det.ignored.append((img.name, "unknown map type", None))
        else:
            candidates.append(info)
    for info in sorted(candidates, key=_rank, reverse=True):
        if info.role in det.maps:
            det.ignored.append((info.image.name, "second {role} map", info.role))
        else:
            det.maps[info.role] = info

    # Texture coordinates: reuse what fed the original base color (or any map).
    for role in ("color",) + ROLES:
        info = det.maps.get(role)
        if info and info.node and info.node.inputs["Vector"].is_linked:
            det.vector_source = info.node.inputs["Vector"].links[0].from_socket
            break
    return det


def slot_defaults(det):
    """Images to put in the panel slots after auto-detection.

    AO and height only go in when the original material used them, so an
    untouched auto-detection builds the same material as before.
    """
    out = {}
    for role, info in det.maps.items():
        if role in ("ao", "height") and not info.connected:
            continue
        out[role] = info.image
    return out


def detect_assigned(mat, assignments, directx=False):
    """Detection from images chosen in the panel slots ({role: image})."""
    det = detect(mat)
    auto = {info.image.as_pointer(): info for info in det.maps.values()}
    nodes = [n for n in (mat.node_tree.nodes if mat.node_tree else [])
             if n.bl_idname == "ShaderNodeTexImage" and n.image is not None
             and not n.get("hextile_generated")]
    det.maps, det.ignored = {}, []
    for role, img in assignments.items():
        if img is None:
            continue
        info = auto.get(img.as_pointer())
        if info is not None and info.role == role:
            usage, node = info.usage, info.node
        else:
            # Same image used by an original node? Keep its settings and usage.
            node = next((n for n in nodes if n.image == img), None)
            usage = trace_usage(node) if node is not None else Usage()
        det.maps[role] = MapInfo(role=role, image=img, node=node, usage=usage,
                                 directx=role == "normal" and directx,
                                 source="slot", forced=True)
    det.vector_source = None
    for role in ("color",) + ROLES:
        info = det.maps.get(role)
        if info and info.node and info.node.inputs["Vector"].is_linked:
            det.vector_source = info.node.inputs["Vector"].links[0].from_socket
            break
    return det


def load_images(directory, filenames):
    images = []
    for fn in filenames:
        path = os.path.join(directory, fn)
        if os.path.isfile(path):
            images.append(bpy.data.images.load(path, check_existing=True))
    return images

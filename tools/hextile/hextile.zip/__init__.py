# SPDX-FileCopyrightText: 2026 mikat
# SPDX-License-Identifier: GPL-3.0-or-later

"""HexTile: rebuild a material with hex-tiling from the Shader Editor sidebar."""

import os

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from bpy.types import Operator, OperatorFileListElement, Panel, PropertyGroup

from . import build
from . import detect as dt
from . import i18n
from . import replace
from .i18n import CTX

KEY_NOTES = "hextile_notes"
MAIN_ROLES = ("color", "normal", "roughness", "metallic", "height", "ao")
MORE_ROLES = ("specular", "gloss", "opacity", "emission")
SLOT_ROLES = MAIN_ROLES + MORE_ROLES


def _material(context):
    space = context.space_data
    if space and space.type == "NODE_EDITOR" and space.tree_type == "ShaderNodeTree":
        if isinstance(space.id, bpy.types.Material):
            return space.id
    return None


def _short_names(names):
    """Drop the prefix shared by a texture set: Rock051_2K_Color.jpg -> …Color.jpg."""
    names = list(names)
    if len(names) < 2:
        return {n: n for n in names}
    prefix = os.path.commonprefix(names)
    cut = max(prefix.rfind(c) for c in "_- .") + 1
    if cut < 4:
        return {n: n for n in names}
    return {n: "…" + n[cut:] for n in names}


def _store_notes(mat, report):
    short = _short_names([img for _, img, _ in report.used])
    def how_text(how):
        parts = [p.strip() for p in how.split(",")]
        return ", ".join(i18n.iface(p) for p in parts)
    lines = [f"{i18n.iface(dt.ROLE_LABELS[r])} ← {short[img]} ({how_text(how)})" for r, img, how in report.used]
    notes = []
    for note in report.notes:
        for full, s in short.items():
            note = note.replace(full, s)
        notes.append(note)
    mat[KEY_NOTES] = lines + notes


def _redraw_node_editors():
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == "NODE_EDITOR":
                area.tag_redraw()


# ---------------------------------------------------------------------------
# Slots: one image per role, stored on the material
# ---------------------------------------------------------------------------

def _poll_image(self, img):
    return img.type == "IMAGE"


def _normal_changed(self, context):
    if self.normal is not None:
        self.normal_directx = dt.image_is_directx(self.normal)


def tiling_params(mat):
    s = mat.hextile
    return {"rotation": s.rotation, "seed": s.seed, "color_contrast": s.color_contrast,
            "color_falloff": s.color_falloff, "normal_contrast": s.normal_contrast}


def push_params(mat):
    """Send the material's tiling settings to every generated node (both modes)."""
    if not build.is_applied(mat) or mat.node_tree is None:
        return
    p = tiling_params(mat)
    dx = mat.hextile.normal_directx
    groups = {k: bpy.data.node_groups.get(v) for k, v in replace.hx.PUBLIC.items()}
    for node in build.generated(mat.node_tree):
        if node.bl_idname != "ShaderNodeGroup" or node.node_tree is None:
            continue
        tree = node.node_tree
        if replace.hx.is_wrapper(tree):
            replace.set_wrapper_params(node, p, dx)
        elif tree == groups["coords"]:
            node.inputs["Rotation"].default_value = p["rotation"]
            node.inputs["Seed"].default_value = p["seed"]
        elif tree == groups["color"]:
            node.inputs["Contrast"].default_value = p["color_contrast"]
            node.inputs["Falloff Contrast"].default_value = p["color_falloff"]
        elif tree == groups["normal"]:
            node.inputs["Contrast"].default_value = p["normal_contrast"]
            node.inputs["Falloff Contrast"].default_value = p["color_falloff"]
            node.inputs["DirectX"].default_value = dx


def _params_changed(self, context):
    push_params(self.id_data)


class HexTileSlots(PropertyGroup):
    initialized: BoolProperty(default=False)
    show_more: BoolProperty(name="More", default=False, translation_context=CTX)
    mode: EnumProperty(
        name="Mode", default="SWAP", translation_context=CTX,
        items=[("SWAP", "Swap Images",
                "Replace only the image nodes; everything after them stays as it is"),
               ("REBUILD", "New Node Tree",
                "Build a new, tidy node tree; the original nodes are kept in a frame")])
    normal_directx: BoolProperty(name="DirectX", default=False, update=_params_changed, translation_context=CTX,
                                 description="The normal map is in DirectX format (green flipped)")
    rotation: FloatProperty(name="Rotation", default=0.0, min=0.0, max=25.0, update=_params_changed,
                            translation_context=CTX,
                            description="Random rotation per tile. Keep 0 for directional textures")
    seed: IntProperty(name="Seed", default=0, min=0, update=_params_changed, translation_context=CTX)
    color_contrast: FloatProperty(name="Contrast", default=0.7, min=0.0, max=0.999, update=_params_changed,
                                  translation_context=CTX)
    color_falloff: FloatProperty(name="Brightness Priority", default=0.6, min=0.0, max=1.0,
                                 update=_params_changed, translation_context=CTX)
    normal_contrast: FloatProperty(name="Contrast", default=0.5, min=0.0, max=0.999, update=_params_changed,
                                   translation_context=CTX)


for _role in SLOT_ROLES:
    _kw = {"update": _normal_changed} if _role == "normal" else {}
    HexTileSlots.__annotations__[_role] = PointerProperty(
        type=bpy.types.Image, name=dt.ROLE_LABELS[_role], poll=_poll_image, translation_context=CTX, **_kw)


def fill_slots(mat, det=None, all_roles=False):
    """Fill the slots from auto-detection (overwrites them)."""
    slots = mat.hextile
    det = det or dt.detect(mat)
    found = {r: i.image for r, i in det.maps.items()} if all_roles else dt.slot_defaults(det)
    for role in SLOT_ROLES:
        setattr(slots, role, found.get(role))
    normal = det.maps.get("normal")
    slots.normal_directx = bool(normal and normal.directx and "normal" in found)
    slots.show_more = slots.show_more or any(found.get(r) for r in MORE_ROLES)
    if not slots.initialized and not replace.has_connected_images(mat):
        slots.mode = "REBUILD"      # images are only lying around: nothing to swap into
    slots.initialized = True


def slot_assignments(mat):
    slots = mat.hextile
    return {role: getattr(slots, role) for role in SLOT_ROLES if getattr(slots, role) is not None}


_pending = set()


def _schedule_fill(mat):
    """Auto-fill the slots the first time a material is shown (can't write in draw())."""
    key = mat.name_full
    if key in _pending or mat.library is not None:
        return
    _pending.add(key)

    def fill():
        _pending.discard(key)
        m = bpy.data.materials.get(key)
        if m is not None and not m.hextile.initialized:
            fill_slots(m)
            _redraw_node_editors()
        return None

    bpy.app.timers.register(fill, first_interval=0.01)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

# Settings now live on the material; only the rebuilt Mapping / Normal Map are carried over.
TUNED_TYPES = {"ShaderNodeMapping", "ShaderNodeNormalMap"}


def _tuned_values(mat):
    """Values the user may have changed on the generated nodes (kept across Update)."""
    out = {}
    if not build.is_applied(mat):
        return out
    for node in build.generated(mat.node_tree):
        if node.bl_idname not in TUNED_TYPES or node.get(build.GEN) in out:
            continue
        vals = {}
        for s in node.inputs:
            if not s.is_linked and hasattr(s, "default_value"):
                v = s.default_value
                vals[s.identifier] = tuple(v) if hasattr(v, "__len__") else v
        out[node.get(build.GEN)] = vals
    return out


def _restore_tuned(mat, saved, skip=("DirectX",)):
    for node in build.generated(mat.node_tree):
        vals = saved.get(node.get(build.GEN))
        if not vals or node.bl_idname not in TUNED_TYPES:
            continue
        for s in node.inputs:
            if s.identifier in vals and s.identifier not in skip and not s.is_linked:
                s.default_value = vals[s.identifier]


def _run_apply(op, mat, mode=None):
    if not mat.hextile.initialized:
        fill_slots(mat)
    assignments = slot_assignments(mat)
    if not assignments:
        op.report({"WARNING"}, i18n.rpt("All image slots are empty (run Detect or pick images)"))
        return {"CANCELLED"}
    mode = mode or mat.hextile.mode
    saved = _tuned_values(mat)
    try:
        if mode == "SWAP":
            report = replace.apply(mat, assignments, directx=mat.hextile.normal_directx,
                                   params=tiling_params(mat))
        else:
            report = build.apply(mat, assignments=assignments, directx=mat.hextile.normal_directx)
    except ValueError as exc:
        op.report({"WARNING"}, str(exc))
        return {"CANCELLED"}
    _restore_tuned(mat, saved)
    push_params(mat)
    _store_notes(mat, report)
    op.report({"INFO"}, i18n.rpt("HexTile: built with {count} maps").format(count=len(report.used)))
    return {"FINISHED"}


class HEXTILE_OT_apply(Operator):
    bl_idname = "hextile.apply"
    bl_translation_context = CTX
    bl_label = "Apply HexTile"
    bl_description = "Hex-tile the material with the images in the slots (see Mode)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        mat = _material(context)
        return mat is not None and mat.library is None

    def execute(self, context):
        return _run_apply(self, _material(context))


class HEXTILE_OT_detect(Operator):
    bl_idname = "hextile.detect"
    bl_translation_context = CTX
    bl_label = "Detect Maps"
    bl_description = "Fill the image slots again from the Image Texture nodes in the material (overwrites manual choices)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        mat = _material(context)
        return mat is not None and mat.library is None

    def execute(self, context):
        fill_slots(_material(context))
        return {"FINISHED"}


class HEXTILE_OT_load_slot(Operator):
    bl_idname = "hextile.load_slot"
    bl_translation_context = CTX
    bl_label = "Open Image"
    bl_description = "Load an image file into this slot"
    bl_options = {"REGISTER", "UNDO"}

    role: StringProperty(options={"HIDDEN"})
    filepath: StringProperty(subtype="FILE_PATH")
    filter_image: BoolProperty(default=True, options={"HIDDEN", "SKIP_SAVE"})
    filter_folder: BoolProperty(default=True, options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        mat = _material(context)
        return mat is not None and mat.library is None

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        mat = _material(context)
        if self.role not in SLOT_ROLES or not os.path.isfile(self.filepath):
            return {"CANCELLED"}
        img = bpy.data.images.load(self.filepath, check_existing=True)
        if self.role in dt.NON_COLOR_ROLES and img.users == 0:
            img.colorspace_settings.name = "Non-Color"
        setattr(mat.hextile, self.role, img)
        mat.hextile.initialized = True
        return {"FINISHED"}


class HEXTILE_OT_apply_files(Operator):
    bl_idname = "hextile.apply_files"
    bl_translation_context = CTX
    bl_label = "Build from Image Files"
    bl_description = "Pick a set of image files (color, normal, roughness, ...), fill the slots and build with hex-tiling"
    bl_options = {"REGISTER", "UNDO"}

    directory: StringProperty(subtype="DIR_PATH")
    files: CollectionProperty(type=OperatorFileListElement)
    filter_image: BoolProperty(default=True, options={"HIDDEN", "SKIP_SAVE"})
    filter_folder: BoolProperty(default=True, options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        mat = _material(context)
        return mat is not None and mat.library is None

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        mat = _material(context)
        images = dt.load_images(self.directory, [f.name for f in self.files])
        if not images:
            self.report({"WARNING"}, i18n.rpt("No images selected"))
            return {"CANCELLED"}
        det = dt.detect(mat, images)
        if not det.maps:
            self.report({"WARNING"}, i18n.rpt("Could not tell what the selected images are"))
            return {"CANCELLED"}
        for info in det.maps.values():
            if info.role in dt.NON_COLOR_ROLES:
                info.image.colorspace_settings.name = "Non-Color"
        fill_slots(mat, det, all_roles=True)     # files were picked on purpose: use them all
        mat.hextile.mode = "REBUILD"             # nothing to swap: the images are new
        return _run_apply(self, mat, "REBUILD")


class HEXTILE_OT_revert(Operator):
    bl_idname = "hextile.revert"
    bl_translation_context = CTX
    bl_label = "Revert"
    bl_description = "Delete the HexTile nodes and put the original nodes back where they were"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return build.is_applied(_material(context))

    def execute(self, context):
        mat = _material(context)
        build.revert(mat)
        if KEY_NOTES in mat:
            del mat[KEY_NOTES]
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

def _prop(layout, node, name, text=None):
    if node is not None and name in node.inputs and not node.inputs[name].is_linked:
        layout.prop(node.inputs[name], "default_value", text=text or name, text_ctxt=CTX)


SHORT_LABELS = {"color": "Color", "normal": "Normal", "roughness": "Rough", "metallic": "Metal",
                "specular": "Spec", "height": "Height", "ao": "AO", "gloss": "Gloss",
                "opacity": "Opacity", "emission": "Emit"}


def _slot_row(col, slots, role, short=None):
    split = col.split(factor=0.29, align=True)
    split.label(text=SHORT_LABELS[role], text_ctxt=CTX)
    row = split.row(align=True)
    row.prop(slots, role, text="")
    if role == "normal":
        sub = row.row(align=True)
        sub.ui_units_x = 1.6
        sub.prop(slots, "normal_directx", text="DX", toggle=True, translate=False)
    op = row.operator(HEXTILE_OT_load_slot.bl_idname, text="", icon="FILEBROWSER")
    op.role = role
    img = getattr(slots, role)
    if short and img is not None and short.get(img.name, img.name) != img.name:
        # The field cuts long names from the end, where the map type is.
        hint = col.split(factor=0.29, align=True)
        hint.scale_y = 0.65
        hint.label(text="")
        sub = hint.row()
        sub.enabled = False
        sub.label(text=short[img.name], translate=False)


class HEXTILE_PT_panel(Panel):
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "HexTile"
    bl_label = "HexTile"
    bl_translation_context = CTX

    @classmethod
    def poll(cls, context):
        return _material(context) is not None

    def draw(self, context):
        layout = self.layout
        mat = _material(context)
        layout.label(text=mat.name, icon="MATERIAL", translate=False)
        if not mat.hextile.initialized:
            _schedule_fill(mat)
        self._draw_slots(layout, mat)
        layout.row().prop(mat.hextile, "mode", expand=True, text_ctxt=CTX)
        if not build.is_applied(mat):
            col = layout.column(align=True)
            col.scale_y = 1.4
            col.operator(HEXTILE_OT_apply.bl_idname, icon="MESH_GRID", text_ctxt=CTX)
            layout.operator(HEXTILE_OT_apply_files.bl_idname, icon="FILE_IMAGE", text_ctxt=CTX)
        else:
            row = layout.row(align=True)
            row.scale_y = 1.2
            row.operator(HEXTILE_OT_apply.bl_idname, text="Update", icon="FILE_REFRESH", text_ctxt=CTX)
            row.operator(HEXTILE_OT_revert.bl_idname, icon="LOOP_BACK", text_ctxt=CTX)
            self._draw_settings(layout, mat)
            notes = mat.get(KEY_NOTES)
            if notes:
                box = layout.box()
                box.label(text="Maps and Notes", icon="INFO", text_ctxt=CTX)
                for line in notes:
                    box.label(text=line, translate=False)

    def _draw_slots(self, layout, mat):
        slots = mat.hextile
        box = layout.box()
        head = box.row()
        head.label(text="Images", icon="IMAGE_DATA", text_ctxt=CTX)
        head.operator(HEXTILE_OT_detect.bl_idname, text="Detect", icon="VIEWZOOM", text_ctxt=CTX)
        filled = {getattr(slots, r).name for r in SLOT_ROLES if getattr(slots, r) is not None}
        short = _short_names(sorted(filled))
        col = box.column(align=True)
        for role in MAIN_ROLES:
            _slot_row(col, slots, role, short)
        box.prop(slots, "show_more", icon="TRIA_DOWN" if slots.show_more else "TRIA_RIGHT", emboss=False)
        if slots.show_more:
            col = box.column(align=True)
            for role in MORE_ROLES:
                _slot_row(col, slots, role, short)
        if build.is_applied(mat):
            box.label(text="Changes apply on Update", icon="INFO", text_ctxt=CTX)

    def _draw_settings(self, layout, mat):
        nt = mat.node_tree
        slots = mat.hextile
        gens = build.generated(nt)
        wrappers = [n for n in gens if n.bl_idname == "ShaderNodeGroup" and replace.hx.is_wrapper(n.node_tree)]
        roles = {n.get(build.GEN, "")[len("wrap_"):] for n in wrappers} | \
                {n.get(build.GEN, "")[len("blend_"):] for n in gens}
        # Scale: the generated Mapping (new node tree) or the user's Mapping (swap mode).
        mapping = build.find_generated(nt, "mapping")
        if mapping is None:
            for node in wrappers + build.generated(nt, "coords"):
                sock = node.inputs["Vector"]
                if sock.is_linked and sock.links[0].from_node.bl_idname == "ShaderNodeMapping":
                    mapping = sock.links[0].from_node
                    break
        # Normal Map strength: the node fed by the normal blend / wrapper.
        nmap = build.find_generated(nt, "normal_map")
        if nmap is None:
            for node in gens:
                if node.get(build.GEN) in ("wrap_normal", "blend_normal"):
                    nmap = next((l.to_node for l in node.outputs["Color"].links
                                 if l.to_node.bl_idname == "ShaderNodeNormalMap"), None)
                    if nmap:
                        break
        box = layout.box()
        box.label(text="Tiling", icon="MESH_GRID", text_ctxt=CTX)
        col = box.column(align=True)
        if mapping is not None and not mapping.inputs["Scale"].is_linked:
            sock = mapping.inputs["Scale"]
            col.label(text="Scale (repeats)", text_ctxt=CTX)
            row = col.row(align=True)
            row.prop(sock, "default_value", index=0, text="X", translate=False)
            row.prop(sock, "default_value", index=1, text="Y", translate=False)
        col.prop(slots, "rotation", text_ctxt=CTX)
        col.prop(slots, "seed", text_ctxt=CTX)
        if roles - {"normal"}:
            box = layout.box()
            box.label(text="Color Blending", icon="COLOR", text_ctxt=CTX)
            col = box.column(align=True)
            col.prop(slots, "color_contrast", text_ctxt=CTX)
            col.prop(slots, "color_falloff", text_ctxt=CTX)
        if "normal" in roles:
            box = layout.box()
            box.label(text="Normal", icon="NORMALS_FACE", text_ctxt=CTX)
            col = box.column(align=True)
            col.prop(slots, "normal_contrast", text_ctxt=CTX)
            _prop(col, nmap, "Strength", "Strength")


classes = (HexTileSlots, HEXTILE_OT_apply, HEXTILE_OT_detect, HEXTILE_OT_load_slot,
           HEXTILE_OT_apply_files, HEXTILE_OT_revert, HEXTILE_PT_panel)


def register():
    i18n.register()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Material.hextile = PointerProperty(type=HexTileSlots)


def unregister():
    del bpy.types.Material.hextile
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    i18n.unregister()

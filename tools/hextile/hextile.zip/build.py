# SPDX-FileCopyrightText: 2026 mikat
# SPDX-License-Identifier: GPL-3.0-or-later

"""Rebuild a material with hex-tiling, keeping the original nodes aside."""

import bpy

from . import detect as dt
from . import i18n
from . import nodes as hx

_ = i18n.iface

GEN = "hextile_generated"
FRAME_LABEL = "HexTile: Original Nodes"
KEY_APPLIED = "hextile_applied"
KEY_SHIFT = "hextile_shift"
KEY_FRAME = "hextile_frame"
KEY_OUTPUTS = "hextile_active_outputs"
GAP = 600.0


class Report:
    def __init__(self):
        self.used = []       # (role, image name, how)
        self.notes = []

    def note(self, text):
        self.notes.append(text)


def is_applied(mat):
    return bool(mat and mat.get(KEY_APPLIED))


def generated(nt, key=None):
    return [n for n in nt.nodes if n.get(GEN) and (key is None or n.get(GEN) == key)]


def find_generated(nt, key):
    return next((n for n in nt.nodes if n.get(GEN) == key), None)


# ---------------------------------------------------------------------------
# Keeping the original nodes
# ---------------------------------------------------------------------------

def _bounds(nodes):
    xs, ys = [], []
    for n in nodes:
        x, y = n.location_absolute
        xs += [x, x + n.width]
        ys += [y, y - 300.0]
    if not xs:
        return 0.0, 0.0, 0.0, 0.0
    return min(xs), max(xs), min(ys), max(ys)


def stash_originals(mat):
    """Move the original nodes left into a frame and deactivate their output."""
    nt = mat.node_tree
    originals = [n for n in nt.nodes if not n.get(GEN)]
    xmin, xmax, ymin, ymax = _bounds(originals)
    shift = (xmax - xmin) + GAP if originals else 0.0
    frame = nt.nodes.new("NodeFrame")
    frame.label = i18n.data(FRAME_LABEL)
    frame.label_size = 28
    frame.use_custom_color = True
    frame.color = (0.25, 0.25, 0.28)
    for n in originals:
        if n.parent is None:
            n.location = (n.location.x - shift, n.location.y)
            n.parent = frame
    active = [n.name for n in originals
              if n.bl_idname == "ShaderNodeOutputMaterial" and n.is_active_output]
    for n in originals:
        if n.bl_idname == "ShaderNodeOutputMaterial":
            n.is_active_output = False
    mat[KEY_SHIFT] = shift
    mat[KEY_FRAME] = frame.name
    mat[KEY_OUTPUTS] = active
    return (xmin, ymax) if originals else (0.0, 300.0)


def revert(mat):
    """Delete the generated nodes and put the originals back."""
    nt = mat.node_tree
    if nt is None or not is_applied(mat):
        return False
    if mat.get("hextile_mode") == "swap":
        from . import replace
        return replace.revert(mat)
    for n in generated(nt):
        nt.nodes.remove(n)
    frame = nt.nodes.get(mat.get(KEY_FRAME, ""))
    shift = float(mat.get(KEY_SHIFT, 0.0))
    if frame is not None:
        for n in [n for n in nt.nodes if n.parent == frame]:
            n.parent = None
            n.location = (n.location.x + shift, n.location.y)
        nt.nodes.remove(frame)
    for name in mat.get(KEY_OUTPUTS, []):
        out = nt.nodes.get(name)
        if out is not None:
            out.is_active_output = True
    for key in (KEY_APPLIED, KEY_SHIFT, KEY_FRAME, KEY_OUTPUTS):
        if key in mat:
            del mat[key]
    return True


# ---------------------------------------------------------------------------
# Building
# ---------------------------------------------------------------------------

class Layout:
    def __init__(self, nt, x0, y0):
        self.nt, self.x0, self.y0 = nt, x0, y0

    def new(self, idname, col, y, key=None, label=None, hide=False, width=None):
        n = self.nt.nodes.new(idname)
        n[GEN] = key or idname
        n.location = (self.x0 + col, self.y0 + y)
        if label:
            n.label = label
        if hide:
            n.hide = True
        if width:
            n.width = width
        return n


def _copy_inputs(src, dst, report):
    for name in ("distribution", "subsurface_method"):
        if hasattr(src, name):
            setattr(dst, name, getattr(src, name))
    for s in src.inputs:
        d = next((x for x in dst.inputs if x.identifier == s.identifier), None)
        if d is None or not hasattr(s, "default_value"):
            continue
        v = s.default_value
        d.default_value = tuple(v) if hasattr(v, "__len__") else v
        if s.is_linked and s.name not in dt.SOCKET_ROLES:
            report.note(_("Principled '{name}' had nodes connected; they are not carried over").format(name=s.name))


def _copy_values(src, dst, skip=()):
    """Copy unlinked input values between nodes of the same type."""
    for s in src.inputs:
        if s.identifier in skip or s.is_linked or not hasattr(s, "default_value"):
            continue
        d = next((x for x in dst.inputs if x.identifier == s.identifier), None)
        if d is not None:
            v = s.default_value
            d.default_value = tuple(v) if hasattr(v, "__len__") else v


def _vector_chain(lay, det, report):
    """Recreate the original texture coordinates (Mapping and its source)."""
    src = det.vector_source
    mapping = None
    if src is not None and src.node.bl_idname == "ShaderNodeMapping":
        mapping = src.node
        src = mapping.inputs["Vector"].links[0].from_socket if mapping.inputs["Vector"].is_linked else None
    if src is not None and src.node.bl_idname == "ShaderNodeUVMap":
        uv = lay.new("ShaderNodeUVMap", 0, -40, "uv")
        uv.uv_map = src.node.uv_map
        out = uv.outputs["UV"]
    else:
        tc = lay.new("ShaderNodeTexCoord", 0, 0, "texcoord")
        name = src.name if (src is not None and src.node.bl_idname == "ShaderNodeTexCoord") else "UV"
        out = tc.outputs[name]
        if src is not None and src.node.bl_idname not in {"ShaderNodeTexCoord", "ShaderNodeUVMap"}:
            report.note(_("Original texture coordinates were too complex; rebuilt with UV"))
    mp = lay.new("ShaderNodeMapping", 220, 0, "mapping")
    if mapping is not None:
        mp.vector_type = mapping.vector_type
        for name in ("Location", "Rotation", "Scale"):
            if not mapping.inputs[name].is_linked:
                mp.inputs[name].default_value = tuple(mapping.inputs[name].default_value)
    lay.nt.links.new(out, mp.inputs["Vector"])
    return mp.outputs["Vector"]


def _three_images(lay, info, coords, y, label):
    nodes = []
    src = info.node
    for i in range(3):
        t = lay.new("ShaderNodeTexImage", 720, y - i * 40, f"img_{info.role}", f"{label} {i + 1}",
                    hide=True, width=220)
        t.image = info.image
        if src is not None:
            t.interpolation = src.interpolation
        t.extension = "REPEAT"
        lay.nt.links.new(coords.outputs[f"UV {i + 1}"], t.inputs["Vector"])
        nodes.append(t)
    return nodes


def apply(mat, images=None, assignments=None, directx=False, rotation=0.0, seed=0):
    """Rebuild `mat` with hex-tiling. Returns a Report.

    images: picked image files to use instead of the Image Texture nodes.
    assignments: {role: image} chosen in the panel slots (overrides detection).
    """
    report = Report()
    if mat.node_tree is None:
        mat.use_nodes = True
    if is_applied(mat):
        revert(mat)
    if assignments is not None:
        det = dt.detect_assigned(mat, assignments, directx)
    else:
        det = dt.detect(mat, images)
    if not det.maps:
        raise ValueError(_("No usable images (add Image Texture nodes or pick image files)"))

    if images is not None:
        for info in det.maps.values():
            if info.role in dt.NON_COLOR_ROLES:
                info.image.colorspace_settings.name = "Non-Color"
    else:
        for info in det.maps.values():
            if (info.role in dt.NON_COLOR_ROLES and not info.connected
                    and info.image.colorspace_settings.name != "Non-Color"):
                info.image.colorspace_settings.name = "Non-Color"
                report.note(_("{name}: set to Non-Color").format(name=info.image.name))

    groups = hx.ensure_groups()
    nt = mat.node_tree
    x0, y0 = stash_originals(mat)
    lay = Layout(nt, x0, y0)
    links = nt.links

    vec = _vector_chain(lay, det, report)
    coords = lay.new("ShaderNodeGroup", 440, 0, "coords", width=200)
    coords.node_tree = groups["coords"]
    coords.inputs["Rotation"].default_value = rotation
    coords.inputs["Seed"].default_value = seed
    links.new(vec, coords.inputs["Vector"])

    bsdf = lay.new("ShaderNodeBsdfPrincipled", 1600, 0, "bsdf")
    if det.principled is not None:
        _copy_inputs(det.principled, bsdf, report)
    else:
        report.note(_("No Principled BSDF in the original; created a new one"))
    out = lay.new("ShaderNodeOutputMaterial", 1950, 0, "output")
    if det.output is not None:
        out.target = det.output.target
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    out.is_active_output = True

    order = ["color", "ao", "roughness", "gloss", "metallic", "specular", "opacity", "emission", "normal", "height"]
    maps = det.maps
    y = 0.0
    weights_src = None
    blended = {}

    def blend(info, kind):
        nonlocal y, weights_src
        label = i18n.data(dt.ROLE_LABELS[info.role])
        imgs = _three_images(lay, info, coords, y, label)
        if kind == "normal":
            g = lay.new("ShaderNodeGroup", 1000, y + 40, f"blend_{info.role}", width=200)
            g.node_tree = groups["normal"]
            links.new(coords.outputs["Angles"], g.inputs["Angles"])
            links.new(coords.outputs["Weights"], g.inputs["Weights"])
            g.inputs["DirectX"].default_value = info.directx
            for i, t in enumerate(imgs):
                links.new(t.outputs["Color"], g.inputs[f"Normal {i + 1}"])
        elif kind == "color" or weights_src is None:
            g = lay.new("ShaderNodeGroup", 1000, y + 40, f"blend_{info.role}", width=200)
            g.node_tree = groups["color"]
            links.new(coords.outputs["Weights"], g.inputs["Weights"])
            for i, t in enumerate(imgs):
                links.new(t.outputs["Color"], g.inputs[f"Color {i + 1}"])
            weights_src = weights_src or g.outputs["Weights"]
        else:
            g = lay.new("ShaderNodeGroup", 1000, y + 40, f"blend_{info.role}", width=200)
            g.node_tree = groups["data"]
            links.new(weights_src, g.inputs["Weights"])
            for i, t in enumerate(imgs):
                links.new(t.outputs["Color"], g.inputs[f"Data {i + 1}"])
        y -= 260.0
        how = {"slot": "slot", "name": "name"}.get(info.source, "link")
        report.used.append((info.role, info.image.name, how + (", DX" if info.directx else "")))
        blended[info.role] = g
        return g

    def value_out(g):
        return g.outputs["Value"] if "Value" in g.outputs else g.outputs["Color"]

    color_out = None
    for role in order:
        info = maps.get(role)
        if info is None:
            continue
        if role == "color":
            color_out = blend(info, "color").outputs["Color"]
        elif role == "ao":
            if info.usage.via_mix is None and not info.connected and not info.forced:
                report.note(_("AO not used (the original material did not use it)"))
                continue
            g = blend(info, "data")
            if color_out is not None:
                mix = lay.new("ShaderNodeMix", 1300, y + 260, "ao_mix", "AO")
                mix.data_type = "RGBA"
                mix.blend_type = "MULTIPLY"
                src = info.usage.via_mix
                fac = 1.0
                if src is not None and "Factor" in src.inputs and not src.inputs["Factor"].is_linked:
                    fac = src.inputs["Factor"].default_value
                    fac = fac if isinstance(fac, float) else 1.0
                mix.inputs["Factor"].default_value = fac
                links.new(color_out, mix.inputs["A"])
                links.new(g.outputs["Color"], mix.inputs["B"])
                color_out = mix.outputs["Result"]
        elif role in ("roughness", "metallic", "specular", "opacity"):
            g = blend(info, "data")
            sock = {"roughness": "Roughness", "metallic": "Metallic",
                    "specular": "Specular IOR Level", "opacity": "Alpha"}[role]
            links.new(value_out(g), bsdf.inputs[sock])
        elif role == "gloss":
            if "roughness" in maps:
                report.note(_("Gloss not used (a Roughness map is set)"))
                continue
            g = blend(info, "data")
            inv = lay.new("ShaderNodeMath", 1300, y + 260, "gloss_invert", i18n.data("1 - Gloss"))
            inv.operation = "SUBTRACT"
            inv.inputs[0].default_value = 1.0
            links.new(value_out(g), inv.inputs[1])
            links.new(inv.outputs[0], bsdf.inputs["Roughness"])
        elif role == "emission":
            g = blend(info, "data")
            links.new(g.outputs["Color"], bsdf.inputs["Emission Color"])
            if det.principled is None or det.principled.inputs["Emission Strength"].default_value == 0.0:
                bsdf.inputs["Emission Strength"].default_value = 1.0
        elif role == "normal":
            g = blend(info, "normal")
            nm = lay.new("ShaderNodeNormalMap", 1300, y + 260, "normal_map")
            if hasattr(nm, "convention"):
                nm.convention = "OPENGL"      # HexTile Blend Normal always outputs OpenGL
            src = info.usage.normal_map
            if src is not None:
                nm.space = src.space
                nm.uv_map = src.uv_map
                if hasattr(src, "base"):
                    nm.base = src.base
                if not src.inputs["Strength"].is_linked:
                    nm.inputs["Strength"].default_value = src.inputs["Strength"].default_value
            links.new(g.outputs["Color"], nm.inputs["Color"])
            links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
        elif role == "height":
            usage = info.usage
            if usage.displacement is None and usage.bump is None and not info.forced:
                report.note(_("Height not used (the original material did not use it)"))
                continue
            g = blend(info, "data")
            if usage.displacement is not None or usage.bump is None:
                d = lay.new("ShaderNodeDisplacement", 1600, -620, "displacement")
                src = usage.displacement
                if src is not None:
                    d.space = src.space
                    _copy_values(src, d, skip={"Height", "Normal"})
                else:
                    # Chosen in the panel without an original setup: a mild default.
                    # (The material's displacement method decides bump vs. real displacement.)
                    d.inputs["Midlevel"].default_value = 0.5
                    d.inputs["Scale"].default_value = 0.05
                    report.note(_("Height connected through a Displacement node (Scale 0.05)"))
                links.new(value_out(g), d.inputs["Height"])
                links.new(d.outputs["Displacement"], out.inputs["Displacement"])
            else:
                src = usage.bump
                bump = lay.new("ShaderNodeBump", 1300, y + 260, "bump")
                bump.invert = src.invert
                _copy_values(src, bump, skip={"Height", "Normal"})
                links.new(value_out(g), bump.inputs["Height"])
                if bsdf.inputs["Normal"].is_linked:
                    links.new(bsdf.inputs["Normal"].links[0].from_socket, bump.inputs["Normal"])
                links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

    if color_out is not None:
        links.new(color_out, bsdf.inputs["Base Color"])
    for name, why, role in det.ignored:
        why = _(why).format(role=_(dt.ROLE_LABELS[role]) if role else "")
        report.note(_("{name}: not used ({why})").format(name=name, why=why))
    mat[KEY_APPLIED] = True
    return report

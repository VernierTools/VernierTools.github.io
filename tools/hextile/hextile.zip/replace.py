# SPDX-FileCopyrightText: 2026 mikat
# SPDX-License-Identifier: GPL-3.0-or-later

"""Swap mode: replace only the Image Texture nodes with hex-tiled versions.

Everything after the images (ColorRamp, Mix, Bump, Normal Map, shaders, ...)
stays as it is: each original image node is swapped for three Image Texture
nodes plus a blend group, whose output goes to exactly the sockets the
original fed. The original image nodes are moved into a frame and relinked
on revert.
"""

import json

import bpy

from . import build
from . import detect as dt
from . import i18n
from . import nodes as hx

_ = i18n.iface

MODE_KEY = "hextile_mode"
RECORD_KEY = "hextile_swap"
FRAME_LABEL = "HexTile: Original Images"
GEN = build.GEN

SKIP_REASONS = {
    "extension": "not set to Repeat",
    "projection": "not Flat projection",
    "tiled": "UDIM / tiled image",
    "source": "not a still image",
}


def skip_reason(node):
    """Why an Image Texture node should not be hex-tiled (None = fine)."""
    img = node.image
    if node.extension != "REPEAT":
        return "extension"
    if node.projection != "FLAT":
        return "projection"
    if img is not None and img.source == "TILED":
        return "tiled"
    if img is not None and img.source not in {"FILE", "GENERATED"}:
        return "source"
    return None


def _image_nodes(nt):
    return [n for n in nt.nodes if n.bl_idname == "ShaderNodeTexImage"
            and n.image is not None and not n.get(GEN)]


def plan(mat, assignments):
    """[(node, role, image)] to swap, plus notes about what is left alone."""
    nt = mat.node_tree
    nodes = _image_nodes(nt)
    det = dt.detect(mat)
    auto = {r: i.image for r, i in det.maps.items()}
    targets, notes, taken, noted = [], [], set(), set()
    order = ("color",) + tuple(r for r in dt.ROLES if r != "color")   # color first: it provides the weights
    for role in order:
        img = assignments.get(role)
        if img is None:
            continue
        found = [n for n in nodes if n.image == img]
        if not found and auto.get(role) is not None:
            # The slot holds a different file than the material: swap that role's nodes.
            found = [n for n in nodes if n.image == auto[role]]
        if not found:
            notes.append(_("{name}: not in the material (use New Node Tree to add it)").format(name=img.name))
            continue
        for n in found:
            if n.as_pointer() in taken:
                continue
            if not any(o.is_linked for o in n.outputs):
                if n.as_pointer() not in noted:
                    noted.add(n.as_pointer())
                    notes.append(_("{name}: not connected (use New Node Tree to use it)").format(name=n.image.name))
                continue
            why = skip_reason(n)
            if why:
                if n.as_pointer() in noted:
                    continue
                noted.add(n.as_pointer())
                notes.append(_("{name}: left as is ({why})").format(name=n.image.name, why=_(SKIP_REASONS[why])))
                continue
            taken.add(n.as_pointer())
            targets.append((n, role, img))
    return targets, notes


def has_connected_images(mat):
    nt = mat.node_tree
    return nt is not None and any(any(o.is_linked for o in n.outputs) for n in _image_nodes(nt))


def _vector_key(node):
    sock = node.inputs["Vector"]
    if sock.is_linked:
        return sock.links[0].from_socket
    return None


def _out_links(node):
    out = []
    for sock in node.outputs:
        for link in sock.links:
            out.append({"out": sock.identifier, "out_name": sock.name,
                        "node": link.to_node.name, "in": link.to_socket.identifier})
    return out


def _socket(sockets, identifier):
    return next((s for s in sockets if s.identifier == identifier), None)


DEFAULT_PARAMS = {"rotation": 0.0, "seed": 0, "color_contrast": hx.DEFAULT_COLOR_CONTRAST,
                  "color_falloff": hx.DEFAULT_FALLOFF_CONTRAST, "normal_contrast": hx.DEFAULT_NORMAL_CONTRAST}


def set_wrapper_params(node, params, directx=None):
    """Push the material's tiling settings into one wrapper node."""
    role = node.node_tree[hx.WRAP_KEY]["role"]
    node.inputs["Rotation"].default_value = params["rotation"]
    node.inputs["Seed"].default_value = params["seed"]
    node.inputs["Falloff Contrast"].default_value = params["color_falloff"]
    node.inputs["Contrast"].default_value = params["normal_contrast" if role == "normal" else "color_contrast"]
    if directx is not None and "DirectX" in node.inputs:
        node.inputs["DirectX"].default_value = bool(directx)


def _hide_params(node):
    # The node should look like an Image Texture: only Vector (and shared Weights) visible.
    for name in hx.PARAM_INPUTS:
        if name in node.inputs:
            node.inputs[name].hide = True
    if not node.inputs["Weights"].is_linked:
        node.inputs["Weights"].hide = True


def apply(mat, assignments, directx=False, params=None, rotation=None, seed=None):
    params = dict(DEFAULT_PARAMS, **(params or {}))
    if rotation is not None:
        params["rotation"] = rotation
    if seed is not None:
        params["seed"] = seed
    report = build.Report()
    if mat.node_tree is None:
        mat.use_nodes = True
    if build.is_applied(mat):
        build.revert(mat)
    nt = mat.node_tree
    targets, notes = plan(mat, assignments)
    for n in notes:
        report.note(n)
    if not targets:
        raise ValueError(_("No image nodes to swap (use New Node Tree, or pick images in the slots)"))
    links = nt.links

    # Colour space for maps the original did not use as colour data.
    for node, role, img in targets:
        if role in dt.NON_COLOR_ROLES and img.colorspace_settings.name != "Non-Color" and img != node.image:
            img.colorspace_settings.name = "Non-Color"

    # Maps reading the same coordinates share the base color's weights.
    by_vec = {}
    for node, role, img in targets:
        key = _vector_key(node)
        by_vec.setdefault(key.as_pointer() if key else None, []).append((node, role, img))

    records = []
    for members in by_vec.values():
        weights_src = None
        for node, role, img in sorted(members, key=lambda m: m[1] != "color"):
            label = i18n.data(dt.ROLE_LABELS[role])
            tree = hx.get_wrapper(img, role, node.interpolation, label)
            w = nt.nodes.new("ShaderNodeGroup")
            w.node_tree = tree
            w[GEN] = f"wrap_{role}"
            w.location = node.location_absolute
            if node.parent is not None:
                w.parent = node.parent
            w.width = max(node.width, 200.0)
            w.label = f"HexTile: {img.name}"
            vec = node.inputs["Vector"]
            if vec.is_linked:
                links.new(vec.links[0].from_socket, w.inputs["Vector"])
                w.inputs["Use Vector"].default_value = True
            set_wrapper_params(w, params, directx if role == "normal" else None)
            if role == "color" and weights_src is None:
                weights_src = w.outputs["Weights"]
            elif role != "normal" and weights_src is not None:
                links.new(weights_src, w.inputs["Weights"])
                w.inputs["Use Weights"].default_value = True

            rec = {"node": node.name, "loc": list(node.location_absolute),
                   "parent": node.parent.name if node.parent else "", "links": _out_links(node)}
            for l in rec["links"]:
                to = nt.nodes.get(l["node"])
                dst = _socket(to.inputs, l["in"]) if to else None
                # Group sockets have their own identifiers ("Socket_2"): match by name.
                src = w.outputs.get(l.get("out_name", l["out"]))
                if dst is not None and src is not None:
                    links.new(src, dst)          # replaces the link from the original node
            for sock in node.outputs:
                for link in list(sock.links):
                    links.remove(link)
            records.append(rec)
            report.used.append((role, img.name, "slot" + (", DX" if role == "normal" and directx else "")))
    for node in build.generated(nt):
        if node.bl_idname == "ShaderNodeGroup" and hx.is_wrapper(node.node_tree):
            _hide_params(node)

    # Park the original image nodes in a frame left of everything.
    others = [n for n in nt.nodes if n.bl_idname != "NodeFrame"]
    xmin = min(n.location_absolute.x for n in others)
    ytop = max(n.location_absolute.y for n in others)
    frame = nt.nodes.new("NodeFrame")
    frame[GEN] = "frame"
    frame.label = i18n.data(FRAME_LABEL)
    frame.label_size = 24
    frame.use_custom_color = True
    frame.color = (0.25, 0.25, 0.28)
    for k, rec in enumerate(records):
        node = nt.nodes[rec["node"]]
        node.parent = None
        node.location = (xmin - 600.0, ytop - k * 320.0)
        node.parent = frame

    mat[RECORD_KEY] = json.dumps(records)
    mat[MODE_KEY] = "swap"
    mat[build.KEY_APPLIED] = True
    return report


def revert(mat):
    nt = mat.node_tree
    records = json.loads(mat.get(RECORD_KEY, "[]"))
    # Unparent and restore the originals before the generated frame goes away.
    for rec in records:
        node = nt.nodes.get(rec["node"])
        if node is None:
            continue
        node.parent = None
        node.location = rec["loc"]
        parent = nt.nodes.get(rec["parent"]) if rec["parent"] else None
        if parent is not None:
            node.parent = parent
    for n in build.generated(nt):
        nt.nodes.remove(n)
    for rec in records:
        node = nt.nodes.get(rec["node"])
        if node is None:
            continue
        for l in rec["links"]:
            to = nt.nodes.get(l["node"])
            src = _socket(node.outputs, l["out"])
            dst = _socket(to.inputs, l["in"]) if to else None
            if src is not None and dst is not None:
                nt.links.new(src, dst)
    for key in (RECORD_KEY, MODE_KEY, build.KEY_APPLIED):
        if key in mat:
            del mat[key]
    hx.remove_unused_wrappers()
    return True

import bpy

PREFIX = "WTM."
MOD_NAME = PREFIX + "Weight Mask"
GN_NAME = PREFIX + "Weight Mask GN"
ATTR_NAME = "WTM.Mask"


def vertex_group_exists(obj, name):
    return bool(name) and obj.vertex_groups.get(name) is not None


def get_socket(sockets, *names_or_indices, default_index=0):
    for item in names_or_indices:
        if isinstance(item, str) and item in sockets:
            return sockets[item]
        elif isinstance(item, int) and 0 <= item < len(sockets):
            return sockets[item]
    if 0 <= default_index < len(sockets):
        return sockets[default_index]
    return None


def safe_link(links, from_socket, to_socket):
    if from_socket is None or to_socket is None:
        return
    for l in list(to_socket.links):
        links.remove(l)
    links.new(from_socket, to_socket)


def is_default_or_clean_material(mat):
    """Return True only when clearing the material is clearly safe."""
    if mat is None or not mat.use_nodes or not mat.node_tree:
        return True

    nodes = mat.node_tree.nodes
    if len(nodes) == 0:
        return True

    # Never treat an arbitrary Principled + Output setup as "clean".
    # Users may have customized those nodes, and clearing them would be destructive.
    return all(n.name.startswith(PREFIX) for n in nodes)


def ensure_geometry_nodes(obj, vertex_group_name):
    mod = obj.modifiers.get(MOD_NAME)
    if mod is None or mod.type != 'NODES':
        mod = obj.modifiers.new(MOD_NAME, 'NODES')

    # A Geometry Nodes group must not be shared between different objects:
    # its Named Attribute node contains the current object's vertex-group name.
    # Sharing one group would make the last object configured overwrite the others.
    ng_name = f"{GN_NAME} - {obj.name}"
    ng = bpy.data.node_groups.get(ng_name)
    if ng is None or ng.bl_idname != 'GeometryNodeTree':
        ng = bpy.data.node_groups.new(ng_name, 'GeometryNodeTree')
    mod.node_group = ng

    ng.nodes.clear()
    ng.links.clear()
    if hasattr(ng, "interface"):
        for item in list(ng.interface.items_tree):
            try:
                ng.interface.remove(item)
            except Exception:
                pass
        ng.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
        ng.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    group_in = ng.nodes.new('NodeGroupInput')
    group_in.name = PREFIX + "GN Input"
    group_in.label = "Input Geometry"
    group_in.location = (-520, 0)

    named = ng.nodes.new('GeometryNodeInputNamedAttribute')
    named.name = PREFIX + "Weight"
    named.label = f'Weight Paint: {vertex_group_name}'
    named.data_type = 'FLOAT'
    if 'Name' in named.inputs:
        named.inputs['Name'].default_value = vertex_group_name
    named.location = (-520, -180)

    store = ng.nodes.new('GeometryNodeStoreNamedAttribute')
    store.name = PREFIX + "Store Mask"
    store.label = 'Store Weight Mask for Shader'
    store.data_type = 'FLOAT'
    store.domain = 'POINT'
    attr_name = ATTR_NAME
    if 'Name' in store.inputs:
        store.inputs['Name'].default_value = attr_name
    if 'Selection' in store.inputs:
        store.inputs['Selection'].default_value = True
    store.location = (-120, 0)

    group_out = ng.nodes.new('NodeGroupOutput')
    group_out.name = PREFIX + "GN Output"
    group_out.label = "Output Geometry"
    group_out.location = (220, 0)
    group_out.is_active_output = True

    ng.links.new(group_in.outputs['Geometry'], store.inputs['Geometry'])
    ng.links.new(named.outputs['Attribute'], store.inputs['Value'])
    ng.links.new(store.outputs['Geometry'], group_out.inputs['Geometry'])

    frame = ng.nodes.new('NodeFrame')
    frame.name = PREFIX + "GN Info"
    frame.label = f"WEIGHT TEXTURE MASK - {vertex_group_name}"
    frame.label_size = 18
    frame.location = (-650, 180)
    for node in (named, store):
        node.parent = frame

    ng.update_tag()
    return mod, attr_name


def find_material_output(mat):
    outputs = [n for n in mat.node_tree.nodes if n.bl_idname == 'ShaderNodeOutputMaterial']
    for n in outputs:
        if getattr(n, 'is_active_output', False):
            return n
    return outputs[0] if outputs else None


def make_shader_setup(obj, attr_name, vertex_group_name, invert=False):
    mat = obj.active_material
    if mat is None:
        mat = bpy.data.materials.new(name=f"WTM Material - {obj.name}")
        mat.use_nodes = True
        # New materials come with a Principled BSDF that the setup wouldn't use.
        mat.node_tree.nodes.clear()
        obj.active_material = mat
    elif not mat.use_nodes:
        mat.use_nodes = True

    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links

    output = find_material_output(mat)
    if output is None:
        output = nodes.new('ShaderNodeOutputMaterial')
        output.name = PREFIX + "Material Output"
    output.location = (600, 0)

    mask = nodes.get(PREFIX + "Mask")
    if mask is None or mask.bl_idname != 'ShaderNodeAttribute':
        mask = nodes.new('ShaderNodeAttribute')
        mask.name = PREFIX + "Mask"
    mask.label = f"Weight Mask: {vertex_group_name}"
    mask.attribute_name = attr_name
    mask.location = (-480, 280)

    ramp = nodes.get(PREFIX + "Mask Ramp")
    if ramp is None or ramp.bl_idname != 'ShaderNodeValToRGB':
        ramp = nodes.new('ShaderNodeValToRGB')
        ramp.name = PREFIX + "Mask Ramp"
    ramp.label = "Optional threshold / softness"
    ramp.location = (-200, 280)
    ramp.color_ramp.elements[0].position = 0.0
    ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    ramp.color_ramp.elements[1].position = 1.0
    ramp.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)

    invert_node = nodes.get(PREFIX + "Invert")
    if invert:
        if invert_node is None or invert_node.bl_idname != 'ShaderNodeInvert':
            invert_node = nodes.new('ShaderNodeInvert')
            invert_node.name = PREFIX + "Invert"
        invert_node.label = "Invert Weight"
        invert_node.location = (-200, 140)
        invert_node.mute = False
    elif invert_node is not None:
        invert_node.mute = True

    bsdf_a = nodes.get(PREFIX + "BSDF A")
    if bsdf_a is None or bsdf_a.bl_idname != 'ShaderNodeBsdfPrincipled':
        bsdf_a = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf_a.name = PREFIX + "BSDF A"
    bsdf_a.label = "A — UNPAINTED BSDF"
    bsdf_a.location = (-200, 40)

    bsdf_b = nodes.get(PREFIX + "BSDF B")
    if bsdf_b is None or bsdf_b.bl_idname != 'ShaderNodeBsdfPrincipled':
        bsdf_b = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf_b.name = PREFIX + "BSDF B"
    bsdf_b.label = "B — PAINTED BSDF"
    bsdf_b.location = (-200, -500)

    mix_shader = nodes.get(PREFIX + "MixShader")
    if mix_shader is None or mix_shader.bl_idname != 'ShaderNodeMixShader':
        mix_shader = nodes.new('ShaderNodeMixShader')
        mix_shader.name = PREFIX + "MixShader"
    mix_shader.label = "Blend BSDF A ↔ BSDF B"
    mix_shader.location = (240, 0)

    info = nodes.get(PREFIX + "Info")
    if info is None:
        info = nodes.new('NodeFrame')
        info.name = PREFIX + "Info"
    info.label = "WEIGHT TEXTURE MASK (BSDF MIX)"
    info.label_size = 18

    for n in (mask, ramp, invert_node, bsdf_a, bsdf_b, mix_shader):
        if n is not None:
            n.parent = info

    mask_fac_out = get_socket(mask.outputs, 'Factor', 'Fac', default_index=2)
    ramp_fac_in = get_socket(ramp.inputs, 'Fac', 'Factor', default_index=0)
    safe_link(links, mask_fac_out, ramp_fac_in)

    ramp_color_out = get_socket(ramp.outputs, 'Color', default_index=0)
    if invert_node is not None and not invert_node.mute:
        inv_in = get_socket(invert_node.inputs, 'Color', 'Fac', default_index=1)
        safe_link(links, ramp_color_out, inv_in)
        mask_out_socket = get_socket(invert_node.outputs, 'Color', default_index=0)
    else:
        mask_out_socket = ramp_color_out

    mix_fac_in = get_socket(mix_shader.inputs, 'Fac', 'Factor', default_index=0)
    safe_link(links, mask_out_socket, mix_fac_in)

    bsdf_a_out = get_socket(bsdf_a.outputs, 'BSDF', default_index=0)
    bsdf_b_out = get_socket(bsdf_b.outputs, 'BSDF', default_index=0)
    shader1_in = get_socket(mix_shader.inputs, 1, default_index=1)
    shader2_in = get_socket(mix_shader.inputs, 2, default_index=2)
    safe_link(links, bsdf_a_out, shader1_in)
    safe_link(links, bsdf_b_out, shader2_in)

    mix_out = get_socket(mix_shader.outputs, 'Shader', default_index=0)
    surf_in = get_socket(output.inputs, 'Surface', default_index=0)
    safe_link(links, mix_out, surf_in)

    return mat


class WTMProperties(bpy.types.PropertyGroup):
    vertex_group: bpy.props.StringProperty(
        name="Vertex Group",
        description="Vertex group used as the Weight Paint mask",
    )
    invert: bpy.props.BoolProperty(
        name="Invert Mask",
        description="Swap painted and unpainted areas",
        default=False,
    )


class WTM_OT_setup(bpy.types.Operator):
    bl_idname = "wtm.setup"
    bl_label = "Setup / Update"
    bl_description = "Create or update the Geometry Nodes mask and shader setup"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        items=[
            ('CLEAR', "Clear", ""),
            ('APPEND', "Append", ""),
        ],
        default='CLEAR',
    )

    def invoke(self, context, event):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first.")
            return {'CANCELLED'}

        props = obj.wtm_props
        if not vertex_group_exists(obj, props.vertex_group):
            self.report({'ERROR'}, "Choose an existing Vertex Group.")
            return {'CANCELLED'}

        mat = obj.active_material
        if is_default_or_clean_material(mat):
            self.mode = 'CLEAR'
            return self.execute(context)

        def draw_menu(self_menu, context):
            layout = self_menu.layout
            # Run execute() directly: with the default INVOKE context the
            # buttons would call invoke() again and reopen this same popup.
            layout.operator_context = 'EXEC_DEFAULT'
            layout.label(text="Existing custom nodes detected:")
            layout.separator()

            op1 = layout.operator("wtm.setup", text="Clear All Nodes & Setup", icon='TRASH')
            op1.mode = 'CLEAR'

            op2 = layout.operator("wtm.setup", text="Keep Existing Nodes & Append", icon='NODE')
            op2.mode = 'APPEND'

        context.window_manager.popup_menu(draw_menu, title="Setup Confirmation", icon='ERROR')
        return {'CANCELLED'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first.")
            return {'CANCELLED'}

        props = obj.wtm_props
        mat = obj.active_material

        if self.mode == 'CLEAR' and mat and mat.use_nodes:
            mat.node_tree.nodes.clear()

        try:
            _, attr_name = ensure_geometry_nodes(obj, props.vertex_group)
            make_shader_setup(obj, attr_name, props.vertex_group, props.invert)
        except Exception as exc:
            self.report({'ERROR'}, f"Weight Texture Mask failed: {exc}")
            raise

        self.report({'INFO'}, f"Weight Texture Mask updated for '{props.vertex_group}'.")
        return {'FINISHED'}


class WTM_PT_panel(bpy.types.Panel):
    bl_label = "Weight Texture Mask"
    bl_idname = "WTM_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Weight Texture Mask'

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        obj = context.object
        props = obj.wtm_props

        box = layout.box()
        box.label(text="Mask Source", icon='GROUP_VERTEX')
        if len(obj.vertex_groups) == 0:
            box.label(text="No Vertex Groups", icon='ERROR')
        else:
            row = box.row()
            row.label(text="Vertex Group")
            row.prop_search(props, "vertex_group", obj, "vertex_groups", text="")

            row = box.row()
            row.prop(props, "invert")

            col = box.column(align=True)
            col.operator("wtm.setup", icon='NODE_MATERIAL')

        info = layout.box()
        info.label(text="Shader", icon='MATERIAL')
        info.label(text="BSDF A = unpainted / BSDF B = painted")
        info.label(text="The generated nodes are editable.")


classes = (
    WTMProperties,
    WTM_OT_setup,
    WTM_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.wtm_props = bpy.props.PointerProperty(type=WTMProperties)


def unregister():
    if hasattr(bpy.types.Object, 'wtm_props'):
        del bpy.types.Object.wtm_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
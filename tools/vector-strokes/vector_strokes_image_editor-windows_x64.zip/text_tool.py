# SPDX-License-Identifier: GPL-3.0-or-later
"""文字ツール (Illustrator の文字ツール = T)。

- 何もない所をクリック: そこに新しい文字を作り、そのまま打ち込める
- 文字の上をクリック: その文字を編集する (カーソルはクリックした場所へ)
- 字の上をドラッグ: 範囲を選ぶ。二度押しでその単語。Shift+矢印でも伸ばせる
- ⌘A 全選択 / ⌘C コピー / ⌘X 切り取り / ⌘V 貼り付け (パソコンのクリップボードを使う)
- キャンバスでは英数字をそのまま打てる。日本語はほかのアプリからの貼り付けか、
  サイドバーの「文字」欄に入力する (Blender のキャンバスでは日本語変換が使えないため)
- Esc / 右クリック: 編集をやめる (中身が空なら文字オブジェクトは消える)。打っていないときの右クリックはメニュー
"""

import bpy

from . import data, keys, render, snap, state, text as text_mod, transform
from .select_tool import pick_leaf, select_only
from .tool_base import Tool

HEADER_TEXT = keys.fmt("文字 | ドラッグ: 枠を作って文字を入れる (クリックだけでは作りません) | "
               "字の上をドラッグ: 範囲を選ぶ (二度押し: 単語) | "
               "{C}A 全選択 {C}C/{C}X/{C}V コピー・切り取り・貼り付け | "
               "日本語は貼り付けかサイドバーの「文字」欄へ | Esc: 編集をやめる")

# 編集中は打ち込む文字として扱うので、ツール切り替えのキーにしない
EDIT_KEYS = {'RET', 'NUMPAD_ENTER', 'BACK_SPACE', 'DEL', 'LEFT_ARROW', 'RIGHT_ARROW',
             'UP_ARROW', 'DOWN_ARROW', 'HOME', 'END'}


def text_at(vs, view, mx, my, iso, tol):
    """その場所にある文字オブジェクトの uid (無ければ None)。
    エリア文字は、枠の中ならどこでも編集できる (Illustrator と同じ)。"""
    from . import geometry as G
    from .select_tool import _clip_ancestors, selectable_item
    import numpy as np
    uid = pick_leaf(vs, view, mx, my, iso, tol)
    m = data.uid_map(vs)
    if uid is not None:
        ob = vs.objects[data.index_of_uid(vs, uid)]
        if ob.kind == 'TEXT':
            return uid
        # 文字をマスクにしている (画像を文字の形で切り抜くなど) ときは、文字の中をクリックすると
        # 中身 (画像など) が先に当たってしまうので、その文字を返す。
        # (見えている所 = マスクが通している所なので、そこにある文字マスクはクリックした場所の上にある)
        ch = data.children_map(vs)
        for c in _clip_ancestors(vs, uid, m, ch):
            if m[c].kind == 'TEXT' and data.is_editable(vs, c, m):
                return c
    editable = data.effective_editable(vs)
    p = np.array([mx, my], np.float64)
    for i in range(len(vs.objects) - 1, -1, -1):
        ob = vs.objects[i]
        if ob.kind != 'TEXT' or ob.text_kind != 'AREA' or not editable[i]:
            continue
        if selectable_item(vs, ob.uid, iso, m) is None:
            continue
        polys = [(view.to_region(poly), closed)
                 for poly, closed in G.polylines(G.text_frame_subpaths(ob))]
        if polys and G.point_in_polys(polys, p, 'NONZERO'):
            return ob.uid
    return None


def tool_settings():
    return bpy.context.window_manager.vstroke_tool


# 図形を「文字の入れ物」にするのは、線のすぐ上をクリックしたときだけ。
# 点をつかむ判定 (hit_radius) を使うと、20〜40px 離れていても変換されてしまい、
# 図形が消えたように見える (2026-09-21 ユーザー報告)
CONTAINER_TOL = 5.0


def container_at(vs, view, mx, my, iso, tol):
    """その場所の「線の上」にあるパス・図形 (文字の入れ物にできるもの)。
    塗りの内側をクリックしただけでは選ばない (Illustrator と同じで、線の上だけ)。
    tol は画面上のピクセル。狭くしておかないと、離れた図形まで変換してしまう。"""
    from . import geometry as G
    from .select_tool import selectable_item
    import numpy as np
    m = data.uid_map(vs)
    editable = data.effective_editable(vs)
    p = np.array([mx, my], np.float64)
    sc = abs(float(view.s[0]))
    for i in range(len(vs.objects) - 1, -1, -1):
        ob = vs.objects[i]
        if ob.kind not in {'PATH', 'SHAPE'} or not editable[i]:
            continue
        if selectable_item(vs, ob.uid, iso, m) is None:
            continue
        t = tol + data.stroke_extent(ob) * sc * 0.5
        for poly, closed in G.polylines(G.object_subpaths(ob)):
            if len(poly) < 2:
                continue
            if G.dist_to_polyline(view.to_region(poly), closed, p) <= t:
                return ob.uid, bool(closed)
    return None, False


def _slice(lines, a, b):
    """(行, 文字) から (行, 文字) までの文字列を取り出す。"""
    (l0, c0), (l1, c1) = a, b
    if l0 == l1:
        return lines[l0][c0:c1]
    out = [lines[l0][c0:]] + lines[l0 + 1:l1] + [lines[l1][:c1]]
    return "\n".join(out)


def clipboard_set(s):
    """パソコンのクリップボードに入れる (画面の無い環境では控えの方だけ使う)。"""
    state.text_clipboard = s
    try:
        bpy.context.window_manager.clipboard = s
    except Exception:
        pass


def clipboard_get():
    """貼り付ける文字。ほかのアプリでコピーしたものがあればそちらを使う。"""
    try:
        s = bpy.context.window_manager.clipboard or ""
    except Exception:
        s = ""
    return s or state.text_clipboard or ""


def set_caret(img_name, uid, line, col, sel=None):
    state.text_caret = (img_name, uid, int(line), int(col)) if uid else None
    state.text_sel = (img_name, uid, sel[0], sel[1]) if (uid and sel) else None


def caret_of(img_name):
    c = state.text_caret
    return c if c is not None and c[0] == img_name else None


def _changed_end(before, now):
    """2つの文字列で、変わった所の終わり (now の中の位置) を (行, 文字数) で返す。"""
    p = 0
    n = min(len(before), len(now))
    while p < n and before[p] == now[p]:
        p += 1
    q = 0
    while q < n - p and before[len(before) - 1 - q] == now[len(now) - 1 - q]:
        q += 1
    end = len(now) - q
    head = now[:end]
    line = head.count("\n")
    col = len(head) - (head.rfind("\n") + 1)
    return line, col


class TextTool(Tool):
    name = 'TEXT'
    header = HEADER_TEXT
    cursor = 'TEXT'

    def __init__(self, img_name, host=None):
        super().__init__(img_name, host)
        self.edit = None        # {"uid": ..., "line": ..., "col": ...}
        self.fresh = set()      # ドラッグで新しく作った文字 (何も打たずにやめたら消す)
        # まだ Undo の履歴に積んでいない打ち込みの種類 ('type' 打つ / 'delete' 消す)。
        # 1文字ずつ積むと Undo が細かすぎるので、単語ごと・種類が変わったときにまとめて積む
        self._pending = None
        self._take_request()

    def _take_request(self):
        """選択ツールでダブルクリックされた文字を、そのまま編集し始める。"""
        req = state.text_edit_request
        state.text_edit_request = None
        if req is None:
            return
        uid, point = req
        img = self.image()
        if img is None:
            return
        vs = img.vstroke
        i = data.index_of_uid(vs, uid)
        if i < 0 or vs.objects[i].kind != 'TEXT':
            return
        line, col = text_mod.index_at(vs.objects[i], point)
        self.begin_edit(vs, uid, line, col)

    # --- 編集中かどうか ---
    def grabs_keys(self):
        """True の間は V / P などをツール切り替えに使わない (文字として打ち込む)。"""
        return self.edit is not None

    def editing_object(self, vs):
        if self.edit is None:
            return None
        i = data.index_of_uid(vs, self.edit["uid"])
        if i < 0:
            self.edit = None
            set_caret(self.img_name, 0, 0, 0)
            return None
        return vs.objects[i]

    def _sync_caret(self):
        if self.edit is None:
            set_caret(self.img_name, 0, 0, 0)
        else:
            set_caret(self.img_name, self.edit["uid"], self.edit["line"], self.edit["col"],
                      self.selection())

    # --- 選んでいる範囲 ---
    def selection(self):
        """選んでいる範囲 ((行, 文字), (行, 文字))。選んでいなければ None。"""
        if self.edit is None:
            return None
        a = self.edit.get("anchor")
        if a is None:
            return None
        b = (self.edit["line"], self.edit["col"])
        if tuple(a) == b:
            return None
        return tuple(sorted([tuple(a), b]))

    def selection_ranges(self):
        """選んでいる範囲を [(行, 始まり, 終わり)] にする (書式を付けるときに使う)。"""
        sel = self.selection()
        if sel is None:
            return []
        img = self.image()
        ob = self.editing_object(img.vstroke) if img else None
        if ob is None:
            return []
        (l0, c0), (l1, c1) = sel
        lines = data.text_string(ob).split("\n")
        out = []
        for line in range(l0, min(l1, len(lines) - 1) + 1):
            a = c0 if line == l0 else 0
            b = c1 if line == l1 else len(lines[line])
            if b > a:
                out.append((line, a, b))
        return out

    def selected_text(self):
        sel = self.selection()
        if sel is None:
            return ""
        img = self.image()
        ob = self.editing_object(img.vstroke) if img else None
        if ob is None:
            return ""
        return _slice(data.text_string(ob).split("\n"), sel[0], sel[1])

    def set_anchor(self, keep):
        """keep が False なら選択を解除する。True なら今の位置から選び始める。"""
        if not keep:
            self.edit["anchor"] = None
        elif self.edit.get("anchor") is None:
            self.edit["anchor"] = (self.edit["line"], self.edit["col"])

    def _delete_selection(self, ob):
        """選んでいる範囲を消す。消したら True。"""
        sel = self.selection()
        if sel is None:
            return False
        (l0, c0), (l1, c1) = sel
        self.edit["anchor"] = None
        line, col = data.delete_text(ob, l0, c0, l1, c1)
        self._after_edit(ob, line, col)
        return True

    def begin_edit(self, vs, uid, line=0, col=0, anchor=None):
        self.edit = {"uid": uid, "line": line, "col": col, "anchor": anchor}
        i = data.index_of_uid(vs, uid)
        self.edit["text"] = data.text_string(vs.objects[i]) if i >= 0 else ""
        select_only(vs, [uid])
        data.set_active(vs, data.index_of_uid(vs, uid))
        self._clamp(vs)
        self.redraw()

    # --- Undo の区切り ---
    def _mark(self, kind):
        """これから kind ('type' / 'delete') の編集をする。種類が変わるなら、前の分を積む。"""
        if self._pending is not None and self._pending != kind:
            self._flush()
        self._pending = kind

    def _flush(self):
        """まだ積んでいない打ち込みを、Undo の履歴に1段積む。"""
        if self._pending is None:
            return
        self._pending = None
        self.push_undo("Edit Text")

    def after_undo(self):
        """Undo / やり直しのあと (handlers.on_undo_redo から呼ばれる)。
        文字は元に戻っているので、カーソルを収め直す。文字そのものが無くなっていたら編集をやめる。"""
        self._pending = None
        self.drag = None
        img = self.image()
        if img is None or self.edit is None:
            return
        vs = img.vstroke
        ob = self.editing_object(vs)
        if ob is None:                            # 作る前まで戻った
            self.edit = None
            self._sync_caret()
            return
        # カーソルは「戻った部分の終わり」に置く (打った分を戻したらその手前、
        # 消した分を戻したら戻った文字のうしろ。ふつうの文字入力と同じ)
        before = self.edit.get("text")
        now = data.text_string(ob)
        if before is not None and before != now:
            self.edit["line"], self.edit["col"] = _changed_end(before, now)
            self.edit["anchor"] = None
        self.edit["text"] = now
        self._clamp(vs)

    def leave(self):
        """別のツールへ移る・編集を終えるときに呼ばれる。打っている途中なら確定する。"""
        img = self.image()
        if self.edit is not None and img is not None:
            self.end_edit(img)

    def end_edit(self, img, push=True):
        """編集をやめる。中身が空なら文字オブジェクトを消す。"""
        vs = img.vstroke
        ob = self.editing_object(vs)
        self.edit = None
        self._sync_caret()
        if ob is None:
            return
        # 何も打たずにやめた新しい文字は消す (空の枠だけが残って、見えないのに
        # クリックできてしまうのを防ぐ)。もとからあった図形・パスを入れ物にした文字は、
        # 空でも残す (元の形が消えてしまうため)
        fresh = ob.uid in self.fresh
        self.fresh.discard(ob.uid)
        if data.text_string(ob) == "" and (ob.text_kind == 'POINT' or fresh):
            data.remove_objects(vs, [ob.uid])
            render.render_image(img)
            if push:
                self._pending = 'delete'
                self._flush()
            self._pending = None
            self.redraw()
            return
        old_name = ob.name
        ob.name = data.text_name(ob)
        render.render_image(img)
        if push and (self._pending is not None or ob.name != old_name):
            self._pending = 'type'
            self._flush()
        self._pending = None
        self.redraw()

    def _clamp(self, vs):
        ob = self.editing_object(vs)
        if ob is None:
            return
        line, col = text_mod.clamp_caret(ob, self.edit["line"], self.edit["col"])
        self.edit["line"], self.edit["col"] = line, col
        a = self.edit.get("anchor")
        if a is not None:
            self.edit["anchor"] = text_mod.clamp_caret(ob, a[0], a[1])
        self._sync_caret()

    # --- イベント ---
    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke

        if self.drag is not None:
            return self._drag_event(img, event, mx, my, view)

        if event.type == 'MOUSEMOVE':
            return 'PASS_THROUGH'

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if self.edit is not None:
                self.end_edit(img)
                return 'RUNNING_MODAL'
            if event.type == 'ESC' and transform.selected_items(vs):
                select_only(vs, [])
                self.redraw()
                return 'RUNNING_MODAL'
            return 'FINISHED'

        if event.type == 'LEFTMOUSE' and event.value in {'PRESS', 'DOUBLE_CLICK'}:
            if not inside:
                return 'PASS_THROUGH'
            return self._press(img, view, mx, my)

        if self.edit is not None and event.value == 'PRESS':
            # マウスがキャンバスの上にあるときだけ、キーを文字に入れる。
            # 上のバーやサイドバーの欄 (文字サイズなど) に数字を打つとき、その数字が
            # 選んでいる文字に入ってしまう不具合があった (欄より先にここが受け取っていた)
            if not inside:
                return 'PASS_THROUGH'
            return self._edit_key(img, event)

        return 'PASS_THROUGH'

    def _press(self, img, view, mx, my):
        self._flush()                   # カーソルを動かす前に、打った分を積む
        vs = img.vstroke
        tol = state.hit_radius()
        iso = self.isolation(vs)
        uid = text_at(vs, view, mx, my, iso, tol)
        p = view.to_image(mx, my)
        if self.edit is not None and (uid is None or uid != self.edit["uid"]):
            self.end_edit(img)
        if uid is not None:
            ob = vs.objects[data.index_of_uid(vs, uid)]
            line, col = text_mod.index_at(ob, p)
            same = self.edit is not None and self.edit["uid"] == uid
            if same and self.double_press(mx, my):
                a, b = text_mod.word_range(ob, line, col)       # 二度押し: 単語を選ぶ
                self.edit.update(line=line, col=b, anchor=(line, a))
                self._clamp(vs)
                self.redraw()
                return 'RUNNING_MODAL'
            if not same:
                self.double_press(mx, my)                       # 押した記録だけ残す
            self.begin_edit(vs, uid, line, col)
            # ここからドラッグすると範囲選択になる
            self.drag = {"start": (mx, my), "cur": (mx, my), "moved": False,
                         "type": 'CARET', "uid": uid}
            return 'RUNNING_MODAL'
        # パスや図形の線の上なら、その形を文字の入れ物にする (線のすぐ上だけ)
        cont, closed = container_at(vs, view, mx, my, iso,
                                    CONTAINER_TOL * state.ui_scale())
        if cont is not None:
            return self._make_container(img, cont, closed)
        # ここからドラッグしたらエリア文字。クリックだけなら何も作らない (v0.22.0)
        targets = snap.make(vs, img, [])
        self.drag = {"start": (mx, my), "cur": (mx, my), "start_img": snap.place(p, targets, view),
                     "moved": False, "type": 'BOX', "targets": targets}
        return 'RUNNING_MODAL'

    def _drag_event(self, img, event, mx, my, view):
        d = self.drag
        if d.get("type") == 'CARET':
            return self._caret_drag(img, event, mx, my, view)
        if event.type == 'MOUSEMOVE':
            d["cur"] = (mx, my)
            if not d["moved"]:
                sx, sy = d["start"]
                if abs(mx - sx) > 3 * state.ui_scale() or abs(my - sy) > 3 * state.ui_scale():
                    d["moved"] = True
            self.redraw()
            return 'RUNNING_MODAL'
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self.drag = None
            self.redraw()
            return 'RUNNING_MODAL'
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            moved = d["moved"]
            p0 = d["start_img"]
            p1 = snap.place(view.to_image(mx, my), d.get("targets"), view)
            self.drag = None
            snap.clear_guides()
            if not moved:
                return 'RUNNING_MODAL'      # クリックだけでは何も起こらない
            return self._create_area(img, p0, p1)
        return 'RUNNING_MODAL'

    def _caret_drag(self, img, event, mx, my, view):
        """字の上をドラッグして範囲を選ぶ。"""
        vs = img.vstroke
        d = self.drag
        if event.type == 'MOUSEMOVE':
            if self.edit is None:
                return 'RUNNING_MODAL'
            sx, sy = d["start"]
            if not d["moved"]:
                if abs(mx - sx) <= 2 * state.ui_scale() and abs(my - sy) <= 2 * state.ui_scale():
                    return 'RUNNING_MODAL'
                d["moved"] = True
                self.set_anchor(True)
            ob = self.editing_object(vs)
            if ob is not None:
                line, col = text_mod.index_at(ob, view.to_image(mx, my))
                self.edit["line"], self.edit["col"] = line, col
                self._clamp(vs)
                self.redraw()
            return 'RUNNING_MODAL'
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.drag = None
            self.redraw()
            return 'RUNNING_MODAL'
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self.drag = None
            self.redraw()
            return 'RUNNING_MODAL'
        return 'RUNNING_MODAL'

    def _make_container(self, img, uid, closed):
        """パス・図形を文字の入れ物に変える。"""
        vs = img.vstroke
        ob = vs.objects[data.index_of_uid(vs, uid)]
        if not data.is_editable(vs, uid):
            self.host.report("ロック中か非表示のオブジェクトです")
            return 'RUNNING_MODAL'
        if data.make_text_container(vs, ob) is None:
            self.host.report("この形は文字の入れ物にできません")
            return 'RUNNING_MODAL'
        render.render_image(img)
        self.push_undo("Text Container")
        self.host.report(keys.fmt("図形を文字の入れ物にしました ({C}Z で元に戻せます)"))
        self.begin_edit(vs, uid, 0, 0)
        return 'RUNNING_MODAL'

    def _create_area(self, img, p0, p1):
        """ドラッグした四角を枠にして、エリア文字を作る。"""
        vs = img.vstroke
        ob = self._new_text(img, (min(p0[0], p1[0]), max(p0[1], p1[1])))
        if ob is None:
            return 'RUNNING_MODAL'
        with render.suspended():
            ob.text_kind = 'AREA'
            ob.text_box = (max(abs(p1[0] - p0[0]), 10.0), max(abs(p1[1] - p0[1]), 10.0))
        self.fresh.add(ob.uid)
        self.begin_edit(vs, ob.uid, 0, 0)
        return 'RUNNING_MODAL'

    def _new_text(self, img, origin):
        """新しい文字オブジェクトを作る (作れなければ None)。"""
        vs = img.vstroke
        if not self.can_create(vs):
            return None
        from . import fonts
        if not fonts.available():
            self.host.report("文字を扱うライブラリ (uharfbuzz) を読み込めません")
            return None
        if not fonts.families():
            self.host.report("使えるフォントが見つかりませんでした")
            return None
        with render.suspended():
            oi = data.new_object(vs, kind='TEXT', parent_uid=self.isolation(vs))
            ob = vs.objects[oi]
            data.ensure_font(ob)
            ob.text_origin = origin
            ob.text_mat = (1.0, 0.0, 0.0, 1.0)
            ob.fill_rule = 'NONZERO'
            ob.text_vertical = bool(tool_settings().text_vertical)
        return ob

    # --- 文字の打ち込み ---
    def _edit_key(self, img, event):
        vs = img.vstroke
        ob = self.editing_object(vs)
        if ob is None:
            return 'PASS_THROUGH'
        t = event.type
        if keys.command_mod(event) or event.ctrl:
            if t in {'A', 'C', 'X', 'V'} and not event.shift:
                return self._edit_command(img, ob, t)
            if t in {'Z', 'Y'}:
                # ⌘Z は Blender にまかせるが、その前に打った分を積む。
                # 積まないと、打った文字が記録されないまま、その前の操作まで戻ってしまう
                # (2026-09-22 ユーザー要望「テキストの入力内容も Undo できるように」)
                self._flush()
            return 'PASS_THROUGH'          # ⌘Z などは Blender にまかせる
        line, col = self.edit["line"], self.edit["col"]
        lines = data.text_string(ob).split("\n")

        if t in {'RET', 'NUMPAD_ENTER'}:
            self._mark('type')
            self._insert(ob, "\n")
            self._flush()                  # 改行で区切る
            return 'RUNNING_MODAL'
        if t in {'BACK_SPACE', 'DEL'}:
            self._mark('delete')
        if t in {'BACK_SPACE', 'DEL'} and self.selection() is not None:
            self._delete_selection(ob)     # 選んでいる範囲をまとめて消す
            return 'RUNNING_MODAL'
        if t == 'BACK_SPACE':
            if col > 0:
                self._after_edit(ob, *data.delete_text(ob, line, col - 1, line, col))
            elif line > 0:
                prev = len(lines[line - 1])
                self._after_edit(ob, *data.delete_text(ob, line - 1, prev, line, 0))
            return 'RUNNING_MODAL'
        if t == 'DEL':
            if col < len(lines[line]):
                self._after_edit(ob, *data.delete_text(ob, line, col, line, col + 1))
            elif line + 1 < len(lines):
                self._after_edit(ob, *data.delete_text(ob, line, col, line + 1, 0))
            return 'RUNNING_MODAL'
        if event.alt and t in {'LEFT_ARROW', 'RIGHT_ARROW'} and self.selection() is None:
            # Alt+←/→: カーソルの前後の2文字の間を詰める・空ける (カーニング。
            # Illustrator と同じく 1回で 20/1000 em)
            self._flush()
            cur = data.kern_at(ob, line, col)
            if cur is None:
                self.host.report("カーニングは、文字と文字の間にカーソルを置いて使います")
                return 'RUNNING_MODAL'
            data.set_kern(ob, line, col, cur + (20.0 if t == 'RIGHT_ARROW' else -20.0))
            self.push_undo("Kerning")
            self.redraw()
            return 'RUNNING_MODAL'
        if t in {'LEFT_ARROW', 'RIGHT_ARROW', 'UP_ARROW', 'DOWN_ARROW', 'HOME', 'END'}:
            self._flush()                  # カーソルを動かしたら区切る
            self.set_anchor(event.shift)
            self._move_caret(lines, t)
            return 'RUNNING_MODAL'

        ch = getattr(event, "unicode", "") or ""
        if not ch and t in {'TAB', 'SPACE'}:
            ch = " "
        if ch and ch.isprintable():
            self._mark('type')
            self._insert(ob, ch)
            if ch.isspace():
                self._flush()              # 単語ごとに区切る
            return 'RUNNING_MODAL'
        return 'PASS_THROUGH'

    def _insert(self, ob, s):
        """カーソルの所に文字を入れる (選んでいる範囲があれば置き換える)。
        書式は直前の文字を引き継ぐ (data.insert_text)。"""
        self._delete_selection(ob)
        line, col = self.edit["line"], self.edit["col"]
        self._after_edit(ob, *data.insert_text(ob, line, col, s))

    def _edit_command(self, img, ob, t):
        """編集中の ⌘A 全選択 / ⌘C コピー / ⌘X 切り取り / ⌘V 貼り付け。
        文字の貼り付けはパソコンのクリップボードを使うので、
        ほかのアプリで書いた日本語もそのまま貼れる。"""
        vs = img.vstroke
        if t == 'A':
            lines = data.text_string(ob).split("\n")
            self.edit["anchor"] = (0, 0)
            self.edit["line"], self.edit["col"] = len(lines) - 1, len(lines[-1])
            self._clamp(vs)
            self.redraw()
            return 'RUNNING_MODAL'
        if t in {'C', 'X'}:
            sel = self.selected_text()
            if not sel:
                return 'RUNNING_MODAL'
            clipboard_set(sel)
            if t == 'X':
                self._flush()
                self._delete_selection(ob)
                self._pending = 'delete'
                self._flush()              # 切り取りは1段
            return 'RUNNING_MODAL'
        # V
        s = clipboard_get()
        s = s.replace("\r\n", "\n").replace("\r", "\n")
        if not s:
            self.host.report("貼り付ける文字がありません")
            return 'RUNNING_MODAL'
        self._flush()
        self._insert(ob, s)
        self._pending = 'type'
        self._flush()                      # 貼り付けは1段
        return 'RUNNING_MODAL'

    def _after_edit(self, ob, line, col):
        """文字を変えたあとの後始末 (カーソル位置・再描画)。"""
        self.edit["line"], self.edit["col"] = line, col
        self.edit["text"] = data.text_string(ob)     # Undo のあとの比べる相手
        self._clamp(ob.id_data.vstroke)
        img = self.image()
        if img is not None:
            render.render_image(img)
        self.redraw()

    def _write(self, ob, lines, line, col):
        data.set_text_string(ob, "\n".join(lines))
        self._after_edit(ob, line, col)

    def _move_caret(self, lines, t):
        line, col = self.edit["line"], self.edit["col"]
        if t == 'LEFT_ARROW':
            if col > 0:
                col -= 1
            elif line > 0:
                line, col = line - 1, len(lines[line - 1])
        elif t == 'RIGHT_ARROW':
            if col < len(lines[line]):
                col += 1
            elif line + 1 < len(lines):
                line, col = line + 1, 0
        elif t == 'UP_ARROW':
            line = max(0, line - 1)
            col = min(col, len(lines[line]))
        elif t == 'DOWN_ARROW':
            line = min(len(lines) - 1, line + 1)
            col = min(col, len(lines[line]))
        elif t == 'HOME':
            col = 0
        elif t == 'END':
            col = len(lines[line])
        self.edit["line"], self.edit["col"] = line, col
        self._sync_caret()
        self.redraw()

    def cursor_at(self, view, mx, my):
        """線の上では別のカーソルにして、「押すと入れ物になる」と分かるようにする。"""
        img = self.image()
        if img is None or self.edit is not None:
            return 'TEXT'
        try:
            uid, _closed = container_at(img.vstroke, view, mx, my,
                                        self.isolation(img.vstroke),
                                        CONTAINER_TOL * state.ui_scale())
        except Exception:
            uid = None
        return 'CROSS' if uid is not None else 'TEXT'

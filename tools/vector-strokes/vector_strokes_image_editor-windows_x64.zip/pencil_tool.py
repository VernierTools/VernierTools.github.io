# SPDX-License-Identifier: GPL-3.0-or-later
"""鉛筆ツール: 手で描いた線を、描きながらベジェ曲線にする (2026-09-22 ユーザー要望)。

- ドラッグ: 描く。描いている間も、曲線にあてはめた形を見せる (fit.py)
- 描き始めの近くで離す: 閉じた形にする
- 選んでいるパスの端から描き始める: そのパスの続きになる (反対の端の近くで離すと閉じる)
- 上のバーの「滑らかさ」: 0 に近いほど手の動きに忠実、1 に近いほど点が少なく滑らか
- Esc / 右クリック: 描いている線を取り消す。何もしていないときは Esc で終える・右クリックでメニュー
筆圧で線の太さを変えることはできない (線の太さは一定のため)。
"""

import bpy
import numpy as np

from . import data, edit_logic, fit, geometry as G, render, state
from .select_tool import select_only
from .tool_base import Tool

HEADER_TEXT = ("鉛筆 | ドラッグ: 描く (描きながら曲線になる) | 描き始めの近くで離す: 閉じる | "
               "選んでいるパスの端から描く: 続きを描く | 滑らかさは上のバーで | "
               "Esc/右クリック: 描いている線を取り消す | 何もしていない時は Esc: 終了・右クリック: メニュー")


def tool_settings():
    return bpy.context.window_manager.vstroke_tool


def fit_params(view, smoothness):
    """滑らかさ (0〜1) から、あてはめの細かさを決める (画面の見た目で揃える)。"""
    scale = max(abs(float(view.s[0])), 1e-6)       # 画像1ピクセルが画面で何ピクセルか
    u = state.ui_scale()
    s = min(max(float(smoothness), 0.0), 1.0)
    return dict(err=(0.5 + 5.5 * s) * u / scale,
                spacing=2.0 * u / scale,
                smoothness=int(round(1 + 5 * s)),
                corner_window=10.0 * u / scale)


class PencilTool(Tool):
    name = 'PENCIL'
    header = HEADER_TEXT
    cursor = 'PAINT_BRUSH'

    def __init__(self, img_name, host=None):
        super().__init__(img_name, host)
        self.preview = []          # 描いている線を曲線にしたもの (画像座標の折れ線)
        self.anchors = []          # その曲線の点 [(co, handle_left, handle_right)]

    # --- イベント ---
    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke
        if self.drag is not None:
            if event.type == 'MOUSEMOVE':
                self._add(view, mx, my)
                return 'RUNNING_MODAL'
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                self._add(view, mx, my)
                return self._finish_stroke(img, view)
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._cancel()
                return 'RUNNING_MODAL'
            return 'RUNNING_MODAL'
        if not inside or event.type == 'MOUSEMOVE':
            return 'PASS_THROUGH'
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if event.type == 'ESC' and any(o.select for o in vs.objects):
                select_only(vs, [])
                self.redraw()
                return 'RUNNING_MODAL'
            return 'FINISHED'
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            return self._start(img, view, mx, my)
        return 'PASS_THROUGH'

    # --- 描く ---
    def _start(self, img, view, mx, my):
        vs = img.vstroke
        cont = self._continue_target(vs, view, mx, my)
        if cont is None and not self.can_create(vs):
            return 'RUNNING_MODAL'
        self.drag = {"screen": [(mx, my)], "img": [tuple(view.to_image(mx, my))],
                     "cont": cont, "view": view}
        self.preview, self.anchors = [], []
        self.redraw()
        return 'RUNNING_MODAL'

    def _continue_target(self, vs, view, mx, my):
        """選んでいる開いたパスの端の近くで描き始めたら (uid, 始点側か)。"""
        ob = data.active_object(vs)
        if (ob is None or ob.kind != 'PATH' or not ob.select or len(ob.subpaths) != 1
                or ob.subpaths[0].closed or len(ob.subpaths[0].points) < 1
                or not data.is_editable(vs, ob.uid)):
            return None
        pts = ob.subpaths[0].points
        tol = state.hit_radius()
        p = np.array([mx, my], np.float64)
        for at_start, pt in ((False, pts[-1]), (True, pts[0])):
            if float(np.hypot(*(view.to_region(pt.co) - p))) <= tol:
                return (ob.uid, at_start)
        return None

    def _add(self, view, mx, my):
        d = self.drag
        lx, ly = d["screen"][-1]
        if abs(mx - lx) < 1.0 and abs(my - ly) < 1.0:
            return
        d["screen"].append((mx, my))
        d["img"].append(tuple(view.to_image(mx, my)))
        self._refit(view)
        self.redraw()

    def _refit(self, view):
        d = self.drag
        prm = fit_params(view, tool_settings().pencil_smooth)
        self.anchors = fit.fit_stroke(d["img"], **prm)
        if len(self.anchors) >= 2:
            self.preview = [tuple(p) for p in G.flatten_t(self.anchors, False)]
        else:
            self.preview = list(d["img"])

    def _cancel(self):
        self.drag = None
        self.preview, self.anchors = [], []
        self.redraw()

    def _finish_stroke(self, img, view):
        d = self.drag
        self._refit(view)
        anchors = list(self.anchors)
        screen = d["screen"]
        self.drag = None
        self.preview, self.anchors = [], []
        u = state.ui_scale()
        length = float(np.hypot(*np.diff(np.array(screen), axis=0).T).sum()) if len(screen) > 1 else 0.0
        if len(anchors) < 2 or length < 3.0 * u:
            self.redraw()                       # クリックだけ・ほとんど動かしていない
            return 'RUNNING_MODAL'
        vs = img.vstroke
        tol = state.hit_radius()
        if d["cont"] is not None:
            uid = self._append(vs, view, d["cont"], anchors, screen[-1], tol)
        else:
            closed = (len(anchors) >= 3 and length > 4.0 * tol
                      and float(np.hypot(screen[-1][0] - screen[0][0],
                                         screen[-1][1] - screen[0][1])) <= tol)
            uid = self._new_path(vs, anchors, closed)
        select_only(vs, [uid])
        render.render_image(img)
        self.push_undo("Pencil")
        self.redraw()
        return 'RUNNING_MODAL'

    def _new_path(self, vs, anchors, closed):
        if closed:
            # 最後の点を最初の点に重ねて閉じる (最後の点の入りのハンドルを引き継ぐ)
            co0, _, hr0 = anchors[0]
            anchors = [(co0, anchors[-1][1], hr0)] + anchors[1:-1]
        with render.suspended():
            oi = data.new_object(vs, style_from=data.style_source(vs),
                                 parent_uid=self.isolation(vs))
            ob = vs.objects[oi]
            sp = ob.subpaths.add()
            for co, hl, hr in anchors:
                p = sp.points.add()
                p.co, p.handle_left, p.handle_right = co, hl, hr
            sp.closed = closed
            uid = ob.uid
        data.set_active(vs, data.index_of_uid(vs, uid))
        return uid

    def _append(self, vs, view, cont, anchors, end_screen, tol):
        """選んでいたパスの続きに足す。反対の端の近くで離したら閉じる。"""
        uid, at_start = cont
        ob = vs.objects[data.index_of_uid(vs, uid)]
        sp = ob.subpaths[0]
        with render.suspended():
            if at_start:
                edit_logic.reverse_subpath(sp)          # 描き始めた端を「終わり」にする
            end = sp.points[len(sp.points) - 1]
            co0, _, hr0 = anchors[0]
            ex, ey = end.co
            end.handle_right = (ex + hr0[0] - co0[0], ey + hr0[1] - co0[1])
            first = sp.points[0]
            closes = (len(sp.points) >= 2 and float(np.hypot(
                *(view.to_region(first.co) - np.array(end_screen, np.float64)))) <= tol)
            rest = anchors[1:]
            if closes and rest:
                first.handle_left = rest[-1][1]
                rest = rest[:-1]
            for co, hl, hr in rest:
                p = sp.points.add()
                p.co, p.handle_left, p.handle_right = co, hl, hr
            if closes:
                sp.closed = True
        data.set_active(vs, data.index_of_uid(vs, uid))
        return uid

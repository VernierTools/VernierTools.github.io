# SPDX-License-Identifier: GPL-3.0-or-later
"""このアドオン用のアイコン。

- サイドバー・上のバー用: icons/*.png を Blender のプレビューとして読み込み、
  `icon_value=` で使う (Illustrator の「塗り」= 塗りつぶした四角、「線」= 枠だけの四角)
- 左ツールバーのツールアイコンは形式が違う (icons/*.dat)。そちらは tools.py が使う
"""

import os

import bpy
import bpy.utils.previews  # noqa: F401  (これを入れないと previews が使えない)

ICON_DIR = os.path.join(os.path.dirname(__file__), "icons")
NAMES = ("fill", "stroke",
         "cap_butt", "cap_round", "cap_square",
         "join_miter", "join_round", "join_bevel",
         "align_center", "align_inside", "align_outside",
         "pf_unite", "pf_minus_front", "pf_intersect", "pf_exclude", "pf_minus_back",
         "pf_divide", "pf_trim", "pf_merge", "pf_crop", "pf_outline")

_previews = None


def icon_id(name):
    """プレビューアイコンの番号 (使えないときは 0)。"""
    if _previews is None:
        return 0
    try:
        return _previews[name].icon_id
    except Exception:
        return 0


def kw(name, fallback=None):
    """layout.label(**icons.kw("fill")) のように使う (読めなければ普通のアイコン)。"""
    i = icon_id(name)
    if i:
        return {"icon_value": i}
    return {"icon": fallback} if fallback else {}


def register():
    global _previews
    try:
        _previews = bpy.utils.previews.new()
        for name in NAMES:
            path = os.path.join(ICON_DIR, name + ".png")
            if os.path.exists(path):
                _previews.load(name, path, 'IMAGE')
    except Exception as e:
        print("[Vector Strokes] アイコンを読み込めません:", e)
        _previews = None


def unregister():
    global _previews
    if _previews is not None:
        try:
            bpy.utils.previews.remove(_previews)
        except Exception:
            pass
        _previews = None

# SPDX-License-Identifier: GPL-3.0-or-later
"""文字の組み方と字形 (アウトライン) の取り出し。

- 並べ方 (どの字をどこに置くか) は uharfbuzz にまかせる。
  これで詰め (カーニング)・合字・日本語の字間が、フォントの指定どおりになる
- 字形はフォントから「輪郭」として取り出し、パスと同じ形式に直す。
  そのため、塗り・線・グラデーション・効果は、パスや図形とまったく同じ仕組みで使える
- 文字の座標: 1行目のベースラインの始まりを原点 (0, 0)、上が + (Blender と同じ)。
  これを text_mat (拡大・回転) と text_origin (位置) で画像座標へ移す
"""

import math

import numpy as np

from . import fonts

# 字形の輪郭のキャッシュ: (path, index, gid) -> [(numpy(n,3,2), closed), ...] (フォント単位)
_glyph_cache = {}
# 組み上がりのキャッシュ: key -> Layout
_layout_cache = {}
_CACHE_MAX = 96

MISSING_MSG = "フォントが見つかりません"


# -----------------------------------------------------------------------------
# 字形 (グリフ) の輪郭
# -----------------------------------------------------------------------------

# 1文字の書式 (組むときに使う形)。
#   (書体, 大きさ, 字間 px, カーニング px (この字の前に空ける), 横の比率, 縦の比率)
# カーニングと比率は 2026-10-18 に追加 (Illustrator の文字パネルと同じ)
def base_attr(face, size, track):
    return (face, size, track, 0.0, 1.0, 1.0)


def _unpack(at):
    """古い3つ組みの書式が来ても読めるようにする。"""
    if len(at) >= 6:
        return at[:6]
    return (at[0], at[1], at[2], 0.0, 1.0, 1.0)


class _ContourPen:
    """uharfbuzz から字形の輪郭を受け取り、(co, handle_left, handle_right) の点列にする。"""

    def __init__(self):
        self.contours = []
        self.pts = None

    def _end(self, closed):
        pts = self.pts
        self.pts = None
        if not pts or len(pts) < 2:
            return
        if closed and _same(pts[0][0], pts[-1][0]):
            # 最後の点が始点と同じ -> 1つにまとめる
            pts[0][1] = pts[-1][1]
            pts.pop()
        self.contours.append(([(tuple(p[0]), tuple(p[1]), tuple(p[2])) for p in pts], closed))

    def moveTo(self, p):
        self._end(True)
        self.pts = [[p, p, p]]

    def lineTo(self, p):
        if self.pts is None:
            self.pts = [[p, p, p]]
            return
        self.pts.append([p, p, p])

    def curveTo(self, *points):
        # (c1, c2, 終点) の組をつなげる
        for i in range(0, len(points) - 2, 2):
            c1, c2, end = points[i], points[i + 1], points[i + 2]
            self._cubic(c1, c2, end)

    def qCurveTo(self, *points):
        if not points:
            return
        if points[-1] is None:          # 全部が制御点の閉じた輪郭 (まれ)
            points = points[:-1]
            if not points:
                return
            mid = _mid(points[-1], points[0])
            self.moveTo(mid)
            points = list(points) + [mid]
        pts = list(points)
        on = pts.pop()
        prev_off = None
        for off in pts:
            if prev_off is not None:
                self._quad(prev_off, _mid(prev_off, off))
            prev_off = off
        if prev_off is None:
            self.lineTo(on)
        else:
            self._quad(prev_off, on)

    def _cubic(self, c1, c2, end):
        if self.pts is None:
            self.pts = [[end, end, end]]
            return
        self.pts[-1][2] = c1
        self.pts.append([end, c2, end])

    def _quad(self, ctrl, end):
        if self.pts is None:
            self.pts = [[end, end, end]]
            return
        p0 = self.pts[-1][0]
        c1 = (p0[0] + 2.0 / 3.0 * (ctrl[0] - p0[0]), p0[1] + 2.0 / 3.0 * (ctrl[1] - p0[1]))
        c2 = (end[0] + 2.0 / 3.0 * (ctrl[0] - end[0]), end[1] + 2.0 / 3.0 * (ctrl[1] - end[1]))
        self._cubic(c1, c2, end)

    def closePath(self):
        self._end(True)

    def endPath(self):
        self._end(False)


def _same(a, b):
    return abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6


def _mid(a, b):
    return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)


def glyph_contours(face, gid):
    """字形の輪郭 (フォント単位、numpy 配列)。"""
    key = (face.path, face.index, int(gid))
    got = _glyph_cache.get(key)
    if got is not None:
        return got
    pen = _ContourPen()
    try:
        fonts.hb_font(face).draw_glyph_with_pen(int(gid), pen)
        pen._end(True)
    except Exception:
        pen.contours = []
    out = [(np.array(pts, np.float64), closed) for pts, closed in pen.contours if len(pts) >= 2]
    _glyph_cache[key] = out
    return out


# -----------------------------------------------------------------------------
# 1行の組み (uharfbuzz)
# -----------------------------------------------------------------------------

class Line:
    """組み上がった1行 (ローカル座標。位置は確定済み)。"""

    def __init__(self, src_line, start, s, glyphs, carets, extent, asc=None, desc=None):
        self.src_line = src_line   # 元の何行目か
        self.start = start         # 元の行の何文字目から始まるか (エリア文字の折り返し用)
        self.text = s
        # [(face, gid, x, y, 1字あたりの拡大率, 傾き)]
        self.glyphs = glyphs
        self.carets = carets       # 文字と文字の間 [(x, y, 傾き)] を len(text)+1 個
        self.extent = extent       # 行の長さ
        # その行の上への高さ・下への深さ (文字ごとに大きさが違うと行ごとに変わる)
        self.asc = asc
        self.desc = desc

    def end(self):
        return self.start + len(self.text)


class Layout:
    """文字全体の組み上がり。"""

    def __init__(self, lines, line_height, ascent, descent, vertical=False,
                 overflow=False):
        self.lines = lines
        self.line_height = line_height
        self.ascent = ascent
        self.descent = descent
        self.vertical = vertical
        self.overflow = overflow   # 枠やパスに入りきらなかった

    def subpaths(self):
        """全部の字形を1つの「サブパスの集まり」にする (ローカル座標)。"""
        out = []
        for ln in self.lines:
            for g in ln.glyphs:
                out.extend(glyph_subpaths(g))
        return out


def glyph_subpaths(g):
    """1文字分の輪郭 (ローカル座標)。"""
    face, gid, x, y, unit, ang = g      # unit は (横, 縦) の拡大率
    out = []
    if ang:
        c, s = math.cos(ang), math.sin(ang)
        R = np.array([[c, -s], [s, c]], np.float64)
    for arr, closed in glyph_contours(face, gid):
        a = arr * np.asarray(unit, np.float64)
        if ang:
            a = a @ R.T
        a = a + (x, y)
        out.append(([(tuple(p[0]), tuple(p[1]), tuple(p[2])) for p in a], closed))
    return out


def _shape_run(hbfont, s, vertical=False):
    """1続きの文字を組む。戻り値: [(gid, x_offset, y_offset, x_advance, y_advance, cluster)]
    (フォント単位)"""
    import uharfbuzz as hb
    buf = hb.Buffer()
    buf.add_str(s)
    buf.guess_segment_properties()
    feats = {"kern": True, "liga": True, "calt": True}
    if vertical:
        buf.direction = "ttb"
        feats.update({"vert": True, "vrt2": True})
    hb.shape(hbfont, buf, feats)
    out = []
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        out.append((info.codepoint, pos.x_offset, pos.y_offset,
                    pos.x_advance, pos.y_advance, info.cluster))
    return out


_fallback_cache = {}


def _has_glyph(hbfont, ch):
    try:
        g = hbfont.get_nominal_glyph(ord(ch))
    except Exception:
        return True
    return bool(g)


def face_for_char(primary, ch):
    """その字を持っている書体。primary で出せればそのまま、出せなければ代わりを探す
    (Illustrator の「環境にないフォントの置換」に近い動き)。"""
    # スペースも、字が無ければ代わりを探す (自作フォントでスペースを作り忘れると豆腐に
    # なっていた。2026-10-09 ユーザー報告)。タブは今まで通り
    if ch == "\t":
        return primary
    key = (primary.key, ch)
    got = _fallback_cache.get(key)
    if got is not None:
        return got
    face = primary
    if not _has_glyph(fonts.hb_font(primary), ch):
        for fam in fonts.DEFAULT_CANDIDATES:
            f = fonts.find(fam)
            if f is None or f.key == primary.key:
                continue
            try:
                if _has_glyph(fonts.hb_font(f), ch):
                    face = f
                    break
            except Exception:
                continue
    _fallback_cache[key] = face
    return face


def _runs(attrs, s):
    """文字列を「同じ書体・同じ大きさ・同じ字間で組む区間」に分ける。

    attrs は1文字につき base_attr の形。文字ごとの書式 (data.apply_char_style)
    と、字が無いときの代替書体 (face_for_char) の両方をここでまとめて見る。
    カーニングは区間を分けない (分けるとフォントの詰めや合字が途切れる。_compose で足す)。
    戻り値: [(開始位置, 文字列, face, 大きさ, 字間, 横の比率, 縦の比率)]
    """
    out = []
    start, cur, buf = 0, None, []
    for i, ch in enumerate(s):
        primary, size, track, _kern, sx, sy = _unpack(attrs[i] if i < len(attrs) else attrs[-1])
        f = face_for_char(primary, ch)
        key = (f.key, round(size, 4), round(track, 4), round(sx, 4), round(sy, 4))
        if cur is not None and key == cur[0]:
            buf.append(ch)
            continue
        if buf:
            out.append((start, "".join(buf)) + cur[1:])
        start, cur, buf = i, (key, f, size, track, sx, sy), [ch]
    if buf:
        out.append((start, "".join(buf)) + cur[1:])
    return out


def font_metrics(hbfont, upem):
    """(上への高さ, 下への深さ) を em 単位で。"""
    try:
        ext = hbfont.get_font_extents("ltr")
        asc = abs(ext.ascender) / upem
        desc = abs(ext.descender) / upem
    except Exception:
        asc, desc = 0.8, 0.2
    return asc, desc


# -----------------------------------------------------------------------------
# 1行を組む (位置はまだ決めない)
# -----------------------------------------------------------------------------

def _compose(attrs, s, vertical):
    """1行分を組む。attrs は1文字につき base_attr の形。
    戻り値: (glyphs, pos, extent)
      glyphs: [(face, gid, 横ずれ, 進んだ距離の位置, (横の拡大率, 縦の拡大率))]
              横書きでは (x, y) = (進んだ距離, 横ずれ)、縦書きでは (横ずれ, -進んだ距離)
      pos:    文字と文字の間の「進んだ距離」 (len(s)+1 個)
      extent: 行全体の長さ"""
    glyphs = []
    pos = [0.0] * (len(s) + 1)
    t = 0.0
    any_glyph = False
    last_track = 0.0
    kerns = [_unpack(attrs[i] if i < len(attrs) else attrs[-1])[3] for i in range(len(s))]
    last_c = None
    for offset, run, run_face, size, track, sx, sy in (_runs(attrs, s) if s else []):
        rf = fonts.hb_font(run_face)
        unit = size / (rf.face.upem or 1000)
        ux, uy = unit * sx, unit * sy
        last_track = track
        for gid, xo, yo, xadv, yadv, cluster in _shape_run(rf, run, vertical):
            any_glyph = True
            c = offset + cluster
            if c != last_c:
                # この字の前に空ける (カーニング)。文字と文字の間のカーソルは空けた後
                if 0 < c < len(kerns) and kerns[c]:
                    t += kerns[c]
                last_c = c
            if vertical:
                glyphs.append((run_face, gid, xo * ux, -t + yo * uy, (ux, uy)))
                step = abs(yadv) * uy + track
            else:
                glyphs.append((run_face, gid, t + xo * ux, yo * uy, (ux, uy)))
                step = xadv * ux + track
            if 0 <= c < len(pos):
                pos[c] = t
            t += step
    extent = max(t - last_track, 0.0) if any_glyph else 0.0
    pos[len(s)] = extent
    known = extent
    for j in range(len(pos) - 1, -1, -1):
        if pos[j] == 0.0 and j != 0:
            pos[j] = known
        else:
            known = pos[j]
    return glyphs, pos, extent


# 禁則処理 (日本語の組版ルール)
KINSOKU_START = set("、。，．・：；？！ヽヾゝゞ々ー）〕］｝〉》」』】"
                    "ぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮ"
                    ",.:;?!)]}”’%‰°℃")   # 行頭に来てはいけない
KINSOKU_END = set("（〔［｛〈《「『【([{“‘¥￥$")   # 行末に来てはいけない


def _is_word(ch):
    """英単語の途中で折らないようにするための判定。"""
    return ch.isascii() and (ch.isalnum() or ch in "'-")


def _wrap(attrs, s, vertical, limit):
    """エリア文字の折り返し。戻り値: [(開始位置, その行の文字列)]"""
    if not limit or limit <= 0:
        return [(0, s)]
    if not s:
        return [(0, s)]
    out = []
    start = 0
    guard = 0
    while start < len(s) and guard < 4000:
        guard += 1
        rest = s[start:]
        sub = attrs[start:]
        _, pos, extent = _compose(sub, rest, vertical)
        if extent <= limit:
            out.append((start, rest))
            break
        # 入りきる文字数 (最低1文字)
        k = 1
        while k < len(rest) and pos[k + 1] <= limit:
            k += 1
        b = k
        if b < len(rest):
            # 英単語の途中なら、直前の空白のうしろで折る
            if _is_word(rest[b - 1]) and _is_word(rest[b]):
                j = rest.rfind(" ", 0, b)
                if j > 0:
                    b = j + 1
            # 禁則: 行頭・行末に来てはいけない文字をずらす
            moved = 0
            while b > 1 and moved < 4 and (rest[b] in KINSOKU_START
                                           or rest[b - 1] in KINSOKU_END):
                b -= 1
                moved += 1
            # 次の行が空白で始まらないようにする (空白は前の行の終わりに付ける)
            while b < len(rest) and rest[b] == " ":
                b += 1
        out.append((start, rest[:b]))
        start += b
    return out


# -----------------------------------------------------------------------------
# オブジェクトから組み上がりを作る
# -----------------------------------------------------------------------------

def text_lines(ob):
    return [ln.text for ln in ob.text_lines] or [""]


def face_of(ob):
    """このオブジェクトが使う書体。見つからなければ None。"""
    if not fonts.available():
        return None
    f = fonts.find(ob.font_family, ob.font_style)
    if f is None:
        fam = fonts.default_family()
        f = fonts.find(fam) if fam else None
    return f


def frame_subpaths(ob):
    """エリア文字の枠 / パス上文字のパス (ローカル座標)。無ければ []。"""
    from . import geometry as G
    if ob.text_kind == 'POINT':
        return []
    if len(ob.subpaths) and len(ob.subpaths[0].points) >= 2:
        return [G.subpath_tuple(sp) for sp in ob.subpaths if len(sp.points) >= 2]
    if ob.text_kind == 'AREA':
        w, h = float(ob.text_box[0]), float(ob.text_box[1])
        pts = [(0.0, 0.0), (w, 0.0), (w, -h), (0.0, -h)]
        return [([(p, p, p) for p in pts], True)]
    return []


def _frame_key(ob):
    if ob.text_kind == 'POINT':
        return ()
    return tuple((tuple(round(v, 4) for v in p.co),
                  tuple(round(v, 4) for v in p.handle_left),
                  tuple(round(v, 4) for v in p.handle_right))
                 for sp in ob.subpaths for p in sp.points)


def _style_key(ob):
    """文字ごとの書式 (これが変わったら組み直す)。"""
    from . import data
    if not len(ob.text_styles):
        return ()
    return (tuple(data.line_styles(ob, i) for i in range(len(ob.text_lines))),
            tuple(data._key_of(st) for st in ob.text_styles))


def _key(ob, face):
    return (face.path, face.index, round(float(ob.font_size), 4),
            round(float(ob.line_spacing), 4), round(float(ob.tracking), 4),
            ob.text_align, ob.text_kind, bool(ob.text_vertical),
            round(float(ob.text_box[0]), 3), round(float(ob.text_box[1]), 3),
            round(float(ob.text_path_offset), 3), bool(ob.text_path_flip),
            ob.text_path_align, ob.text_box_align, _frame_key(ob), tuple(text_lines(ob)),
            _style_key(ob))


def layout(ob):
    """文字の組み上がり (ローカル座標)。フォントが無ければ None。"""
    face = face_of(ob)
    if face is None:
        return None
    key = _key(ob, face)
    got = _layout_cache.get(key)
    if got is not None:
        return got
    hbfont = fonts.hb_font(face)
    upem = hbfont.face.upem or 1000
    size = float(ob.font_size)
    track = float(ob.tracking) / 1000.0 * size      # 1/1000 em
    line_height = float(ob.line_spacing) * size
    a, d = font_metrics(hbfont, upem)
    asc, desc = a * size, d * size

    attrs = [char_attr_list(ob, i, face) for i in range(max(len(ob.text_lines), 1))]

    if ob.text_kind == 'PATH':
        lay = _layout_path(ob, attrs, face, size, track, line_height, asc, desc)
    elif (ob.text_kind == 'AREA' and not ob.text_vertical and _has_shape_frame(ob)):
        # 形の中に流し込む (丸や自由な形)
        lay = _layout_shape_area(ob, attrs, face, size, track, line_height, asc, desc)
        if ob.text_box_align != 'TOP' and not lay.overflow and lay.lines:
            # 余った高さの分だけ下げて組み直す (中央・下ぞろえ)
            extra = max(lay.bottom - lay.floor, 0.0)
            shift = extra / 2.0 if ob.text_box_align == 'CENTER' else extra
            if shift > 0.01:
                lay = _layout_shape_area(ob, attrs, face, size, track, line_height,
                                         asc, desc, shift)
    else:
        lay = _layout_lines(ob, attrs, face, size, track, line_height, asc, desc)
    lay.face = face
    lay.scale = size / upem
    if len(_layout_cache) > _CACHE_MAX:
        _layout_cache.clear()
    _layout_cache[key] = lay
    return lay


def _spans_at(polys, y):
    """折れ線の集まりを、高さ y で横に切ったときの区間 [(x0, x1), ...]。"""
    xs = []
    for poly, _closed in polys:
        n = len(poly)
        if n < 2:
            continue
        for i in range(n):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % n]
            if (y0 > y) != (y1 > y):
                t = (y - y0) / (y1 - y0)
                xs.append(x0 + (x1 - x0) * t)
    xs.sort()
    return [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]


def _intersect(a, b):
    out = []
    for x0, x1 in a:
        for y0, y1 in b:
            lo, hi = max(x0, y0), min(x1, y1)
            if hi - lo > 1e-6:
                out.append((lo, hi))
    return out


def _line_span(polys, base, asc, desc):
    """そのベースラインで、文字を置ける横の区間 (x0, x1)。置けなければ None。"""
    ys = (base + asc * 0.75, base + asc * 0.3, base - desc * 0.5)
    spans = None
    for y in ys:
        cur = _spans_at(polys, y)
        if not cur:
            return None
        spans = cur if spans is None else _intersect(spans, cur)
        if not spans:
            return None
    return max(spans, key=lambda s: s[1] - s[0])


def _layout_shape_area(ob, attrs_by_line, face, size, track, line_height,
                       asc, desc, shift=0.0):
    """形 (丸や自由なパス) の中に文字を流し込む。
    shift は「上からどれだけ下げて始めるか」(枠の中の位置合わせに使う)。"""
    from . import geometry as G
    subs = frame_subpaths(ob)
    polys = G.polylines(subs)
    b = G.bounds_in_frame(polys)
    if b is None:
        return Layout([], line_height, asc, desc, False, False)
    align = ob.text_align
    source = text_lines(ob)
    lines = []
    cur, col = 0, 0
    i = 0
    base = b[3] - asc - shift
    guard = 0
    while cur < len(source) and guard < 2000:
        guard += 1
        if base - desc < b[1]:
            break
        span = _line_span(polys, base, asc, desc)
        if span is None or (span[1] - span[0]) < size * 0.9:
            base -= line_height
            i += 1
            continue
        s = source[cur][col:]
        if s == "":
            cur += 1
            col = 0
            continue
        width = span[1] - span[0]
        at = (attrs_by_line[cur] if cur < len(attrs_by_line) else [base_attr(face, size, track)])
        at = _slice_attrs(at, col, len(s))
        seg = _wrap(at, s, False, width)[0][1]
        glyphs, pos, extent = _compose(_slice_attrs(at, 0, len(seg)), seg, False)
        x0 = span[0]
        if align == 'CENTER':
            x0 = span[0] + (width - extent) / 2.0
        elif align == 'RIGHT':
            x0 = span[1] - extent
        gl = [(f, g, x + x0, y + base, u, 0.0) for f, g, x, y, u in glyphs]
        car = [(x0 + q, base, 0.0) for q in pos]
        lines.append(Line(cur, col, seg, gl, car, extent))
        col += len(seg)
        if col >= len(source[cur]):
            cur += 1
            col = 0
        base -= line_height
        i += 1
    overflow = cur < len(source)
    lay = Layout(lines, line_height, asc, desc, False, overflow)
    lay.bottom = (lines[-1].carets[0][1] - desc) if lines else b[1]
    lay.top = b[3]
    lay.floor = b[1]
    return lay


def _has_shape_frame(ob):
    return bool(len(ob.subpaths) and len(ob.subpaths[0].points) >= 3)


def _slice_attrs(attrs, start, n):
    """attrs の一部 (空にならないようにする)。"""
    out = attrs[start:start + n]
    return out or attrs[-1:] or [(None, 0.0, 0.0, 0.0, 1.0, 1.0)]


def _seg_metrics(attrs, base_asc, base_desc, base_size, spacing=1.0):
    """その区間の (上への高さ, 下への深さ, 行送り)。
    いちばん大きい文字に合わせるので、大きい字を混ぜても行が重ならない。"""
    if not attrs or attrs[0][0] is None:
        return base_asc, base_desc, max(spacing * base_size, 1e-6)
    asc = desc = big = 0.0
    seen = {}
    for at in attrs:
        face, size, _tr, _kern, _sx, sy = _unpack(at)
        k = (face.key, round(size, 4), round(sy, 4))
        m = seen.get(k)
        if m is None:
            hb = fonts.hb_font(face)
            a, d = font_metrics(hb, hb.face.upem or 1000)
            m = (a * size * sy, d * size * sy)        # 縦の比率で高さも変わる
            seen[k] = m
        asc = max(asc, m[0])
        desc = max(desc, m[1])
        big = max(big, size * sy)
    return asc, desc, max(spacing * big, 1e-6)


def char_attr_list(ob, i, base_face):
    """i 行目の1文字ずつの書式 (base_attr の形)。文字ごとの書式を反映する。
    字間・カーニングは 1/1000 em (Illustrator と同じ単位) から px に直す。"""
    from . import data
    text = ob.text_lines[i].text if i < len(ob.text_lines) else ""
    base_size = float(ob.font_size)
    base = base_attr(base_face, base_size, float(ob.tracking) / 1000.0 * base_size)
    if not text:
        return [base]
    if not len(ob.text_styles) or set(data.line_styles(ob, i)) <= {"0"}:
        return [base] * len(text)          # この行に書式は付いていない (ふつうの場合)
    out, cache = [], {}
    for col in range(len(text)):
        if data.char_style(ob, i, col) is None:
            out.append(base)
            continue
        fam, sty, size, tr, kern, sx, sy = data.char_attrs_full(ob, i, col)
        k = (fam, sty, round(size, 4), round(tr, 4), round(kern, 4), round(sx, 4), round(sy, 4))
        v = cache.get(k)
        if v is None:
            f = fonts.find(fam, sty) if fam else None
            v = (f or base_face, size, tr / 1000.0 * size, kern / 1000.0 * size,
                 sx / 100.0, sy / 100.0)
            cache[k] = v
        out.append(v)
    return out


def _layout_lines(ob, attrs_by_line, face, size, track, line_height, asc, desc):
    """点文字とエリア文字の組み。

    文字ごとに大きさを変えられるので、行の高さ・上下の余白は**行ごとに**求める
    (その行でいちばん大きい文字に合わせる)。全部同じ大きさなら今までと同じ結果になる。
    """
    vertical = bool(ob.text_vertical)
    area = ob.text_kind == 'AREA'
    bw, bh = float(ob.text_box[0]), float(ob.text_box[1])
    limit = (bh if vertical else bw) if area else 0.0
    align = ob.text_align
    spacing = float(ob.line_spacing)

    # 折り返して「表示する行」に分ける
    segs = []
    for i, s in enumerate(text_lines(ob)):
        at = attrs_by_line[i] if i < len(attrs_by_line) else [base_attr(face, size, track)]
        for start, seg in _wrap(at, s, vertical, limit if area else 0.0):
            segs.append((i, start, seg, _slice_attrs(at, start, len(seg))))

    # 行ごとの (上への高さ, 下への深さ, 行送り)
    met = [_seg_metrics(at, asc, desc, size, spacing) for _s, _st, _sg, at in segs]

    # 枠に入る行数
    overflow = False
    if area and segs:
        room = bw if vertical else bh
        keep = 1
        for n in range(1, len(segs) + 1):
            adv = [max(met[k][2], met[k - 1][1] + met[k][0]) for k in range(1, n)]
            if vertical:
                need = met[0][2] + sum(adv)
            else:
                need = met[0][0] + sum(adv) + met[n - 1][1]
            if need <= room or n == 1:
                keep = n
            else:
                break
        if keep < len(segs):
            segs, met = segs[:keep], met[:keep]
            overflow = True

    # 枠の中のどこに寄せるか (上/中央/下。縦書きでは 右/中央/左)
    shift = 0.0
    if area and segs:
        adv = [max(met[k][2], met[k - 1][1] + met[k][0]) for k in range(1, len(met))]
        if vertical:
            used, room = met[0][2] + sum(adv), bw
        else:
            used, room = met[0][0] + sum(adv) + met[-1][1], bh
        extra = max(room - used, 0.0)
        if ob.text_box_align == 'CENTER':
            shift = extra / 2.0
        elif ob.text_box_align == 'BOTTOM':
            shift = extra

    lines = []
    off = 0.0                       # 1行目から何だけ下 (縦書きでは左) へ進んだか
    for i, (src, start, seg, at) in enumerate(segs):
        a_i, d_i, lh_i = met[i]
        if i > 0:
            # 前の行の「下への深さ」と この行の「上への高さ」がぶつからない分は必ず空ける
            # (大きい文字を混ぜても行が重ならないようにするため)
            off += max(lh_i, met[i - 1][1] + a_i)
        glyphs, pos, extent = _compose(at, seg, vertical)
        if vertical:
            # 縦書き: 行は右から左へ。x は行の中心
            cx = (bw - shift - (off + lh_i / 2.0)) if area else (-off)
            room = bh if area else 0.0
            if area:
                t0 = 0.0 if align == 'LEFT' else (
                    (room - extent) / 2.0 if align == 'CENTER' else room - extent)
            else:
                t0 = 0.0 if align == 'LEFT' else (
                    extent / 2.0 if align == 'CENTER' else extent)
            gl = [(f, g, cx + x, y - t0, u, 0.0) for f, g, x, y, u in glyphs]
            car = [(cx, -t0 - p, 0.0) for p in pos]
        else:
            base = (-met[0][0] - shift - off) if area else (-off)
            if area:
                x0 = 0.0 if align == 'LEFT' else (
                    (bw - extent) / 2.0 if align == 'CENTER' else bw - extent)
            else:
                x0 = 0.0 if align == 'LEFT' else (
                    -extent / 2.0 if align == 'CENTER' else -extent)
            gl = [(f, g, x + x0, y + base, u, 0.0) for f, g, x, y, u in glyphs]
            car = [(x0 + p, base, 0.0) for p in pos]
        lines.append(Line(src, start, seg, gl, car, extent, a_i, d_i))
    return Layout(lines, line_height, asc, desc, vertical, overflow)


# -----------------------------------------------------------------------------
# パス上の文字
# -----------------------------------------------------------------------------

def _polyline(ob):
    """パス上文字のパス (ローカル座標の折れ線と、累積の長さ)。"""
    from . import geometry as G
    subs = frame_subpaths(ob)
    if not subs:
        return None, None
    pts, closed = subs[0]
    poly = G.flatten_t(pts, closed)
    if closed and len(poly) > 1:
        poly = np.vstack([poly, poly[:1]])
    if len(poly) < 2:
        return None, None
    seg = np.linalg.norm(np.diff(poly, axis=0), axis=1)
    cum = np.concatenate([[0.0], np.cumsum(seg)])
    return poly, cum


def _point_at(poly, cum, d):
    """パスに沿って距離 d の位置と、その場所の傾き。"""
    total = float(cum[-1])
    d = min(max(d, 0.0), total)
    i = int(np.searchsorted(cum, d, side='right') - 1)
    i = min(max(i, 0), len(poly) - 2)
    seg = float(cum[i + 1] - cum[i])
    t = 0.0 if seg <= 1e-9 else (d - float(cum[i])) / seg
    p = poly[i] + (poly[i + 1] - poly[i]) * t
    v = poly[i + 1] - poly[i]
    return (float(p[0]), float(p[1])), math.atan2(float(v[1]), float(v[0]))


def _baseline_shift(ob, asc, desc):
    kind = ob.text_path_align
    if kind == 'CENTER':
        return -(asc - desc) / 2.0
    if kind == 'TOP':
        return -asc
    if kind == 'BOTTOM':
        return desc
    return 0.0


def _layout_path(ob, attrs_by_line, face, size, track, line_height, asc, desc):
    """パス上の文字 (1行として、パスに沿って並べる)。"""
    poly, cum = _polyline(ob)
    s = "".join(text_lines(ob))
    if poly is None or not s:
        return Layout([], line_height, asc, desc, False, False)
    total = float(cum[-1])
    at = attrs_by_line[0] if attrs_by_line else [base_attr(face, size, track)]
    glyphs, pos, extent = _compose(_slice_attrs(at, 0, len(s)), s, False)
    if ob.text_align == 'CENTER':
        d0 = (total - extent) / 2.0
    elif ob.text_align == 'RIGHT':
        d0 = total - extent
    else:
        d0 = 0.0
    d0 += float(ob.text_path_offset)
    flip = bool(ob.text_path_flip)
    shift = _baseline_shift(ob, asc, desc)

    def place(d, local_x, local_y):
        """パス上の距離 d に、そこを原点とする (local_x, local_y) を置く。"""
        dd = (total - d) if flip else d
        p, ang = _point_at(poly, cum, dd)
        if flip:
            ang += math.pi
        c, sn = math.cos(ang), math.sin(ang)
        return (p[0] + c * local_x - sn * local_y,
                p[1] + sn * local_x + c * local_y), ang

    out = []
    xs = [g[2] for g in glyphs]
    for i, (f, gid, gx, gy, unit) in enumerate(glyphs):
        adv = (xs[i + 1] - gx) if i + 1 < len(xs) else max(extent - gx, 0.0)
        mid = d0 + gx + adv / 2.0
        (px, py), ang = place(mid, -adv / 2.0, gy + shift)
        out.append((f, gid, px, py, unit, ang))
    car = []
    for p in pos:
        (px, py), ang = place(d0 + p, 0.0, shift)
        car.append((px, py, ang))
    lines = [Line(0, 0, s, out, car, extent)]
    return Layout(lines, line_height, asc, desc, False, extent > total + 1e-6)


# -----------------------------------------------------------------------------
# ローカル座標 <-> 画像座標
# -----------------------------------------------------------------------------

def matrix(ob):
    """ローカル座標 -> 画像座標 の行列 (3x3)。"""
    a, b, c, d = (float(v) for v in ob.text_mat)
    tx, ty = (float(v) for v in ob.text_origin)
    return np.array([[a, c, tx], [b, d, ty], [0.0, 0.0, 1.0]])


def set_matrix(ob, m):
    ob.text_mat = (m[0, 0], m[1, 0], m[0, 1], m[1, 1])
    ob.text_origin = (m[0, 2], m[1, 2])


def local_subpaths(ob):
    lay = layout(ob)
    return [] if lay is None else lay.subpaths()


def to_image(ob, subs):
    """ローカル座標のサブパスを画像座標に直す。"""
    from . import geometry as G
    m = matrix(ob)
    return [(G.transform_points(pts, m), closed) for pts, closed in subs]


def text_subpaths(ob):
    """文字の形を、パスと同じ [(点列, closed), ...] で返す (画像座標)。"""
    lay = layout(ob)
    if lay is None:
        return []
    m = matrix(ob)
    L = np.array([[m[0, 0], m[0, 1]], [m[1, 0], m[1, 1]]], np.float64)
    tx, ty = m[0, 2], m[1, 2]
    out = []
    for ln in lay.lines:
        for face, gid, x, y, unit, ang in ln.glyphs:
            a = np.cos(ang), np.sin(ang)
            for arr, closed in glyph_contours(face, gid):
                q = arr * np.asarray(unit, np.float64)
                if ang:
                    R = np.array([[a[0], -a[1]], [a[1], a[0]]], np.float64)
                    q = q @ R.T
                p = (q + (x, y)) @ L.T + (tx, ty)
                out.append(([(tuple(v[0]), tuple(v[1]), tuple(v[2])) for v in p], closed))
    return out


def char_subpaths(ob):
    """1文字ずつの形 (画像座標)。アウトライン化に使う。
    戻り値: [(文字, [(点列, closed), ...]), ...]"""
    lay = layout(ob)
    if lay is None:
        return []
    out = []
    for ln in lay.lines:
        for i, g in enumerate(ln.glyphs):
            subs = glyph_subpaths(g)
            if not subs:
                continue
            ch = ln.text[i] if i < len(ln.text) else ""
            out.append((ch, to_image(ob, subs)))
    return out


def frame_image_subpaths(ob):
    """枠・パスの形 (画像座標)。表示用。"""
    return to_image(ob, frame_subpaths(ob))


def overflowing(ob):
    lay = layout(ob)
    return bool(lay is not None and lay.overflow)


# -----------------------------------------------------------------------------
# カーソル (キャンバスで直接入力するときの位置)
# -----------------------------------------------------------------------------

def clamp_caret(ob, line, col):
    texts = text_lines(ob)
    line = max(0, min(int(line), len(texts) - 1))
    col = max(0, min(int(col), len(texts[line])))
    return line, col


def _find_line(lay, line, col):
    """元の (行, 文字数) が、表示上のどの行のどこに当たるか。"""
    cands = [ln for ln in lay.lines if ln.src_line == line]
    if not cands:
        return None, 0
    for ln in cands:
        if ln.start <= col < ln.end():
            return ln, col - ln.start
    last = cands[-1]
    return last, min(max(col - last.start, 0), len(last.text))


def _caret_local(lay, ln, c):
    """その行の c 文字目のカーソルの線 (ローカル座標の 2 点)。
    行ごとに文字の大きさが違うことがあるので、その行の高さを使う。"""
    x, y, ang = ln.carets[min(c, len(ln.carets) - 1)]
    asc = ln.asc if ln.asc is not None else lay.ascent
    desc = ln.desc if ln.desc is not None else lay.descent
    if lay.vertical:
        half = asc * 0.6
        a, b = (x - half, y), (x + half, y)
    else:
        a, b = (x, y - desc * 0.35), (x, y + asc * 0.95)
    if ang:
        c_, s_ = math.cos(ang), math.sin(ang)

        def rot(p):
            dx, dy = p[0] - x, p[1] - y
            return (x + c_ * dx - s_ * dy, y + s_ * dx + c_ * dy)
        a, b = rot(a), rot(b)
    return a, b


def caret_segment(ob, line, col):
    """カーソルの線 (画像座標の 2 点)。フォントが無ければ None。"""
    lay = layout(ob)
    if lay is None:
        return None
    line, col = clamp_caret(ob, line, col)
    ln, c = _find_line(lay, line, col)
    if ln is None:
        return None
    from . import geometry as G
    a, b = _caret_local(lay, ln, c)
    m = matrix(ob)
    return (G.apply(m, a), G.apply(m, b))


def selection_quads(ob, start, end):
    """選んでいる範囲を塗りつぶすための四角形の一覧 (画像座標、1文字に1つ)。

    1文字ずつ作るので、縦書きでもパス上文字 (字ごとに傾く) でも正しい形になる。
    """
    lay = layout(ob)
    if lay is None or not lay.lines:
        return []
    (l0, c0), (l1, c1) = sorted([clamp_caret(ob, *start), clamp_caret(ob, *end)])
    if (l0, c0) == (l1, c1):
        return []
    from . import geometry as G
    m = matrix(ob)
    out = []
    for ln in lay.lines:
        if ln.src_line < l0 or ln.src_line > l1:
            continue
        lo = c0 if ln.src_line == l0 else ln.start
        hi = c1 if ln.src_line == l1 else ln.end()
        lo = max(lo, ln.start)
        hi = min(hi, ln.end())
        for col in range(lo, hi):
            c = col - ln.start
            a0, b0 = _caret_local(lay, ln, c)
            a1, b1 = _caret_local(lay, ln, c + 1)
            out.append([tuple(G.apply(m, q)) for q in (a0, b0, b1, a1)])
    return out


WORD_BREAK = set(" \t\u3000、。，．,.!?！？「」『』（）()[]{}:;：；/\\|=+*&^%$#@~")


def word_range(ob, line, col):
    """その場所にある「ひとつながりの文字」の範囲 (始まり, 終わり)。"""
    texts = text_lines(ob)
    line = max(0, min(int(line), len(texts) - 1))
    s = texts[line]
    if not s:
        return (0, 0)
    col = max(0, min(int(col), len(s)))
    i = min(col, len(s) - 1)
    if s[i] in WORD_BREAK:                 # 区切りの上なら、その1字だけ
        return (i, i + 1)
    a = i
    while a > 0 and s[a - 1] not in WORD_BREAK:
        a -= 1
    b = i
    while b < len(s) and s[b] not in WORD_BREAK:
        b += 1
    return (a, b)


def index_at(ob, point):
    """画像座標の点に一番近い文字の位置 (元の行, 文字数)。"""
    lay = layout(ob)
    if lay is None or not lay.lines:
        return (0, 0)
    m = matrix(ob)
    try:
        inv = np.linalg.inv(m)
    except Exception:
        return (0, 0)
    from . import geometry as G
    p = G.apply(inv, point)
    best = None
    for ln in lay.lines:
        for c, (cx, cy, _ang) in enumerate(ln.carets):
            d = (cx - p[0]) ** 2 + (cy - p[1]) ** 2
            if best is None or d < best[0]:
                best = (d, ln.src_line, ln.start + c)
    return (best[1], best[2]) if best else (0, 0)


def bounds(ob):
    """文字全体の範囲 (画像座標)。空なら None。"""
    from . import geometry as G
    subs = text_subpaths(ob)
    if not subs:
        return None
    return G.bounds_in_frame(G.polylines(subs))


def clear_cache():
    _glyph_cache.clear()
    _layout_cache.clear()
    _fallback_cache.clear()


def angle_of(ob):
    """文字の傾き (選択枠の角度に使う)。"""
    a, b = float(ob.text_mat[0]), float(ob.text_mat[1])
    return math.atan2(b, a) if abs(a) + abs(b) > 1e-12 else 0.0

# SPDX-License-Identifier: GPL-3.0-or-later
"""ベクター編集中のキャンバスに、アクティブなメッシュの UV の線を重ねて描く。

2026-09-25 ユーザー報告「このアドオンで編集を始めると UV の線がなくなる」。
Blender のイメージエディターは、ペイントモードではアクティブなメッシュの UV を出すが、
表示モードではメッシュを編集モードにしているときしか出さない。ベクター編集は表示モードで
行うので (edit_tool)、そのぶんをこちらで描く。

- 出すのは、表示モードでベクター編集のキャンバスを見ているとき。ヘッダーの UV ボタンと、
  Blender のオーバーレイのオン/オフに従う
- メッシュが編集モードのときは Blender が描くので描かない (二重にしない)
- 線は UV の座標 (0〜1) のまま GPU に渡しておき、描くたびに画面の拡大・移動を行列でかける
  (大きなメッシュでも、描くたびに座標を計算し直さない)
"""

import bpy
import numpy as np
from bpy.app.handlers import persistent

_cache = {"key": None, "segs": None, "batch": None}

EDGE_DARK = (0.0, 0.0, 0.0, 0.45)
EDGE_LIGHT = (1.0, 1.0, 1.0, 0.75)


def uv_segments(me):
    """メッシュの UV の辺を、線分の端点の並び (2N, 2) にする (重なる辺は1本に)。"""
    uvl = me.uv_layers.active
    n = len(me.loops)
    if uvl is None or n == 0 or len(me.polygons) == 0:
        return None
    uv = np.empty(n * 2, np.float32)
    uvl.uv.foreach_get("vector", uv)
    uv = uv.reshape(n, 2)
    starts = np.empty(len(me.polygons), np.int64)
    totals = np.empty(len(me.polygons), np.int64)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    idx = np.arange(n)
    poly = np.repeat(np.arange(len(starts)), totals)
    nxt = idx + 1
    last = nxt == (starts + totals)[poly]
    nxt[last] = starts[poly][last]                 # 面の最後の点は最初の点へつなぐ
    a, b = uv[idx], uv[nxt]
    # 向きをそろえて、となりの面と共有する辺を1本にする (半透明の線が濃くならないように)
    swap = (a[:, 0] > b[:, 0]) | ((a[:, 0] == b[:, 0]) & (a[:, 1] > b[:, 1]))
    a2 = np.where(swap[:, None], b, a)
    b2 = np.where(swap[:, None], a, b)
    segs = np.unique(np.round(np.hstack([a2, b2]), 6), axis=0)
    return segs.reshape(-1, 2).astype(np.float32)


def _mesh_object():
    try:
        ob = bpy.context.view_layer.objects.active
    except Exception:
        return None
    if ob is None or ob.type != 'MESH' or ob.mode == 'EDIT':
        return None
    return ob


def _batch(shader, me):
    key = (me.name, len(me.loops), len(me.polygons),
           getattr(me.uv_layers.active, "name", ""))
    if _cache["key"] != key:
        from gpu_extras.batch import batch_for_shader
        segs = uv_segments(me)
        _cache["key"] = key
        _cache["segs"] = segs
        _cache["batch"] = None
        if segs is not None and len(segs):
            pos = np.zeros((len(segs), 3), np.float32)
            pos[:, :2] = segs
            _cache["batch"] = batch_for_shader(shader, 'LINES', {"pos": pos})
    return _cache["batch"]


def should_draw(space):
    img = getattr(space, "image", None)
    if img is None or not img.vstroke.enabled or getattr(space, "ui_mode", "") != 'VIEW':
        return False
    try:
        if not space.overlay.show_overlays:
            return False
        return bool(bpy.context.window_manager.vstroke_tool.show_uv)
    except Exception:
        return False


def draw(space, region, u=1.0):
    """UV の線を描く。描いたら True。"""
    if not should_draw(space):
        return False
    ob = _mesh_object()
    if ob is None:
        return False
    import gpu
    sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch = _batch(sh, ob.data)
    if batch is None:
        return False
    ox, oy = region.view2d.view_to_region(0.0, 0.0, clip=False)
    ex, ey = region.view2d.view_to_region(1.0, 1.0, clip=False)
    gpu.state.blend_set('ALPHA')
    with gpu.matrix.push_pop():
        gpu.matrix.translate((float(ox), float(oy)))
        gpu.matrix.scale((float(ex - ox), float(ey - oy)))
        sh.bind()
        sh.uniform_float("viewportSize", (float(region.width), float(region.height)))
        for col, width in ((EDGE_DARK, 2.5 * u), (EDGE_LIGHT, 1.0 * u)):
            sh.uniform_float("lineWidth", width)
            sh.uniform_float("color", col)
            batch.draw(sh)
    gpu.state.blend_set('NONE')
    return True


@persistent
def _on_depsgraph(scene, depsgraph):
    """メッシュが変わったら作り直す (UV を編集したあとなど)。"""
    try:
        for up in depsgraph.updates:
            if isinstance(up.id, bpy.types.Mesh) or (
                    isinstance(up.id, bpy.types.Object) and up.is_updated_geometry):
                _cache["key"] = None
                return
    except Exception:
        _cache["key"] = None


def register():
    if _on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)


def unregister():
    if _on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph)
    _cache.update(key=None, segs=None, batch=None)

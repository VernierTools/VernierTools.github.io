# SPDX-License-Identifier: GPL-3.0-or-later
"""ツールとモードの切り替えを、ここだけで受け持つ (v0.23.0)。

**なぜ作り直したか**
それまでは「ツールが変わった」を3か所がそれぞれ見張っていた:
  1. 上のバー (ツール設定) が描かれたこと      -> tools._draw_tool_settings
  2. キャンバスが描かれたこと                  -> tools.notice_brush_selected
  3. 0.3 秒ごとの見張り                        -> tools.watch_paint
どれも「描かれたかどうか」「時間」に頼るので、上のバーを閉じていると届かない、
自分で変えた分にも反応して往復する、といった不具合が出た。同じ種類の不具合を
v0.21.4 / v0.21.5 / v0.22.1 / v0.22.2 と4回直したのはそのため。

**ここでの決まり (これを崩さないこと)**
- 「ツールが変わった」の合図は **msgbus 1本だけ**。上のバーを閉じていても届く
- 合図が来たら、少しあと (次のタイマー) に `settle()` が**今の実際の状態を読んで**決める。
  msgbus は値が確定する前に呼ばれるので、その場で読んではいけない (実測で確認)
- 自分で変えている間は `applying()` を立てる。ただし **msgbus の通知は遅れて届く**ので、
  これだけでは自分の変更を取りこぼす (実測で確認)。そこで判断は**時間ではなく状態**で行う:
  ペイントに入っても、筆を選び終える (`state.paint["ready"]`) までは「ベクターのツールが
  選ばれている」と見なさない。これが「入った直後 0.7 秒は無視」の置き換え
- 切り替えるかどうかの判断は `settle()` の中だけに書く。他の場所に足さないこと
"""

import contextlib

import bpy

from . import state

# msgbus の持ち主 (購読を解除するときの目印)
_owner = object()
_applying = {"depth": 0}
_pending = {"on": False}


# -----------------------------------------------------------------------------
# 自分の変更に反応しないための囲い
# -----------------------------------------------------------------------------

@contextlib.contextmanager
def applying():
    """この中でツールやモードを変えても、切り替えの判断をやり直さない。"""
    _applying["depth"] += 1
    try:
        yield
    finally:
        _applying["depth"] -= 1


def is_applying():
    return _applying["depth"] > 0


# -----------------------------------------------------------------------------
# 合図 (msgbus) と、その少しあとの見直し
# -----------------------------------------------------------------------------

def _notify():
    """ツールが変わった。値はまだ確定していないので、ここでは読まない。

    自分の変更の最中でも**合図を捨てない**。以前は捨てていたが、そこにユーザーの
    クリックが重なるとクリックが消えた。settle() は状態を読んで決めるので、
    自分の変更で余分に呼ばれても結果は変わらない。"""
    _schedule()


def _schedule():
    if _pending["on"]:
        return
    _pending["on"] = True
    try:
        bpy.app.timers.register(_settle_timer, first_interval=0.01)
    except Exception:
        _pending["on"] = False


def _settle_timer():
    _pending["on"] = False
    try:
        settle()
    except Exception as e:
        print("[Vector Strokes] ツールの切り替えに失敗:", e)
    return None


def subscribe():
    """「ツールが変わったら教えて」を Blender に頼む。"""
    if bpy.app.background:
        return
    unsubscribe()
    try:
        bpy.msgbus.subscribe_rna(key=(bpy.types.WorkSpace, "tools"), owner=_owner,
                                 args=(), notify=_notify)
    except Exception as e:
        print("[Vector Strokes] ツールの変更を受け取れません:", e)
    try:
        # ヘッダーの「表示 / ペイント」の切り替えも同じ合図で受ける (v0.30.1)。
        # ツールの一覧はモードごとに別なので、モードを変えてもツールの合図は来ない
        bpy.msgbus.subscribe_rna(key=(bpy.types.SpaceImageEditor, "ui_mode"), owner=_owner,
                                 args=(), notify=_notify)
    except Exception as e:
        print("[Vector Strokes] モードの変更を受け取れません:", e)


def unsubscribe():
    try:
        bpy.msgbus.clear_by_owner(_owner)
    except Exception:
        pass


# -----------------------------------------------------------------------------
# 今の状態を読む
# -----------------------------------------------------------------------------

def area_showing(check):
    """条件に合う画像を表示しているイメージエディターを探す。"""
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                img = getattr(area.spaces.active, "image", None)
                if img is not None and check(img):
                    return win, area
    except Exception:
        pass
    return None, None


def painting_area():
    """いまブラシで描いているレイヤーを表示しているエリア。"""
    return area_showing(lambda im: bool(im.vstroke.paint_owner))


def vector_area():
    """ベクター編集を有効にした画像を表示しているエリア。"""
    return area_showing(lambda im: im.vstroke.enabled)


def window_region(area):
    for r in area.regions:
        if r.type == 'WINDOW':
            return r
    return None


def active_tool_id(context, mode):
    try:
        t = context.workspace.tools.from_space_image_mode(mode, create=False)
        return t.idname if t is not None else ""
    except Exception:
        return ""


def set_tool(window, area, tool_id):
    """ツールを選び直す (自分の変更なので、切り替えの判断はやり直さない)。"""
    if window is None or area is None:
        return False
    with applying():
        try:
            with bpy.context.temp_override(window=window, area=area,
                                           region=window_region(area)):
                bpy.ops.wm.tool_set_by_id(name=tool_id, space_type='IMAGE_EDITOR')
            return True
        except Exception as e:
            print("[Vector Strokes] ツールを切り替えられませんでした:", tool_id, e)
            return False


# -----------------------------------------------------------------------------
# 切り替えの判断 (ここだけに書く)
# -----------------------------------------------------------------------------

def settle():
    """今の実際のツールを見て、必要ならペイントに入る / ペイントから戻る。"""
    from . import tools
    if is_applying():
        return
    if state.paint:
        _settle_painting(tools)
    else:
        _settle_vector(tools)


def paint_should_leave():
    """ペイント中に、もうベクターに戻るべきか。戻り値: (戻るか, 戻った先で選ぶツールの ID)"""
    from . import tools
    win, area = painting_area()
    if area is None:
        return True, None               # 表示が変わった -> 後始末だけする
    if not (state.paint or {}).get("ready"):
        # まだ筆を選び終えていない。この間に見えている「ベクターのツール」は、
        # 入る前のツールが残っているだけなので、それで追い出さない
        return False, None
    mode = getattr(area.spaces.active, "ui_mode", 'PAINT')
    if mode != 'PAINT':
        # ヘッダーで「表示」に戻した -> ベクターに戻る (表示モードで選ばれているツールで)
        tid = active_tool_id(bpy.context, mode)
        return True, (tid if tid in tools.TOOL_NAMES else None)
    tid = active_tool_id(bpy.context, mode)
    if tid in tools.TOOL_NAMES and tools.TOOL_NAMES[tid] != 'BRUSH':
        return True, tid
    return False, None


def _settle_painting(tools):
    """ペイント中: ベクターのツールが選ばれていたら戻る。
    (ふつうは見張り役 (operators.VS_OT_paint_guard) が先に戻している。これは予備)"""
    leave, tid = paint_should_leave()
    if leave:
        leave_paint(tid)


def _settle_vector(tools):
    """ペイントしていない: ブラシが選ばれていたら / ヘッダーでペイントモードにしたら、
    ペイントに入る。"""
    win, area = _canvas_in_paint_mode()
    if area is not None:
        # ベクターのキャンバスがペイントモードになっている = ユーザーがヘッダーで切り替えた
        # (こちらはキャンバスをペイントモードのままにしない: 有効化・編集開始・ファイルを
        #  開いたときに表示モードにする)。キャンバスに直接描いても次の描き直しで消えるので、
        # ブラシのボタンと同じくペイントレイヤーに描く (2026-09-25 ユーザー報告
        # 「View から Paint に移るとツールが切り替わらないなど、挙動がおかしい」)
        enter_paint(win, area)
        return
    win, area = vector_area()
    if area is None and _brush_selected_somewhere(tools):
        # 開いたばかりの画像で、最初にブラシを押した。他のツールと同じく、表示している
        # 画像をここで有効にする (2026-09-25 ユーザー報告「一発目のブラシで何も起こらない」。
        # 他のツールはクリックで有効になるが、ブラシはクリックを受け取らないため漏れていた)
        win, area = _enable_shown_image(tools)
    if area is None:
        # ブラシが選ばれているのに、ベクター編集を有効にした画像が表示されていない。
        # このときボタンを押しても何も起きない (ユーザー報告「切り替わらない時がある」の
        # 原因候補)。黙って諦めず、何が見えていたかを残す
        if _brush_selected_somewhere(tools):
            _log_stuck()
        return
    # 表示モード・ペイントモードのどちらのツールバーで押しても入る
    # (モードごとにツールの一覧が別。今のモードの方しか見ていなかったため、
    #  キャンバスがペイントモードになっていると反応しなかった)
    if _brush_selected_somewhere(tools):
        enter_paint(win, area)


def _canvas_in_paint_mode():
    """ペイントモードになっている、ベクター編集のキャンバス (描いているレイヤーではない。
    描いているレイヤーの画像は有効化されていないので、ここには当たらない)。"""
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                sp = area.spaces.active
                img = getattr(sp, "image", None)
                if (img is not None and img.vstroke.enabled
                        and getattr(sp, "ui_mode", 'VIEW') == 'PAINT'):
                    return win, area
    except Exception:
        pass
    return None, None


def canvases_to_view_mode():
    """ペイントモードで表示されているベクターのキャンバスを、表示モードにする
    (ファイルを開いたとき・有効化したとき。こちらはキャンバスをペイントモードにしておかない)。"""
    with applying():
        try:
            for win in bpy.context.window_manager.windows:
                for area in win.screen.areas:
                    sp = area.spaces.active if area.type == 'IMAGE_EDITOR' else None
                    img = getattr(sp, "image", None) if sp is not None else None
                    if (img is not None and img.vstroke.enabled
                            and getattr(sp, "ui_mode", 'VIEW') == 'PAINT'):
                        sp.ui_mode = 'VIEW'
        except Exception:
            pass


def _enable_shown_image(tools):
    """ブラシが選ばれているイメージエディターの画像を、ベクター編集にする。

    そのエディターで**いま見えているツールバー**がブラシのときだけ (前に押したブラシが
    別のモードの一覧に残っているだけのときは、勝手に有効にしない)。戻り値: (window, area)"""
    from . import operators
    found = []
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                sp = area.spaces.active
                img = getattr(sp, "image", None)
                if img is None or img.vstroke.enabled or operators.enable_problem(img, deep=False):
                    continue
                mode = getattr(sp, "ui_mode", 'VIEW')
                if active_tool_id(bpy.context, mode) != tools.TOOL_IDS['BRUSH']:
                    continue
                found.append((area.width * area.height, win, area, img))
    except Exception as e:
        print("[Vector Strokes] ブラシで始める画像を探せません:", e)
        return None, None
    if not found:
        return None, None
    _, win, area, img = max(found, key=lambda f: f[0])     # いちばん大きく出ているもの
    msg = operators.enable_image(img)
    if not img.vstroke.enabled:
        print("[Vector Strokes] ベクター編集を有効にできません:", img.name, msg, flush=True)
        return None, None
    push_undo(win, area, "Enable Vector Editing")       # ペンで始めたときと同じ段を積む
    return win, area


def _brush_selected_somewhere(tools):
    for mode in ('VIEW', 'PAINT'):
        if active_tool_id(bpy.context, mode) == tools.TOOL_IDS['BRUSH']:
            return True
    return False


def _log_stuck():
    """切り替えられなかったときの様子を出す (ターミナルから Blender を起動すると見える)。"""
    shown = []
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                im = getattr(area.spaces.active, "image", None)
                shown.append("%s(有効=%s, 描画中=%s)" % (
                    getattr(im, "name", "なし"),
                    getattr(getattr(im, "vstroke", None), "enabled", "?"),
                    bool(getattr(getattr(im, "vstroke", None), "paint_owner", ""))))
    except Exception:
        pass
    print("[Vector Strokes] ブラシに切り替えられません: "
          "ベクター編集中の画像が表示されていません。表示中 =", shown or "なし", flush=True)


# -----------------------------------------------------------------------------
# 出入り
# -----------------------------------------------------------------------------

def enter_paint(win=None, area=None):
    """ブラシで描き始める (無ければペイントレイヤーを作る)。"""
    if state.paint:
        # すでに描いている所でブラシを押した -> 筆に戻すだけ
        pwin, parea = painting_area()
        if parea is not None:
            set_tool(pwin, parea, "builtin.brush")
        return
    if area is None:
        win, area = vector_area()
    if area is None:
        return
    with applying():
        with bpy.context.temp_override(window=win, area=area, region=window_region(area)):
            bpy.ops.vstroke.paint_begin('EXEC_DEFAULT', create=True)
    # 筆を選び直す予約は paint_begin の中で済んでいる (on_paint_entered)


def on_paint_entered(win, area):
    """ペイントに入った直後の仕上げ (ツールバー・サイドバーのどちらから入っても共通)。

    ペイントモードのツールバーにも**こちらのベクターツールが並んでいる**ので、
    筆を明示的に選び直さないとクリックがベクター編集に取られる (実測で確認)。
    オペレーターの中ではモードの切り替えがまだツールに反映されないので、少しあとに選ぶ。
    """
    if win is None or area is None:
        return
    try:
        # 二重に予約しない (ツールバーから入ると enter_paint とオペレーターの両方から
        # 呼ばれ、「ペイントを始める」が Undo の履歴に2回積まれていた)
        if not bpy.app.timers.is_registered(_select_brush_soon):
            bpy.app.timers.register(_select_brush_soon, first_interval=0.02)
    except Exception:
        pass


def _select_brush_soon():
    win, area = painting_area()
    if area is not None:
        set_tool(win, area, "builtin.brush")
    if state.paint and not state.paint.get("ready"):
        # ここまで来たら、あとで見えるツールの変化は「ユーザーが選んだ」もの
        state.paint["ready"] = True
        # Undo の履歴に「ペイントを始めた」を積む。これが無いと、筆の1画を Undo したとき
        # Blender は「ペイントレイヤーを作る前」まで戻してしまい、表示中の画像が消えて
        # 「+新規 開く」になる (2026-09-22 ユーザー報告。履歴を出して確認)。
        # **筆を選び終えてから**積むこと: Undo は選んでいたツールも戻すので、先に積むと
        # Undo でベクターのツールに戻ってペイントから追い出される
        push_undo(win, area, "ペイントを始める")
    return None


# -----------------------------------------------------------------------------
# 見張り役 (ペイント中、入力を最初に受け取って、ツールの変化にその場で応じる)
# -----------------------------------------------------------------------------
# **なぜ要るか** (2026-10-05 ユーザー報告「クリップを作った直後に Undo するとおかしい・
# Redo されない。複雑な場面で起こる」)
# ツールの変化は msgbus -> タイマーで受けていた。Blender はたまっている入力をすべて
# 片付けてからタイマーを動かすので、重い場面では、選択ツールに戻したあとに押したキーが
# 「まだペイントモード」のまま処理されていた:
#   - A・⌘7 などはベクター編集が始まる前なので捨てられる (クリップが作られない)
#   - ⌘Z はペイントモードの Undo として筆の1画を戻す
#   - そのあと遅れて「描いた絵を確定」「ベクターに戻る」が積まれ、Redo の履歴が消える
# 見張り役は、ツールが変わったあとの最初の入力で、その場でベクターに戻る。
# 以後の入力は正しい順番で、ベクター編集が受け取る。

def guard_alive():
    try:
        for win in bpy.context.window_manager.windows:
            for op in win.modal_operators:
                if op.bl_idname == "VSTROKE_OT_paint_guard":
                    return True
    except Exception:
        pass
    return False


def start_guard(win=None, area=None):
    """ペイント中の見張り役を動かす (もう動いていれば何もしない)。"""
    if guard_alive() or not state.paint:
        return
    if area is None:
        win, area = painting_area()
    if area is None:
        return
    try:
        with bpy.context.temp_override(window=win, area=area, region=window_region(area)):
            bpy.ops.vstroke.paint_guard('INVOKE_DEFAULT')
    except Exception as e:
        print("[Vector Strokes] 見張り役を動かせません:", e)


def push_undo(win, area, message):
    """Undo の履歴に1段積む (ペイント中でも「全体の状態」の段になる。実測で確認)。"""
    if win is None or area is None:
        return
    with applying():
        try:
            with bpy.context.temp_override(window=win, area=area,
                                           region=window_region(area)):
                bpy.ops.ed.undo_push(message=message)
        except Exception as e:
            print("[Vector Strokes] Undo の履歴に積めません:", e)


def mark_ready():
    """筆を選ぶのを待たずに「もう判断してよい」印を付ける (テスト・画面の無い環境用)。"""
    if state.paint:
        state.paint["ready"] = True


def leave_paint(next_tool=None):
    """ペイントをやめてベクターに戻る。next_tool は戻った先で選ぶツールの ID。"""
    from . import operators, tools
    win, area = painting_area()
    if area is None:
        info = state.paint or {}
        im = bpy.data.images.get(info.get("layer", ""))
        if im is not None:
            operators.end_paint(im)
        return
    with applying():
        with bpy.context.temp_override(window=win, area=area, region=window_region(area)):
            bpy.ops.vstroke.paint_end('EXEC_DEFAULT', push=False)
    # 表示モード側のツールがブラシのままだと、すぐペイントに引き戻されてしまう
    # (Blender はモードごとに「選んでいるツール」を別々に覚えているため)
    wanted = next_tool or tools.TOOL_IDS['SELECT']
    if wanted == tools.TOOL_IDS['BRUSH']:
        wanted = tools.TOOL_IDS['SELECT']
    set_tool(win, area, wanted)
    push_undo(win, area, "ベクターに戻る")     # ツールを選び終えてから積む (上と同じ理由)
    start_editing(win, area, tools.TOOL_NAMES.get(wanted))


def start_editing(win, area, name):
    """ベクター編集をすぐ始める (キャンバスをクリックしなくても V / P などが効くように。
    2026-09-25 ユーザー報告「View モードに戻ってきてもショートカットが使えない」)。"""
    from . import edit_tool
    if name not in edit_tool.TOOL_CLASSES or state.paint:
        return
    try:
        with bpy.context.temp_override(window=win, area=area, region=window_region(area)):
            bpy.ops.vstroke.edit('INVOKE_DEFAULT', tool=name)
    except Exception as e:
        print("[Vector Strokes] ベクター編集を始められません:", e)


def recover_after_undo():
    """Undo / やり直しのあと、ペイントの状態と画面の表示を食い違わせない。

    Undo はデータ (画像やその印) を戻すが、画面の表示 (どの画像を出しているか・
    表示/ペイントのモード) は戻さない。ペイントを始める前まで戻ると、
    描いていたレイヤーの画像が無くなり、画面が「+新規 開く」になってしまう。
    そのときはキャンバスの表示に戻して、ペイントを終えた状態にする。"""
    from . import operators, tools
    info = state.paint
    if not info:
        _clear_stale_paint_marks(None)
        return
    layer = bpy.data.images.get(info.get("layer", ""))
    canvas = bpy.data.images.get(info.get("canvas", ""))
    still = (layer is not None and canvas is not None
             and layer.vstroke.paint_owner == canvas.name)
    if still:
        return                       # まだ描いている状態のまま。何もしない
    if canvas is not None and _follow_moved_paint(layer, canvas):
        return                       # 描いているレイヤーが変わっただけ (切り替えを戻した)
    # 描いていた状態ではなくなった -> キャンバスの表示に戻す
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                sp = area.spaces.active
                im = getattr(sp, "image", None)
                if im is None or (layer is not None and im == layer):
                    with applying():
                        if canvas is not None:
                            sp.image = canvas
                        try:
                            sp.ui_mode = 'VIEW'
                        except Exception:
                            pass
                        if active_tool_id(bpy.context, 'VIEW') == tools.TOOL_IDS['BRUSH']:
                            set_tool(win, area, tools.TOOL_IDS['SELECT'])
                    area.tag_redraw()
    except Exception as e:
        print("[Vector Strokes] Undo のあとの表示を戻せません:", e)
    operators.drop_backdrops()
    from . import alpha_tools
    alpha_tools.drop_lock()      # 描いていた状態ではない (レイヤーの絵は Undo で戻っている)
    state.paint = None
    _clear_stale_paint_marks(None)


def _follow_moved_paint(layer, canvas):
    """Undo / やり直しで「描いている」印が、同じキャンバスの別の画像に移っていたら、
    そちらに描く状態にして画面も合わせる (ペイント中の描く先の切り替えを戻したとき)。
    これが無いと、ペイントが終わったものとしてベクターに戻ってしまう (2026-09-26 に確認)。
    戻り値: 合わせたら True"""
    from . import alpha_tools, operators, paint_preview
    others = [im for im in bpy.data.images
              if im.vstroke.paint_owner == canvas.name and im != layer]
    if len(others) != 1:
        return False
    target = others[0]
    _, ob = operators.paint_target(target)
    if ob is None:
        return False
    mask = ob.mask_image == target
    if not mask and ob.image != target:
        return False
    operators.drop_backdrops()
    alpha_tools.drop_lock()
    state.paint = None
    paint_preview.drop()
    if not operators.begin_paint(canvas.vstroke, canvas, ob, mask=mask):
        return False
    state.paint["ready"] = True
    new_im = bpy.data.images.get(state.paint["layer"])
    with applying():
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                sp = area.spaces.active
                im = getattr(sp, "image", None)
                if im is None or (layer is not None and im == layer):
                    sp.image = new_im
                    area.tag_redraw()
    return True


def _clear_stale_paint_marks(keep):
    """描いていないのに「描いている」印が残っている画像から、印を外す
    (Undo で印だけが戻ってくることがある)。"""
    for im in bpy.data.images:
        try:
            if im.vstroke.paint_owner and im.name != keep:
                im.vstroke.paint_owner = ""
                im.vstroke.paint_uid = 0
        except Exception:
            pass


def check_still_painting():
    """ペイント中の画像が表示されなくなっていないか (常駐の見張りから呼ばれる)。
    ツールの変更は msgbus が知らせてくれるので、ここでは見ない。"""
    if state.paint and painting_area()[1] is None:
        leave_paint()


def register():
    subscribe()


def unregister():
    unsubscribe()
    for fn in (_settle_timer, _select_brush_soon):
        try:
            if bpy.app.timers.is_registered(fn):
                bpy.app.timers.unregister(fn)
        except Exception:
            pass
    _pending["on"] = False
    _applying["depth"] = 0

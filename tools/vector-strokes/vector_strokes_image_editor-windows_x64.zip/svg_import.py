# SPDX-License-Identifier: GPL-3.0-or-later
"""SVG を、編集できる形 (パス・グループ・画像) で読み込む (2026-09-22 ユーザー要望)。

Skia は SVG を「丸ごと1枚の絵」として描けるだけで、編集できる形には読めない。
パスの文字列 (円弧を含む) は fontTools の parse_path に任せ、それ以外はここで読む:
  - 要素: path / rect / circle / ellipse / line / polyline / polygon / g / svg / use / image
  - 見た目: 塗り・線 (色・太さ・端・角・破線・不透明度)、塗りの規則、不透明度、描画モード
  - 色の書き方: #rgb / #rrggbb / rgb() / rgba() / hsl() / hsla() / 色の名前 (CSS の 148 色) /
    currentColor / none
  - **<style> のクラス** (.st0{fill:#f00} など)。Illustrator が書き出す SVG は色をここに持つので、
    読まないと全部真っ黒になる
  - 変形 (transform)・viewBox・単位 (px / pt / mm / cm / in)
  - 線形・円形グラデーション、クリッピングパス・マスク (→ クリップグループ)、埋め込み画像
読まないもの (数を知らせる): 文字 (<text>)・フィルター・パターン。

置き方: SVG の左上をキャンバスの左上に合わせ、1 SVG 単位 = 1 ピクセル。
このアドオンで書き出した SVG は、同じ位置・大きさで戻る。読み込んだものは1つのグループにまとめる。
"""

import base64
import math
import os
import re
import xml.etree.ElementTree as ET

import numpy as np

from . import data, render

SVG_NS = "{http://www.w3.org/2000/svg}"
XLINK = "{http://www.w3.org/1999/xlink}href"

INHERITED = ("fill", "stroke", "stroke-width", "fill-rule", "fill-opacity", "stroke-opacity",
             "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-dasharray",
             "stroke-dashoffset", "color", "visibility")
OWN = ("opacity", "mix-blend-mode", "display", "clip-path", "mask", "filter",
       "stop-color", "stop-opacity")
STYLE_KEYS = INHERITED + OWN

# CSS の色の名前 (全 148 色)。0.36.8 までは約 70 色しかなく、表に無い名前
# (darkorange・slategray など) は黒になっていた
NAMED = {
    "aliceblue": "#f0f8ff", "antiquewhite": "#faebd7", "aqua": "#00ffff",
    "aquamarine": "#7fffd4", "azure": "#f0ffff", "beige": "#f5f5dc", "bisque": "#ffe4c4",
    "black": "#000000", "blanchedalmond": "#ffebcd", "blue": "#0000ff", "blueviolet": "#8a2be2",
    "brown": "#a52a2a", "burlywood": "#deb887", "cadetblue": "#5f9ea0", "chartreuse": "#7fff00",
    "chocolate": "#d2691e", "coral": "#ff7f50", "cornflowerblue": "#6495ed",
    "cornsilk": "#fff8dc", "crimson": "#dc143c", "cyan": "#00ffff", "darkblue": "#00008b",
    "darkcyan": "#008b8b", "darkgoldenrod": "#b8860b", "darkgray": "#a9a9a9",
    "darkgreen": "#006400", "darkgrey": "#a9a9a9", "darkkhaki": "#bdb76b",
    "darkmagenta": "#8b008b", "darkolivegreen": "#556b2f", "darkorange": "#ff8c00",
    "darkorchid": "#9932cc", "darkred": "#8b0000", "darksalmon": "#e9967a",
    "darkseagreen": "#8fbc8f", "darkslateblue": "#483d8b", "darkslategray": "#2f4f4f",
    "darkslategrey": "#2f4f4f", "darkturquoise": "#00ced1", "darkviolet": "#9400d3",
    "deeppink": "#ff1493", "deepskyblue": "#00bfff", "dimgray": "#696969", "dimgrey": "#696969",
    "dodgerblue": "#1e90ff", "firebrick": "#b22222", "floralwhite": "#fffaf0",
    "forestgreen": "#228b22", "fuchsia": "#ff00ff", "gainsboro": "#dcdcdc",
    "ghostwhite": "#f8f8ff", "gold": "#ffd700", "goldenrod": "#daa520", "gray": "#808080",
    "green": "#008000", "greenyellow": "#adff2f", "grey": "#808080", "honeydew": "#f0fff0",
    "hotpink": "#ff69b4", "indianred": "#cd5c5c", "indigo": "#4b0082", "ivory": "#fffff0",
    "khaki": "#f0e68c", "lavender": "#e6e6fa", "lavenderblush": "#fff0f5",
    "lawngreen": "#7cfc00", "lemonchiffon": "#fffacd", "lightblue": "#add8e6",
    "lightcoral": "#f08080", "lightcyan": "#e0ffff", "lightgoldenrodyellow": "#fafad2",
    "lightgray": "#d3d3d3", "lightgreen": "#90ee90", "lightgrey": "#d3d3d3",
    "lightpink": "#ffb6c1", "lightsalmon": "#ffa07a", "lightseagreen": "#20b2aa",
    "lightskyblue": "#87cefa", "lightslategray": "#778899", "lightslategrey": "#778899",
    "lightsteelblue": "#b0c4de", "lightyellow": "#ffffe0", "lime": "#00ff00",
    "limegreen": "#32cd32", "linen": "#faf0e6", "magenta": "#ff00ff", "maroon": "#800000",
    "mediumaquamarine": "#66cdaa", "mediumblue": "#0000cd", "mediumorchid": "#ba55d3",
    "mediumpurple": "#9370db", "mediumseagreen": "#3cb371", "mediumslateblue": "#7b68ee",
    "mediumspringgreen": "#00fa9a", "mediumturquoise": "#48d1cc", "mediumvioletred": "#c71585",
    "midnightblue": "#191970", "mintcream": "#f5fffa", "mistyrose": "#ffe4e1",
    "moccasin": "#ffe4b5", "navajowhite": "#ffdead", "navy": "#000080", "oldlace": "#fdf5e6",
    "olive": "#808000", "olivedrab": "#6b8e23", "orange": "#ffa500", "orangered": "#ff4500",
    "orchid": "#da70d6", "palegoldenrod": "#eee8aa", "palegreen": "#98fb98",
    "paleturquoise": "#afeeee", "palevioletred": "#db7093", "papayawhip": "#ffefd5",
    "peachpuff": "#ffdab9", "peru": "#cd853f", "pink": "#ffc0cb", "plum": "#dda0dd",
    "powderblue": "#b0e0e6", "purple": "#800080", "rebeccapurple": "#663399", "red": "#ff0000",
    "rosybrown": "#bc8f8f", "royalblue": "#4169e1", "saddlebrown": "#8b4513",
    "salmon": "#fa8072", "sandybrown": "#f4a460", "seagreen": "#2e8b57", "seashell": "#fff5ee",
    "sienna": "#a0522d", "silver": "#c0c0c0", "skyblue": "#87ceeb", "slateblue": "#6a5acd",
    "slategray": "#708090", "slategrey": "#708090", "snow": "#fffafa", "springgreen": "#00ff7f",
    "steelblue": "#4682b4", "tan": "#d2b48c", "teal": "#008080", "thistle": "#d8bfd8",
    "tomato": "#ff6347", "turquoise": "#40e0d0", "violet": "#ee82ee", "wheat": "#f5deb3",
    "white": "#ffffff", "whitesmoke": "#f5f5f5", "yellow": "#ffff00", "yellowgreen": "#9acd32", "transparent": "none",
}

UNITS = {"": 1.0, "px": 1.0, "pt": 96.0 / 72.0, "pc": 16.0, "mm": 96.0 / 25.4,
         "cm": 96.0 / 2.54, "in": 96.0}

CAPS = {"butt": 'BUTT', "round": 'ROUND', "square": 'SQUARE'}
JOINS = {"miter": 'MITER', "miter-clip": 'MITER', "arcs": 'ROUND', "round": 'ROUND',
         "bevel": 'BEVEL'}


def _tag(el):
    t = el.tag
    return t.split("}", 1)[1] if "}" in t else t


def _num(s, default=0.0):
    """長さ (単位付き可) を数にする。"""
    if s is None:
        return default
    m = re.match(r"\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)\s*([a-z%]*)", str(s))
    if not m:
        return default
    v = float(m.group(1))
    return v * UNITS.get(m.group(2), 1.0)


def _nums(s):
    return [float(v) for v in re.findall(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", s or "")]


# -----------------------------------------------------------------------------
# 色
# -----------------------------------------------------------------------------

def parse_color(s, current=(0.0, 0.0, 0.0, 1.0)):
    """色の文字列 -> (r, g, b, a) の sRGB 値。塗らないなら None。読めなければ黒。"""
    if s is None:
        return None
    s = s.strip()
    low = s.lower()
    if low in {"none", ""}:
        return None
    if low == "currentcolor":
        return current
    low = NAMED.get(low, low)
    if low == "none":
        return None
    if low.startswith("#"):
        h = low[1:]
        if len(h) in (3, 4):
            h = "".join(c * 2 for c in h)
        if len(h) not in (6, 8):
            return (0.0, 0.0, 0.0, 1.0)
        try:
            v = [int(h[i:i + 2], 16) / 255.0 for i in range(0, len(h), 2)]
        except ValueError:
            return (0.0, 0.0, 0.0, 1.0)
        return (v[0], v[1], v[2], v[3] if len(v) > 3 else 1.0)
    m = re.match(r"rgba?\(([^)]*)\)", low)
    if m:
        parts = [p.strip() for p in re.split(r"[,\s/]+", m.group(1)) if p.strip()]
        out = []
        for i, p in enumerate(parts[:4]):
            if p.endswith("%"):
                out.append(float(p[:-1]) / 100.0)
            else:
                out.append(float(p) / (255.0 if i < 3 else 1.0))
        while len(out) < 4:
            out.append(1.0)
        return tuple(min(max(v, 0.0), 1.0) for v in out)
    m = re.match(r"hsla?\(([^)]*)\)", low)
    if m:
        return _parse_hsl(m.group(1))
    return (0.0, 0.0, 0.0, 1.0)


def _parse_hsl(body):
    """hsl(色相, 彩度%, 明度% [, 不透明度]) -> (r, g, b, a)。読めなければ黒。"""
    import colorsys
    parts = [p.strip() for p in re.split(r"[,\s/]+", body) if p.strip()]
    if len(parts) < 3:
        return (0.0, 0.0, 0.0, 1.0)
    try:
        hue = parts[0].lower()
        if hue.endswith("deg"):
            hue = float(hue[:-3])
        elif hue.endswith("turn"):
            hue = float(hue[:-4]) * 360.0
        elif hue.endswith("rad"):
            hue = math.degrees(float(hue[:-3]))
        else:
            hue = float(hue)
        sat = float(parts[1].rstrip("%")) / 100.0
        lig = float(parts[2].rstrip("%")) / 100.0
        a = 1.0
        if len(parts) > 3:
            a = float(parts[3][:-1]) / 100.0 if parts[3].endswith("%") else float(parts[3])
    except ValueError:
        return (0.0, 0.0, 0.0, 1.0)
    sat, lig, a = (min(max(v, 0.0), 1.0) for v in (sat, lig, a))
    r, g, b = colorsys.hls_to_rgb((hue % 360.0) / 360.0, lig, sat)
    return (r, g, b, a)


# -----------------------------------------------------------------------------
# 変形
# -----------------------------------------------------------------------------

def parse_transform(s):
    """transform 属性 -> 3x3 の行列。"""
    m = np.eye(3)
    for name, args in re.findall(r"(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)",
                                 s or ""):
        v = _nums(args)
        t = np.eye(3)
        if name == "matrix" and len(v) >= 6:
            t = np.array([[v[0], v[2], v[4]], [v[1], v[3], v[5]], [0, 0, 1.0]])
        elif name == "translate" and v:
            t[0, 2] = v[0]
            t[1, 2] = v[1] if len(v) > 1 else 0.0
        elif name == "scale" and v:
            t[0, 0] = v[0]
            t[1, 1] = v[1] if len(v) > 1 else v[0]
        elif name == "rotate" and v:
            a = math.radians(v[0])
            r = np.array([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0],
                          [0, 0, 1.0]])
            if len(v) >= 3:
                cx, cy = v[1], v[2]
                t = (np.array([[1, 0, cx], [0, 1, cy], [0, 0, 1.0]]) @ r
                     @ np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1.0]]))
            else:
                t = r
        elif name == "skewX" and v:
            t[0, 1] = math.tan(math.radians(v[0]))
        elif name == "skewY" and v:
            t[1, 0] = math.tan(math.radians(v[0]))
        m = m @ t
    return m


def _apply(m, p):
    return (float(m[0, 0] * p[0] + m[0, 1] * p[1] + m[0, 2]),
            float(m[1, 0] * p[0] + m[1, 1] * p[1] + m[1, 2]))


# -----------------------------------------------------------------------------
# CSS (<style>)
# -----------------------------------------------------------------------------

def parse_css(text):
    """簡単な CSS を [(選択子, 重み, 順番, {プロパティ: 値})] にする。
    読める選択子: .クラス / #id / 要素名 / 要素名.クラス / * (「,」区切り)。"""
    text = re.sub(r"/\*.*?\*/", "", text or "", flags=re.S)
    rules = []
    order = 0
    for sel_text, body in re.findall(r"([^{}]+)\{([^{}]*)\}", text):
        decls = _parse_decls(body)
        for sel in sel_text.split(","):
            sel = sel.strip()
            if not sel or " " in sel or ">" in sel or ":" in sel:
                continue                        # 子孫・疑似クラスなどは読まない
            weight = (100 if "#" in sel else 0) + 10 * sel.count(".") + \
                (1 if re.match(r"^[a-zA-Z]", sel) else 0)
            rules.append((sel, weight, order, decls))
            order += 1
    return rules


def _parse_decls(body):
    out = {}
    for part in (body or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip().lower()] = v.strip().replace("!important", "").strip()
    return out


def _matches(sel, el):
    tag = _tag(el)
    classes = set((el.get("class") or "").split())
    if sel == "*":
        return True
    m = re.match(r"^([a-zA-Z][\w-]*)?((?:[.#][\w-]+)*)$", sel)
    if not m:
        return False
    if m.group(1) and m.group(1) != tag:
        return False
    for kind, name in re.findall(r"([.#])([\w-]+)", m.group(2)):
        if kind == "." and name not in classes:
            return False
        if kind == "#" and el.get("id") != name:
            return False
    return True


# -----------------------------------------------------------------------------
# パス
# -----------------------------------------------------------------------------

class _Pen:
    """fontTools のペン: 描かれた形を、このアドオンのパスの点 [co, 入り, 出] にする。"""

    def __init__(self):
        self.subs = []
        self.cur = None

    def moveTo(self, p):
        self._finish(False)
        p = tuple(p)
        self.cur = [[p, p, p]]

    def lineTo(self, p):
        if self.cur is None:
            self.moveTo(p)
            return
        p = tuple(p)
        self.cur.append([p, p, p])

    def curveTo(self, *pts):
        if self.cur is None:
            self.moveTo(pts[0])
        pts = [tuple(p) for p in pts]
        if len(pts) == 3:
            c1, c2, p = pts
            self.cur[-1][2] = c1
            self.cur.append([p, c2, p])
        else:                                   # まれな形: 直線でつなぐ
            for p in pts:
                self.lineTo(p)

    def qCurveTo(self, *pts):
        if self.cur is None:
            self.moveTo(pts[0])
        pts = [tuple(p) for p in pts]
        offs, end = pts[:-1], pts[-1]
        if not offs:
            self.lineTo(end)
            return
        # 続けて並んだ制御点のあいだには、暗黙の点 (中点) がある
        segs = []
        for i, q in enumerate(offs):
            nxt = end if i == len(offs) - 1 else (
                (q[0] + offs[i + 1][0]) / 2, (q[1] + offs[i + 1][1]) / 2)
            segs.append((q, nxt))
        for q, p in segs:
            p0 = self.cur[-1][0]
            c1 = (p0[0] + 2 / 3 * (q[0] - p0[0]), p0[1] + 2 / 3 * (q[1] - p0[1]))
            c2 = (p[0] + 2 / 3 * (q[0] - p[0]), p[1] + 2 / 3 * (q[1] - p[1]))
            self.cur[-1][2] = c1
            self.cur.append([p, c2, p])

    def closePath(self):
        self._finish(True)

    def endPath(self):
        self._finish(False)

    def _finish(self, closed):
        cur = self.cur
        self.cur = None
        if not cur:
            return
        if closed and len(cur) > 1:
            a, b = cur[0][0], cur[-1][0]
            if abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6:
                cur[0][1] = cur[-1][1]           # 最後の点は最初の点と同じ -> まとめる
                cur.pop()
        self.subs.append((cur, closed))


def _shape_d(el):
    """基本図形を、パスの文字列にする。"""
    t = _tag(el)
    g = lambda k, d=0.0: _num(el.get(k), d)    # noqa: E731
    if t == "rect":
        x, y, w, h = g("x"), g("y"), g("width"), g("height")
        if w <= 0 or h <= 0:
            return ""
        rx, ry = el.get("rx"), el.get("ry")
        rx = _num(rx) if rx is not None else (_num(ry) if ry is not None else 0.0)
        ry = _num(ry) if ry is not None else rx
        rx, ry = min(rx, w / 2), min(ry, h / 2)
        if rx <= 0 or ry <= 0:
            return "M%g,%g H%g V%g H%g Z" % (x, y, x + w, y + h, x)
        return ("M%g,%g H%g A%g,%g 0 0 1 %g,%g V%g A%g,%g 0 0 1 %g,%g H%g "
                "A%g,%g 0 0 1 %g,%g V%g A%g,%g 0 0 1 %g,%g Z"
                % (x + rx, y, x + w - rx, rx, ry, x + w, y + ry, y + h - ry, rx, ry,
                   x + w - rx, y + h, x + rx, rx, ry, x, y + h - ry, y + ry, rx, ry, x + rx, y))
    if t in ("circle", "ellipse"):
        cx, cy = g("cx"), g("cy")
        rx = g("r") if t == "circle" else g("rx")
        ry = g("r") if t == "circle" else g("ry")
        if rx <= 0 or ry <= 0:
            return ""
        return ("M%g,%g A%g,%g 0 1 0 %g,%g A%g,%g 0 1 0 %g,%g Z"
                % (cx - rx, cy, rx, ry, cx + rx, cy, rx, ry, cx - rx, cy))
    if t == "line":
        return "M%g,%g L%g,%g" % (g("x1"), g("y1"), g("x2"), g("y2"))
    if t in ("polyline", "polygon"):
        v = _nums(el.get("points"))
        if len(v) < 4:
            return ""
        pts = list(zip(v[0::2], v[1::2]))
        d = "M%g,%g " % pts[0] + " ".join("L%g,%g" % p for p in pts[1:])
        return d + (" Z" if t == "polygon" else "")
    if t == "path":
        return el.get("d") or ""
    return ""


def path_subs(d):
    """パスの文字列 -> [(点の並び, 閉じているか)]。"""
    from fontTools.svgLib.path import parse_path
    pen = _Pen()
    try:
        parse_path(d, pen)
    except Exception as e:
        print("[Vector Strokes] SVG のパスを読めません:", e)
    pen._finish(False)
    return pen.subs


# -----------------------------------------------------------------------------
# 読み込み本体
# -----------------------------------------------------------------------------

class SvgReader:
    def __init__(self, vs, img, root, base_dir=""):
        self.vs = vs
        self.img = img
        self.root = root
        self.base_dir = base_dir
        self.canvas_h = float(img.size[1])
        self.ids = {el.get("id"): el for el in root.iter() if el.get("id")}
        css = "".join((el.text or "") for el in root.iter() if _tag(el) == "style")
        self.css = sorted(parse_css(css), key=lambda r: (r[1], r[2]))
        self.skipped = {}
        self.count = 0
        self.in_mask = 0          # マスクの中身を読んでいる間 (中の効果は色を変えるだけなので数えない)
        self.flip = np.array([[1.0, 0, 0], [0, -1.0, self.canvas_h], [0, 0, 1.0]])

    def skip(self, what):
        self.skipped[what] = self.skipped.get(what, 0) + 1

    # --- 見た目 ---
    def own_style(self, el):
        """その要素に書かれた見た目 (属性 < CSS < style 属性 の順に強い)。"""
        st = {}
        for k in STYLE_KEYS:
            v = el.get(k)
            if v is not None:
                st[k] = v.strip()
        for sel, _w, _o, decls in self.css:
            if _matches(sel, el):
                st.update({k: v for k, v in decls.items() if k in STYLE_KEYS})
        st.update({k: v for k, v in _parse_decls(el.get("style")).items() if k in STYLE_KEYS})
        return st

    def computed(self, el, parent):
        st = {k: parent[k] for k in INHERITED if k in parent}
        st.update(self.own_style(el))
        return st

    # --- 木をたどる ---
    def read(self):
        """全体を読み込む。戻り値: いちばん上のグループの uid"""
        root = self.root
        vb = _nums(root.get("viewBox"))
        w_attr, h_attr = root.get("width"), root.get("height")
        m = np.eye(3)
        if len(vb) == 4 and vb[2] > 0 and vb[3] > 0:
            w = _num(w_attr, vb[2]) if w_attr and not w_attr.endswith("%") else vb[2]
            h = _num(h_attr, vb[3]) if h_attr and not h_attr.endswith("%") else vb[3]
            s = min(w / vb[2], h / vb[3])
            m = np.array([[s, 0, -vb[0] * s], [0, s, -vb[1] * s], [0, 0, 1.0]])
        top = self._group(0, None, {})
        root_st = self.computed(root, {"fill": "black"})
        root_st.pop("opacity", None)
        for ch in root:
            self.node(ch, top, m, root_st)
        return top

    def _group(self, parent, el, st, clip=False):
        with render.suspended():
            oi = data.new_object(self.vs, kind='GROUP', parent_uid=parent)
            ob = self.vs.objects[oi]
            if el is not None and el.get("id"):
                ob.name = el.get("id")
            elif parent == 0:
                ob.name = "SVG"
            self._object_look(ob, st)
            ob.clip = clip
            return ob.uid

    def _object_look(self, ob, st):
        try:
            op = float(st.get("opacity", "1"))
        except ValueError:
            op = 1.0
        ob.opacity = min(max(op, 0.0), 1.0)
        mode = st.get("mix-blend-mode", "normal").strip().lower()
        from .export import CSS_BLEND
        inv = {v: k for k, v in CSS_BLEND.items()}
        ob.blend_mode = inv.get(mode, 'NORMAL')

    def _ref(self, value):
        m = re.match(r"\s*url\(\s*['\"]?#([^'\")\s]+)", value or "")
        return self.ids.get(m.group(1)) if m else None

    def node(self, el, parent, ctm, pst):
        tag = _tag(el)
        if tag in {"defs", "style", "title", "desc", "metadata", "clipPath", "mask",
                   "linearGradient", "radialGradient", "symbol", "marker", "pattern",
                   "filter", "namedview"} or "}" in el.tag and SVG_NS not in el.tag:
            return
        st = self.computed(el, pst)
        if st.get("display", "").strip() == "none":
            return
        m = ctm @ parse_transform(el.get("transform"))
        if tag in {"text", "tspan", "textPath"}:
            self.skip("文字")
            return
        if st.get("filter") and st.get("filter") != "none" and not self.in_mask:
            self.skip("フィルター (影・ぼかしなど)")
        clip_el = self._ref(st.get("clip-path")) if st.get("clip-path") else None
        mask_el = self._ref(st.get("mask")) if st.get("mask") else None
        if clip_el is not None or mask_el is not None:
            # クリップグループにする: 中身 → 最後にマスクの形
            g = self._group(parent, None, {})
            self.vs.objects[data.index_of_uid(self.vs, g)].name = "クリップグループ %d" % g
            inner = {k: v for k, v in st.items() if k not in {"clip-path", "mask"}}
            self._content(el, tag, g, m, inner)
            self._mask(clip_el or mask_el, g, m, st, is_clip=clip_el is not None)
            with render.suspended():
                self.vs.objects[data.index_of_uid(self.vs, g)].clip = True
            return
        self._content(el, tag, parent, m, st)

    def _same_shape_parts(self, el):
        """同じ形の <path> だけが並んだグループか (このアドオンの書き出しは、1つの形の
        塗りと線を別々の <path> に分けてグループで包む)。そうなら子の一覧。"""
        kids = list(el)
        if len(kids) < 2 or any(_tag(k) != "path" for k in kids):
            return None
        d0 = (kids[0].get("d") or "").strip()
        for k in kids:
            if ((k.get("d") or "").strip() != d0 or k.get("transform") or k.get("id")
                    or any(self.own_style(k).get(x) not in (None, "none")
                           for x in ("clip-path", "mask", "filter"))):
                return None
        return kids

    def _content(self, el, tag, parent, m, st):
        parts = self._same_shape_parts(el) if tag == "g" else None
        if parts is not None:
            # 1つのオブジェクトにまとめる (塗りと線を、書かれた順に重ねる)
            self._shape(parts[0], parent, m, st, parts=parts, name_el=el)
            return
        if tag in {"g", "svg", "a", "switch"}:
            if tag == "svg" and el is not self.root:
                m = m @ np.array([[1, 0, _num(el.get("x"))], [0, 1, _num(el.get("y"))],
                                  [0, 0, 1.0]])
            g = self._group(parent, el, st)
            for ch in el:
                self.node(ch, g, m, st)
            return
        if tag == "use":
            ref = self.ids.get((el.get("href") or el.get(XLINK) or "").lstrip("#"))
            if ref is None:
                self.skip("参照先の無い use")
                return
            m2 = m @ np.array([[1, 0, _num(el.get("x"))], [0, 1, _num(el.get("y"))],
                               [0, 0, 1.0]])
            if _tag(ref) == "symbol":
                g = self._group(parent, el, st)
                for ch in ref:
                    self.node(ch, g, m2, st)
            else:
                self.node(ref, parent, m2, st)
            return
        if tag == "image":
            self._image(el, parent, m, st)
            return
        if tag in {"path", "rect", "circle", "ellipse", "line", "polyline", "polygon"}:
            self._shape(el, parent, m, st)
            return
        if tag not in {"style"}:
            self.skip("<%s>" % tag)

    def _mask(self, el, g, m, st, is_clip):
        """クリッピングパス・マスクの中身を、クリップグループのマスクの形にする。"""
        self.in_mask += 1
        try:
            self._mask_inner(el, g, m, st, is_clip)
        finally:
            self.in_mask -= 1

    def _mask_inner(self, el, g, m, st, is_clip):
        kids = list(el)
        m2 = m @ parse_transform(el.get("transform"))
        if is_clip:
            look = {"fill": "black", "stroke": "none", "fill-rule": st.get("clip-rule",
                                                                          "nonzero")}
        else:
            look = {"fill": "white"}
        if len(kids) == 1 and _tag(kids[0]) not in {"g"}:
            self.node(kids[0], g, m2, look)
            if is_clip:
                self._force_solid(g)
            return
        holder = self._group(g, None, {})
        for ch in kids:
            self.node(ch, holder, m2, look)
        if is_clip:
            for u in data.descendants(self.vs, holder):
                self._force_solid_uid(u)

    def _force_solid(self, g):
        kids = data.children_map(self.vs).get(g, [])
        if kids:
            self._force_solid_uid(kids[-1])

    def _force_solid_uid(self, uid):
        """クリッピングパスは形だけが効く: 不透明な塗りだけにする。"""
        ob = self.vs.objects[data.index_of_uid(self.vs, uid)]
        if ob.kind != 'PATH':
            return
        with render.suspended():
            for p in ob.paints:
                if p.kind == 'FILL':
                    p.enabled, p.paint_type, p.color = True, 'SOLID', (0, 0, 0, 1)
                else:
                    p.enabled = False
            ob.opacity = 1.0

    # --- 形 ---
    def _pattern_images(self, pat):
        """パターンの中の画像 [(image 要素, パターンの中での変形)]。画像の無いパターンは []。
        Figma は画像を「画像1枚を敷いたパターン」で書き出す。"""
        out = []
        for ch in pat:
            t = _tag(ch)
            tm = parse_transform(ch.get("transform"))
            if t == "image":
                out.append((ch, tm))
            elif t == "use":
                ref = self.ids.get((ch.get("href") or ch.get(XLINK) or "").lstrip("#"))
                if ref is not None and _tag(ref) == "image":
                    move = np.array([[1, 0, _num(ch.get("x"))], [0, 1, _num(ch.get("y"))],
                                     [0, 0, 1.0]])
                    out.append((ref, tm @ move))
        return out

    def _pattern_fill(self, el, parent, m, st, pat, subs):
        """画像のパターンで塗った形 -> 「その形で切り抜いた画像」(クリップグループ)。
        線があれば、その上に線だけの形を重ねる。画像を並べて繰り返すことはしない (1枚だけ)。"""
        pts = [q for sp, _c in subs for pt in sp for q in (pt[0],)]
        xs, ys = [q[0] for q in pts], [q[1] for q in pts]
        x0, y0 = min(xs), min(ys)
        w, h = max(xs) - x0, max(ys) - y0
        base = m @ parse_transform(pat.get("patternTransform"))
        if (pat.get("patternContentUnits") or "userSpaceOnUse") == "objectBoundingBox":
            base = base @ np.array([[w, 0, x0], [0, h, y0], [0, 0, 1.0]])
        g = self._group(parent, None, {})
        gob = self.vs.objects[data.index_of_uid(self.vs, g)]
        gob.name = el.get("id") or "画像の塗り %d" % g
        with render.suspended():
            self._object_look(gob, st)
        for image_el, tm in self._pattern_images(pat):
            self._image(image_el, g, base @ tm, {})
        solid = {k: v for k, v in st.items() if k not in {"opacity", "mix-blend-mode"}}
        solid.update({"fill": "black", "stroke": "none", "fill-opacity": "1"})
        self._shape(el, g, m, solid, pattern_ok=False)
        with render.suspended():
            self.vs.objects[data.index_of_uid(self.vs, g)].clip = True
        if st.get("stroke", "none").strip() not in {"none", ""}:
            only_stroke = dict(st)
            only_stroke["fill"] = "none"
            self._shape(el, parent, m, only_stroke, pattern_ok=False)

    def _shape(self, el, parent, m, st, parts=None, name_el=None, pattern_ok=True):
        subs = path_subs(_shape_d(el))
        if not subs:
            return
        pat = self._ref(st.get("fill")) if pattern_ok and parts is None else None
        if pat is not None and _tag(pat) == "pattern" and self._pattern_images(pat):
            self._pattern_fill(el, parent, m, st, pat, subs)
            return
        full = self.flip @ m
        scale = math.sqrt(abs(np.linalg.det(m[:2, :2]))) or 1.0
        with render.suspended():
            oi = data.new_object(self.vs, kind='PATH', parent_uid=parent)
            ob = self.vs.objects[oi]
            name_el = name_el if name_el is not None else el
            if name_el.get("id"):
                ob.name = name_el.get("id")
            for pts, closed in subs:
                sp = ob.subpaths.add()
                for co, hl, hr in pts:
                    p = sp.points.add()
                    p.co, p.handle_left, p.handle_right = \
                        _apply(full, co), _apply(full, hl), _apply(full, hr)
                sp.closed = closed
            if parts is None:
                ob.fill_rule = 'EVENODD' if st.get("fill-rule", "") == "evenodd" else 'NONZERO'
                self._paints(ob, st, full, scale)
            else:
                pst = [self.computed(k, st) for k in parts]
                ob.fill_rule = ('EVENODD' if any(x.get("fill-rule", "") == "evenodd" for x in pst)
                                else 'NONZERO')
                keep = []
                for x in pst:
                    self._paints(ob, x, full, scale, clear=False)
                ob_paints = list(ob.paints)
                # 使っていない方 (塗りだけの <path> の「線」など) を捨て、塗りと線を1つずつは残す
                for i in range(len(ob_paints) - 1, -1, -1):
                    if not ob.paints[i].enabled:
                        ob.paints.remove(i)
                data.ensure_fill_and_stroke(ob, fill_on=False, stroke_on=False)
            self._object_look(ob, st)
        self.count += 1

    def _paints(self, ob, st, full, scale, clear=True):
        if clear:
            ob.paints.clear()
        cur = parse_color(st.get("color", "black")) or (0.0, 0.0, 0.0, 1.0)
        fill = self._paint(ob, 'FILL', st.get("fill", "black"), st.get("fill-opacity"), cur, full)
        stroke = self._paint(ob, 'STROKE', st.get("stroke", "none"),
                             st.get("stroke-opacity"), cur, full)
        stroke.width = max(_num(st.get("stroke-width"), 1.0) * scale, 0.0)
        stroke.cap = CAPS.get(st.get("stroke-linecap", "butt").strip(), 'BUTT')
        stroke.join = JOINS.get(st.get("stroke-linejoin", "miter").strip(), 'MITER')
        try:
            stroke.miter_limit = max(float(st.get("stroke-miterlimit", 4)), 1.0)
        except ValueError:
            pass
        dash = [v * scale for v in _nums(st.get("stroke-dasharray"))
                if st.get("stroke-dasharray", "none") != "none"]
        if dash and any(v > 0 for v in dash):
            if len(dash) % 2:
                dash = dash * 2
            dash = (dash + [0.0] * 6)[:6]
            stroke.dash_enable = True
            stroke.dash = dash
            stroke.dash_offset = _num(st.get("stroke-dashoffset")) * scale
        ob.active_paint = len(ob.paints) - 1

    def _paint(self, ob, kind, value, opacity, cur, full):
        p = data.add_paint(ob, kind)
        try:
            op = float(opacity) if opacity is not None else 1.0
        except ValueError:
            op = 1.0
        grad = self._ref(value) if value and value.strip().startswith("url(") else None
        if grad is not None and _tag(grad) in {"linearGradient", "radialGradient"}:
            if self._gradient(p, grad, op, full, ob):
                return p
            value = "black"
        if grad is not None or (value and value.strip().startswith("url(")):
            # 使えない参照 (パターンなど): 後ろに書かれた予備の色か、黒
            fb = re.sub(r"url\([^)]*\)", "", value or "").strip()
            if grad is not None and _tag(grad) == "pattern":
                self.skip("パターン")
            value = fb or "black"
        col = parse_color(value, cur)
        if col is None:
            p.enabled = False
            p.color = (0.0, 0.0, 0.0, 1.0)
            return p
        p.enabled = True
        p.color = (col[0], col[1], col[2], col[3] * op)
        return p

    # --- グラデーション ---
    def _grad_attr(self, el, name, seen=None):
        """グラデーションの属性 (href で指した先から引き継ぐ)。"""
        seen = seen or set()
        v = el.get(name)
        if v is not None:
            return v
        ref = (el.get("href") or el.get(XLINK) or "").lstrip("#")
        if ref and ref not in seen and ref in self.ids:
            seen.add(ref)
            return self._grad_attr(self.ids[ref], name, seen)
        return None

    def _grad_stops(self, el, seen=None):
        seen = seen or set()
        stops = [s for s in el if _tag(s) == "stop"]
        if stops:
            return stops
        ref = (el.get("href") or el.get(XLINK) or "").lstrip("#")
        if ref and ref not in seen and ref in self.ids:
            seen.add(ref)
            return self._grad_stops(self.ids[ref], seen)
        return []

    def _gradient(self, p, el, op, full, ob):
        stops = self._grad_stops(el)
        if len(stops) < 1:
            return False
        units = self._grad_attr(el, "gradientUnits") or "objectBoundingBox"
        gt = parse_transform(self._grad_attr(el, "gradientTransform"))
        if units == "objectBoundingBox":
            # 形の範囲 (SVG の座標) を 0〜1 に当てはめる
            inv = np.linalg.inv(full)
            pts = [_apply(inv, pt.co) for sp in ob.subpaths for pt in sp.points]
            if not pts:
                return False
            xs, ys = [q[0] for q in pts], [q[1] for q in pts]
            bb = np.array([[max(xs) - min(xs), 0, min(xs)], [0, max(ys) - min(ys), min(ys)],
                           [0, 0, 1.0]])
            m = full @ bb @ gt
            frac = lambda v, d: (float(v[:-1]) / 100.0 if v and v.endswith("%")  # noqa: E731
                                 else (float(v) if v else d))
        else:
            m = full @ gt
            frac = lambda v, d: _num(v, d) if v is not None else d                # noqa: E731
        if _tag(el) == "linearGradient":
            a = (frac(self._grad_attr(el, "x1"), 0.0), frac(self._grad_attr(el, "y1"), 0.0))
            b = (frac(self._grad_attr(el, "x2"), 1.0 if units == "objectBoundingBox" else 0.0),
                 frac(self._grad_attr(el, "y2"), 0.0))
            p.paint_type = 'LINEAR'
            p.g_start, p.g_end = _apply(m, a), _apply(m, b)
        else:
            half = 0.5 if units == "objectBoundingBox" else 0.0
            c = (frac(self._grad_attr(el, "cx"), half), frac(self._grad_attr(el, "cy"), half))
            r = frac(self._grad_attr(el, "r"), half)
            p.paint_type = 'RADIAL'
            p.g_start = _apply(m, c)
            p.g_end = _apply(m, (c[0] + r, c[1]))
        p.stops.clear()
        for s in stops:
            sst = self.own_style(s)
            off = s.get("offset", "0").strip()
            pos = float(off[:-1]) / 100.0 if off.endswith("%") else float(off or 0)
            col = parse_color(sst.get("stop-color", "black")) or (0.0, 0.0, 0.0, 0.0)
            try:
                a = float(sst.get("stop-opacity", "1"))
            except ValueError:
                a = 1.0
            q = p.stops.add()
            q.position = min(max(pos, 0.0), 1.0)
            q.color = (col[0], col[1], col[2], col[3] * a * op)
        if len(p.stops) == 1:
            q = p.stops.add()
            q.position, q.color = 1.0, tuple(p.stops[0].color)
        p.enabled = True
        return True

    # --- 画像 ---
    def _image(self, el, parent, m, st):
        import bpy
        href = el.get("href") or el.get(XLINK) or ""
        im = None
        if href.startswith("data:"):
            try:
                raw = base64.b64decode(href.split(",", 1)[1])
                im = _image_from_bytes(raw, el.get("id") or "SVG の画像")
            except Exception as e:
                print("[Vector Strokes] SVG の画像を読めません:", e)
        elif href:
            path = href if os.path.isabs(href) else os.path.join(self.base_dir, href)
            if os.path.exists(path):
                im = bpy.data.images.load(path, check_existing=True)
        if im is None:
            self.skip("読めない画像")
            return
        iw, ih = im.size
        w = _num(el.get("width"), float(iw))
        h = _num(el.get("height"), float(ih))
        x, y = _num(el.get("x")), _num(el.get("y"))
        if iw <= 0 or ih <= 0 or w <= 0 or h <= 0:
            return
        # 画像の画素 (左下が原点・上が +) -> SVG の座標
        a = np.array([[w / iw, 0, x], [0, -h / ih, y + h], [0, 0, 1.0]])
        full = self.flip @ m @ a
        with render.suspended():
            oi = data.new_object(self.vs, kind='IMAGE', parent_uid=parent)
            ob = self.vs.objects[oi]
            ob.image = im
            ob.name = el.get("id") or im.name
            ob.img_mat = (full[0, 0], full[1, 0], full[0, 1], full[1, 1])
            ob.img_origin = (full[0, 2], full[1, 2])
            self._object_look(ob, st)
        self.count += 1


def _image_from_bytes(raw, name):
    """PNG / JPEG のバイト列から、埋め込んだ Blender の画像を作る。"""
    import bpy
    from .render import skia
    sk = skia.Image.MakeFromEncoded(raw)
    if sk is None:
        return None
    arr = sk.toarray(colorType=skia.ColorType.kRGBA_8888_ColorType,
                     alphaType=skia.AlphaType.kUnpremul_AlphaType)
    h, w = arr.shape[:2]
    im = bpy.data.images.new(name, w, h, alpha=True)
    px = (arr[::-1].astype(np.float32) / 255.0)
    im.pixels.foreach_set(np.ascontiguousarray(px).ravel())
    im.update()
    try:
        im.pack()
    except Exception:
        pass
    return im


def import_svg(vs, img, path=None, text=None, parent_uid=0):
    """SVG を読み込む。戻り値: (いちばん上のグループの uid, 読まなかったもの {名前: 数})
    読めなければ (None, エラーの文言)。"""
    try:
        if text is None:
            with open(path, "rb") as f:
                text = f.read()
        if isinstance(text, str):
            text = text.encode("utf-8")
        root = ET.fromstring(text)
    except Exception as e:
        return None, "SVG を読めませんでした: %s" % e
    if _tag(root) != "svg":
        return None, "SVG ではないようです"
    rd = SvgReader(vs, img, root, os.path.dirname(path) if path else "")
    top = rd.read()
    with render.suspended():
        ob = vs.objects[data.index_of_uid(vs, top)]
        if path:
            ob.name = os.path.splitext(os.path.basename(path))[0]
        if parent_uid:
            ob.parent_uid = parent_uid
            data.normalize_order(vs)
    if rd.count == 0:
        data.remove_objects(vs, [top])
        return None, "読み込める形がありませんでした"
    return top, rd.skipped

# SPDX-License-Identifier: GPL-3.0-or-later
"""パスファインダー (ブーリアン)。Skia の計算を使うので曲線は曲線のまま残る。

Illustrator と同じく、実行するとその場で形が確定する (元の図形は残らない。Undo で戻せる)。

    形を組み合わせる: 合体 / 前面で型抜き / 交差 / 中マド / 背面で型抜き
    分ける:           分割 / トリム / 合流 / 切り抜き / アウトライン
"""

from . import data, geometry as G, render, transform

skia = render.skia

# (識別子, 名前, 説明)
MODES = (
    ('UNITE', "合体", "重なりをくっつけて1つの形にする"),
    ('MINUS_FRONT', "前面で型抜き", "一番背面の形から、前面の形を抜く"),
    ('INTERSECT', "交差", "すべてが重なっている部分だけ残す"),
    ('EXCLUDE', "中マド", "重なっている部分を抜く"),
    ('MINUS_BACK', "背面で型抜き", "一番前面の形から、背面の形を抜く"),
    ('DIVIDE', "分割", "重なりの境目ですべてを切り分ける"),
    ('TRIM', "トリム", "前面の形に隠れた部分を削る (線は消える)"),
    ('MERGE', "合流", "トリムしたうえで、同じ塗りの色どうしをくっつける"),
    ('CROP', "切り抜き", "一番前面の形の内側だけを残す"),
    ('OUTLINE', "アウトライン", "境界線だけにする (塗りの色の線になる)"),
)
MODE_NAMES = {k: n for k, n, _ in MODES}
NEEDS_TWO = {k for k, _, _ in MODES}


# -----------------------------------------------------------------------------
# Skia のパス <-> このアドオンのパス
# -----------------------------------------------------------------------------

def to_skia(ob):
    return render.skia_path(ob)


def _quad_to_cubic(p0, p1, p2):
    c1 = (p0[0] + 2.0 / 3.0 * (p1[0] - p0[0]), p0[1] + 2.0 / 3.0 * (p1[1] - p0[1]))
    c2 = (p2[0] + 2.0 / 3.0 * (p1[0] - p2[0]), p2[1] + 2.0 / 3.0 * (p1[1] - p2[1]))
    return c1, c2


def _conic_to_cubic(p0, p1, p2, w):
    """円弧 (conic) を3次ベジェで近似する。t=0.5 の点が一致するように合わせる。"""
    denom = 2.0 + 2.0 * w
    mid = ((p0[0] + 2.0 * w * p1[0] + p2[0]) / denom, (p0[1] + 2.0 * w * p1[1] + p2[1]) / denom)
    num = (8.0 * mid[0] - 4.0 * p0[0] - 4.0 * p2[0], 8.0 * mid[1] - 4.0 * p0[1] - 4.0 * p2[1])
    den = (3.0 * (2.0 * p1[0] - p0[0] - p2[0]), 3.0 * (2.0 * p1[1] - p0[1] - p2[1]))
    k = 2.0 / 3.0
    if abs(den[0]) >= abs(den[1]) and abs(den[0]) > 1e-9:
        k = num[0] / den[0]
    elif abs(den[1]) > 1e-9:
        k = num[1] / den[1]
    c1 = (p0[0] + k * (p1[0] - p0[0]), p0[1] + k * (p1[1] - p0[1]))
    c2 = (p2[0] + k * (p1[0] - p2[0]), p2[1] + k * (p1[1] - p2[1]))
    return c1, c2


def from_skia(path):
    """skia.Path -> [(点列, closed), ...]"""
    if path is None:
        return []
    subs = []
    pts = []          # [co, handle_left, handle_right] の作業用リスト
    closed = False

    def flush():
        nonlocal pts, closed
        if len(pts) >= 2:
            # 閉じたパスでは、最後の点が始点と同じなら重複を消す
            if closed and G.same_point(pts[0][0], pts[-1][0]):
                pts[0][1] = pts[-1][1]
                pts.pop()
            subs.append(([tuple(tuple(v) for v in p) for p in pts], closed))
        pts = []
        closed = False

    it = skia.Path.Iter(path, False)
    while True:
        verb, p = it.next()
        if verb == skia.Path.Verb.kDone_Verb:
            break
        if verb == skia.Path.Verb.kMove_Verb:
            flush()
            co = (p[0].x(), p[0].y())
            pts.append([co, co, co])
        elif verb == skia.Path.Verb.kClose_Verb:
            closed = True
            flush()
        elif verb in (skia.Path.Verb.kLine_Verb, skia.Path.Verb.kQuad_Verb,
                      skia.Path.Verb.kCubic_Verb, skia.Path.Verb.kConic_Verb):
            if not pts:
                continue
            ends = [(q.x(), q.y()) for q in p]
            p0 = ends[0]
            if verb == skia.Path.Verb.kLine_Verb:
                c1, c2, p3 = p0, ends[1], ends[1]
            elif verb == skia.Path.Verb.kQuad_Verb:
                c1, c2 = _quad_to_cubic(p0, ends[1], ends[2])
                p3 = ends[2]
            elif verb == skia.Path.Verb.kConic_Verb:
                c1, c2 = _conic_to_cubic(p0, ends[1], ends[2], it.conicWeight())
                p3 = ends[2]
            else:
                c1, c2, p3 = ends[1], ends[2], ends[3]
            pts[-1][2] = c1
            pts.append([p3, c2, p3])
    flush()
    return subs


def rule_of(path):
    """Skia のパスの塗り方を、このアドオンの塗りの規則に直す。
    Skia のブーリアンの結果は偶奇規則で返るので、これを引き継がないと穴が塞がる。"""
    ft = path.getFillType()
    evenodd = {skia.PathFillType.kEvenOdd, skia.PathFillType.kInverseEvenOdd}
    return 'EVENODD' if ft in evenodd else 'NONZERO'


def _op(a, b, name):
    return skia.Op(a, b, getattr(skia.PathOp, name))


def union_all(paths):
    out = paths[0]
    for p in paths[1:]:
        out = _op(out, p, "kUnion_PathOp")
    return out


def _is_empty(path):
    return path is None or path.isEmpty()


# -----------------------------------------------------------------------------
# 計算 (skia.Path のレベル)
# -----------------------------------------------------------------------------

def combine(paths, mode):
    """1つの形になる組み合わせ。戻り値: skia.Path or None"""
    if mode == 'UNITE':
        return union_all(paths)
    if mode == 'INTERSECT':
        out = paths[0]
        for p in paths[1:]:
            out = _op(out, p, "kIntersect_PathOp")
        return out
    if mode == 'EXCLUDE':
        out = paths[0]
        for p in paths[1:]:
            out = _op(out, p, "kXOR_PathOp")
        return out
    if mode == 'MINUS_FRONT':
        return _op(paths[0], union_all(paths[1:]), "kDifference_PathOp")
    if mode == 'MINUS_BACK':
        return _op(paths[-1], union_all(paths[:-1]), "kDifference_PathOp")
    return None


def divide_faces(paths):
    """重なりで切り分けた領域を返す。戻り値: [(skia.Path, その領域に関わる元の番号のリスト), ...]
    番号は背面から 0, 1, 2...。前面のものほど後ろ。"""
    faces = []  # (path, [index...])
    for i, p in enumerate(paths):
        rest = p
        new = []
        for fp, idx in faces:
            inter = _op(fp, p, "kIntersect_PathOp")
            if not _is_empty(inter):
                new.append((inter, idx + [i]))
                outside = _op(fp, p, "kDifference_PathOp")
                if not _is_empty(outside):
                    new.append((outside, idx))
                rest = _op(rest, fp, "kDifference_PathOp")
            else:
                new.append((fp, idx))
        if not _is_empty(rest):
            new.append((rest, [i]))
        faces = new
    return faces


def trim_pieces(paths):
    """各形から、前面の形に隠れた部分を取り除く。戻り値: [(path, 元の番号), ...] (背面から)"""
    out = []
    for i, p in enumerate(paths):
        front = paths[i + 1:]
        piece = _op(p, union_all(front), "kDifference_PathOp") if front else p
        if not _is_empty(piece):
            out.append((piece, i))
    return out


# -----------------------------------------------------------------------------
# オブジェクトへの適用
# -----------------------------------------------------------------------------

STYLE_KEYS = ("fill_rule", "opacity", "blend_mode")


def _paint_values(p):
    return {k: (tuple(v) if hasattr(v, "__len__") and not isinstance(v, str) else v)
            for k, v in ((k, getattr(p, k)) for k in
                         ("kind", "enabled", "paint_type", "color", "width", "cap", "join",
                          "miter_limit", "align", "dash_enable", "dash", "dash_offset",
                          "g_start", "g_end"))}


def _style_of(ob):
    """スタイルを値としてコピーしておく (オブジェクトを増やすと参照がずれるため)。"""
    st = {k: getattr(ob, k) for k in STYLE_KEYS}
    st["paints"] = [(_paint_values(p), [(s.position, tuple(s.color)) for s in p.stops])
                    for p in ob.paints]
    return st


def _apply_style(ob, st):
    for k in STYLE_KEYS:
        setattr(ob, k, st[k])
    ob.paints.clear()
    for values, stops in st["paints"]:
        p = ob.paints.add()
        for k, v in values.items():
            setattr(p, k, v)
        for pos, col in stops:
            sp = p.stops.add()
            sp.position, sp.color = pos, col
    ob.active_paint = max(len(ob.paints) - 1, 0)


def _first_fill_color(st):
    for values, stops in st["paints"]:
        if values["kind"] == 'FILL':
            return stops[0][1] if stops and values["paint_type"] != 'SOLID' else values["color"]
    return (0.0, 0.0, 0.0, 1.0)


def _paint_look(v, stops):
    """その塗り/線の「見た目」。グラデーションは分岐点と向きまで見る。"""
    base = (v["kind"], tuple(v["color"]), v["paint_type"])
    if v["paint_type"] == 'SOLID':
        return base
    return base + (tuple(v["g_start"]), tuple(v["g_end"]),
                   tuple((round(pos, 5), tuple(c)) for pos, c in stops))


def _same_fill(a, b):
    """塗りの見た目が同じか (合流でくっつけてよいか)。"""
    fa = [_paint_look(v, st) for v, st in a["paints"] if v["enabled"]]
    fb = [_paint_look(v, st) for v, st in b["paints"] if v["enabled"]]
    return fa == fb


def apply(vs, uids, mode):
    """パスファインダーを実行する。戻り値: 新しくできたオブジェクトの uid のリスト、
    またはエラーメッセージ (str)。"""
    m = data.uid_map(vs)
    order = data.flatten_tree(data.children_map(vs))
    uids = [u for u in uids if u in m and m[u].kind in {'PATH', 'SHAPE'}]
    if len(uids) < 2:
        return "パスか図形を2つ以上選んでください (グループは中身を選んでください)"
    uids = sorted(uids, key=order.index)          # 背面から前面へ
    objs = [m[u] for u in uids]
    paths = [to_skia(ob) for ob in objs]
    if any(p is None for p in paths):
        return "形を取り出せないオブジェクトがあります"
    front = objs[-1]
    parent = front.parent_uid
    anchor = uids[-1]

    styles = [_style_of(ob) for ob in objs]
    pieces = []   # (subpaths, スタイル, 名前, 塗りの規則)
    if mode in {'UNITE', 'INTERSECT', 'EXCLUDE', 'MINUS_FRONT', 'MINUS_BACK'}:
        res = combine(paths, mode)
        if not _is_empty(res):
            pieces.append((from_skia(res), styles[-1], MODE_NAMES[mode], rule_of(res)))
    elif mode in {'DIVIDE', 'OUTLINE'}:
        for fp, idx in divide_faces(paths):
            pieces.append((from_skia(fp), styles[max(idx)], MODE_NAMES[mode], rule_of(fp)))
    elif mode in {'TRIM', 'MERGE'}:
        parts = trim_pieces(paths)
        if mode == 'MERGE':
            merged = []
            for p, i in parts:
                if merged and _same_fill(styles[merged[-1][1]], styles[i]):
                    merged[-1] = (_op(merged[-1][0], p, "kUnion_PathOp"), merged[-1][1])
                else:
                    merged.append((p, i))
            parts = [(p, i) for p, i in merged if not _is_empty(p)]
        for p, i in parts:
            pieces.append((from_skia(p), styles[i], MODE_NAMES[mode], rule_of(p)))
    elif mode == 'CROP':
        for i, p in enumerate(paths[:-1]):
            piece = _op(p, paths[-1], "kIntersect_PathOp")
            if not _is_empty(piece):
                pieces.append((from_skia(piece), styles[i], MODE_NAMES[mode], rule_of(piece)))
    else:
        return "不明な操作です: %s" % mode

    pieces = [p for p in pieces if p[0]]
    if not pieces:
        # 何も残らない (前面の形が背面を完全に覆った、同じ形どうし、重なりが無い等)。
        # Illustrator と同じく、元の形も削除する
        data.remove_objects(vs, uids)
        return []

    new_uids = []
    with render.suspended():
        for subs, st, label, rule in pieces:
            oi = data.new_object(vs, parent_uid=parent)
            ob = vs.objects[oi]
            _apply_style(ob, st)
            ob.name = "%s %d" % (label, ob.uid)
            ob.fill_rule = rule               # Skia が返した塗り方 (穴のある形は偶奇規則)
            if mode in {'TRIM', 'MERGE', 'CROP'}:
                for q in ob.paints:           # Illustrator と同じく線は消える
                    if q.kind == 'STROKE':
                        q.enabled = False
            if mode == 'OUTLINE':
                col = _first_fill_color(st)
                ob.paints.clear()
                data.add_paint(ob, 'STROKE', color=col, width=1.0)
            transform.write_subpaths(ob, subs)
            new_uids.append(ob.uid)
        # 結果は一番前面にあったものの位置へ。2つ以上ならグループにまとめる
        ch = data.children_map(vs)
        sib = ch[data._parent_key(ch, data.uid_map(vs), anchor)]
        for u in new_uids:
            if u in sib:
                sib.remove(u)
        pos = sib.index(anchor) + 1
        sib[pos:pos] = new_uids
        data.reorder(vs, data.flatten_tree(ch))
        data.remove_objects(vs, uids)
    if len(new_uids) > 1:
        g = data.group(vs, new_uids, name="%s %s" % (MODE_NAMES[mode], "グループ"))
        return [g] if g else new_uids
    return new_uids

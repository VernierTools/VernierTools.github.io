# SPDX-License-Identifier: GPL-3.0-or-later
"""図形ツール (矩形・角丸矩形・楕円・多角形・星)。

- 矩形・角丸矩形・楕円: 角から角へドラッグ (Shift: 正方形/正円、Alt: 中心から)
- 多角形・星: 中心から外へドラッグ (Illustrator と同じ)
- ドラッグせずにクリック: 大きさを聞く小窓が出る (Illustrator と同じ)
  → vstroke.shape_size (operators.VS_OT_shape_size) が実際に作る
作った図形はパラメーターのまま保存され、後からサイドバーで変更できる。
"""

import math

import bpy

from . import data, keys, render, snap, state, transform
from .select_tool import select_only
from .tool_base import Tool

HEADER_TEXT = ("図形 | ドラッグ: 図形を作る (Shift: 正方形・正円, Alt: 中心から) | "
               "クリック: 大きさを数値で指定 | 種類はツール設定かサイドバーで | "
               "V: 選択 P: ペン M: 矩形 L: 楕円 | Esc: 終了 | 右クリック: メニュー")

DEFAULT_SIZE = 100.0

NAMES = {"RECT": "矩形", "ROUNDED_RECT": "角丸矩形", "ELLIPSE": "楕円",
         "POLYGON": "多角形", "STAR": "星"}


def tool_settings():
    return bpy.context.window_manager.vstroke_tool


def from_center(shape_type):
    return shape_type in {'POLYGON', 'STAR'}


def new_shape(vs, ts, parent_uid=0):
    """ツール設定どおりの図形を 1 つ作る (大きさ・位置は呼び出し側で決める)。
    ドラッグでも、大きさを聞く小窓でも、ここを通る。"""
    src = data.style_source(vs)
    oi = data.new_object(vs, style_from=src, kind='SHAPE', parent_uid=parent_uid)
    ob = vs.objects[oi]
    t = ts.shape_type
    ob.shape_type = 'RECT' if t == 'ROUNDED_RECT' else t
    ob.corner_radius = ts.corner_radius if t == 'ROUNDED_RECT' else 0.0
    ob.sides = ts.sides
    ob.star_points = ts.star_points
    ob.inner_ratio = ts.inner_ratio
    ob.size = (0.0, 0.0)
    ob.name = NAMES[t] + " %d" % ob.uid
    return ob


class ShapeTool(Tool):
    name = 'SHAPE'
    header = HEADER_TEXT
    cursor = 'CROSSHAIR'

    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke

        if self.drag is not None:
            if event.type == 'MOUSEMOVE':
                self._update(img, view, mx, my, event)
                return 'RUNNING_MODAL'
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                return self._release(img)
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                uid = self.drag["uid"]
                self.drag = None
                data.remove_objects(vs, [uid])
                render.render_image(img)
                return 'RUNNING_MODAL'
            return 'RUNNING_MODAL'

        if not inside or event.type == 'MOUSEMOVE':
            return 'PASS_THROUGH'

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if event.type == 'ESC' and transform.selected_items(vs):
                select_only(vs, [])
                self.redraw()
                return 'RUNNING_MODAL'
            return 'FINISHED'

        if event.type == 'LEFTMOUSE' and event.value in {'PRESS', 'DOUBLE_CLICK'}:
            return self._press(img, view, mx, my)

        if event.value == 'PRESS' and not keys.command_mod(event):
            if event.type in keys.CONFIRM_KEYS:
                select_only(vs, [])
                self.redraw()
                return 'RUNNING_MODAL'
            if event.type in keys.DELETE_KEYS:
                items = transform.selected_items(vs)
                if items:
                    data.remove_objects(vs, items)
                    render.render_image(img)
                    self.push_undo("Delete Objects")
                return 'RUNNING_MODAL'
        return 'PASS_THROUGH'

    def _press(self, img, view, mx, my):
        vs = img.vstroke
        if not self.can_create(vs):
            return 'RUNNING_MODAL'
        ts = tool_settings()
        ix, iy = view.to_image(mx, my)
        targets = snap.make(vs, img, [])
        ix, iy = snap.place((ix, iy), targets, view)
        with render.suspended():
            ob = new_shape(vs, ts, parent_uid=self.isolation(vs))
            ob.center = (ix, iy)
        select_only(vs, [ob.uid])
        self.drag = {"uid": ob.uid, "start_img": (ix, iy), "start": (mx, my),
                     "moved": False, "center_mode": from_center(ob.shape_type),
                     "targets": targets}
        return 'RUNNING_MODAL'

    def _update(self, img, view, mx, my, event):
        d = self.drag
        if not d["moved"]:
            sx, sy = d["start"]
            if math.hypot(mx - sx, my - sy) < 3 * state.ui_scale():
                return
            d["moved"] = True
        vs = img.vstroke
        ob = vs.objects[data.index_of_uid(vs, d["uid"])]
        x0, y0 = d["start_img"]
        x1, y1 = view.to_image(mx, my)
        if not event.shift:
            x1, y1 = snap.place((x1, y1), d.get("targets"), view)
        dx, dy = x1 - x0, y1 - y0
        with render.suspended():
            if d["center_mode"]:
                r = math.hypot(dx, dy)
                ob.center = (x0, y0)
                ob.size = (2 * r, 2 * r)
            else:
                if event.shift:
                    s = max(abs(dx), abs(dy))
                    dx = math.copysign(s, dx)
                    dy = math.copysign(s, dy)
                if event.alt:
                    ob.center = (x0, y0)
                    ob.size = (2 * abs(dx), 2 * abs(dy))
                else:
                    ob.center = (x0 + dx / 2, y0 + dy / 2)
                    ob.size = (abs(dx), abs(dy))
        self.maybe_render(img)

    def _release(self, img):
        vs = img.vstroke
        d = self.drag
        self.drag = None
        snap.clear_guides()
        if not d["moved"]:
            # クリックしただけ: 下書きは捨てて、大きさを数値で聞く (Illustrator と同じ)
            data.remove_objects(vs, [d["uid"]])
            render.render_image(img)
            self.host.ask_shape_size(img, d["start_img"])
            return 'RUNNING_MODAL'
        render.render_image(img)
        self.push_undo("Add Shape")
        return 'RUNNING_MODAL'

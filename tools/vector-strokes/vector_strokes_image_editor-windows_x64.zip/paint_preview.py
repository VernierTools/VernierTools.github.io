# SPDX-License-Identifier: GPL-3.0-or-later
"""ペイント中の絵を、キャンバスの画像にも途中で反映する (3D ビューで様子を見るため)。

v0.31.5 (2026-09-25 ユーザー要望「横の 3D ビューで様子を見ながら描きたい」)。
それまでは「ベクターに戻る」まで、キャンバス (= 3D ビューのマテリアルが使う画像) は
描き始める前のままだった。

**いつ反映するか**
- 筆を離したとき (1画ごと)。描いている最中は何もしない (筆の動きを重くしないため)
- 描いているかどうかは Window.modal_operators にペイントのオペレーターがいるかで見る
  (タイマーで 0.02 秒ごとに見るだけなので軽い)。見逃すほど短い1画は、次の1画で一緒に反映する
- Undo・キャンバスの描き直しのあとも、次の見回りで合わせ直す

**どう反映するか (2通り)**
1. 重ねるだけで完成形と同じになるとき (ペイントレイヤーはほとんどこれ):
   画面に重ねて見せている「下の絵 → 描いているレイヤー → 上の絵」(operators.begin_paint)
   と同じ重ね方で、**変わった範囲だけ**合成し直してキャンバスに書く。
   1画あたり 2048px で約 40ms、4096px で約 0.1 秒 (全体を描き直すと 0.2 秒 / 0.7 秒)
2. そうでないとき (キャンバスにぴったり重なっていない画像 = 動かした・変形した写真など、
   描いているレイヤーやその親の不透明度・描画モード・効果・色調補正、
   上に通常以外の描画モードのものがある) と、変わった範囲が広いとき (塗りつぶしなど):
   いつもの描画 (render.render_image) でキャンバス全体を描き直す。遅いが正確

**決まり**
- マテリアルやノードには触らない。書き換えるのはキャンバスの画素だけ
  (「ベクターに戻る」ときも同じことをしている。そのときに正式な描画で描き直す)
- 何か失敗したら、そのペイントの間は反映をやめる (描くこと自体は邪魔しない)
- アドオン設定の「ペイント中も 3D ビューに反映」で切れる
"""

import bpy
import numpy as np

from . import data, render, state

INTERVAL = 0.02          # 描いているかの見回り (秒)
IDLE_INTERVAL = 0.25     # ペイントしていないとき
BAND = 256               # 合成を何行ずつに分けるか (一時的な配列を小さくする)
FULL_RATIO = 0.4         # 変わった範囲がキャンバスのこれより広ければ、全体を描き直す

_cache = {}              # 今のペイントの控え (_build)。ペイントしていなければ空
_flags = {"stroke": False, "check": False, "warned": False}


def enabled():
    pr = state.prefs()
    return bool(getattr(pr, "paint_live_3d", True)) if pr is not None else True


def note_press():
    """筆で描き始めた (見張り役が知らせる)。筆が終わったら、見回りで必ず反映する
    (タイマーが筆の最中を見逃しても、反映しそびれないように)。"""
    _flags["pressed"] = True


def request():
    """次の見回りで、レイヤーの絵が変わっていないか確かめる。"""
    _flags["check"] = True


def canvas_rewritten():
    """キャンバスが描き直された (Undo など)。持っている控えは古いので読み直す。"""
    if _cache:
        _cache["canvas_stale"] = True
    request()


def drop():
    _cache.clear()
    _flags["stroke"] = False
    _flags["check"] = False


def start():
    """描き始め (operators.begin_paint)。まだ何も描いていないうちに控えを作る。
    見回りで作ると、すぐ描き始めた最初の1画が控えに入ってしまい、反映されない。"""
    drop()
    info = state.paint
    try:
        from . import paint3d
        paint3d.sync()          # 入った直後から 3D ビューでも描けるように
    except Exception as e:
        print("[Vector Strokes] 3D ビューの描き先を合わせられません:", e)
    if not info or not enabled():
        return
    try:
        _cache.update(_build(info, _key(info)))
    except Exception as e:
        print("[Vector Strokes] ペイント中の 3D ビューへの反映を用意できません:", e)
        drop()
        _cache.update(off=True, key=_key(info))


def flush():
    """描いた分を、いまキャンバスに反映しきる (描く先を切り替える直前に呼ぶ)。
    戻り値: キャンバスが最新になったか。False なら呼ぶ側で描き直す。"""
    info = state.paint
    if (not info or not enabled() or not _cache or _cache.get("off")
            or _cache.get("key") != _key(info)):
        return False
    try:
        _flags["stroke"] = _flags["check"] = False
        update()
        return True
    except Exception as e:
        print("[Vector Strokes] 切り替えの前に反映できません:", e)
        return False


def lock_changed():
    """「透明部分をロック」を描いている途中で切り替えた (しきい値を変えた)。
    守る所の見せ方を作り直し、キャンバスも全体を合わせ直す。"""
    info = state.paint
    layer = bpy.data.images.get((info or {}).get("layer", ""))
    if layer is not None:
        render.clear_cache(layer.name)
    if _cache.get("exact") and layer is not None:
        _cache["lock"] = _lock_entry(layer)
    if _cache:
        _cache["full"] = True
    request()


def _key(info):
    return (info.get("canvas"), info.get("layer"), info.get("uid"))


# -----------------------------------------------------------------------------
# 見回り
# -----------------------------------------------------------------------------

def _stroke_active():
    """ペイントの1画 (モーダルのオペレーター) の最中か。"""
    wm = bpy.context.window_manager
    if wm is None:
        return False
    for win in wm.windows:
        for op in getattr(win, "modal_operators", ()):
            idname = getattr(op, "bl_idname", "") or ""
            if idname.startswith("PAINT_OT_") or idname.startswith("paint."):
                return True
    return False


def tick():
    from . import paint3d
    try:
        paint3d.sync()          # 3D ビューのテクスチャペイントの描き先 (ペイント中だけレイヤーへ)
    except Exception as e:
        print("[Vector Strokes] 3D ビューの描き先を合わせられません:", e)
    info = state.paint
    if not info or not enabled():
        if _cache:
            drop()
        return IDLE_INTERVAL
    try:
        if _stroke_active():
            _flags["stroke"] = True
            _flags["pressed"] = False
            return INTERVAL
        key = _key(info)
        if _cache.get("key") != key:
            # 描いている途中で設定をオンにしたときなど。もう描いた分があるかもしれないので、
            # 次は全体を合わせ直す
            drop()
            _cache.update(_build(info, key))
            _cache["full"] = True
            request()
            return INTERVAL
        if _cache.get("off"):
            return INTERVAL
        if _flags.get("pressed"):
            _flags["pressed"] = False       # 描き始めたが、筆の最中を見逃した
            _flags["check"] = True
        if _flags["stroke"] or _flags["check"]:
            _flags["stroke"] = _flags["check"] = False
            update()
    except Exception as e:
        if not _flags["warned"]:
            print("[Vector Strokes] ペイント中の 3D ビューへの反映をやめます:", e)
            _flags["warned"] = True
        key = _cache.get("key")
        drop()
        _cache.update(off=True, key=key)
    return INTERVAL


# -----------------------------------------------------------------------------
# 控えを作る
# -----------------------------------------------------------------------------

def _read(im, into=None):
    """画素を (h, w, 4) の float32 で。into (同じ大きさの配列) があれば、そこに読む。"""
    w, h = im.size
    if into is not None and into.shape == (h, w, 4):
        im.pixels.foreach_get(into.reshape(-1))
        return into
    arr = np.empty(w * h * 4, np.float32)
    im.pixels.foreach_get(arr)
    return arr.reshape(h, w, 4)


def _read_backdrop(name):
    """重ねて見せている絵 (下の絵・上の絵など)。8bit の画像は 8bit のまま持つ
    (値は k/255 なので戻しても同じ。4096px で float だと 1枚 256MB になる)。"""
    im = bpy.data.images.get(name or "")
    if im is None:
        return None
    arr = _read(im)
    if not im.is_float:
        arr = np.rint(arr * 255.0).astype(np.uint8)
    return arr


def _plain_node(ob):
    """重ねるだけで完成形と同じになるか (不透明度 100%・通常・効果なし・補正なし)。
    クリッピングマスクはかまわない (切り抜きは重ね方と入れ替えても結果が同じ)。"""
    if not ob.visible or ob.opacity < 1.0 or ob.blend_mode != 'NORMAL':
        return False
    if any(getattr(ob, k, False) for k in data.FX_PROPS if k.endswith("_enable")):
        return False
    if data.has_mask(ob):
        return False         # レイヤーマスクは重ね方では表せない (いつもの描画で描き直す)
    return not data.has_adjust(ob)


def stack_is_exact(vs, uid, w, h):
    """「下の絵 → 描いているレイヤー → 上の絵」と重ねるだけで、完成形と同じになるか。"""
    m = data.uid_map(vs)
    ob = m.get(uid)
    if ob is None or ob.kind != 'IMAGE' or ob.image is None or not _plain_node(ob):
        return False
    if (ob.img_quad_on or data.has_crop(ob) or tuple(ob.image.size) != (w, h)
            or tuple(round(v, 9) for v in ob.img_origin) != (0.0, 0.0)
            or tuple(round(v, 9) for v in ob.img_mat) != (1.0, 0.0, 0.0, 1.0)):
        return False
    holders = set(data.ancestors(vs, uid, m))
    if not all(_plain_node(m[u]) for u in holders if u in m):
        return False
    # 上にあるものは、通常の描画モードなら1枚にまとめて重ねても同じ
    # (不透明度・影などは、まとめた絵の中で済んでいる)
    _, above = render.layer_split(vs, uid)
    # 上に調整レイヤーがあると、描いているレイヤーにも補正がかかる (重ねるだけでは表せない)
    if any(m[u].kind == 'ADJUST' for u in above if u in m):
        return False
    return all(m[u].blend_mode == 'NORMAL' for u in above - holders if u in m)


def _build(info, key):
    canvas = bpy.data.images.get(info.get("canvas", ""))
    layer = bpy.data.images.get(info.get("layer", ""))
    out = {"key": key, "canvas": None}
    if canvas is None or layer is None or canvas.channels != 4 or layer.channels != 4:
        out["off"] = True
        return out
    # 置いた写真など、キャンバスと大きさ・位置・向きが違う画像は stack_is_exact が False になり、
    # いつもの描画で全体を描き直す (変形も正しくかかる)
    w, h = canvas.size
    vs = canvas.vstroke
    # レイヤーマスクに描いているときは、描いている絵は「中身」ではないので重ねられない
    out["exact"] = (info.get("mode") != 'LMASK'
                    and stack_is_exact(vs, info.get("uid", 0), w, h))
    out["snap"] = _read(layer)          # 前に見たときのレイヤーの絵 (変わった所を探す)
    if not out["exact"]:
        return out
    out["mode"] = info.get("mode", 'NORMAL')
    out["below"] = _read_backdrop(info.get("below"))
    out["above"] = _read_backdrop(info.get("above"))
    backdrop = bpy.data.images.get(info.get("below", ""))
    out["backdrop_float"] = bool(backdrop.is_float) if backdrop is not None else canvas.is_float
    if out["mode"] == 'MASK':
        out["content"] = _read_backdrop(info.get("content"))
    elif out["mode"] == 'CLIP':
        clip = bpy.data.images.get(info.get("clip", ""))
        out["clip"] = _read(clip)[..., 3].copy() if clip is not None else None
    out["lock"] = _lock_entry(layer)
    return out


def _lock_entry(layer):
    """透明部分をロックしていれば (守る所, 覚えておいた元の絵)。守る所には元の絵を見せる
    (ベクターに戻るとき、その通りに確定する。alpha_tools.enforce_lock)。無ければ None。"""
    from . import alpha_tools
    locked = alpha_tools.locked_pixels(layer.name)
    if locked is None:
        return None
    mask, vals = locked
    w, h = layer.size
    keep = np.zeros((h, w, 4), np.float32)
    keep[mask] = vals
    return (mask, keep)


# -----------------------------------------------------------------------------
# 反映
# -----------------------------------------------------------------------------

def update():
    info = state.paint or {}
    canvas = bpy.data.images.get(info.get("canvas", ""))
    layer = bpy.data.images.get(info.get("layer", ""))
    if canvas is None or layer is None:
        return
    # 前の控えと2枚を交互に使う (毎回 4096px で 256MB を作り直すと遅い)
    cur = _read(layer, _cache.pop("spare", None))
    h, w = cur.shape[:2]
    if _cache.pop("full", False):
        y0, y1, x0, x1 = 0, h, 0, w
    else:
        # 1画素 (float 4つ = 16 バイト) を 64bit 2つとして比べる。行を先に絞ってから列を探す
        # (np.any(cur != snap, axis=2) だと 4096px で 150ms、こちらは 25ms)
        ne = cur.view(np.uint64).reshape(h, -1) != _cache["snap"].view(np.uint64).reshape(h, -1)
        rows = np.flatnonzero(ne.any(axis=1))
        if rows.size == 0:
            _cache["spare"] = cur
            return
        y0, y1 = int(rows[0]), int(rows[-1]) + 1
        cols = np.flatnonzero(ne[y0:y1].reshape(y1 - y0, w, 2).any(axis=(0, 2)))
        del ne
        x0, x1 = int(cols[0]), int(cols[-1]) + 1
    _cache["spare"], _cache["snap"] = _cache["snap"], cur
    big = (y1 - y0) * (x1 - x0) > FULL_RATIO * h * w
    if not _cache.get("exact") or (big and _cache.get("lock") is None):
        # 重ねるだけでは完成形と変わる / 変わった範囲が広い (塗りつぶしなど) -> いつもの描画で
        # 全体を描き直す。広い範囲を numpy で重ねるより、Skia で全部描く方が速い
        # (4096px の全体: numpy 1.7 秒、render_image 0.7 秒)。
        # 透明部分をロックしていても使える: いつもの描画は、守る所を元の絵に差し替えて読む
        # (render._apply_lock)。0.33.3 まではロック中ここで何もせず、効果付きのレイヤーなどでは
        # ロックを一度切るまで 3D ビューが変わらなかった (2026-10-05 ユーザー報告)
        render.clear_cache(layer.name)
        render.render_image(canvas)
        return
    arr = _cache.get("canvas")
    if arr is None or _cache.pop("canvas_stale", False):
        arr = _cache["canvas"] = _read(canvas, arr)
    for b0 in range(y0, y1, BAND):
        b1 = min(b0 + BAND, y1)
        arr[b0:b1, x0:x1] = _compose(cur, arr, b0, b1, x0, x1,
                                     bool(layer.is_float), bool(canvas.is_float))
    canvas.pixels.foreach_set(arr.ravel())
    canvas.update()
    try:
        canvas.update_tag()          # Cycles にも知らせる (render.render_image と同じ)
    except Exception:
        pass
    render.tag_redraw_all()


def _premul_straight(s, src_float, dst_float):
    """ストレートの色 (src_float ならリニア、そうでなければ sRGB。8bit の配列でもよい) を、
    キャンバスの色空間の乗算済みにした新しい配列。None なら None。"""
    if s is None:
        return None
    if s.dtype == np.uint8:
        out = np.multiply(s, np.float32(1.0 / 255.0), dtype=np.float32)
    else:
        out = s.astype(np.float32, copy=True)
    if dst_float and not src_float:
        out[..., :3] = render._srgb_to_linear_arr(out[..., :3])
    elif src_float and not dst_float:
        out[..., :3] = render._linear_to_srgb(out[..., :3])
    out[..., :3] *= out[..., 3:4]
    return out


def _layer_premul(s, layer_float, canvas_float):
    """レイヤーの画素を、キャンバスの色空間の乗算済みにした新しい配列。
    Blender の float 画像はリニア・乗算済み、8bit 画像は sRGB・ストレート。"""
    if not layer_float:
        return _premul_straight(s, False, canvas_float)
    if canvas_float:
        return s.astype(np.float32, copy=True)
    a = s[..., 3:4]
    rgb = np.divide(s[..., :3], a, out=np.zeros_like(s[..., :3]), where=a > 1e-8)
    return _premul_straight(np.concatenate([rgb, a], axis=2), True, False)


def _over(top, bottom):
    """乗算済みの top を bottom の上に重ねる (bottom を書き換えて返す)。"""
    bottom *= 1.0 - top[..., 3:4]
    bottom += top
    return bottom


def _compose(cur, arr, y0, y1, x0, x1, layer_float, canvas_float):
    """(y0:y1, x0:x1) の範囲を「下の絵 → 描いているレイヤー → 上の絵」で重ねた、
    キャンバスの画素 (float はリニア・乗算済み、8bit は sRGB・ストレート)。"""
    c = _cache
    bf = c["backdrop_float"]
    sl = (slice(y0, y1), slice(x0, x1))
    L = cur[sl]
    lock = c.get("lock")
    if lock is not None:
        L = np.where(lock[0][sl][..., None], lock[1][sl], L)
    if c["mode"] == 'MASK':
        # 描いているのはマスク: 切り抜かれる中身に、描いている絵のアルファを掛ける
        content = c.get("content")
        if content is None:
            P = np.zeros((y1 - y0, x1 - x0, 4), np.float32)
        else:
            P = _premul_straight(content[sl], bf, canvas_float)
            P *= L[..., 3:4]
    else:
        P = _layer_premul(L, layer_float, canvas_float)
        if c["mode"] == 'CLIP' and c.get("clip") is not None:
            P *= c["clip"][sl][..., None]
    below = c.get("below")
    if below is not None:
        P = _over(P, _premul_straight(below[sl], bf, canvas_float))
    above = c.get("above")
    if above is not None:
        P = _over(_premul_straight(above[sl], bf, canvas_float), P)
    if canvas_float:
        return P
    # 8bit のキャンバスはストレートに戻す。完全に透明な所は、今の色を残す
    # (render.compose と同じ。マテリアルがアルファを使わないとき色が変わらないように)
    a = P[..., 3:4]
    np.divide(P[..., :3], a, out=P[..., :3], where=a > 1e-8)
    empty = a[..., 0] <= 1e-8
    if empty.any():
        P[..., :3][empty] = arr[sl][..., :3][empty]
    np.clip(P, 0.0, 1.0, out=P)
    return P


# -----------------------------------------------------------------------------

def register():
    if not bpy.app.background:
        bpy.app.timers.register(tick, first_interval=IDLE_INTERVAL, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    drop()

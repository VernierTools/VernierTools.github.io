# SPDX-License-Identifier: GPL-3.0-or-later
"""保存されるデータ(PropertyGroup)、オブジェクトの親子関係、旧バージョンからの移行。

構造 (Image.vstroke):
    schema_version   保存形式の番号 (SCHEMA_VERSION)
    base_image       下地画像 (v0.28.3 までの形式。今は元の画像をいちばん下のペイントレイヤーにする)
    objects[]        オブジェクト一覧。並び順 = 重なり順 (後ろほど前面)
        uid / name / kind (LAYER / PATH / SHAPE / GROUP / ADJUST) / parent_uid (0 = 最上位)
        visible / locked / select (オブジェクト単位の選択) / rotation / expanded
        opacity / blend_mode      不透明度と描画モード (レイヤー・グループにも)
        clip                      クリップグループ (最前面の子がマスクの形)
        layer_color               レイヤーの選択枠の色
        subpaths[]   パスの形 (kind == PATH)。穴あき図形用に複数持てる
            points[] co / handle_left / handle_right / select (点の選択)
            closed
        shape_type / center / size / corner_radius / sides / star_points / inner_ratio
                     図形のパラメーター (kind == SHAPE)
        stroke_* / fill_*
    active_index     アクティブなオブジェクトの番号
    paths[]          v0.3.x の旧データ (読み込み時に objects へ移行して空にする)

並び順の決まり: グループの直後に、その子孫が続く (深さ優先)。兄弟の中では後ろほど前面。
構造を変えたら normalize_order() で並び直す。
最上位はレイヤー (kind == LAYER) と調整レイヤー (kind == ADJUST) だけ。それ以外は必ずどこかの
レイヤーの子孫。調整レイヤーは中身を持たず、下にあるものすべてに色調補正をかける。
どのオブジェクトにもレイヤーマスク (mask_image。キャンバスと同じ大きさの白黒の画像) を付けられる。
クリップグループの最前面の子 (マスクの形) は線・塗りを描かないが、値は残す (解除で元に戻る)。

座標はすべて画像ピクセル座標 (原点は左下、Blender と同じ)。
色は sRGB の値 (COLOR_GAMMA) で保存する。
rotation はパス・グループでは「選択枠の傾き」、図形では図形そのものの回転 (ラジアン)。
"""

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    IntVectorProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

SCHEMA_VERSION = 8  # 0/1=v0.3.x, 2=v0.4-0.5(レイヤー無), 3=v0.6(塗りの規則無), 4=v0.7(塗り/線は1つ),
#                    5=v0.8-0.9(文字なし), 6=v0.10(点文字のみ), 7=v0.28.3まで(元の画像は固定の下地)

STYLE_PROPS = ("stroke_enable", "stroke_width", "stroke_color", "fill_enable", "fill_color")
SHAPE_PROPS = ("shape_type", "center", "size", "corner_radius", "sides", "star_points",
               "inner_ratio")

SHAPE_TYPES = (
    ('RECT', "矩形", "矩形 (角の半径で角丸にもなる)", 'MESH_PLANE', 0),
    ('ELLIPSE', "楕円", "楕円", 'MESH_CIRCLE', 1),
    ('POLYGON', "多角形", "正多角形", 'SEQ_CHROMA_SCOPE', 2),
    ('STAR', "星", "星形", 'SOLO_OFF', 3),
)

BLEND_MODES = (
    ('NORMAL', "通常", ""),
    ('DARKEN', "比較（暗）", ""),
    ('MULTIPLY', "乗算", ""),
    ('COLOR_BURN', "焼き込みカラー", ""),
    ('LIGHTEN', "比較（明）", ""),
    ('SCREEN', "スクリーン", ""),
    ('COLOR_DODGE', "覆い焼きカラー", ""),
    ('OVERLAY', "オーバーレイ", ""),
    ('SOFT_LIGHT', "ソフトライト", ""),
    ('HARD_LIGHT', "ハードライト", ""),
    ('DIFFERENCE', "差の絶対値", ""),
    ('EXCLUSION', "除外", ""),
    ('HUE', "色相", ""),
    ('SATURATION', "彩度", ""),
    ('COLOR', "カラー", ""),
    ('LUMINOSITY', "輝度", ""),
)

# レイヤーの選択枠の色 (Illustrator の既定色の順)
LAYER_COLORS = (
    (0.31, 0.50, 1.00), (1.00, 0.31, 0.31), (0.31, 1.00, 0.31), (0.31, 0.31, 1.00),
    (1.00, 1.00, 0.31), (1.00, 0.31, 1.00), (0.31, 1.00, 1.00), (0.50, 0.50, 0.50),
)

CORNER_TYPES = (('ROUND', "丸", "角を丸くする"),
                ('BEVEL', "面取り", "角を直線で切り落とす"),
                ('INVERTED', "内側の丸", "角を内側にえぐる"))

STROKE_CAPS = (('BUTT', "なし", "線をそのまま切る"),
               ('ROUND', "丸", "丸く出っ張る"),
               ('SQUARE', "四角", "四角く出っ張る"))
STROKE_JOINS = (('MITER', "マイター", "角を尖らせる"),
                ('ROUND', "丸", "角を丸める"),
                ('BEVEL', "ベベル", "角を切り落とす"))
STROKE_ALIGNS = (('CENTER', "中央", "パスの上に線の中心を置く"),
                 ('INSIDE', "内側", "パスの内側にだけ線を描く (閉じた形のみ)"),
                 ('OUTSIDE', "外側", "パスの外側にだけ線を描く (閉じた形のみ)"))
PAINT_TYPES = (('SOLID', "単色", ""),
               ('LINEAR', "線形グラデーション", ""),
               ('RADIAL', "円形グラデーション", ""))

# 新しいオブジェクトの初期の塗り・線 (以後は「最後に使ったもの」を引き継ぐ)
DEFAULT_FILL = (1.0, 0.8, 0.2, 1.0)
DEFAULT_STROKE = (0.0, 0.0, 0.0, 1.0)
DEFAULT_STROKE_WIDTH = 2.0      # 8px は太すぎた (2026-09-21 ユーザー確認)
DEFAULT_TEXT_FILL = (0.0, 0.0, 0.0, 1.0)

_guard = {"active": 0}


def owner_image(pg):
    idd = getattr(pg, "id_data", None)
    return idd if isinstance(idd, bpy.types.Image) else None


def _lock_changed(self, context):
    from . import alpha_tools
    alpha_tools.lock_changed(self, context)


def _upd(self, context):
    from . import render
    render.request_render(owner_image(self))


def _on_active(self, context):
    """一覧でオブジェクトをクリックしたら、そのオブジェクトを選択する。
    レイヤーをクリックした時は選択を変えない (そのレイヤーが描き込み先になる)。"""
    vs = self
    _remember_style(vs)
    if _guard["active"]:
        return
    act = active_object(vs)
    if act is None or act.kind in {'LAYER', 'ADJUST'}:
        return
    if not is_editable(vs, act.uid):
        # ロック中・非表示のものは選べない。それでも押したのはこの行なので、ほかの選択は外す
        # (外さないと「レイヤーへ移動」で前に選んでいた別のものが動いた。2026-09-27)
        for ob in vs.objects:
            ob.select = False
        from . import render
        render.tag_redraw_all()
        return
    for i, ob in enumerate(vs.objects):
        ob.select = (i == vs.active_index)
    from . import render
    render.tag_redraw_all()


def _remember_style(vs):
    """最後に使ったスタイルの持ち主を覚えておく (文字と図形は別々に覚える)。"""
    act = active_object(vs)
    if act is None:
        return
    if act.kind in {'PATH', 'SHAPE'} and vs.style_uid != act.uid:
        vs.style_uid = act.uid
    elif act.kind == 'TEXT' and vs.text_style_uid != act.uid:
        vs.text_style_uid = act.uid


def set_active(vs, index):
    """選択状態を変えずにアクティブだけ変える。"""
    _guard["active"] += 1
    try:
        vs.active_index = index
    finally:
        _guard["active"] -= 1


def _on_lock(self, context):
    """ロックしたら、そのオブジェクトと中身の選択を外す。"""
    if not self.locked:
        return
    vs = owner_image(self).vstroke
    uids = {self.uid} | set(descendants(vs, self.uid))
    for ob in vs.objects:
        if ob.uid in uids:
            ob.select = False
            for sp in ob.subpaths:
                for p in sp.points:
                    p.select = False
    from . import render
    render.tag_redraw_all()


# -----------------------------------------------------------------------------
# PropertyGroup
# -----------------------------------------------------------------------------

def _point_place(pt):
    """点の (画像, オブジェクト, si, pi)。path_from_id は
    'vstroke.objects[3].subpaths[0].points[2]' のような形。"""
    import re
    img = owner_image(pt)
    nums = [int(x) for x in re.findall(r"\[(\d+)\]", pt.path_from_id())]
    ob = img.vstroke.objects[nums[0]]
    return img, ob, nums[1], nums[2]


def _corner_max(ob, si, pi):
    from . import corners
    info = corners.corner_info(ob, si, pi)
    return corners.max_radius(*info) if info is not None else 0.0


def _corner_pct_get(self):
    try:
        img, ob, si, pi = _point_place(self)
    except Exception:
        return 0.0
    m = _corner_max(ob, si, pi)
    return 0.0 if m <= 1e-9 else min(float(self.corner_radius) / m * 100.0, 100.0)


def _corner_pct_set(self, value):
    try:
        img, ob, si, pi = _point_place(self)
    except Exception:
        return
    m = _corner_max(ob, si, pi)
    self.corner_radius = max(min(float(value), 100.0), 0.0) / 100.0 * m
    # キャンバスで、いま触っている角を少しのあいだ強調する
    import time
    from . import state
    state.corner_focus = (img.name, ob.uid, si, pi, time.monotonic())
    _redraw_after_focus()


def _focus_redraw():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == 'IMAGE_EDITOR':
                a.tag_redraw()
    return None


def _redraw_after_focus():
    """強調を消すために、時間がたったらもう一度描き直す (つまみを動かしている間は延ばす)。"""
    from . import state
    if bpy.app.timers.is_registered(_focus_redraw):
        bpy.app.timers.unregister(_focus_redraw)
    bpy.app.timers.register(_focus_redraw, first_interval=state.CORNER_FOCUS_SECONDS + 0.1)


class VS_Point(PropertyGroup):
    co: FloatVectorProperty(size=2)
    handle_left: FloatVectorProperty(size=2)
    handle_right: FloatVectorProperty(size=2)
    select: BoolProperty(default=False)
    # 角ごとの丸め (Illustrator のライブコーナー)。0 なら尖ったまま
    corner_radius: FloatProperty(name="角の半径", default=0.0, min=0.0, soft_max=500.0,
                                 subtype='PIXEL', update=_upd)
    # サイドバーの「各角の丸み」用。その角で丸められる限界 (丸印をいちばん外まで
    # ドラッグしたとき) を 100% とした割合。保存するのは corner_radius (px) の方
    corner_pct: FloatProperty(name="丸み", min=0.0, max=100.0, subtype='PERCENTAGE',
                              get=_corner_pct_get, set=_corner_pct_set,
                              description="この角の丸み。100% はこの角で丸められる限界")
    corner_type: EnumProperty(name="角の形", items=CORNER_TYPES, default='ROUND',
                              update=_upd)


class VS_Stop(PropertyGroup):
    """グラデーションの分岐点。"""
    position: FloatProperty(name="位置", default=0.0, min=0.0, max=1.0,
                            subtype='FACTOR', update=_upd)
    color: FloatVectorProperty(name="色", size=4, subtype='COLOR_GAMMA', min=0.0, max=1.0,
                               default=(1.0, 1.0, 1.0, 1.0), update=_upd)


class VS_Paint(PropertyGroup):
    """塗り、または線。1つのオブジェクトに何個でも持てる
    (この並びの先頭から順に描く = 先頭が奥。サイドバーの表示は種類ごとに分けて逆向き。ui._draw_fills・_draw_strokes)。"""
    kind: EnumProperty(name="種類", items=(('FILL', "塗り", ""), ('STROKE', "線", "")),
                       default='FILL', update=_upd)
    enabled: BoolProperty(name="表示", default=True, update=_upd)
    paint_type: EnumProperty(name="塗り方", items=PAINT_TYPES, default='SOLID',
                             update=lambda self, ctx: _on_paint_type(self, ctx))
    color: FloatVectorProperty(name="色", size=4, subtype='COLOR_GAMMA', min=0.0, max=1.0,
                               default=(0.0, 0.0, 0.0, 1.0), update=_upd)
    stops: CollectionProperty(type=VS_Stop)
    active_stop: IntProperty(default=0)
    # グラデーションの位置 (画像座標)。線形: 始点と終点 / 円形: 中心と外周の点
    g_start: FloatVectorProperty(name="始点", size=2, update=_upd)
    g_end: FloatVectorProperty(name="終点", size=2, default=(100.0, 0.0), update=_upd)
    # 線のときだけ使う
    width: FloatProperty(name="線幅", default=8.0, min=0.0, soft_max=200.0,
                         subtype='PIXEL', update=_upd)
    cap: EnumProperty(name="端の形", items=STROKE_CAPS, default='ROUND', update=_upd)
    join: EnumProperty(name="角の形", items=STROKE_JOINS, default='ROUND', update=_upd)
    miter_limit: FloatProperty(name="角の比率", default=4.0, min=1.0, soft_max=20.0,
                               update=_upd,
                               description="マイターの角が尖りすぎたらベベルに切り替える比率")
    align: EnumProperty(name="線の位置", items=STROKE_ALIGNS, default='CENTER', update=_upd)
    dash_enable: BoolProperty(name="破線", default=False, update=_upd)
    dash: FloatVectorProperty(name="線分と間隔", size=6, min=0.0, subtype='XYZ_LENGTH',
                              default=(12.0, 6.0, 0.0, 0.0, 0.0, 0.0), update=_upd,
                              description="線分・間隔を3組まで (0 は使わない)")
    dash_offset: FloatProperty(name="開始位置", default=0.0, subtype='PIXEL', update=_upd)


def object_of_paint(paint):
    """その塗り/線を持っているオブジェクトを探す。"""
    img = owner_image(paint)
    if img is None:
        return None
    ptr = paint.as_pointer()
    for ob in img.vstroke.objects:
        for p in ob.paints:
            if p.as_pointer() == ptr:
                return ob
    return None


def _on_font(self, context):
    """書体を変えたとき、そのスタイルが無ければ選び直す。"""
    from . import fonts
    try:
        f = fonts.find(self.font_family, self.font_style)
        if f is None:
            self.font_style = fonts.default_style(self.font_family)
        elif f.style != self.font_style:
            self.font_style = f.style       # 無いスタイル名は、太さの近い実在のものへ
        refresh_font_lists(fonts.resolve_family(self.font_family))
    except Exception:
        pass
    _upd(self, context)


def _on_paint_type(self, context):
    if self.paint_type != 'SOLID':
        from . import geometry as G
        ob = object_of_paint(self)
        b = G.bounds_in_frame(G.polylines(G.object_subpaths(ob))) if ob is not None else None
        ensure_gradient_stops(self, b)
    _upd(self, context)


class VS_TextStyle(PropertyGroup):
    """文字の一部だけに付ける見た目 (Illustrator・Affinity と同じ「文字単位の書式」)。
    use_* が False の項目は、オブジェクト全体の設定をそのまま使う。"""
    use_family: BoolProperty(default=False)
    font_family: StringProperty(name="書体", default="", update=_upd)
    use_style: BoolProperty(default=False)
    font_style: StringProperty(name="スタイル", default="", update=_upd)
    use_size: BoolProperty(default=False)
    font_size: FloatProperty(name="文字サイズ", default=72.0, min=1.0, step=100, precision=1,
                             subtype='PIXEL', update=_upd)      # 上限なし (下限だけ)
    use_tracking: BoolProperty(default=False)
    tracking: FloatProperty(name="字間", default=0.0, min=-500.0, max=2000.0, update=_upd)
    # カーニング: この字の**前**に空ける量 (1/1000 em)。文字と文字の間にカーソルを置いて
    # 変えると、カーソルのうしろの字に付く (2026-10-18 追加)
    use_kern: BoolProperty(default=False)
    kern: FloatProperty(name="カーニング", default=0.0, min=-1000.0, max=1000.0, update=_upd)
    # 比率 (%)。Illustrator の「水平比率」「垂直比率」
    use_scale_x: BoolProperty(default=False)
    scale_x: FloatProperty(name="水平比率", default=100.0, min=1.0, max=1000.0, update=_upd)
    use_scale_y: BoolProperty(default=False)
    scale_y: FloatProperty(name="垂直比率", default=100.0, min=1.0, max=1000.0, update=_upd)


class VS_TextLine(PropertyGroup):
    """文字オブジェクトの1行分。サイドバーではこの欄に日本語変換で入力できる。"""
    text: StringProperty(name="文字", default="", update=_upd)
    # 1文字につき1文字の「見た目の番号」。'0' = そのまま、'1' 以降は text_styles の何番目か
    styles: StringProperty(default="", options={'HIDDEN'})


class VS_Subpath(PropertyGroup):
    points: CollectionProperty(type=VS_Point)
    closed: BoolProperty(name="閉じる", default=False, update=_upd)


class VS_Object(PropertyGroup):
    uid: IntProperty(default=0)
    name: StringProperty(default="Path")
    kind: EnumProperty(name="種類", items=(
        ('PATH', "パス", ""), ('SHAPE', "図形", ""), ('TEXT', "文字", ""),
        ('IMAGE', "画像", ""), ('GROUP', "グループ", ""),
        ('LAYER', "レイヤー", ""),
        ('ADJUST', "調整レイヤー", "")), default='PATH')   # 保存は番号なので、足すのは最後に
    parent_uid: IntProperty(default=0)  # 0 = 最上位
    visible: BoolProperty(name="表示", default=True, update=_upd)
    locked: BoolProperty(name="ロック", default=False, update=_on_lock,
                         description="ロックすると選択・編集できなくなる")
    select: BoolProperty(default=False)
    opacity: FloatProperty(name="不透明度", default=1.0, min=0.0, max=1.0,
                           subtype='FACTOR', update=_upd)
    blend_mode: EnumProperty(name="描画モード", items=BLEND_MODES, default='NORMAL',
                             update=_upd)
    clip: BoolProperty(name="クリッピングマスク", default=False, update=_upd,
                       description="最前面の子の形で、他の子を切り抜く")
    layer_color: FloatVectorProperty(name="レイヤーの色", size=3, subtype='COLOR',
                                     min=0.0, max=1.0, default=LAYER_COLORS[0],
                                     description="選択したときの枠の色")
    rotation: FloatProperty(name="角度", default=0.0, subtype='ANGLE', update=_upd)
    expanded: BoolProperty(name="開く", default=True)
    subpaths: CollectionProperty(type=VS_Subpath)
    paints: CollectionProperty(type=VS_Paint)     # 塗りと線 (先頭から順に描く = 先頭が奥)
    active_paint: IntProperty(default=0)
    # 角を丸くする (パス・図形の角。0 で無効)
    corner_round: FloatProperty(name="角を丸くする", default=0.0, min=0.0, soft_max=200.0,
                                subtype='PIXEL', update=_upd,
                                description="尖った角を、この半径で丸くする (形は元のまま残る)")
    # エフェクト (オブジェクト・グループ・レイヤーごと)
    fx_shadow_enable: BoolProperty(name="ドロップシャドウ", default=False, update=_upd)
    fx_shadow_offset: FloatVectorProperty(name="位置", size=2, default=(6.0, -6.0),
                                          subtype='XYZ_LENGTH', update=_upd,
                                          description="影のずれ (Y は + が上)")
    fx_shadow_blur: FloatProperty(name="ぼかし", default=6.0, min=0.0, soft_max=100.0,
                                  subtype='PIXEL', update=_upd)
    fx_shadow_color: FloatVectorProperty(name="影の色", size=4, subtype='COLOR_GAMMA',
                                         min=0.0, max=1.0, default=(0.0, 0.0, 0.0, 0.5),
                                         update=_upd)
    fx_blur_enable: BoolProperty(name="ぼかし", default=False, update=_upd)
    fx_blur_amount: FloatProperty(name="ぼかしの強さ", default=6.0, min=0.0, soft_max=100.0,
                                  subtype='PIXEL', update=_upd)
    fx_glow_enable: BoolProperty(name="光彩", default=False, update=_upd)
    fx_glow_kind: EnumProperty(name="光彩の向き", default='OUTER', update=_upd, items=(
        ('OUTER', "外側", "形の外側をぼんやり光らせる"),
        ('INNER', "内側", "形の内側の縁をぼんやり光らせる")))
    fx_glow_size: FloatProperty(name="広がり", default=10.0, min=0.0, soft_max=100.0,
                                subtype='PIXEL', update=_upd)
    fx_glow_color: FloatVectorProperty(name="光の色", size=4, subtype='COLOR_GAMMA',
                                       min=0.0, max=1.0, default=(1.0, 0.9, 0.3, 0.8),
                                       update=_upd)
    # 粒子 (フィルムの粒のようなざらつき。2026-09-25 ユーザー要望)
    fx_grain_enable: BoolProperty(name="粒子", default=False, update=_upd)
    fx_grain_amount: FloatProperty(name="強さ", default=0.25, min=0.0, max=1.0,
                                   subtype='FACTOR', update=_upd,
                                   description="明るさを上下させる幅")
    fx_grain_size: FloatProperty(name="粒の大きさ", default=1.0, min=1.0, soft_max=20.0,
                                 subtype='PIXEL', update=_upd,
                                 description="1 で画素ごとの細かい粒。大きくするほど粗くなる")
    fx_grain_mono: BoolProperty(name="モノクロ", default=True, update=_upd,
                                description="明るさだけを揺らす (切ると色も少しずつ揺れる)")
    # ミラー (キャンバスの中心で、片側を反対側へ写す。2026-09-25 ユーザーのアドオン
    # Texture Paint 2D Mirror を統合。元の絵は変えない。ベクターにもペイントレイヤーにも)
    fx_mirror_enable: BoolProperty(name="ミラー", default=False, update=_upd)
    fx_mirror_mode: EnumProperty(name="向き", default='L2R', update=_upd, items=(
        ('L2R', "左→右", "左半分を、右半分へ反転して写す"),
        ('R2L', "右→左", "右半分を、左半分へ反転して写す"),
        ('T2B', "上→下", "上半分を、下半分へ反転して写す"),
        ('B2T', "下→上", "下半分を、上半分へ反転して写す")))
    # 文字のパラメーター (kind == TEXT)
    text_lines: CollectionProperty(type=VS_TextLine)
    text_styles: CollectionProperty(type=VS_TextStyle)   # 文字単位の書式の一覧
    font_family: StringProperty(name="書体", default="", update=_on_font)
    font_style: StringProperty(name="スタイル", default="", update=_upd)
    font_size: FloatProperty(name="文字サイズ", default=72.0, min=1.0, step=100, precision=1,
                             subtype='PIXEL', update=_upd)      # 上限なし (下限だけ)
    line_spacing: FloatProperty(name="行の間隔", default=1.5, min=0.1, soft_max=4.0,
                                update=_upd,
                                description="文字サイズの何倍ずつ下に送るか")
    tracking: FloatProperty(name="字間", default=0.0, min=-500.0, max=1000.0, update=_upd,
                            description="文字と文字の間を広げる量 (文字サイズの1/1000単位)")
    text_align: EnumProperty(name="行揃え", default='LEFT', update=_upd, items=(
        ('LEFT', "左揃え", ""), ('CENTER', "中央揃え", ""), ('RIGHT', "右揃え", "")))
    text_origin: FloatVectorProperty(name="文字の基準点", size=2, update=_upd,
                                     description="1行目のベースラインの始まり")
    text_mat: FloatVectorProperty(name="文字の変形", size=4, default=(1.0, 0.0, 0.0, 1.0),
                                  update=_upd)
    text_kind: EnumProperty(name="文字の種類", default='POINT', update=_upd, items=(
        ('POINT', "点文字", "クリックした位置から、改行するまで1行で伸びる"),
        ('AREA', "エリア文字", "枠の中に流し込む (枠の幅で自動的に折り返す)"),
        ('PATH', "パス上文字", "パスの形に沿って並べる")))
    text_box: FloatVectorProperty(name="枠の大きさ", size=2, default=(300.0, 150.0),
                                  min=1.0, subtype='XYZ_LENGTH', update=_upd,
                                  description="エリア文字の枠の幅と高さ")
    text_box_align: EnumProperty(
        name="枠の中の位置", default='TOP', update=_upd,
        description="エリア文字を、枠の中のどこに寄せるか (縦書きでは 上=右 / 下=左)",
        items=(('TOP', "上ぞろえ", "枠の上から並べる (縦書きでは右から)"),
               ('CENTER', "中央", "枠の中央に寄せる"),
               ('BOTTOM', "下ぞろえ", "枠の下に寄せる (縦書きでは左に)")))
    text_vertical: BoolProperty(name="縦書き", default=False, update=_upd,
                                description="上から下へ、行は右から左へ並べる")
    text_path_offset: FloatProperty(name="開始位置", default=0.0, subtype='PIXEL',
                                    update=_upd,
                                    description="パスに沿って、どれだけずらして始めるか")
    text_path_flip: BoolProperty(name="パスの反対側", default=False, update=_upd,
                                 description="文字をパスの反対側に回す")
    text_path_align: EnumProperty(name="パスとの位置", default='BASELINE', update=_upd,
                                  items=(('BASELINE', "ベースライン", "文字の足もとをパスに乗せる"),
                                         ('CENTER', "中央", "文字の中心をパスに合わせる"),
                                         ('TOP', "上", "文字の上をパスに合わせる"),
                                         ('BOTTOM', "下", "文字の下をパスに合わせる")))
    # 読み込んだ画像 (kind == IMAGE)
    image: PointerProperty(type=bpy.types.Image, name="画像")
    img_origin: FloatVectorProperty(name="画像の位置", size=2, update=_upd,
                                    description="画像の左下の位置")
    img_mat: FloatVectorProperty(name="画像の変形", size=4, default=(1.0, 0.0, 0.0, 1.0),
                                 update=_upd)
    img_paint: BoolProperty(default=False)   # ブラシで描くために作ったレイヤーか
    # レイヤーマスク (Photoshop と同じ。白 = 見える、黒 = 隠れる、灰色 = 半透明。
    # 透明な所は白と同じ)。キャンバスと同じ大きさで、キャンバスにぴったり重ねる
    mask_image: PointerProperty(type=bpy.types.Image, name="レイヤーマスク")
    mask_enable: BoolProperty(name="マスクを使う", default=True, update=_upd,
                              description="オフにすると、マスクが無いときと同じに見える "
                                          "(マスクの絵は残る)")
    # ブラシを選んだとき、中身ではなくマスクに描くか (Photoshop でマスクのサムネールを選んだ状態)
    mask_target: BoolProperty(default=False)
    # 有効化したときの元の画像 (一番下のペイントレイヤー)。書き出しの「元の画像も含める」で使う
    img_original: BoolProperty(default=False)
    # 透明部分をロック (ペイントレイヤー。ブラシで描いても、薄い所には入らない。
    # 2026-09-25 ユーザーのアドオン Alpha Paint Lock を統合。alpha_tools.py)
    paint_lock_alpha: BoolProperty(
        name="透明部分をロック", default=False,
        update=lambda self, ctx: _lock_changed(self, ctx),
        description="ブラシで描いても、アルファがしきい値より小さい所 (透明な所) には描かれない")
    paint_lock_threshold: FloatProperty(
        name="ロックのしきい値", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
        update=lambda self, ctx: _lock_changed(self, ctx),
        description="描き始めたときに、アルファがこれより小さかった所を守る")
    # 遠近変形 (4隅を自由に動かす。2026-09-22 ユーザー要望)。img_quad_on のあいだは
    # img_mat / img_origin ではなく、この4隅 (左下・右下・右上・左上。画像座標) で置く
    img_quad_on: BoolProperty(default=False, update=_upd)
    img_quad: FloatVectorProperty(size=8, update=_upd)
    # トリミング (2026-10-18 ユーザー要望)。元の画像の見せる範囲を、左下を原点にした
    # 割合 (左, 下, 右, 上) で持つ。画素は消さないので、いつでも元に戻せる
    img_crop: FloatVectorProperty(name="トリミング", size=4, default=(0.0, 0.0, 1.0, 1.0),
                                  min=0.0, max=1.0, update=_upd)
    crop_left: FloatProperty(name="左", min=0.0, subtype='PIXEL', precision=0,
                             get=lambda s: _crop_get(s, 0), set=lambda s, v: _crop_set(s, 0, v),
                             description="左から切り取る幅 (元の画像の画素)")
    crop_right: FloatProperty(name="右", min=0.0, subtype='PIXEL', precision=0,
                              get=lambda s: _crop_get(s, 2), set=lambda s, v: _crop_set(s, 2, v),
                              description="右から切り取る幅 (元の画像の画素)")
    crop_top: FloatProperty(name="上", min=0.0, subtype='PIXEL', precision=0,
                            get=lambda s: _crop_get(s, 3), set=lambda s, v: _crop_set(s, 3, v),
                            description="上から切り取る高さ (元の画像の画素)")
    crop_bottom: FloatProperty(name="下", min=0.0, subtype='PIXEL', precision=0,
                               get=lambda s: _crop_get(s, 1), set=lambda s, v: _crop_set(s, 1, v),
                               description="下から切り取る高さ (元の画像の画素)")
    # 画像補正 (その画像だけにかかる。元の画像は変えない。2026-09-22 ユーザー要望)
    adj_exposure: FloatProperty(name="露光量", default=0.0, soft_min=-3.0, soft_max=3.0,
                                update=_upd, description="明るさを段 (2倍・半分) で変える")
    adj_brightness: FloatProperty(name="明るさ", default=0.0, min=-1.0, max=1.0,
                                  subtype='FACTOR', update=_upd)
    adj_contrast: FloatProperty(name="コントラスト", default=0.0, min=-1.0, max=1.0,
                                subtype='FACTOR', update=_upd)
    adj_black: FloatProperty(name="黒", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
                             update=_upd, description="レベル補正: これより暗い所を真っ黒にする")
    adj_white: FloatProperty(name="白", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                             update=_upd, description="レベル補正: これより明るい所を真っ白にする")
    adj_gamma: FloatProperty(name="中間", default=1.0, min=0.1, max=10.0, soft_max=4.0,
                             update=_upd,
                             description="レベル補正: 中間の明るさ (1より大きいと明るく)")
    adj_hue: FloatProperty(name="色相", default=0.0, min=-0.5, max=0.5, subtype='FACTOR',
                           update=_upd, description="色合いを回す (0.5 で半周)")
    adj_saturation: FloatProperty(name="彩度", default=0.0, min=-1.0, max=1.0,
                                  subtype='FACTOR', update=_upd,
                                  description="-1 で白黒、+ で鮮やかに")
    adj_lightness: FloatProperty(name="明度", default=0.0, min=-1.0, max=1.0,
                                 subtype='FACTOR', update=_upd,
                                 description="+ で白に、- で黒に近づける")
    adj_temperature: FloatProperty(name="色温度", default=0.0, min=-1.0, max=1.0,
                                   subtype='FACTOR', update=_upd,
                                   description="+ で暖かい色 (黄・赤)、- で冷たい色 (青)")
    adj_invert: BoolProperty(name="階調の反転", default=False, update=_upd)
    adj_alpha_cut: FloatProperty(
        name="アルファのしきい値", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
        update=_upd,
        description="これより薄い (アルファが小さい) 所を透明にする。0 で何もしない "
                    "(元の絵は変えない。2026-09-25 ユーザーのアドオン Alpha Threshold Cutoff を統合)")
    # 図形のパラメーター
    shape_type: EnumProperty(name="図形", items=SHAPE_TYPES, default='RECT', update=_upd)
    center: FloatVectorProperty(name="中心", size=2, update=_upd)
    size: FloatVectorProperty(name="大きさ", size=2, default=(100.0, 100.0), update=_upd)
    corner_radius: FloatProperty(name="角の半径", default=0.0, min=0.0, soft_max=500.0,
                                 subtype='PIXEL', update=_upd)
    sides: IntProperty(name="辺の数", default=6, min=3, soft_max=64, update=_upd)
    star_points: IntProperty(name="頂点の数", default=5, min=3, soft_max=64, update=_upd)
    inner_ratio: FloatProperty(name="内側の半径", default=0.5, min=0.01, max=1.0,
                               subtype='FACTOR', update=_upd,
                               description="外側の半径に対する内側の半径の割合")
    # スタイル
    stroke_enable: BoolProperty(name="線", default=True, update=_upd)
    stroke_width: FloatProperty(name="線幅", default=8.0, min=0.0,
                                soft_max=200.0, subtype='PIXEL', update=_upd)
    stroke_color: FloatVectorProperty(name="線の色", size=4, subtype='COLOR_GAMMA',
                                      min=0.0, max=1.0,
                                      default=(0.0, 0.0, 0.0, 1.0), update=_upd)
    fill_enable: BoolProperty(name="塗り", default=False, update=_upd)
    fill_rule: EnumProperty(
        name="塗りの規則", default='NONZERO', update=_upd, items=(
            ('NONZERO', "重なりを塗る", "自己交差する形の中心も塗る (Illustrator の初期設定)"),
            ('EVENODD', "重なりを抜く", "重なった部分を抜く (穴あき図形を作れる)")))
    fill_color: FloatVectorProperty(name="塗りの色", size=4, subtype='COLOR_GAMMA',
                                    min=0.0, max=1.0,
                                    default=(1.0, 0.8, 0.2, 1.0), update=_upd)


class VS_LegacyPath(PropertyGroup):
    """v0.3.x の VS_Path。旧ファイルを読むためだけに残している。"""
    name: StringProperty(default="Path")
    points: CollectionProperty(type=VS_Point)
    visible: BoolProperty(default=True)
    closed: BoolProperty(default=False)
    stroke_enable: BoolProperty(default=True)
    stroke_width: FloatProperty(default=8.0)
    stroke_color: FloatVectorProperty(size=4, default=(0.0, 0.0, 0.0, 1.0))
    fill_enable: BoolProperty(default=False)
    fill_color: FloatVectorProperty(size=4, default=(1.0, 0.8, 0.2, 1.0))


# サイドバーの位置・大きさ・角度の欄 (選択中のオブジェクトから計算し、入力で変形する)
def _xf_get(key):
    def get(self):
        from . import transform
        return transform.proxy_get(owner_image(self), key)
    return get


def _xf_set(key):
    def set_(self, value):
        from . import transform
        transform.proxy_set(owner_image(self), key, value)
    return set_


class VS_Transform(PropertyGroup):
    x: FloatProperty(name="X", subtype='PIXEL', get=_xf_get("x"), set=_xf_set("x"),
                     description="選択範囲の中心の X 座標")
    y: FloatProperty(name="Y", subtype='PIXEL', get=_xf_get("y"), set=_xf_set("y"),
                     description="選択範囲の中心の Y 座標 (下が 0)")
    w: FloatProperty(name="幅", subtype='PIXEL', get=_xf_get("w"), set=_xf_set("w"))
    h: FloatProperty(name="高さ", subtype='PIXEL', get=_xf_get("h"), set=_xf_set("h"))
    angle: FloatProperty(name="角度", subtype='ANGLE', get=_xf_get("angle"),
                         set=_xf_set("angle"))


def _corner_refs(vs):
    from . import corners, transform
    items = transform.selected_items(vs)
    if not items:
        act = active_object(vs)
        items = [act.uid] if act is not None and act.kind == 'PATH' else []
    return corners.target_points(vs, items)


def _corner_radius_get(self):
    from . import corners
    img = owner_image(self)
    return 0.0 if img is None else corners.common_radius(img.vstroke,
                                                         _corner_refs(img.vstroke))


def _corner_radius_set(self, value):
    from . import corners, render
    img = owner_image(self)
    if img is None:
        return
    vs = img.vstroke
    with render.suspended():
        corners.set_radius(vs, _corner_refs(vs), value)
    render.render_image(img)


class VS_CornerProxy(PropertyGroup):
    """サイドバーの「角」の欄 (選んでいる角に効く)。"""
    radius: FloatProperty(name="角の半径", min=0.0, soft_max=500.0, subtype='PIXEL',
                          get=_corner_radius_get, set=_corner_radius_set,
                          description="選んでいる角の丸み (点を選んでいなければ全部の角)")


def selected_char_ranges():
    """文字ツールで今選んでいる文字 (オブジェクト, [(行, 始まり, 終わり)])。
    選んでいなければ (None, [])。"""
    from . import state
    tool = state.current_tool
    if tool is None or getattr(tool, "name", "") != 'TEXT':
        return None, []
    try:
        ranges = tool.selection_ranges()
        if not ranges:
            return None, []
        img = tool.image()
        vs = img.vstroke if img is not None else None
        ob = tool.editing_object(vs) if vs is not None else None
    except Exception:
        return None, []
    return (ob, ranges) if ob is not None else (None, [])


def caret_target():
    """文字ツールで、文字を選ばずにカーソルだけ置いているとき (オブジェクト, 行, 位置)。
    それ以外は None。カーニングはここ (文字と文字の間) に付ける。"""
    from . import state
    tool = state.current_tool
    if tool is None or getattr(tool, "name", "") != 'TEXT':
        return None
    try:
        if tool.edit is None or tool.selection_ranges():
            return None
        img = tool.image()
        vs = img.vstroke if img is not None else None
        ob = tool.editing_object(vs) if vs is not None else None
    except Exception:
        return None
    if ob is None:
        return None
    return ob, int(tool.edit["line"]), int(tool.edit["col"])


def _kern_get(self):
    got = caret_target()
    if got is None:
        return 0.0
    v = kern_at(*got)
    return 0.0 if v is None else v


def _kern_set(self, value):
    got = caret_target()
    if got is not None:
        set_kern(got[0], got[1], got[2], value)


def _attr_target(pg):
    """書式を表示・変更する相手。選んでいる文字があればそれ、無ければアクティブな文字。"""
    ob, ranges = selected_char_ranges()
    if ob is not None:
        return ob, ranges
    img = owner_image(pg)
    vs = img.vstroke if img is not None else None
    act = active_object(vs) if vs is not None else None
    return (act if act is not None and act.kind == 'TEXT' else None), []


def _attr_get(name, prop):
    def get(self):
        ob, ranges = _attr_target(self)
        if ob is None:
            return "" if isinstance(prop, str) else prop
        if ranges:
            v = common_char_attr(ob, ranges, name)
            if v is not None:
                return v
        return getattr(ob, prop) if isinstance(prop, str) else prop
    return get


def _attr_set(name):
    def set_(self, value):
        ob, ranges = selected_char_ranges()
        if ob is None or not ranges:
            return          # 文字を選んでいないときは何も変えない (ユーザー要望)
        kw = {name: value}
        if name == "family":
            # 書体を変えたら、スタイルも新しい書体に実際にあるものへ直す (前の書体の
            # 「Bold」が残り、見た目は Regular のまま、にならないように)
            from . import fonts
            sty = common_char_attr(ob, ranges, "style")
            f = fonts.find(value, ob.font_style if sty is None else sty)
            if f is not None:
                kw["style"] = f.style
        apply_char_style(ob, ranges, **kw)
    return set_


def _unique_styles(family):
    from . import fonts
    out = []
    for st in (fonts.styles(family) if family else []):
        if st not in out:
            out.append(st)
    return out


_style_items = []   # 選択肢の文字列は Blender が後から読むので、消えないように持っておく


def _style_choices(self, context):
    names = _unique_styles(self.font_family)
    items = [(str(i), st, "", i) for i, st in enumerate(names)] or [("0", "", "", 0)]
    _style_items[:] = items
    return items


def _style_choice_get(self):
    """今の書体に実際にあるスタイルのうち、使われているもの (名前が合わなければ太さの近いもの)。"""
    from . import fonts
    fam = self.font_family
    names = _unique_styles(fam)
    f = fonts.find(fam, self.font_style) if names else None
    return names.index(f.style) if f is not None and f.style in names else 0


def _style_choice_set(self, value):
    names = _unique_styles(self.font_family)
    if 0 <= value < len(names):
        self.font_style = names[value]


class VS_TextAttr(PropertyGroup):
    """サイドバーと上のバーの文字の欄。**選んでいる文字にだけ**効く
    (Affinity と同じ考え方。何も選んでいなければ何も変わらない)。"""
    font_family: StringProperty(
        name="書体", get=_attr_get("family", "font_family"), set=_attr_set("family"),
        description="選んでいる文字の書体")
    font_style: StringProperty(
        name="スタイル", get=_attr_get("style", "font_style"), set=_attr_set("style"),
        description="選んでいる文字のスタイル (太字・斜体など)")
    # サイドバーと上のバーに出す欄。選択肢はその場で書体から作るので、前の書体の一覧が
    # 残ることがない (前は WindowManager の一覧を作り直し忘れて出たり出なかったりした)
    font_style_choice: EnumProperty(
        name="スタイル", items=_style_choices, get=_style_choice_get, set=_style_choice_set,
        description="選んでいる文字のスタイル (太字・斜体など)")
    font_size: FloatProperty(
        name="文字サイズ", min=1.0, step=100, precision=1, subtype='PIXEL',   # 上限なし
        get=_attr_get("size", "font_size"), set=_attr_set("size"),
        description="選んでいる文字の大きさ")
    tracking: FloatProperty(
        name="字間", min=-500.0, max=2000.0,
        get=_attr_get("tracking", "tracking"), set=_attr_set("tracking"),
        description="選んでいる文字の字間 (1/1000 em)")
    # カーニング: 文字を選ばず、文字と文字の間にカーソルを置いたときに、その2文字の間を
    # 空ける・詰める (Illustrator と同じ。Alt+←/→ でも変えられる)
    kerning: FloatProperty(
        name="カーニング", min=-1000.0, max=1000.0, step=100, precision=0,
        get=_kern_get, set=_kern_set,
        description="カーソルの前後の2文字の間 (1/1000 em)。文字と文字の間に"
                    "カーソルを置いたときだけ変えられます")
    scale_x: FloatProperty(
        name="水平比率", min=1.0, max=1000.0, subtype='PERCENTAGE', precision=0,
        get=_attr_get("scale_x", 100.0), set=_attr_set("scale_x"),
        description="選んでいる文字の幅の比率 (100% がそのまま)")
    scale_y: FloatProperty(
        name="垂直比率", min=1.0, max=1000.0, subtype='PERCENTAGE', precision=0,
        get=_attr_get("scale_y", 100.0), set=_attr_set("scale_y"),
        description="選んでいる文字の高さの比率 (100% がそのまま)")


class VS_ImageData(PropertyGroup):
    enabled: BoolProperty(default=False)
    schema_version: IntProperty(default=0)
    base_image: PointerProperty(type=bpy.types.Image)
    objects: CollectionProperty(type=VS_Object)
    active_index: IntProperty(default=0, update=_on_active)
    next_uid: IntProperty(default=1)
    style_uid: IntProperty(default=0)       # 新しい図形・パスが引き継ぐスタイルの元
    text_style_uid: IntProperty(default=0)  # 新しい文字が引き継ぐスタイルの元
    live_update: BoolProperty(
        name="ドラッグ中もリアルタイム反映", default=True,
        description="オフにすると、ドラッグ中は枠線プレビューのみ、離した時に画像へ反映")
    scale_strokes: BoolProperty(
        name="線幅も拡大・縮小", default=False,
        description="オンにすると、拡大・縮小したときに線の太さも同じ割合で変わる")
    scale_corners: BoolProperty(
        name="角の丸みも拡大・縮小", default=True,
        description="オンにすると、拡大・縮小したときに角の丸みも同じ割合で変わる "
                    "(見た目の丸みが保たれる)")
    keep_ratio: BoolProperty(name="縦横比を固定", default=False,
                             description="幅か高さを入力したとき、もう一方も同じ割合で変える")
    align_to: EnumProperty(name="整列の基準", items=(
        ('SELECTION', "選択範囲", "選択したオブジェクト全体の範囲に揃える"),
        ('IMAGE', "画像", "画像全体に揃える")), default='SELECTION')
    # 最後に合わせたキャンバスの大きさ。画像の大きさがこれと違ったら、リサイズされたと
    # 見なして中身を合わせる (sync_canvas_size)。(0, 0) は「まだ覚えていない」
    canvas_size: IntVectorProperty(size=2, default=(0, 0))
    xform: PointerProperty(type=VS_Transform)
    corner: PointerProperty(type=VS_CornerProxy)
    text_attr: PointerProperty(type=VS_TextAttr)
    # ブラシで描いている間だけ使う (この画像は、どのキャンバスのどのレイヤーか)
    paint_owner: StringProperty(default="")
    paint_uid: IntProperty(default=0)
    paths: CollectionProperty(type=VS_LegacyPath)


class VS_FontName(PropertyGroup):
    """サイドバーの書体一覧の1項目 (name に書体名が入る)。保存はしない。"""
    label: StringProperty(default="")


# 今どの書体のスタイル一覧を作ってあるか (作り直しを減らすため)
_font_list_state = {"family": None, "count": 0}


def refresh_font_lists(family=None, force=False):
    """サイドバーの「書体」「スタイル」の候補一覧を作る。
    描画中には呼べないので、ファイルを開いた時・書体を変えた時などに呼ぶ。"""
    from . import fonts
    try:
        wm = bpy.context.window_manager
    except Exception:
        return
    if wm is None or not hasattr(wm, "vstroke_font_families"):
        return
    fams = fonts.families()
    if force or len(wm.vstroke_font_families) != len(fams):
        wm.vstroke_font_families.clear()
        for f in fams:
            wm.vstroke_font_families.add().name = f
        _font_list_state["family"] = None
    if family is None:
        return
    if not force and _font_list_state["family"] == family:
        return
    wm.vstroke_font_styles.clear()
    for st in fonts.styles(family):
        wm.vstroke_font_styles.add().name = st
    _font_list_state["family"] = family


def _guides_changed(self, context):
    from . import render
    render.tag_redraw_all()


class VS_ToolSettings(PropertyGroup):
    """図形ツールの設定 (ツールバー上部とサイドバーに表示。ファイルには保存しない)。"""
    shape_type: EnumProperty(name="図形", items=(
        ('RECT', "矩形", "", 'MESH_PLANE', 0),
        ('ROUNDED_RECT', "角丸矩形", "", 'MESH_PLANE', 1),
        ('ELLIPSE', "楕円", "", 'MESH_CIRCLE', 2),
        ('POLYGON', "多角形", "", 'SEQ_CHROMA_SCOPE', 3),
        ('STAR', "星", "", 'SOLO_OFF', 4)), default='RECT')
    corner_radius: FloatProperty(name="角の半径", default=20.0, min=0.0, subtype='PIXEL')
    sides: IntProperty(name="辺の数", default=6, min=3, soft_max=64)
    star_points: IntProperty(name="頂点の数", default=5, min=3, soft_max=64)
    inner_ratio: FloatProperty(name="内側の半径", default=0.5, min=0.01, max=1.0,
                               subtype='FACTOR')
    text_vertical: BoolProperty(name="縦書きで作る", default=False,
                                description="これから作る文字を縦書きにする")
    cut_threshold: FloatProperty(
        name="しきい値", default=0.1, min=0.0, max=1.0, subtype='FACTOR',
        description="アルファがこれより小さい所を、完全に透明にする")
    pencil_smooth: FloatProperty(
        name="滑らかさ", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
        description="鉛筆で描いた線を曲線にするとき、0 に近いほど手の動きに忠実、"
                    "1 に近いほど点が少なく滑らかにする")
    snap_enable: BoolProperty(
        name="スナップ", default=True,
        description="キャンバスの端や中心、他のオブジェクトの端・中心に吸い付かせる")
    show_uv: BoolProperty(
        name="UV", default=True, update=_guides_changed,
        description="アクティブなメッシュの UV の線をキャンバスに重ねて表示する "
                    "(ベクター編集中。ペイントモードでは Blender が表示する)")
    show_guides: BoolProperty(
        name="枠線", default=True, update=_guides_changed,
        description="オブジェクトの枠線・点・ハンドル・選択枠などの表示を切り替える。"
                    "切ると、仕上がりの見た目だけが表示される (編集はそのまま続けられる)")


# -----------------------------------------------------------------------------
# オブジェクトのヘルパー
# -----------------------------------------------------------------------------

def copy_style(dst, src):
    """スタイル (塗りと線、塗りの規則) をコピーする。"""
    for k in STYLE_PROPS:
        setattr(dst, k, getattr(src, k))
    dst.fill_rule = getattr(src, "fill_rule", 'NONZERO')
    dst.paints.clear()
    src_paints = getattr(src, "paints", None)
    if src_paints is None:                 # 旧データ (塗り/線が1つずつ) から
        paints_from_legacy(dst)
        return
    for sp in src_paints:
        copy_props(dst.paints.add(), sp)
    dst.active_paint = min(src.active_paint, max(len(dst.paints) - 1, 0))


def paints_from_legacy(ob):
    """v0.7 までの「塗り1つ・線1つ」から、paints を作る。"""
    ob.paints.clear()
    if ob.fill_enable:
        add_paint(ob, 'FILL', color=tuple(ob.fill_color))
    if ob.stroke_enable:
        add_paint(ob, 'STROKE', color=tuple(ob.stroke_color), width=ob.stroke_width)
    ob.active_paint = max(len(ob.paints) - 1, 0)


FX_PROPS = ("corner_round", "fx_shadow_enable", "fx_shadow_offset", "fx_shadow_blur",
            "fx_shadow_color", "fx_blur_enable", "fx_blur_amount", "fx_glow_enable",
            "fx_glow_kind", "fx_glow_size", "fx_glow_color",
            "fx_grain_enable", "fx_grain_amount", "fx_grain_size", "fx_grain_mono",
            "fx_mirror_enable", "fx_mirror_mode")


def has_mirror(ob):
    return bool(getattr(ob, "fx_mirror_enable", False))


def mirror_rect(b, mode, w, h):
    """範囲 (x0, y0, x1, y1) を、ミラーの軸 (キャンバスの中心) で反転した範囲。"""
    if mode in {'L2R', 'R2L'}:
        return (w - b[2], b[1], w - b[0], b[3])
    return (b[0], h - b[3], b[2], h - b[1])


def has_grain(ob):
    return bool(getattr(ob, "fx_grain_enable", False) and ob.fx_grain_amount > 0.0)


def has_effects(ob):
    """画像フィルターが要るエフェクトがあるか (内側の光彩は別扱い)。"""
    return bool(ob.fx_shadow_enable or (ob.fx_blur_enable and ob.fx_blur_amount > 0)
                or (ob.fx_glow_enable and ob.fx_glow_kind == 'OUTER' and ob.fx_glow_size > 0))


def effect_margin(ob):
    """エフェクトで形の外にはみ出す量 (描画範囲を広げるのに使う)。"""
    m = 0.0
    if ob.fx_blur_enable:
        m = max(m, ob.fx_blur_amount * 3.0)
    if ob.fx_glow_enable and ob.fx_glow_kind == 'OUTER':
        m = max(m, ob.fx_glow_size * 3.0)
    if ob.fx_shadow_enable:
        d = max(abs(ob.fx_shadow_offset[0]), abs(ob.fx_shadow_offset[1]))
        m = max(m, d + ob.fx_shadow_blur * 3.0)
    return m


def fills(ob):
    return [p for p in ob.paints if p.kind == 'FILL']


def strokes(ob):
    return [p for p in ob.paints if p.kind == 'STROKE']


def active_fill(ob):
    """一番上の塗り (無ければ None)。"""
    fs = [p for p in ob.paints if p.kind == 'FILL' and p.enabled]
    return fs[-1] if fs else None


def has_fill(ob):
    return any(p.kind == 'FILL' and p.enabled for p in ob.paints)


def has_stroke(ob):
    return any(p.kind == 'STROKE' and p.enabled and p.width > 0 for p in ob.paints)


def paint_is_opaque_somewhere(p):
    """塗り/線が、少しでも色が見える (アルファが 0 ではない) か。
    マスクの形として使うときの「通す部分」の判定に使う。"""
    if p.paint_type == 'SOLID' or len(p.stops) < 2:
        return p.color[3] > 0.0
    return any(st.color[3] > 0.0 for st in p.stops)


def mask_fill(ob):
    """マスクの形として、塗りの中を通すか。"""
    return any(p.kind == 'FILL' and p.enabled and paint_is_opaque_somewhere(p)
               for p in ob.paints)


def mask_strokes(ob):
    """マスクの形として通す線の一覧 [(幅, 位置 'CENTER'/'INSIDE'/'OUTSIDE')]。
    線が無い・透明なら空。"""
    out = []
    aligned = can_align_stroke(ob)
    for p in ob.paints:
        if (p.kind != 'STROKE' or not p.enabled or p.width <= 0
                or not paint_is_opaque_somewhere(p)):
            continue
        out.append((float(p.width), p.align if aligned else 'CENTER'))
    return out


def can_align_stroke(ob):
    """線の「内側/外側」を使えるか (閉じた形だけ。開いたパスでは意味がない)。"""
    if ob is None:
        return False
    if ob.kind in {'SHAPE', 'TEXT'}:
        return True
    if ob.kind != 'PATH':
        return False
    return any(sp.closed and len(sp.points) >= 3 for sp in ob.subpaths)


def stroke_extent(ob):
    """線がパスからどれだけ外へはみ出すか (当たり判定や範囲の計算用)。"""
    out = 0.0
    aligned = can_align_stroke(ob)      # 開いたパスでは内側/外側は効かない
    for p in ob.paints:
        if p.kind != 'STROKE' or not p.enabled or p.width <= 0:
            continue
        align = p.align if aligned else 'CENTER'
        out = max(out, p.width if align == 'OUTSIDE' else
                  (0.0 if align == 'INSIDE' else p.width * 0.5))
    return out


def add_paint(ob, kind='FILL', color=None, width=None):
    """塗りか線を一番上に足す。"""
    p = ob.paints.add()
    p.kind = kind
    if color is not None:
        p.color = color
    if width is not None:
        p.width = width
    ob.active_paint = len(ob.paints) - 1
    return p


def ensure_fill_and_stroke(ob, fill_on=True, stroke_on=True):
    """塗りと線を必ず1つずつ持たせる (足りない方は追加して、表示/非表示だけ切り替える)。
    こうしておくと、サイドバーのチェックだけで塗り/線を出し入れできる。"""
    if ob.kind not in {'PATH', 'SHAPE', 'TEXT'}:
        return
    if not any(p.kind == 'FILL' for p in ob.paints):
        p = add_paint(ob, 'FILL', color=(DEFAULT_TEXT_FILL if ob.kind == 'TEXT'
                                         else DEFAULT_FILL))
        p.enabled = fill_on
        ob.paints.move(len(ob.paints) - 1, 0)      # 塗りは線より先に描く
    if not any(p.kind == 'STROKE' for p in ob.paints):
        p = add_paint(ob, 'STROKE', color=DEFAULT_STROKE, width=DEFAULT_STROKE_WIDTH)
        p.enabled = stroke_on
    ob.active_paint = min(max(ob.active_paint, 0), len(ob.paints) - 1)


def ensure_gradient_stops(paint, bounds=None):
    """グラデーションに分岐点が無ければ作る。bounds があれば位置も決める。"""
    if len(paint.stops) == 0:
        a = paint.stops.add()
        a.position, a.color = 0.0, tuple(paint.color)
        b = paint.stops.add()
        b.position = 1.0
        b.color = (0.0, 0.0, 0.0, 1.0) if tuple(paint.color)[:3] != (0, 0, 0) else (1, 1, 1, 1)
    if bounds is not None:
        x0, y0, x1, y1 = bounds
        if paint.paint_type == 'RADIAL':
            paint.g_start = ((x0 + x1) / 2, (y0 + y1) / 2)
            paint.g_end = (x1, (y0 + y1) / 2)
        else:
            paint.g_start = (x0, (y0 + y1) / 2)
            paint.g_end = (x1, (y0 + y1) / 2)


def sorted_stops(paint):
    return sorted(paint.stops, key=lambda s: s.position)


def color_at(paint, t):
    """グラデーションの t (0〜1) の位置の色。"""
    stops = sorted_stops(paint)
    if not stops:
        return tuple(paint.color)
    if t <= stops[0].position:
        return tuple(stops[0].color)
    if t >= stops[-1].position:
        return tuple(stops[-1].color)
    for a, b in zip(stops[:-1], stops[1:]):
        if a.position <= t <= b.position:
            span = b.position - a.position
            f = 0.0 if span < 1e-9 else (t - a.position) / span
            return tuple(x + (y - x) * f for x, y in zip(a.color, b.color))
    return tuple(stops[-1].color)


def insert_stop(paint, t):
    """t の位置に分岐点を足す (色はその場所の色)。戻り値: 足した分岐点の番号"""
    t = min(max(float(t), 0.0), 1.0)
    col = color_at(paint, t)
    st = paint.stops.add()
    st.position, st.color = t, col
    paint.active_stop = len(paint.stops) - 1
    return len(paint.stops) - 1


def active_object(vs):
    if 0 <= vs.active_index < len(vs.objects):
        return vs.objects[vs.active_index]
    return None


def style_source(vs, kind='PATH'):
    """新しいオブジェクトが引き継ぐスタイルの元。
    アクティブなもの、無ければ最後にアクティブだったもの。
    文字と図形は別々に覚える (Illustrator も文字の初期設定は別)。"""
    want = {'TEXT'} if kind == 'TEXT' else {'PATH', 'SHAPE'}
    ob = active_object(vs)
    if ob is not None and ob.kind in want:
        return ob
    uid = vs.text_style_uid if kind == 'TEXT' else vs.style_uid
    i = index_of_uid(vs, uid) if uid else -1
    return vs.objects[i] if i >= 0 and vs.objects[i].kind in want else None


def index_of_uid(vs, uid):
    for i, ob in enumerate(vs.objects):
        if ob.uid == uid:
            return i
    return -1


def uid_map(vs):
    return {ob.uid: ob for ob in vs.objects}


def copy_type(dst, src):
    """文字の書式 (書体・スタイル・大きさ・字間・行の間隔) を引き継ぐ。
    文字ごとに書式を変えていたら、**最後の文字の見た目**を使う (続きを打つのと同じ感覚)。
    新しい文字は1つの書式で始める (文字ごとの書式は持ち込まない)。
    2026-09-22 ユーザー要望 (それまでは色と線だけ引き継ぎ、書体・大きさは毎回既定値だった)"""
    n = len(src.text_lines)
    last = None
    for i in range(n - 1, -1, -1):
        if src.text_lines[i].text:
            last = (i, len(src.text_lines[i].text) - 1)
            break
    fam, sty, size, tr = (char_attrs(src, *last) if last is not None else
                          (src.font_family, src.font_style, src.font_size, src.tracking))
    dst.font_family, dst.font_style = fam, sty
    dst.font_size, dst.tracking = size, tr
    dst.line_spacing = src.line_spacing


def free_number(vs, fmt, start):
    """fmt % n がどのオブジェクトの名前とも重ならない、start 以上でいちばん小さい n。"""
    used = {ob.name for ob in vs.objects}
    n = max(int(start), 1)
    while fmt % n in used:
        n += 1
    return n


def new_object(vs, style_from=None, kind='PATH', parent_uid=0):
    """オブジェクトを追加する (親の中の最前面)。戻り値: 追加したオブジェクトの番号
    parent_uid が 0 なら、レイヤー以外は現在のレイヤーに入れる。"""
    from . import render
    if kind not in {'LAYER', 'ADJUST'} and not parent_uid:
        parent_uid = current_layer(vs, create=True)
    if kind in {'LAYER', 'ADJUST'}:
        parent_uid = 0
    # 一覧に追加すると一覧のメモリが移ることがあり、その前に取った参照 (style_from など) は
    # 壊れて別の場所を読む (線幅などが既定に戻っていた)。同じ一覧の中のものは uid で取り直す
    from_uid = None
    if style_from is not None and getattr(style_from, "id_data", None) == vs.id_data:
        from_uid = style_from.uid
        style_from = None
    with render.suspended():
        ob = vs.objects.add()
        ob.uid = vs.next_uid
        vs.next_uid += 1
        ob.kind = kind
        ob.parent_uid = parent_uid
        if kind == 'LAYER':
            # 数えた番号だと、途中のレイヤーを消してから足したときに名前が重なった
            # (レイヤー 1・2・3 → 2 を消して足すと「レイヤー 3」が2つ)。重ならない番号にする
            n = sum(1 for o in vs.objects if o.kind == 'LAYER' and not is_background_layer(o))
            n = free_number(vs, "レイヤー %d", n)
            ob.name = "レイヤー %d" % n
            ob.layer_color = LAYER_COLORS[(n - 1) % len(LAYER_COLORS)]
        else:
            base = {"PATH": "Path", "SHAPE": "Shape", "TEXT": "文字",
                    "IMAGE": "画像", "GROUP": "Group", "ADJUST": "調整"}[kind]
            ob.name = "%s %d" % (base, ob.uid)
        if kind == 'TEXT':
            ob.text_lines.add()
        if kind in {'PATH', 'SHAPE', 'TEXT'}:
            if from_uid is not None:
                j = index_of_uid(vs, from_uid)
                src = vs.objects[j] if j >= 0 else None
            else:
                src = style_from if style_from is not None else style_source(vs, kind)
            if src is not None and src.uid != ob.uid:
                copy_style(ob, src)
                if kind == 'TEXT' and src.kind == 'TEXT':
                    copy_type(ob, src)
            # 塗りと線は必ず1つずつ持たせ、初めて作るときは両方とも表示にする
            # (文字だけ線を消していたが、分かりにくいので揃えた。2026-09-21 ユーザー要望)
            ensure_fill_and_stroke(ob)
        uid = ob.uid
    if parent_uid:
        normalize_order(vs)
    return index_of_uid(vs, uid)


# -----------------------------------------------------------------------------
# レイヤー・ロック
# -----------------------------------------------------------------------------

def layer_of(vs, uid, m=None):
    """uid が属するレイヤー (レイヤー自身ならそれ) の uid。無ければ 0。"""
    m = m or uid_map(vs)
    chain = [uid] + ancestors(vs, uid, m)
    for u in chain:
        if u in m and m[u].kind == 'LAYER':
            return u
    return 0


def layers(vs):
    """図形を入れるレイヤー (元の画像の「背景」レイヤーは含めない)。
    背景は描き込み先・「レイヤーへ移動」の行き先にしない。"""
    return [ob for ob in vs.objects if ob.kind == 'LAYER' and not is_background_layer(ob)]


def current_layer(vs, create=False):
    """描き込み先のレイヤー: アクティブなオブジェクトのレイヤー、無ければ最前面のレイヤー。
    元の画像の「背景」レイヤーには入れない (元の画像を選んでいるときに図形を描いても、
    図形は背景ではなく普通のレイヤーに入る)。"""
    ob = active_object(vs)
    if ob is not None:
        lay = layer_of(vs, ob.uid)
        if lay and not is_background_layer(vs.objects[index_of_uid(vs, lay)]):
            return lay
    ls = layers(vs)
    if ls:
        return ls[-1].uid
    if not create:
        return 0
    i = new_object(vs, kind='LAYER')
    return vs.objects[i].uid


def ensure_layers(vs):
    """レイヤーに入っていない最上位のオブジェクトを、レイヤーに入れる (旧データの移行用)。"""
    loose = [ob.uid for ob in vs.objects
             if ob.kind not in {'LAYER', 'ADJUST'} and ob.parent_uid == 0]
    if not loose and layers(vs):
        return False
    act = active_object(vs)
    act_uid = act.uid if act is not None else None
    ls = layers(vs)
    if ls:
        target = ls[0].uid
    else:
        i = new_object(vs, kind='LAYER')
        target = vs.objects[i].uid
    for ob in vs.objects:
        if ob.uid in loose:
            ob.parent_uid = target
    normalize_order(vs)
    if act_uid is not None:
        set_active(vs, index_of_uid(vs, act_uid))
    return True


def is_editable(vs, uid, m=None):
    """自分と祖先がすべて表示中かつロックされていない。"""
    m = m or uid_map(vs)
    ob = m.get(uid)
    if ob is None or ob.locked or not ob.visible:
        return False
    return all(not m[a].locked and m[a].visible for a in ancestors(vs, uid, m))


def effective_editable(vs):
    """番号ごとに is_editable。"""
    m = uid_map(vs)
    return [is_editable(vs, ob.uid, m) for ob in vs.objects]


def clip_path_uid(vs, group_uid, ch=None):
    """クリップグループのマスクの形 (最前面の子) の uid。無ければ 0。"""
    ch = ch or children_map(vs)
    kids = ch.get(group_uid, [])
    return kids[-1] if kids else 0


def is_clip_path(vs, uid, m=None, ch=None):
    m = m or uid_map(vs)
    ob = m.get(uid)
    if ob is None or not ob.parent_uid or ob.parent_uid not in m:
        return False
    g = m[ob.parent_uid]
    return g.clip and clip_path_uid(vs, g.uid, ch) == uid


def object_is_empty(ob):
    """中身の無いパス (ペンツールが描き始めに使い回す)。"""
    return ob.kind == 'PATH' and all(len(sp.points) == 0 for sp in ob.subpaths)


# -----------------------------------------------------------------------------
# 文字
# -----------------------------------------------------------------------------

def sync_canvas_size(img):
    """キャンバスの画像の大きさが変わっていたら、中身をその大きさに合わせる。
    戻り値: 合わせ直したら True

    2026-10-18 ユーザー報告「リサイズしてキャンバスの解像度を変えるとおかしくなる」。
    中身は画素の座標で持っているので、画像だけ大きく (小さく) なると、図形は元の画素の
    位置に残り、キャンバスと同じ大きさのはずのペイントレイヤー・マスク・元の画像は
    大きさが合わなくなっていた。

    レイアウトを保つように、全体を同じ割合で拡大縮小する:
    - キャンバスと同じ大きさで重ねている画像 (ペイントレイヤー・元の画像・レイヤーマスク) は、
      画素を新しい大きさに引き伸ばす (Blender の Image.scale)。ぴったり重なったままにする
    - それ以外 (パス・図形・文字・置いた画像・グラデーションの位置・線幅・角の丸み) は、
      左下を中心に同じ割合で拡大縮小する
    - 効果の数値 (影のずれ・ぼかしなど) はそのまま"""
    from . import geometry as G, render, transform
    vs = img.vstroke
    W, H = (int(v) for v in img.size)
    if W <= 0 or H <= 0:
        return False
    old = tuple(int(v) for v in vs.canvas_size)
    if old == (0, 0):
        # まだ覚えていない (この版より前のファイル)。元の画像の大きさが、有効化したときの
        # キャンバスの大きさ
        base = next((o for o in vs.objects if is_original(o) and o.image is not None), None)
        old = tuple(int(v) for v in base.image.size) if base is not None else (W, H)
    if old == (W, H) or old[0] <= 0 or old[1] <= 0:
        if tuple(vs.canvas_size) != (W, H):
            vs.canvas_size = (W, H)
        return False
    sx, sy = W / old[0], H / old[1]
    with render.suspended():
        resampled = set()
        for ob in vs.objects:
            # レイヤーマスク: いつもキャンバスと同じ大きさ
            mi = ob.mask_image
            if mi is not None and tuple(mi.size) == old:
                try:
                    mi.scale(W, H)
                except Exception as e:
                    print("[Vector Strokes] マスクの大きさを合わせられません:", e)
            # キャンバスにぴったり重ねたペイントレイヤー (元の画像も)
            if (ob.kind == 'IMAGE' and is_paint_layer(ob) and ob.image is not None
                    and tuple(ob.image.size) == old and not ob.img_quad_on
                    and tuple(round(float(v), 6) for v in ob.img_origin) == (0.0, 0.0)
                    and tuple(round(float(v), 6) for v in ob.img_mat) == (1.0, 0.0, 0.0, 1.0)):
                try:
                    ob.image.scale(W, H)
                    resampled.add(ob.uid)
                except Exception as e:
                    print("[Vector Strokes] レイヤーの大きさを合わせられません:", e)
        roots = [ob.uid for ob in vs.objects if ob.kind not in {'LAYER', 'ADJUST'}]
        if roots:
            transform.transform_items(vs, roots, G.scale(sx, sy), True, True)
        # 引き伸ばしたレイヤーは、拡大縮小を掛けずにぴったり重ねたままにする
        # (親のグループを拡大縮小したときに、一緒に掛かってしまう分を戻す)
        for ob in vs.objects:
            if ob.uid in resampled:
                ob.img_origin = (0.0, 0.0)
                ob.img_mat = (1.0, 0.0, 0.0, 1.0)
        vs.canvas_size = (W, H)
    render.clear_cache()
    print("[Vector Strokes] キャンバスの大きさが %dx%d -> %dx%d に変わったので、中身を合わせました"
          % (old[0], old[1], W, H))
    return True


CROP_MIN_PX = 2.0     # トリミングで残す最小の幅・高さ (元の画像の画素)


def _crop_get(ob, i):
    """左・下・右・上 (i = 0..3) それぞれ、端から切り取っている画素数。"""
    w, h = image_size(ob)
    c = ob.img_crop
    if i == 0:
        return float(c[0]) * w
    if i == 1:
        return float(c[1]) * h
    if i == 2:
        return (1.0 - float(c[2])) * w
    return (1.0 - float(c[3])) * h


def _crop_set(ob, i, value):
    w, h = image_size(ob)
    if w <= 0 or h <= 0:
        return
    c = list(ob.img_crop)
    v = max(float(value), 0.0)
    if i == 0:
        c[0] = min(v / w, c[2] - CROP_MIN_PX / w)
    elif i == 1:
        c[1] = min(v / h, c[3] - CROP_MIN_PX / h)
    elif i == 2:
        c[2] = max(1.0 - v / w, c[0] + CROP_MIN_PX / w)
    else:
        c[3] = max(1.0 - v / h, c[1] + CROP_MIN_PX / h)
    ob.img_crop = [min(max(x, 0.0), 1.0) for x in c]


def has_crop(ob):
    """トリミングしているか。"""
    if getattr(ob, "kind", "") != 'IMAGE':
        return False
    c = ob.img_crop
    return c[0] > 1e-6 or c[1] > 1e-6 or c[2] < 1.0 - 1e-6 or c[3] < 1.0 - 1e-6


def crop_rect_px(ob, full=False):
    """見せる範囲 (左, 下, 右, 上)。元の画像の画素 (左下が原点)。"""
    w, h = image_size(ob)
    if full or not has_crop(ob):
        return (0.0, 0.0, float(w), float(h))
    c = ob.img_crop
    return (float(c[0]) * w, float(c[1]) * h, float(c[2]) * w, float(c[3]) * h)


def _homography(src, dst):
    """4点 src -> 4点 dst の射影変換 (3x3)。"""
    import numpy as np
    A, b = [], []
    for (x, y), (u, v) in zip(src, dst):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y])
        b.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y])
        b.append(v)
    try:
        h = np.linalg.solve(np.array(A, np.float64), np.array(b, np.float64))
    except np.linalg.LinAlgError:
        return None
    return np.array([[h[0], h[1], h[2]], [h[3], h[4], h[5]], [h[6], h[7], 1.0]])


def source_matrix(ob):
    """元の画像の画素 (左下が原点) -> 画像座標 の 3x3 行列 (遠近変形なら射影変換)。"""
    if getattr(ob, "img_quad_on", False):
        w, h = image_size(ob)
        H = _homography([(0.0, 0.0), (w, 0.0), (w, h), (0.0, h)], image_corners(ob))
        if H is not None:
            return H
    return image_matrix(ob)


def source_to_image(ob, p, M=None):
    import numpy as np
    M = source_matrix(ob) if M is None else M
    v = M @ np.array([float(p[0]), float(p[1]), 1.0])
    return (float(v[0] / v[2]), float(v[1] / v[2]))


def image_to_source(ob, p, M=None):
    """画像座標 -> 元の画像の画素。戻せなければ None。"""
    import numpy as np
    M = source_matrix(ob) if M is None else M
    try:
        v = np.linalg.inv(M) @ np.array([float(p[0]), float(p[1]), 1.0])
    except np.linalg.LinAlgError:
        return None
    if abs(v[2]) < 1e-12:
        return None
    return (float(v[0] / v[2]), float(v[1] / v[2]))


def image_visible_corners(ob):
    """見えている範囲の4隅 (左下・右下・右上・左上。画像座標)。トリミングしていれば
    その範囲。選択枠・当たり判定・スナップはこれを使う (遠近変形の4隅は image_corners)。"""
    if not has_crop(ob):
        return image_corners(ob)
    x0, y0, x1, y1 = crop_rect_px(ob)
    M = source_matrix(ob)
    return [source_to_image(ob, q, M) for q in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]


def image_size(ob):
    """画像オブジェクトの元の大きさ (px)。無ければ (0, 0)。"""
    im = ob.image if ob.kind == 'IMAGE' else None
    if im is None:
        return (0, 0)
    try:
        w, h = im.size
    except Exception:
        return (0, 0)
    return (int(w), int(h))


def image_matrix(ob):
    """画像のローカル座標 (左下が原点、元の画素の大きさ) -> 画像座標 の行列。"""
    import numpy as np
    a, b, c, d = (float(v) for v in ob.img_mat)
    tx, ty = (float(v) for v in ob.img_origin)
    return np.array([[a, c, tx], [b, d, ty], [0.0, 0.0, 1.0]])


def image_corners(ob):
    """画像の4隅 (左下・右下・右上・左上。画像座標)。遠近変形していればその4隅。"""
    if getattr(ob, "img_quad_on", False):
        q = [float(v) for v in ob.img_quad]
        return [(q[0], q[1]), (q[2], q[3]), (q[4], q[5]), (q[6], q[7])]
    import numpy as np
    w, h = image_size(ob)
    m = image_matrix(ob)
    out = []
    for x, y in ((0.0, 0.0), (w, 0.0), (w, h), (0.0, h)):
        v = m @ np.array([x, y, 1.0])
        out.append((float(v[0]), float(v[1])))
    return out


def set_image_corners(ob, pts):
    """4隅を決めて、遠近変形の状態にする。"""
    ob.img_quad = [c for p in pts for c in (float(p[0]), float(p[1]))]
    ob.img_quad_on = True


def can_distort(ob):
    """遠近変形できる画像か (ペイントレイヤーは、描くときの位置がずれるので対象外)。"""
    return (ob is not None and ob.kind == 'IMAGE' and ob.image is not None
            and not is_paint_layer(ob))


def paint_placement(ob, w, h):
    """ブラシで描くとき、画像がキャンバスにどう重なっているか (w, h はキャンバスの大きさ)。
    'ALIGNED': 同じ大きさで原点に置いてあり、変形なし (ペイントレイヤーと同じ。周りも正しく見せる)
    'OFFSET':  動かしただけ (拡大・回転・遠近変形なし)。周りの絵をずらして重ねれば合う
    'SOLO':    拡大・回転・遠近変形している。描いている間はその画像だけを見せる
    どれでも、描くのは元の画像そのもの (変形前の画素)。変形は描き直すときにいつも通りかかる。"""
    if (ob.img_quad_on or has_crop(ob)
            or tuple(round(float(v), 9) for v in ob.img_mat) != (1.0, 0.0, 0.0, 1.0)):
        return 'SOLO'
    if (image_size(ob) == (int(w), int(h))
            and tuple(round(float(v), 9) for v in ob.img_origin) == (0.0, 0.0)):
        return 'ALIGNED'
    return 'OFFSET'


def is_paint_layer(ob):
    """ブラシで描くために作ったレイヤーか (読み込んだ写真と区別する)。"""
    return ob.kind == 'IMAGE' and bool(getattr(ob, "img_paint", False))


def is_original(ob):
    """有効化したときの元の画像を持つレイヤーか。"""
    return is_paint_layer(ob) and bool(getattr(ob, "img_original", False))


def is_background_layer(ob):
    """元の画像を入れておく、いちばん下のレイヤー「背景」か。"""
    return ob.kind == 'LAYER' and bool(getattr(ob, "img_original", False))


ORIGINAL_NAME = "元の画像"
BACKGROUND_NAME = "背景"


def attach_original(vs, im):
    """元の画像 im を、いちばん下のレイヤー「背景」のペイントレイヤーとして置く。
    戻り値: そのオブジェクト

    2026-09-25 ユーザー決定: 以前は「下地」として固定していたので、有効化する前に
    Blender のブラシで描いた絵は、有効化したあと二度と描き足せなかった。
    ペイントレイヤーにすれば、ブラシで描き足す・隠す・補正する、が他のレイヤーと同じにできる。
    - **自分だけのレイヤー (背景) に入れる**: 描いた図形と同じレイヤーに入れると、そのレイヤーを
      隠したり薄くしたりしたとき元の画像まで消える (図形だけ隠して見比べる、ができない)
    - **ロックしておく**: キャンバス全体を覆うので、ロックしないと空いている所をクリックする
      たびに選ばれて動いてしまう。ロックしていても、一覧で選べばブラシで描ける"""
    from . import render
    ensure_layers(vs)                       # 図形を描くレイヤー (レイヤー 1) を先に作っておく
    with render.suspended():
        li = new_object(vs, kind='LAYER')
        lay = vs.objects[li]
        lay.name = BACKGROUND_NAME
        lay.img_original = True
        lay_uid = lay.uid
        oi = new_object(vs, kind='IMAGE', parent_uid=lay_uid)
        ob = vs.objects[oi]
        ob.image = im
        ob.img_paint = True
        ob.img_original = True
        ob.img_origin = (0.0, 0.0)          # キャンバスにぴったり重ねる
        ob.img_mat = (1.0, 0.0, 0.0, 1.0)
        ob.name = ORIGINAL_NAME
        ob.locked = True
        uid = ob.uid
        # 背景のレイヤーを、いちばん下 (最上位の最初) にする
        ch = children_map(vs)
        top = ch.get(0, [])
        if lay_uid in top:
            top.remove(lay_uid)
            top.insert(0, lay_uid)
        reorder(vs, flatten_tree(ch))
    vs.base_image = None
    return vs.objects[index_of_uid(vs, uid)]


def image_name(ob):
    im = ob.image
    return im.name if im is not None else "画像なし"


def text_string(ob):
    """文字オブジェクトの中身 (改行でつないだ1つの文字列)。"""
    return "\n".join(ln.text for ln in ob.text_lines)


def set_text_string(ob, s):
    """文字オブジェクトの中身を入れ替える (書式番号は長さを合わせるだけ)。"""
    lines = s.split("\n")
    old = [line_styles(ob, i) for i in range(len(ob.text_lines))]
    styles = [(old[i] if i < len(old) else "") for i in range(len(lines))]
    _write_lines(ob, lines, styles)



# -----------------------------------------------------------------------------
# 文字ごとの書式 (選んだ文字だけ書体・大きさ・字間を変える)
# -----------------------------------------------------------------------------

STYLE_BASE = 48          # '0'
MAX_STYLES = 500         # 1つの文字オブジェクトに持てる書式の数 (カーニングで増えやすい)
CHAR_ATTRS = ("family", "style", "size", "tracking", "kern", "scale_x", "scale_y")


def line_styles(ob, i):
    """i 行目の「文字ごとの書式番号」。必ず本文と同じ長さに揃える。"""
    if i >= len(ob.text_lines):
        return ""
    ln = ob.text_lines[i]
    n = len(ln.text)
    st = ln.styles or ""
    if len(st) < n:
        st += chr(STYLE_BASE) * (n - len(st))
    return st[:n]


def _idx(ch):
    return max(ord(ch) - STYLE_BASE, 0)


def _ch(idx):
    return chr(STYLE_BASE + max(int(idx), 0))


def char_style(ob, line, col):
    """その文字に付いている書式 (無ければ None)。"""
    st = line_styles(ob, line)
    if not (0 <= col < len(st)):
        return None
    i = _idx(st[col])
    return ob.text_styles[i - 1] if 1 <= i <= len(ob.text_styles) else None


def char_attrs(ob, line, col):
    """その文字に実際に使う (書体, スタイル, 大きさ, 字間)。"""
    return char_attrs_full(ob, line, col)[:4]


def char_attrs_full(ob, line, col):
    """その文字に実際に使う (書体, スタイル, 大きさ, 字間, カーニング, 水平比率, 垂直比率)。
    カーニングと比率は文字オブジェクト全体の設定が無いので、既定は 0 / 100%。"""
    fam, sty = ob.font_family, ob.font_style
    size, tr = float(ob.font_size), float(ob.tracking)
    kern, sx, sy = 0.0, 100.0, 100.0
    st = char_style(ob, line, col)
    if st is not None:
        if st.use_family:
            fam = st.font_family
        if st.use_style:
            sty = st.font_style
        if st.use_size:
            size = float(st.font_size)
        if st.use_tracking:
            tr = float(st.tracking)
        if st.use_kern:
            kern = float(st.kern)
        if st.use_scale_x:
            sx = float(st.scale_x)
        if st.use_scale_y:
            sy = float(st.scale_y)
    return fam, sty, size, tr, kern, sx, sy


def _key_of(st):
    if st is None:
        return EMPTY_KEY
    # 使っていない項目は値を既定にそろえる (そろえないと、全部「そのまま」に戻しても
    # 中身の無い書式が残り、文字が書式付きのままになる)
    return (bool(st.use_family), st.font_family if st.use_family else "",
            bool(st.use_style), st.font_style if st.use_style else "",
            bool(st.use_size), round(float(st.font_size), 4) if st.use_size else 0.0,
            bool(st.use_tracking), round(float(st.tracking), 4) if st.use_tracking else 0.0,
            bool(st.use_kern), round(float(st.kern), 4) if st.use_kern else 0.0,
            bool(st.use_scale_x), round(float(st.scale_x), 4) if st.use_scale_x else 0.0,
            bool(st.use_scale_y), round(float(st.scale_y), 4) if st.use_scale_y else 0.0)


EMPTY_KEY = (False, "", False, "", False, 0.0, False, 0.0, False, 0.0, False, 0.0, False, 0.0)


def _key_with(key, family=None, style=None, size=None, tracking=None, clear=(),
              kern=None, scale_x=None, scale_y=None):
    uf, fam, us, sty, uz, sz, ut, tr, uk, kn, ux, sx, uy, sy = key
    if "family" in clear:
        uf, fam = False, ""
    if "style" in clear:
        us, sty = False, ""
    if "size" in clear:
        uz, sz = False, 0.0
    if "tracking" in clear:
        ut, tr = False, 0.0
    if "kern" in clear:
        uk, kn = False, 0.0
    if "scale_x" in clear:
        ux, sx = False, 0.0
    if "scale_y" in clear:
        uy, sy = False, 0.0
    if family is not None:
        uf, fam = True, family
    if style is not None:
        us, sty = True, style
    if size is not None:
        uz, sz = True, round(float(size), 4)
    if tracking is not None:
        ut, tr = True, round(float(tracking), 4)
    if kern is not None:
        uk, kn = True, round(float(kern), 4)
        if kn == 0.0:
            uk = False          # 0 は「付けていない」と同じ (書式を増やさない)
    if scale_x is not None:
        ux, sx = True, round(float(scale_x), 4)
        if sx == 100.0:
            ux, sx = False, 0.0
    if scale_y is not None:
        uy, sy = True, round(float(scale_y), 4)
        if sy == 100.0:
            uy, sy = False, 0.0
    return (uf, fam, us, sty, uz, sz, ut, tr, uk, kn, ux, sx, uy, sy)


def _style_number(ob, key, cache, full=None):
    """その書式の番号 (無ければ作る)。0 = そのまま。
    上限に達したら full["hit"] を立てて知らせる (黙って既定に戻さない)。"""
    if key == EMPTY_KEY:
        return 0
    got = cache.get(key)
    if got is not None:
        return got
    if len(ob.text_styles) >= MAX_STYLES:
        if full is not None:
            full["hit"] = True
        return 0
    st = ob.text_styles.add()
    (st.use_family, st.font_family, st.use_style, st.font_style,
     st.use_size, st.font_size, st.use_tracking, st.tracking) = (
        key[0], key[1], key[2], key[3], key[4], key[5] or 72.0, key[6], key[7])
    st.use_kern, st.kern = key[8], key[9]
    st.use_scale_x, st.scale_x = key[10], key[11] or 100.0
    st.use_scale_y, st.scale_y = key[12], key[13] or 100.0
    n = len(ob.text_styles)
    cache[key] = n
    return n


def _gc_styles(ob):
    """どの文字にも使われていない書式を捨てて、番号を詰める。"""
    used = set()
    for i in range(len(ob.text_lines)):
        for c in line_styles(ob, i):
            used.add(_idx(c))
    used.discard(0)
    keep = [n for n in range(1, len(ob.text_styles) + 1) if n in used]
    if len(keep) == len(ob.text_styles):
        return
    remap = {old: new + 1 for new, old in enumerate(keep)}
    values = [_key_of(ob.text_styles[n - 1]) for n in keep]
    for i in range(len(ob.text_lines)):
        st = line_styles(ob, i)
        ob.text_lines[i].styles = "".join(_ch(remap.get(_idx(c), 0)) for c in st)
    ob.text_styles.clear()
    for key in values:
        _style_number(ob, key, {})


def apply_char_style(ob, ranges, family=None, style=None, size=None, tracking=None,
                     clear=(), kern=None, scale_x=None, scale_y=None):
    """ranges = [(行, 始まり, 終わり)] の文字に書式を付ける。
    clear には "size" などを入れると、その項目を「そのまま」に戻す。
    戻り値: 全部付けられたら True (上限に達したら False)。"""
    if ob.kind != 'TEXT':
        return False
    cache = {}
    for n, st in enumerate(ob.text_styles, start=1):
        cache.setdefault(_key_of(st), n)
    changed = False
    full = {"hit": False}
    for line, c0, c1 in ranges:
        if not (0 <= line < len(ob.text_lines)):
            continue
        cur = list(line_styles(ob, line))
        for col in range(max(c0, 0), min(c1, len(cur))):
            key = _key_with(_key_of(char_style(ob, line, col)), family, style, size,
                            tracking, clear, kern, scale_x, scale_y)
            cur[col] = _ch(_style_number(ob, key, cache, full))
            changed = True
        ob.text_lines[line].styles = "".join(cur)
    if changed:
        _gc_styles(ob)
        from . import render
        render.request_render(owner_image(ob))
    if full["hit"]:
        print("[Vector Strokes] 1つの文字に付けられる書式は %d 種類までです" % MAX_STYLES)
    return not full["hit"]


def common_char_attr(ob, ranges, name):
    """その範囲で共通の値 (ばらばらなら None)。name は family/style/size/tracking。"""
    i = CHAR_ATTRS.index(name)
    got = None
    for line, c0, c1 in ranges:
        if not (0 <= line < len(ob.text_lines)):
            continue
        end = min(c1, len(ob.text_lines[line].text))
        for col in range(max(c0, 0), end):
            v = char_attrs_full(ob, line, col)[i]
            if got is None:
                got = v
            elif got != v:
                return None
    return got


def _neighbor_style(styles, line, col):
    """新しく入れる文字が引き継ぐ書式番号。直前の文字、無ければ直後の文字。
    空の行なら、上の行の最後の文字、無ければ下の行の最初の文字。
    どこにも文字が無ければ 0 (= 文字オブジェクト自体の書式。全部消したときは
    delete_text が、消した文字の書式をそこへ覚えさせてある)。"""
    st = styles[line]
    if col > 0:
        return st[col - 1]
    if col < len(st):
        return st[col]
    for i in range(line - 1, -1, -1):
        if styles[i]:
            return styles[i][-1]
    for i in range(line + 1, len(styles)):
        if styles[i]:
            return styles[i][0]
    return _ch(0)


def _without_kern(ob, ch):
    """書式番号 ch から、カーニングだけ外した書式番号 (無ければ作る)。"""
    i = _idx(ch)
    if not (1 <= i <= len(ob.text_styles)):
        return ch
    key = _key_of(ob.text_styles[i - 1])
    if not key[8]:
        return ch
    cache = {}
    for n, st in enumerate(ob.text_styles, start=1):
        cache.setdefault(_key_of(st), n)
    return _ch(_style_number(ob, _key_with(key, clear=("kern",)), cache))


def kern_at(ob, line, col):
    """文字と文字の間 (カーソル col) のカーニング。端なら None (カーニングできない)。"""
    if not (0 <= line < len(ob.text_lines)):
        return None
    n = len(ob.text_lines[line].text)
    if not (0 < col < n):
        return None
    return char_attrs_full(ob, line, col)[4]


def set_kern(ob, line, col, value):
    """文字と文字の間 (カーソル col) のカーニングを変える。うしろの字に付ける。"""
    if kern_at(ob, line, col) is None:
        return False
    return apply_char_style(ob, [(line, col, col + 1)], kern=value)


def insert_text(ob, line, col, s):
    """(行, 文字数) の所に文字を入れる。書式は直前の文字を引き継ぐ。
    戻り値: 入れ終わった後の (行, 文字数)"""
    lines = [ln.text for ln in ob.text_lines] or [""]
    styles = [line_styles(ob, i) for i in range(len(lines))] or [""]
    line = max(0, min(line, len(lines) - 1))
    col = max(0, min(col, len(lines[line])))
    inherit = _without_kern(ob, _neighbor_style(styles, line, col))
    parts = s.split("\n")
    head, tail = lines[line][:col], lines[line][col:]
    hst, tst = styles[line][:col], styles[line][col:]
    new_t, new_s = [], []
    for j, part in enumerate(parts):
        t = (head if j == 0 else "") + part + (tail if j == len(parts) - 1 else "")
        st = ((hst if j == 0 else "") + inherit * len(part)
              + (tst if j == len(parts) - 1 else ""))
        new_t.append(t)
        new_s.append(st)
    lines[line:line + 1] = new_t
    styles[line:line + 1] = new_s
    _write_lines(ob, lines, styles)
    if len(parts) == 1:
        return (line, col + len(s))
    return (line + len(parts) - 1, len(parts[-1]))


def delete_text(ob, l0, c0, l1, c1):
    """(l0, c0) から (l1, c1) までを消す。"""
    lines = [ln.text for ln in ob.text_lines] or [""]
    styles = [line_styles(ob, i) for i in range(len(lines))] or [""]
    l0 = max(0, min(l0, len(lines) - 1))
    l1 = max(0, min(l1, len(lines) - 1))
    if (l1, c1) < (l0, c0):
        l0, c0, l1, c1 = l1, c1, l0, c0
    c0 = max(0, min(c0, len(lines[l0])))
    c1 = max(0, min(c1, len(lines[l1])))
    first = _first_char(lines, l0, c0, l1, c1)
    kept = char_attrs(ob, *first) if first is not None else None
    lines[l0:l1 + 1] = [lines[l0][:c0] + lines[l1][c1:]]
    styles[l0:l1 + 1] = [styles[l0][:c0] + styles[l1][c1:]]
    _write_lines(ob, lines, styles)
    if kept is not None and not any(lines):
        # 全部消した: 消した先頭の文字の書式を、文字オブジェクト自体に覚えさせる。
        # こうしないと、打ち直した文字が既定の書体・大きさに戻ってしまう
        # (2026-09-22 ユーザー報告。Illustrator も空の文字は最後の書式を覚えている)
        from . import render
        with render.suspended():
            ob.font_family, ob.font_style, ob.font_size, ob.tracking = kept
    return (l0, c0)


def _first_char(lines, l0, c0, l1, c1):
    """消す範囲の最初の文字の (行, 文字数)。範囲に文字が無ければ None。"""
    line, col = l0, c0
    while (line, col) < (l1, c1):
        if col < len(lines[line]):
            return (line, col)
        line, col = line + 1, 0
    return None


def _write_lines(ob, lines, styles):
    """本文と書式番号をまとめて書き込む。"""
    while len(ob.text_lines) > len(lines):
        ob.text_lines.remove(len(ob.text_lines) - 1)
    while len(ob.text_lines) < len(lines):
        ob.text_lines.add()
    for item, t, st in zip(ob.text_lines, lines, styles):
        if item.text != t:
            item.text = t
        st = (st + _ch(0) * len(t))[:len(t)]
        if item.styles != st:
            item.styles = st
    _gc_styles(ob)


def text_name(ob):
    """一覧に出す名前 (中身の先頭を使う。Illustrator と同じ)。"""
    s = text_string(ob).strip().replace("\n", " ")
    return (s[:20] if s else "空の文字")


def text_is_container(ob):
    """枠やパスを持つ文字か (エリア文字・パス上文字)。"""
    return ob.kind == 'TEXT' and ob.text_kind in {'AREA', 'PATH'}


def make_text_container(vs, ob, closed=None):
    """パスや図形を「文字の入れ物」に変える。
    閉じた形ならエリア文字 (中に流し込む)、開いたパスならパス上文字 (線に沿わせる)。
    戻り値: 文字オブジェクト (変換できなければ None)"""
    from . import geometry as G, render, text as text_mod, transform
    if ob.kind not in {'PATH', 'SHAPE'}:
        return None
    subs = G.object_subpaths(ob)
    if not subs or len(subs[0][0]) < 2:
        return None
    if closed is None:
        closed = bool(subs[0][1])
    b = G.bounds_in_frame(G.polylines(subs))
    if b is None:
        return None
    ox, oy = b[0], b[3]          # 左上を基準にする
    local = [([(( co[0] - ox, co[1] - oy), (hl[0] - ox, hl[1] - oy),
                (hr[0] - ox, hr[1] - oy)) for co, hl, hr in pts], cl)
             for pts, cl in subs]
    with render.suspended():
        ob.kind = 'TEXT'
        ob.text_kind = 'AREA' if closed else 'PATH'
        ob.text_origin = (ox, oy)
        ob.text_mat = (1.0, 0.0, 0.0, 1.0)
        ob.rotation = 0.0
        ob.text_box = (max(b[2] - b[0], 1.0), max(b[3] - b[1], 1.0))
        ob.fill_rule = 'NONZERO'
        transform.write_subpaths(ob, local)
        if len(ob.text_lines) == 0:
            ob.text_lines.add()
        ensure_font(ob)
        # 入れ物になった形の線と塗りは描かない (Illustrator と同じ)。文字は黒い塗りにする
        ob.paints.clear()
        add_paint(ob, 'FILL', color=(0.0, 0.0, 0.0, 1.0))
        ob.name = text_name(ob)
    text_mod.clear_cache()
    return ob


def ensure_font(ob):
    """書体が指定されていなければ、このパソコンにあるものを選ぶ。"""
    from . import fonts
    if not fonts.available():
        return
    if not ob.font_family or fonts.resolve_family(ob.font_family) == "":
        fam = fonts.default_family()
        if fam:
            ob.font_family = fam
            ob.font_style = fonts.default_style(fam)


# -----------------------------------------------------------------------------
# 親子関係 (グループ)
# -----------------------------------------------------------------------------

def children_map(vs):
    """親 uid -> 子 uid のリスト (並び順)。0 = 最上位。存在しない親は最上位扱い。"""
    uids = {ob.uid for ob in vs.objects}
    ch = {0: []}
    for ob in vs.objects:
        p = ob.parent_uid if ob.parent_uid in uids and ob.parent_uid != ob.uid else 0
        ch.setdefault(p, []).append(ob.uid)
    return ch


def descendants(vs, uid, ch=None):
    ch = ch or children_map(vs)
    out = []
    stack = list(reversed(ch.get(uid, [])))
    while stack:
        u = stack.pop()
        out.append(u)
        stack.extend(reversed(ch.get(u, [])))
    return out


def ancestors(vs, uid, m=None):
    """親、祖父母… の uid (近い順)。"""
    m = m or uid_map(vs)
    out = []
    ob = m.get(uid)
    seen = {uid}
    while ob is not None and ob.parent_uid and ob.parent_uid in m and ob.parent_uid not in seen:
        out.append(ob.parent_uid)
        seen.add(ob.parent_uid)
        ob = m[ob.parent_uid]
    return out


def depth(vs, uid, m=None):
    return len(ancestors(vs, uid, m))


def effective_visibility(vs):
    """番号ごとに、自分と祖先がすべて表示なら True。"""
    m = uid_map(vs)
    out = []
    for ob in vs.objects:
        v = ob.visible and all(m[a].visible for a in ancestors(vs, ob.uid, m))
        out.append(v)
    return out


def flatten_tree(ch):
    order = []

    def walk(u):
        for c in ch.get(u, []):
            order.append(c)
            walk(c)
    walk(0)
    return order


def reorder(vs, uid_order):
    """objects を uid_order の順に並べ替える (アクティブは同じオブジェクトを指したまま)。"""
    act = active_object(vs)
    act_uid = act.uid if act is not None else None
    for target, uid in enumerate(uid_order):
        cur = index_of_uid(vs, uid)
        if cur >= 0 and cur != target:
            vs.objects.move(cur, target)
    if act_uid is not None:
        set_active(vs, max(index_of_uid(vs, act_uid), 0))


def normalize_order(vs):
    """グループの直後に子孫が続く並びに直す。"""
    ch = children_map(vs)
    # 親が存在しない子は最上位へ
    uids = {ob.uid for ob in vs.objects}
    for ob in vs.objects:
        if ob.parent_uid and (ob.parent_uid not in uids or ob.parent_uid == ob.uid):
            ob.parent_uid = 0
    reorder(vs, flatten_tree(ch))


def remove_objects(vs, uids):
    """オブジェクトを削除 (グループなら中身も)。空になったグループも消す。"""
    ch = children_map(vs)
    doomed = set()
    for u in uids:
        doomed.add(u)
        doomed.update(descendants(vs, u, ch))
    act = active_object(vs)
    act_uid = act.uid if act is not None and act.uid not in doomed else None
    from . import render
    with render.suspended():
        for i in range(len(vs.objects) - 1, -1, -1):
            if vs.objects[i].uid in doomed:
                vs.objects.remove(i)
        prune_empty_groups(vs)
    i = index_of_uid(vs, act_uid) if act_uid is not None else -1
    set_active(vs, i if i >= 0 else min(vs.active_index, max(len(vs.objects) - 1, 0)))


def prune_empty_groups(vs):
    while True:
        ch = children_map(vs)
        empty = [i for i, ob in enumerate(vs.objects)
                 if ob.kind == 'GROUP' and not ch.get(ob.uid)]
        if not empty:
            return
        for i in reversed(empty):
            vs.objects.remove(i)


# 読み書きの関数で作っている値 (保存されている別の値から計算する)。コピーしてはいけない:
# 例えば角の % は、コピーの途中 (隣の点がまだ無い) に書くと、丸み (px) を壊してしまう
COMPUTED_PROPS = {"corner_pct", "crop_left", "crop_right", "crop_top", "crop_bottom"}


def copy_props(dst, src):
    """PropertyGroup の中身を丸ごとコピー (コレクションも)。"""
    for prop in src.bl_rna.properties:
        k = prop.identifier
        if k in {"rna_type"} or k in COMPUTED_PROPS or (
                prop.is_readonly and prop.type != 'COLLECTION'):
            continue
        if prop.type == 'COLLECTION':
            dcol = getattr(dst, k)
            dcol.clear()
            for item in getattr(src, k):
                copy_props(dcol.add(), item)
        elif prop.type == 'POINTER':
            continue
        else:
            setattr(dst, k, getattr(src, k))


def _parent_key(ch, m, uid):
    """children_map の中で uid が属する親のキー。"""
    p = m[uid].parent_uid
    return p if p in m and p != uid else 0


def duplicate(vs, uids):
    """オブジェクトを複製し、それぞれ元の真上 (すぐ前面) に置く。戻り値: 新しい uid のリスト"""
    from . import render
    ch = children_map(vs)
    new_tops = []
    with render.suspended():
        for top in uids:
            mapping = {}
            for u in [top] + descendants(vs, top, ch):
                dst = vs.objects.add()
                src = vs.objects[index_of_uid(vs, u)]
                copy_props(dst, src)
                if src.kind == 'IMAGE':
                    give_image(dst, src.image)   # copy_props は画像への参照を写さない
                give_mask(dst, src.mask_image)
                dst.uid = vs.next_uid
                vs.next_uid += 1
                mapping[u] = dst.uid
                dst.parent_uid = mapping.get(src.parent_uid, src.parent_uid)
                dst.select = False
                if u == top:
                    dst.name = src.name + " のコピー"
            new_tops.append((top, mapping[top]))
    ch = children_map(vs)
    m = uid_map(vs)
    for orig, new in new_tops:
        sib = ch[_parent_key(ch, m, orig)]
        sib.remove(new)
        sib.insert(sib.index(orig) + 1, new)
    reorder(vs, flatten_tree(ch))
    return [n for _, n in new_tops]


def new_canvas_part(canvas, name, w, h):
    """キャンバスの部品 (ペイントレイヤー・レイヤーマスク) の画像を作る。
    キャンバスが float (16bit / 32bit。EXR など) なら部品も float にする
    (0.36.8 までは常に 8bit で、描いた所だけ精度が落ち、1 より明るい色は 1 で頭打ちになった)。"""
    im = bpy.data.images.new(name, w, h, alpha=True, float_buffer=canvas.is_float)
    if canvas.is_float:
        try:
            im.colorspace_settings.name = canvas.colorspace_settings.name
        except Exception:
            pass
        im.file_format = 'OPEN_EXR'
    return im


def clone_image(im):
    """画像を、画素ごと別の画像として複製する。"""
    import numpy as np
    w, h = im.size
    if w <= 0 or h <= 0:
        return im
    new = bpy.data.images.new(im.name, w, h, alpha=True, float_buffer=im.is_float)
    try:
        new.colorspace_settings.name = im.colorspace_settings.name
        new.alpha_mode = im.alpha_mode
    except Exception:
        pass
    arr = np.empty(w * h * 4, np.float32)
    im.pixels.foreach_get(arr)
    new.pixels.foreach_set(arr)
    new.file_format = 'OPEN_EXR' if im.is_float else 'PNG'
    new.update()
    return new


def give_image(dst, im):
    """複製・貼り付けでできた画像オブジェクトに、画像をつなぐ。

    ペイントレイヤーは自分だけの絵を持つ。同じ画像を指したままだと、片方に描くと
    もう片方も変わる (0.31.8 まで。複製の方は画像が空になっていた)。
    置いた画像 (写真など) は同じ画像を指す (Illustrator のリンク配置と同じ。重い写真を
    複製のたびに増やさない)。描き始めるときに ensure_own_image が分ける。"""
    if im is None:
        return
    if dst.img_paint:
        dst.image = clone_image(im)
        dst.img_original = False     # 元の画像 (背景) はキャンバスに1つだけ
    else:
        dst.image = im


def give_mask(dst, im):
    """複製・貼り付けでできたオブジェクトに、自分だけのレイヤーマスクを持たせる。"""
    dst.mask_image = clone_image(im) if im is not None else None


def ensure_own_mask(ob):
    """ob のマスクを他のオブジェクトも使っていたら、ob 用に複製する (ensure_own_image と同じ)。"""
    im = ob.mask_image
    if im is None:
        return None
    me = ob.as_pointer()
    for canvas in bpy.data.images:
        try:
            if not canvas.vstroke.enabled:
                continue
            shared = any(o.mask_image == im and o.as_pointer() != me
                         for o in canvas.vstroke.objects)
        except Exception:
            continue
        if shared:
            ob.mask_image = clone_image(im)
            return ob.mask_image
    return im


def has_mask(ob):
    """レイヤーマスクが効いているか。"""
    return ob is not None and ob.mask_enable and ob.mask_image is not None


def is_adjust_layer(ob):
    return ob is not None and ob.kind == 'ADJUST'


def ensure_own_image(ob):
    """ob の画像を他のオブジェクト (別のキャンバスも含む) も使っていたら、ob 用に複製する。
    ブラシで描き始める直前に呼ぶ (描いた絵が、複製した方にまで出ないように)。
    戻り値: ob が使う画像"""
    im = ob.image
    if im is None:
        return None
    me = ob.as_pointer()
    for canvas in bpy.data.images:
        try:
            if not canvas.vstroke.enabled:
                continue
            shared = any(o.kind == 'IMAGE' and o.image == im and o.as_pointer() != me
                         for o in canvas.vstroke.objects)
        except Exception:
            continue
        if shared:
            ob.image = clone_image(im)
            return ob.image
    return im


# -----------------------------------------------------------------------------
# コピー・貼り付け
# -----------------------------------------------------------------------------

def props_to_dict(src):
    """PropertyGroup の中身を、ただの辞書にする (コピー用。別の画像にも貼れる)。"""
    out = {}
    for prop in src.bl_rna.properties:
        k = prop.identifier
        if k == "rna_type" or k in COMPUTED_PROPS or (
                prop.is_readonly and prop.type != 'COLLECTION'):
            continue
        if prop.type == 'COLLECTION':
            out[k] = {"__col__": [props_to_dict(it) for it in getattr(src, k)]}
        elif prop.type == 'POINTER':
            v = getattr(src, k)
            out[k] = {"__id__": getattr(v, "name", "")} if v is not None else {"__id__": ""}
        else:
            v = getattr(src, k)
            out[k] = list(v) if (hasattr(v, "__len__") and not isinstance(v, str)) else v
    return out


def dict_to_props(dst, d):
    """props_to_dict で作った辞書を PropertyGroup に戻す。"""
    for k, v in d.items():
        if isinstance(v, dict) and "__col__" in v:
            col = getattr(dst, k, None)
            if col is None:
                continue
            col.clear()
            for item in v["__col__"]:
                dict_to_props(col.add(), item)
        elif isinstance(v, dict) and "__id__" in v:
            name = v["__id__"]
            if name and k == "image":
                img = bpy.data.images.get(name)
                if img is not None:
                    dst.image = img
        else:
            try:
                setattr(dst, k, v)
            except Exception:
                pass            # 読み取り専用など、戻せないものは飛ばす


def copy_objects(vs, uids):
    """選んだオブジェクト (と中身) をコピーする。戻り値: コピーした数"""
    from . import state
    ch = children_map(vs)
    m = uid_map(vs)
    order = flatten_tree(ch)
    picked = []
    for u in uids:
        if u in m and m[u].kind != 'LAYER':
            picked += [u] + descendants(vs, u, ch)
    seen, items = set(), []
    for u in order:                      # 奥から手前の順で覚える
        if u in picked and u not in seen:
            seen.add(u)
            items.append(props_to_dict(m[u]))
    state.clipboard = items
    state.clipboard_src = vs.id_data.name if vs.id_data is not None else ""
    return len(items)


def _fit_mask(im, w, h, dx, dy):
    """レイヤーマスクを別のキャンバスの大きさ (w, h) に合わせた新しい画像。
    マスクはキャンバスに固定なので、左下をそろえて写し、貼った物を (dx, dy) 動かしたなら
    同じだけずらす。はみ出した所は捨て、足りない所は白 (= 見える)。"""
    import numpy as np
    sw, sh = im.size
    src = np.empty(sw * sh * 4, np.float32)
    im.pixels.foreach_get(src)
    src = src.reshape(sh, sw, 4)
    out = np.ones((h, w, 4), np.float32)
    dx, dy = int(round(dx)), int(round(dy))
    x0, y0 = max(dx, 0), max(dy, 0)
    x1, y1 = min(sw + dx, w), min(sh + dy, h)
    if x1 > x0 and y1 > y0:
        out[y0:y1, x0:x1] = src[y0 - dy:y1 - dy, x0 - dx:x1 - dx]
    # 画素はそのまま写すので、元と同じ形式 (8bit / float) で作る
    new = bpy.data.images.new(im.name, w, h, alpha=True, float_buffer=im.is_float)
    new.pixels.foreach_set(out.ravel())
    new.update()
    return new


def _settle_in_canvas(vs, roots):
    """別のキャンバスに貼った物が、キャンバスの外に出てしまったら真ん中へ寄せる
    (大きさの違うテクスチャへ貼ると、元の位置ではまったく見えないことがある)。
    少しでもキャンバスに掛かっていれば、元と同じ位置のまま (同じ大きさのテクスチャどうしで
    同じ場所に貼りたいとき用)。戻り値: 動かした量 (dx, dy)"""
    from . import geometry as G, transform
    W, H = vs.id_data.size
    b = G.bounds_in_frame(transform.items_polylines(vs, roots))
    if b is None:
        return 0.0, 0.0
    if b[2] > 0 and b[0] < W and b[3] > 0 and b[1] < H:
        return 0.0, 0.0
    dx = W / 2.0 - (b[0] + b[2]) / 2.0
    dy = H / 2.0 - (b[1] + b[3]) / 2.0
    transform.transform_items(vs, roots, G.translate(dx, dy), False, False)
    return dx, dy


def paste_objects(vs, parent_uid=0):
    """コピーしたものを貼り付ける。戻り値: 新しくできた一番外側の uid のリスト"""
    from . import render, state
    items = list(state.clipboard or [])
    if not items:
        return []
    if not parent_uid:
        parent_uid = current_layer(vs, create=True)
    copied = {d.get("uid") for d in items}
    mapping, made = {}, []
    with render.suspended():
        for d in items:
            ob = vs.objects.add()
            dict_to_props(ob, d)
            if ob.kind == 'IMAGE':
                give_image(ob, ob.image)
            mask = d.get("mask_image")
            give_mask(ob, bpy.data.images.get(mask.get("__id__", "")) if mask else None)
            old = d.get("uid")
            ob.uid = vs.next_uid
            vs.next_uid += 1
            mapping[old] = ob.uid
            ob.select = False
            made.append((old, ob.uid))
        for old, new in made:
            ob = vs.objects[index_of_uid(vs, new)]
            src_parent = next(dd.get("parent_uid") for dd in items if dd.get("uid") == old)
            ob.parent_uid = 0 if ob.kind == 'ADJUST' else mapping.get(src_parent, parent_uid)
        normalize_order(vs)
    roots = [new for old, new in made
             if next(dd.get("parent_uid") for dd in items if dd.get("uid") == old)
             not in copied]
    if roots and vs.id_data is not None and state.clipboard_src != vs.id_data.name:
        # 別のテクスチャへの貼り付け: 見える所へ寄せ、レイヤーマスクをこのキャンバスの
        # 大きさに合わせる (マスクはキャンバスと同じ大きさで持つ決まり)
        dx, dy = _settle_in_canvas(vs, roots)
        W, H = vs.id_data.size
        new_uids = {new for _old, new in made}
        for ob in vs.objects:
            if ob.uid in new_uids and ob.mask_image is not None and (
                    tuple(ob.mask_image.size) != (W, H) or dx or dy):
                old_mask = ob.mask_image
                ob.mask_image = _fit_mask(old_mask, W, H, dx, dy)
                if old_mask.users == 0:
                    bpy.data.images.remove(old_mask)    # give_mask で作った途中の複製
    for ob in vs.objects:                # 貼り付けたものを選んだ状態にする
        ob.select = ob.uid in set(roots)
    if roots:
        set_active(vs, index_of_uid(vs, roots[-1]))
    return roots


def move_in_siblings(vs, uid, direction):
    """兄弟の中で前面 (direction=+1) / 背面 (-1) へ1つ移動。移動したら True。"""
    ch = children_map(vs)
    sib = ch[_parent_key(ch, uid_map(vs), uid)]
    i = sib.index(uid)
    j = i + direction
    if not (0 <= j < len(sib)):
        return False
    sib[i], sib[j] = sib[j], sib[i]
    reorder(vs, flatten_tree(ch))
    return True


def group(vs, uids, name=None):
    """uids をまとめて新しいグループにする。戻り値: グループの uid (できなければ 0)"""
    m = uid_map(vs)
    uids = [u for u in uids if u in m and m[u].kind not in {'LAYER', 'ADJUST'}]
    # 選択したグループの中身も同時に選ばれていたら、中身は除く
    uids = [u for u in uids if not set(ancestors(vs, u, m)) & set(uids)]
    if not uids:
        return 0
    order = flatten_tree(children_map(vs))
    front = max(uids, key=order.index)
    parents = {m[u].parent_uid for u in uids}
    # 親が揃っていなければ、最前面のもののレイヤーに作る
    parent = parents.pop() if len(parents) == 1 else layer_of(vs, front, m)
    # front を含む、parent 直下の要素 (その位置にグループを置く)
    anchor = front
    while m[anchor].parent_uid != parent and m[anchor].parent_uid in m:
        anchor = m[anchor].parent_uid
    gi = new_object(vs, kind='GROUP', parent_uid=parent)
    g = vs.objects[gi]
    if name:
        g.name = name
    guid = g.uid
    ch = children_map(vs)
    for lst in ch.values():
        if guid in lst:
            lst.remove(guid)
    sib = ch.setdefault(parent, [])
    sib.insert(sib.index(anchor) + 1, guid)
    for u in uids:
        for lst in ch.values():
            if u in lst:
                lst.remove(u)
    kids = sorted(uids, key=order.index)
    ch[guid] = kids
    for u in kids:
        vs.objects[index_of_uid(vs, u)].parent_uid = guid
    reorder(vs, flatten_tree(ch))
    return guid


def ungroup(vs, guid):
    """グループを解除し、中身をグループのあった位置に戻す。戻り値: 中身の uid"""
    m = uid_map(vs)
    g = m.get(guid)
    if g is None or g.kind != 'GROUP':
        return []
    parent = g.parent_uid
    ch = children_map(vs)
    kids = list(ch.get(guid, []))
    sib = ch.setdefault(parent, [])
    pos = sib.index(guid)
    sib[pos:pos + 1] = kids
    ch.pop(guid, None)
    for u in kids:
        m[u].parent_uid = parent
    reorder(vs, flatten_tree(ch))
    from . import render
    with render.suspended():
        vs.objects.remove(index_of_uid(vs, guid))
    return kids


def make_clip(vs, uids):
    """uids をまとめてクリップグループにする (最前面のものがマスクの形)。

    1つだけ選んだときは、**そのすぐ下にあるもの**を切り抜く相手にする
    (Photoshop のように1クリックで作れるようにするため。
    ただしマスクになるのは選んだ方＝上のもので、Illustrator と同じ向き)。
    マスクの形の塗り・線の透明度がそのまま「見える濃さ」になる (render.draw_clipped)。
    戻り値: グループの uid、またはエラーメッセージ (str)"""
    m = uid_map(vs)
    uids = [u for u in uids if u in m and m[u].kind != 'LAYER']
    if len(uids) == 1:
        ch = children_map(vs)
        sib = ch.get(_parent_key(ch, m, uids[0]), [])
        i = sib.index(uids[0]) if uids[0] in sib else 0
        if i == 0:
            return "すぐ下に、切り抜くものがありません"
        uids = [sib[i - 1], uids[0]]
    if len(uids) < 2:
        return "マスクの形と、切り抜くものの2つ以上を選んでください"
    order = flatten_tree(children_map(vs))
    front = max(uids, key=order.index)
    # 何でもマスクにできる: 見た目のアルファ (透明度) で切り抜くので、パス・図形・文字・
    # 画像・ペイントレイヤー・グループのどれでも同じように使える。
    # ただし中身が空だと何も見えなくなるので、その場合だけ断る
    front_ob = m[front]
    if front_ob.kind == 'TEXT':
        from . import geometry as _G
        if not _G.object_subpaths(front_ob):
            return "マスクにする文字が空です"
    elif front_ob.kind == 'IMAGE':
        if front_ob.image is None:
            return "マスクにする画像が入っていません"
    elif front_ob.kind == 'GROUP':
        if not children_map(vs).get(front, []):
            return "マスクにするグループが空です"
    g = group(vs, uids)
    if g:
        from . import render
        with render.suspended():
            vs.objects[index_of_uid(vs, g)].clip = True
            vs.objects[index_of_uid(vs, g)].name = "クリップグループ %d" % g
    return g


def arrange(vs, uids, mode):
    """重なり順を変える。mode: FRONT (最前面) / FORWARD (前面へ) / BACKWARD / BACK"""
    m = uid_map(vs)
    ch = children_map(vs)
    uids = [u for u in uids if u in m]
    by_parent = {}
    for u in uids:
        by_parent.setdefault(_parent_key(ch, m, u), []).append(u)
    changed = False
    for p, us in by_parent.items():
        sib = ch[p]
        before = list(sib)
        sel = [u for u in sib if u in us]
        rest = [u for u in sib if u not in us]
        if mode == 'FRONT':
            sib[:] = rest + sel
        elif mode == 'BACK':
            sib[:] = sel + rest
        elif mode == 'FORWARD':
            for i in range(len(sib) - 2, -1, -1):
                if sib[i] in us and sib[i + 1] not in us:
                    sib[i], sib[i + 1] = sib[i + 1], sib[i]
        elif mode == 'BACKWARD':
            for i in range(1, len(sib)):
                if sib[i] in us and sib[i - 1] not in us:
                    sib[i], sib[i - 1] = sib[i - 1], sib[i]
        changed |= sib != before
    if changed:
        reorder(vs, flatten_tree(ch))
    return changed


def move_to_layer(vs, uids, layer_uid):
    """オブジェクトを別のレイヤーの最前面へ移す。"""
    m = uid_map(vs)
    if layer_uid not in m or m[layer_uid].kind != 'LAYER':
        return False
    uids = [u for u in uids if u in m and m[u].kind != 'LAYER'
            and not set(ancestors(vs, u, m)) & set(uids)]
    if not uids:
        return False
    ch = children_map(vs)
    order = flatten_tree(ch)
    for u in sorted(uids, key=order.index):
        for lst in ch.values():
            if u in lst:
                lst.remove(u)
        ch.setdefault(layer_uid, []).append(u)
        m[u].parent_uid = layer_uid
    reorder(vs, flatten_tree(ch))
    prune_empty_groups(vs)
    return True


# -----------------------------------------------------------------------------
# 旧データの移行
# -----------------------------------------------------------------------------

def needs_migration(vs):
    return vs.schema_version < SCHEMA_VERSION and (vs.enabled or len(vs.paths) > 0)


def migrate(img):
    """旧データを今の形式に直す。移行したら True。
    v0.3.x: paths を objects へ移す / v0.4-0.5: レイヤーに入れる"""
    vs = img.vstroke
    if not needs_migration(vs) or img.library is not None:
        return False
    from . import render
    with render.suspended():
        if len(vs.paths) and not layers(vs):
            new_object(vs, kind='LAYER')
        for lp in vs.paths:
            oi = new_object(vs)
            ob = vs.objects[oi]
            ob.name = lp.name
            ob.visible = lp.visible
            copy_style(ob, lp)
            paints_from_legacy(ob)
            sp = ob.subpaths.add()
            for p in lp.points:
                q = sp.points.add()
                q.co = p.co
                q.handle_left = p.handle_left
                q.handle_right = p.handle_right
                q.select = False
            sp.closed = lp.closed
        if vs.schema_version < 5:
            # v0.7 まで: 塗りと線は1つずつ。塗り -> 線 の順に並べる
            for ob in vs.objects:
                if ob.kind in {'PATH', 'SHAPE'} and len(ob.paints) == 0:
                    paints_from_legacy(ob)
        if vs.schema_version < 7:
            # v0.10 までの文字はすべて点文字 (エリア文字・縦書きは無かった)
            for ob in vs.objects:
                if ob.kind == 'TEXT':
                    ob.text_kind = 'POINT'
        if vs.schema_version < 4:
            # v0.6 までは「重なりを抜く」だけだった。見た目が変わらないようにする
            for ob in vs.objects:
                ob.fill_rule = 'EVENODD'
        vs.paths.clear()
        ensure_layers(vs)
        if vs.schema_version < 8 and vs.base_image is not None:
            # v0.28.3 まで: 元の画像は固定の「下地」だった -> いちばん下のペイントレイヤーにする。
            # 下地の画像 (元の画像のコピー。埋め込み済み) をそのままレイヤーの画像にする
            base = vs.base_image
            base.use_fake_user = False
            try:
                base.name = "%s_%s" % (img.name, ORIGINAL_NAME)
            except Exception:
                pass
            attach_original(vs, base)
        set_active(vs, min(vs.active_index + 1, max(len(vs.objects) - 1, 0))
                   if vs.schema_version < 2 else vs.active_index)
        vs.schema_version = SCHEMA_VERSION
    print("[Vector Strokes] 旧データを移行しました:", img.name)
    return True


def migrate_all():
    changed = False
    for img in bpy.data.images:
        try:
            changed |= migrate(img)
        except Exception as e:
            print("[Vector Strokes] 移行に失敗:", img.name, e)
    return changed


classes = (VS_Point, VS_Stop, VS_Paint, VS_TextStyle, VS_TextLine, VS_Subpath,
           VS_Object, VS_TextAttr,
           VS_FontName, VS_LegacyPath,
           VS_Transform, VS_CornerProxy, VS_ImageData, VS_ToolSettings)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Image.vstroke = PointerProperty(type=VS_ImageData)
    bpy.types.WindowManager.vstroke_tool = PointerProperty(type=VS_ToolSettings)
    bpy.types.WindowManager.vstroke_font_families = CollectionProperty(type=VS_FontName)
    bpy.types.WindowManager.vstroke_font_styles = CollectionProperty(type=VS_FontName)


def unregister():
    del bpy.types.WindowManager.vstroke_font_styles
    del bpy.types.WindowManager.vstroke_font_families
    del bpy.types.WindowManager.vstroke_tool
    del bpy.types.Image.vstroke
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


# -----------------------------------------------------------------------------
# 「共通」で選ぶ (Select Similar。2026-09-22 ユーザー要望)
# -----------------------------------------------------------------------------

SIMILAR_MODES = (
    ('FILL_COLOR', "塗りの色", "塗りの色が同じものを選ぶ"),
    ('STROKE_COLOR', "線の色", "線の色が同じものを選ぶ"),
    ('STROKE_WIDTH', "線の太さ", "線の太さが同じものを選ぶ"),
    ('FILL_STROKE', "塗りと線", "塗りと線 (色・太さ) がどちらも同じものを選ぶ"),
    ('OPACITY', "不透明度", "不透明度が同じものを選ぶ"),
    ('BLEND', "描画モード", "描画モードが同じものを選ぶ"),
    ('KIND', "種類", "同じ種類 (図形・パス・文字・画像・ペイントレイヤー) を選ぶ"),
    ('FONT', "書体", "書体が同じ文字を選ぶ"),
)

LEAF_KINDS = {'PATH', 'SHAPE', 'TEXT', 'IMAGE'}


def _top_paint(ob, kind):
    """いちばん上の、表示している塗り / 線 (無ければ None)。"""
    got = [p for p in ob.paints if p.kind == kind and p.enabled
           and (kind != 'STROKE' or p.width > 0)]
    return got[-1] if got else None


def _paint_key(p):
    """塗り/線の「色」を比べるための値 (単色は色、グラデーションは種類と分岐点)。"""
    if p is None:
        return None
    r = lambda c: tuple(round(float(v), 4) for v in c)      # noqa: E731
    if p.paint_type == 'SOLID':
        return ('SOLID', r(p.color))
    return (p.paint_type, tuple((round(float(st.position), 4), r(st.color))
                                for st in sorted_stops(p)))


def similar_key(ob, mode):
    """mode で比べる値。比べられないもの (その項目を持たない) は None。"""
    if ob is None or ob.kind not in LEAF_KINDS:
        return None
    if mode == 'KIND':
        return (ob.kind, is_paint_layer(ob) if ob.kind == 'IMAGE' else False)
    if mode == 'OPACITY':
        return round(float(ob.opacity), 4)
    if mode == 'BLEND':
        return ob.blend_mode
    if mode == 'FONT':
        return ob.font_family if ob.kind == 'TEXT' else None
    if ob.kind == 'IMAGE':
        return None                                       # 画像には塗りと線が無い
    fill, stroke = _top_paint(ob, 'FILL'), _top_paint(ob, 'STROKE')
    width = round(float(stroke.width), 4) if stroke is not None else None
    if mode == 'FILL_COLOR':
        return _paint_key(fill)
    if mode == 'STROKE_COLOR':
        return _paint_key(stroke)
    if mode == 'STROKE_WIDTH':
        return width
    if mode == 'FILL_STROKE':
        f, s_ = _paint_key(fill), _paint_key(stroke)
        return None if f is None and s_ is None else (f, s_, width)
    return None


def similar_uids(vs, uid, mode, iso=0):
    """uid と mode の値が同じものの uid (並び順)。
    選べるものだけ (ロック中・非表示・マスクの形は除く)。グループの中のものも対象。
    iso (グループ編集中のグループ) を渡すと、その中だけから探す。"""
    m = uid_map(vs)
    ref = m.get(uid)
    want = similar_key(ref, mode)
    if want is None:
        return []
    ch = children_map(vs)
    inside = set(descendants(vs, iso, ch)) if iso else None
    out = []
    for ob in vs.objects:
        if ob.kind not in LEAF_KINDS or not is_editable(vs, ob.uid, m):
            continue
        if inside is not None and ob.uid not in inside:
            continue
        if is_clip_path(vs, ob.uid, m, ch):
            continue
        if similar_key(ob, mode) == want:
            out.append(ob.uid)
    return out


# -----------------------------------------------------------------------------
# 画像補正
# -----------------------------------------------------------------------------

# (名前, 何もしないときの値)。並びは計算の順番 (render.adjust_rgb) と同じ
ADJUST_DEFAULTS = (("exposure", 0.0), ("black", 0.0), ("white", 1.0), ("gamma", 1.0),
                   ("brightness", 0.0), ("contrast", 0.0), ("temperature", 0.0),
                   ("hue", 0.0), ("saturation", 0.0), ("lightness", 0.0), ("invert", False),
                   ("alpha_cut", 0.0))


ADJUST_KINDS = {'IMAGE', 'GROUP', 'LAYER', 'ADJUST'}


def adjust_values(ob):
    """色調補正の値 (比べられる形)。何もしない設定なら None。
    画像のほか、レイヤーとグループにもかけられる (中身をまとめた絵にかかる。v0.30.0)。"""
    if ob is None or ob.kind not in ADJUST_KINDS:
        return None
    vals = tuple((name, round(float(getattr(ob, "adj_" + name)), 5)
                  if not isinstance(default, bool) else bool(getattr(ob, "adj_" + name)))
                 for name, default in ADJUST_DEFAULTS)
    if ob.kind == 'ADJUST':
        # 調整レイヤーは下の絵全体にかかるので、アルファのしきい値は使わない
        # (キャンバスの透明な所まで消えてしまう)
        vals = tuple((n, 0.0 if n == "alpha_cut" else v) for n, v in vals)
    if all(v == d for (_, v), (_, d) in zip(vals, ADJUST_DEFAULTS)):
        return None
    return vals


def has_adjust(ob):
    return adjust_values(ob) is not None

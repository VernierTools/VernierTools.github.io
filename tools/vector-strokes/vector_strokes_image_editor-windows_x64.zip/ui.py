# SPDX-License-Identifier: GPL-3.0-or-later
"""サイドバー (N) の Vector タブと、アドオン設定。

0.34.0 でサイドバーを整理した (2026-10-17 ユーザー「UI がごちゃごちゃしている」)。
方針は「直感的に分かることが最優先。Illustrator・Affinity は参考にとどめる」:
- 不透明度と描画モードはレイヤー一覧の上 (Photoshop・Affinity と同じ場所。ここ1か所)
- 一覧の追加・削除のボタンは一覧の下に横1列。種類の多い追加は「+」のメニューにまとめる
- 「塗りと線」は 塗り / 線 / 効果 の見出しに分け、よく使う設定は最初から見せる
- 説明の文は、? のボタンにマウスを乗せると出るヒントにする
- 整列とパスファインダーは、選んでいるときだけ出す
- 書き出しは「画像」メニューと一覧の「…」、操作方法はレイヤーの見出しの ? から
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from bpy.types import Menu, Operator, Panel, UIList

from . import data, icons, keys, pathops, render, state, text, tools, transform
from .tool_base import isolation

KIND_ICONS = {'PATH': 'CURVE_BEZCURVE', 'TEXT': 'FONT_DATA', 'IMAGE': 'IMAGE_DATA',
              'GROUP': 'FILE_FOLDER', 'LAYER': 'RENDERLAYERS', 'CLIP': 'MOD_MASK',
              'ADJUST': 'MODIFIER'}
SHAPE_ICONS = {k: icon for k, _, _, icon, _ in data.SHAPE_TYPES}


class VS_AddonPrefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    hit_radius: FloatProperty(
        name="点の当たり判定", default=state.HIT_RADIUS_DEFAULT, min=4.0, max=60.0,
        description="点やハンドルをつかめる範囲の半径(画面上のピクセル、UIスケール考慮)")
    snap_distance: FloatProperty(
        name="スナップの距離", default=8.0, min=1.0, max=40.0,
        description="どれくらい近づいたら吸い付くか(画面上のピクセル)")
    paint_live_3d: BoolProperty(
        name="ペイント中も 3D ビューに反映", default=True,
        description="ブラシで描いている間も、筆を離すたびにキャンバスの画像を更新して、"
                    "3D ビューで様子を見られるようにする (大きな画像では、筆を離したときに"
                    "少し待つことがあります)")
    dblclick_pen: BoolProperty(
        name="ダブルクリックでパスの点を編集", default=False,
        description="選択ツールでパスや図形をダブルクリックしたら、ペンツールに切り替えて"
                    "点を編集する (Illustrator と同じ)。オフなら選ぶだけ。グループの中に入る・"
                    "文字の打ち直しは、どちらでもダブルクリックで行えます")

    def draw(self, context):
        self.layout.prop(self, "hit_radius", slider=True)
        self.layout.prop(self, "snap_distance", slider=True)
        self.layout.prop(self, "paint_live_3d")
        self.layout.prop(self, "dblclick_pen")


class VS_OT_set_tool(Operator):
    """編集中に使うツールを切り替える"""
    bl_idname = "vstroke.set_tool"
    bl_label = "ツールを切り替え"
    tool: EnumProperty(items=(('SELECT', "選択", "オブジェクトを選んで移動・拡大縮小・回転 (V)"),
                              ('PEN', "ペン", "パスを描く・点を編集 (P)"),
                              ('SHAPE', "図形", "矩形・楕円・多角形・星を作る (M / L)"),
                              ('GRADIENT', "グラデーション", "向きと長さを決める (G)"),
                              ('TEXT', "文字", "文字を入れる・打ち直す (T)"),
                              ('PENCIL', "鉛筆", "手で描いた線を、描きながら曲線にする")))

    @classmethod
    def description(cls, context, props):
        return {'SELECT': "オブジェクトを選んで移動・拡大縮小・回転 (V)",
                'PEN': "パスを描く・点を編集 (P)",
                'SHAPE': "矩形・楕円・多角形・星を作る (M / L)",
                'GRADIENT': "グラデーションの向きと長さを決める (G)",
                'TEXT': "文字を入れる・打ち直す (T)",
                'PENCIL': "手で描いた線を、描きながら曲線にする"}.get(props.tool, "")

    def execute(self, context):
        if not state.editing_image:
            bpy.ops.vstroke.edit('INVOKE_DEFAULT', tool=self.tool)
            return {'FINISHED'}
        area = next((a for a in context.screen.areas if a.type == 'IMAGE_EDITOR'
                     and getattr(a.spaces.active, "image", None) is not None
                     and a.spaces.active.image.name == state.editing_image), context.area)
        tools.set_tool(context.window, area, tools.TOOL_IDS[self.tool])
        return {'FINISHED'}


def _hint(layout, text, icon='QUESTION'):
    """マウスを乗せると説明が出る小さなボタン (押しても何もしない)。
    パネルに説明の文を何行も並べる代わりに使う。"""
    op = layout.operator("vstroke.hint", text="", icon=icon, emboss=False)
    op.text = text


def _icon_button(layout, op_id, icon_name, fallback_text, depress=False):
    """自作アイコンのボタン (アイコンが読めなければ短い文字にする)。"""
    i = icons.icon_id(icon_name)
    if i:
        return layout.operator(op_id, text="", icon_value=i, depress=depress)
    return layout.operator(op_id, text=fallback_text, depress=depress)


# -----------------------------------------------------------------------------
# 一覧の「選んでいる行」は、ウィンドウの側の値として出す
# -----------------------------------------------------------------------------
# 一覧の行を押すと、Blender は「Select List Item」という Undo の段を積む。
# ただしそれは、選んでいる行の値が Undo の対象のデータ (ここでは画像) にあるときだけ。
# 行を選ぶだけで段が積まれると、Undo しても見た目が変わらない段が大量にたまる
# (2026-10-05 ユーザー報告「いろいろな操作をしていると空の Undo が大量にできる」。
#  本物のクリックで「Select List Item」が積まれることを確かめた)。
# そこで一覧には、Undo の対象にならないウィンドウマネージャーの値を渡し、読み書きの先で
# 本当の値 (画像の側。保存される) に取り次ぐ。Photoshop・Illustrator でも、選ぶことは
# 履歴に入らない。

def _space_vs():
    """いま描いているイメージエディターのベクター編集のデータ (無ければ None)。"""
    sp = getattr(bpy.context, "space_data", None)
    img = getattr(sp, "image", None) if sp is not None else None
    if img is None:
        return None
    vs = img.vstroke
    return vs if vs.enabled else None


def _get_list_index(self):
    vs = _space_vs()
    return vs.active_index if vs is not None else -1


def _set_list_index(self, value):
    vs = _space_vs()
    if vs is not None and 0 <= value < len(vs.objects):
        cur = state.crop_edit
        if cur is not None and vs.objects[value].uid != cur[1]:
            from .select_tool import end_crop_edit
            end_crop_edit()              # 別のものを選んだら、トリミングを終える
        vs.active_index = value          # 押した行を選ぶ (data._on_active) のは今までどおり


def display_order(vs, ch=None):
    """レイヤー一覧に出す並び (uid を上から順に)。

    実データは「後ろにあるものほど手前」の順。一覧は Illustrator・Photoshop と同じく
    **手前のものほど上**に出す。ただし親 (レイヤー・グループ) は子より上のままにする。
    """
    ch = ch or data.children_map(vs)
    out = []

    def walk(uid):
        for kid in reversed(ch.get(uid, [])):
            out.append(kid)
            walk(kid)

    walk(0)
    return out


def _kind_icon(item):
    if item.kind in {'GROUP', 'LAYER'}:
        return KIND_ICONS['CLIP' if item.clip else item.kind]
    if item.kind == 'IMAGE' and data.is_paint_layer(item):
        return 'BRUSH_DATA'
    if item.kind == 'SHAPE':
        return SHAPE_ICONS.get(item.shape_type, 'MESH_PLANE')
    return KIND_ICONS.get(item.kind, 'CURVE_BEZCURVE')


def _tree_head(row, data_, item):
    """一覧の行の頭 (深さの字下げと、レイヤー・グループの開閉)。"""
    for _ in range(data.depth(data_, item.uid)):
        row.separator(factor=1.5)
    if item.kind in {'GROUP', 'LAYER'}:
        row.prop(item, "expanded", text="", emboss=False,
                 icon='DOWNARROW_HLT' if item.expanded else 'RIGHTARROW')


class _ObjectListBase:
    """レイヤー一覧の共通部分 (並び・開閉)。

    **登録した UIList を、別の UIList で直接継承しないこと。** 0.33.0 で
    VS_UL_paint_targets(VS_UL_objects) としたら、Blender の中で VS_UL_objects の型が
    作れなくなり (「subtype could not be generated」)、普段のレイヤー一覧の行が
    空になった (2026-09-27 ユーザー報告「レイヤー画面が透明になる」)。
    共通部分はこの登録しないクラスに置き、それぞれ UIList を継承する。"""

    def filter_items(self, context, data_, propname):
        objs = getattr(data_, propname)
        flags = [self.bitflag_filter_item] * len(objs)
        ch = data.children_map(data_)
        hidden = set()
        for ob in objs:
            if ob.kind in {'GROUP', 'LAYER'} and not ob.expanded:
                hidden.update(data.descendants(data_, ob.uid, ch))
        for i, ob in enumerate(objs):
            if ob.uid in hidden:
                flags[i] = 0
        # 表示だけ「手前が上」に並べ替える (実データの並びは変えない)
        place = {uid: pos for pos, uid in enumerate(display_order(data_, ch))}
        order, extra = [], len(place)
        for ob in objs:
            pos = place.get(ob.uid)
            if pos is None:          # 親が見つからないなど、念のための逃げ道
                pos, extra = extra, extra + 1
            order.append(pos)
        return flags, order


class VS_UL_objects(_ObjectListBase, UIList):
    def draw_item(self, context, layout, data_, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        # 目と鍵は行の左端 (Illustrator・Photoshop と同じ)。鍵は掛けていないときは薄く出す
        row.prop(item, "visible", text="", emboss=False,
                 icon='HIDE_OFF' if item.visible else 'HIDE_ON')
        sub = row.row(align=True)
        sub.active = item.locked
        sub.prop(item, "locked", text="", emboss=False,
                 icon='LOCKED' if item.locked else 'UNLOCKED')
        _tree_head(row, data_, item)
        ic = _kind_icon(item)
        if item.kind == 'LAYER':
            sub = row.row()
            sub.ui_units_x = 0.6
            sub.prop(item, "layer_color", text="")
        row.prop(item, "name", text="", emboss=False, icon=ic)
        if item.mask_image is not None:
            # レイヤーマスクの印 (押すとマスクのオン/オフ)
            sub = row.row(align=True)
            sub.active = item.mask_enable        # オフのときは薄く出す
            sub.prop(item, "mask_enable", text="", emboss=False, icon='IMAGE_ALPHA')
        if data.is_clip_path(data_, item.uid):
            row.label(text="", icon='MOD_MASK')
        if item.kind not in {'LAYER', 'ADJUST'}:
            # 選択の丸 (Illustrator と同じく、ここを押すと選べる。⌘/Shift で複数選択)
            op = row.operator("vstroke.list_select", text="", emboss=False,
                              icon='RADIOBUT_ON' if item.select else 'RADIOBUT_OFF')
            op.index = index
            op.image = data_.id_data.name if data_.id_data else ""
        else:
            row.label(text="", icon='BLANK1')     # 丸の分だけ空けて、右端をそろえる


class VS_UL_paint_targets(_ObjectListBase, UIList):
    """ブラシで描いている間の一覧。名前を押すと、描く先がそのレイヤーに変わる
    (半分塗りの四角はそのマスク)。いま描いている所は押された見た目になる。
    並び・開閉は普段の一覧と同じ。重なり順や表示の変更はここではできない。"""

    def draw_item(self, context, layout, data_, item, icon, active_data, active_propname, index):
        info = state.paint or {}
        cur = item.uid == info.get("uid")
        on_mask = info.get("mode") == 'LMASK'
        row = layout.row(align=True)
        _tree_head(row, data_, item)
        ic = _kind_icon(item)
        left = row.row(align=True)
        left.alignment = 'LEFT'           # ボタンの文字は真ん中に寄るので、名前は左に詰める
        if item.kind == 'IMAGE' and item.image is not None:
            here = cur and not on_mask
            op = left.operator("vstroke.paint_switch", text=item.name, icon=ic,
                               emboss=here, depress=here)
            op.uid = item.uid
            op.target = 'CONTENT'
        else:
            left.active = item.kind in {'GROUP', 'LAYER', 'ADJUST'}   # 図形などは描けない
            left.label(text=item.name, icon=ic)
        right = row.row(align=True)
        right.alignment = 'RIGHT'
        if item.mask_image is not None:
            here = cur and on_mask
            op = right.operator("vstroke.paint_switch", text="", icon='IMAGE_ALPHA',
                                emboss=here, depress=here)
            op.uid = item.uid
            op.target = 'MASK'
        if not item.visible:
            right.label(text="", icon='HIDE_ON')


def draw_paint_targets(layout, img):
    """ブラシで描いている間の、描く先を切り替える一覧。"""
    canvas = bpy.data.images.get(img.vstroke.paint_owner)
    if canvas is None or not canvas.vstroke.enabled:
        layout.label(text="描いているキャンバスが見つかりません", icon='ERROR')
        return
    row = layout.row()
    row.label(text="名前を押すと描く先が変わります", icon='BRUSH_DATA')
    _hint(row, "名前を押すと、そのレイヤーに描きます\n"
               "半分塗りの四角を押すと、そのレイヤーマスクに描きます\n"
               "重なり順や表示の切り替えは、ベクターに戻ってから行います")
    layout.template_list("VS_UL_paint_targets", "", canvas.vstroke, "objects",
                         bpy.context.window_manager, "vstroke_paint_target_index", rows=10)


def _vs(context):
    img = context.space_data.image if context.space_data else None
    return img, (img.vstroke if img is not None else None)


def _editing(context):
    img, vs = _vs(context)
    return img is not None and state.editing_image == img.name


class _VecPanel:
    """Vector タブのパネル共通 (ベクター編集を有効にした画像のときだけ出す)。"""
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Vector"

    @classmethod
    def poll(cls, context):
        img, vs = _vs(context)
        return vs is not None and vs.enabled and render.available()


def _active(context):
    """ベクター編集の画像で、いま選んでいるもの (無ければ None)。"""
    img, vs = _vs(context)
    if vs is None or not vs.enabled:
        return None
    return data.active_object(vs)


class VS_MT_add(Menu):
    """一覧の「+」メニュー (レイヤーの種類が多いので、追加はここにまとめる)。"""
    bl_idname = "VS_MT_add"
    bl_label = "追加"

    def draw(self, context):
        layout = self.layout
        layout.operator("vstroke.layer_add", icon='RENDERLAYERS')
        layout.operator("vstroke.paint_layer_add", icon='BRUSH_DATA')
        layout.operator("vstroke.adjust_add", icon='MODIFIER')
        layout.separator()
        layout.operator("vstroke.image_add", text="画像・SVG を読み込む", icon='IMAGE_DATA')
        layout.separator()
        layout.operator("vstroke.mask_add", text="レイヤーマスク (すべて表示)",
                        icon='IMAGE_ALPHA').fill = 'WHITE'
        layout.operator("vstroke.mask_add", text="レイヤーマスク (すべて隠す)",
                        icon='IMAGE_ALPHA').fill = 'BLACK'


class VS_MT_object(Menu):
    """一覧の「…」メニュー (あまり使わない操作をまとめる)。"""
    bl_idname = "VS_MT_object"
    bl_label = "オブジェクト"

    def draw(self, context):
        layout = self.layout
        layout.operator("vstroke.copy", icon='COPYDOWN')
        layout.operator("vstroke.copy", text="切り取り", icon='X').cut = True
        layout.operator("vstroke.paste", icon='PASTEDOWN')
        layout.separator()
        # アクティブなものと同じ塗り・線などをまとめて選ぶ (Illustrator の「選択 → 共通」)
        layout.operator_menu_enum("vstroke.select_similar", "mode", text="共通のものを選ぶ",
                                  icon='RESTRICT_SELECT_OFF')
        layout.separator()
        layout.operator("vstroke.group", icon='NEWFOLDER')
        layout.operator("vstroke.ungroup", icon='FOLDER_REDIRECT')
        layout.operator_menu_enum("vstroke.move_to_layer", "layer",
                                  text="選択をレイヤーへ移動", icon='RENDERLAYERS')
        layout.separator()
        layout.label(text="重なり順")
        for mode, label, icon in (('FRONT', "最前面へ", 'TRIA_UP_BAR'),
                                  ('FORWARD', "前面へ", 'TRIA_UP'),
                                  ('BACKWARD', "背面へ", 'TRIA_DOWN'),
                                  ('BACK', "最背面へ", 'TRIA_DOWN_BAR')):
            layout.operator("vstroke.arrange", text=label, icon=icon).mode = mode
        layout.separator()
        layout.label(text="パス")
        layout.operator("vstroke.point_type", text="点を滑らかに",
                        icon='HANDLE_AUTO').kind = 'SMOOTH'
        layout.operator("vstroke.point_type", text="点を角に",
                        icon='HANDLE_VECTOR').kind = 'CORNER'
        layout.operator("vstroke.path_split", icon='UNLINKED')
        layout.operator("vstroke.path_reverse", icon='ARROW_LEFTRIGHT')
        layout.operator("vstroke.shape_to_path", icon='CURVE_BEZCURVE')
        layout.operator("vstroke.text_outline", icon='OUTLINER_OB_CURVE')
        layout.separator()
        layout.operator("vstroke.clip_make", icon='MOD_MASK')
        layout.operator("vstroke.clip_release", icon='X')
        layout.separator()
        layout.operator("vstroke.export", text="SVG で書き出す…", icon='EXPORT').fmt = 'SVG'
        layout.operator("vstroke.export", text="PDF で書き出す…", icon='EXPORT').fmt = 'PDF'
        layout.separator()
        img, vs = _vs(context)
        if vs is not None and vs.enabled:
            layout.prop(vs, "live_update")
        layout.operator("vstroke.refresh", icon='FILE_REFRESH')
        layout.operator("vstroke.apply", icon='CHECKMARK')


class VS_MT_arrange(Menu):
    bl_idname = "VS_MT_arrange"
    bl_label = "重なり順"

    def draw(self, context):
        for mode, label, icon in (('FRONT', "最前面へ", 'TRIA_UP_BAR'),
                                  ('FORWARD', "前面へ", 'TRIA_UP'),
                                  ('BACKWARD', "背面へ", 'TRIA_DOWN'),
                                  ('BACK', "最背面へ", 'TRIA_DOWN_BAR')):
            self.layout.operator("vstroke.arrange", text=label, icon=icon).mode = mode


class VS_MT_pathfinder(Menu):
    bl_idname = "VS_MT_pathfinder"
    bl_label = "パスファインダー"

    def draw(self, context):
        layout = self.layout
        for k, name, _desc in pathops.MODES:
            if k == 'DIVIDE':
                layout.separator()
            i = icons.icon_id("pf_" + k.lower())
            kw = {"icon_value": i} if i else {}
            layout.operator("vstroke.pathfinder", text=name, **kw).mode = k


class VS_MT_context(Menu):
    """キャンバスの右クリックのメニュー (選んでいるものに合わせて中身が変わる)。
    いちばん下は「ベクター編集を終了」(2026-10-17 までは右クリックで終了していた)。"""
    bl_idname = "VS_MT_context"
    bl_label = "ベクター編集"

    def draw(self, context):
        layout = self.layout
        img, vs = _vs(context)
        if vs is None or not vs.enabled:
            layout.operator("vstroke.edit_exit", icon='PANEL_CLOSE')
            return
        items = transform.selected_items(vs)
        m = data.uid_map(vs)
        kinds = {m[u].kind for u in items if u in m}
        layout.operator("vstroke.copy", icon='COPYDOWN')
        layout.operator("vstroke.copy", text="切り取り", icon='X').cut = True
        layout.operator("vstroke.paste", icon='PASTEDOWN')
        if items:
            layout.operator("vstroke.path_remove", icon='TRASH')
            layout.separator()
            layout.operator("vstroke.group", icon='NEWFOLDER')
            if 'GROUP' in kinds:
                layout.operator("vstroke.ungroup", icon='FOLDER_REDIRECT')
            layout.menu("VS_MT_arrange", icon='SORTSIZE')
            layout.operator_menu_enum("vstroke.move_to_layer", "layer",
                                      text="レイヤーへ移動", icon='RENDERLAYERS')
            layout.separator()
            layout.operator("vstroke.clip_make", icon='MOD_MASK')
            if 'GROUP' in kinds or 'LAYER' in kinds:
                layout.operator("vstroke.clip_release", icon='X')
            if _shape_count(vs) >= 2:
                layout.menu("VS_MT_pathfinder", icon='SELECT_INTERSECT')
            if 'SHAPE' in kinds:
                layout.operator("vstroke.shape_to_path", icon='CURVE_BEZCURVE')
            if 'TEXT' in kinds:
                layout.operator("vstroke.text_outline", icon='OUTLINER_OB_CURVE')
            if kinds == {'IMAGE'} and len(items) == 1:
                layout.operator("vstroke.crop_edit", icon='SELECT_SET')
            cur = state.current_tool.name if state.current_tool is not None else ""
            if cur == 'PEN' and 'PATH' in kinds:
                layout.separator()
                layout.operator("vstroke.point_type", text="点を滑らかに",
                                icon='HANDLE_AUTO').kind = 'SMOOTH'
                layout.operator("vstroke.point_type", text="点を角に",
                                icon='HANDLE_VECTOR').kind = 'CORNER'
                layout.operator("vstroke.path_split", icon='UNLINKED')
                layout.operator("vstroke.path_reverse", icon='ARROW_LEFTRIGHT')
            layout.separator()
            layout.operator_menu_enum("vstroke.select_similar", "mode",
                                      text="共通のものを選ぶ", icon='RESTRICT_SELECT_OFF')
            layout.operator("vstroke.deselect", icon='X')
        layout.separator()
        layout.operator("vstroke.edit_exit", icon='PANEL_CLOSE')


class VS_PT_main(Panel):
    """レイヤー (オブジェクトの一覧)。"""
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Vector"
    bl_label = "レイヤー"
    bl_order = 0

    def draw_header_preset(self, context):
        img, vs = _vs(context)
        if vs is not None and vs.enabled:
            self.layout.popover("VS_PT_help", text="", icon='QUESTION')

    def draw(self, context):
        layout = self.layout
        if not render.available():
            col = layout.column()
            col.alert = True
            col.label(text="描画ライブラリ(Skia)を読み込めません", icon='ERROR')
            col.label(text=render.SKIA_ERROR[:80])
            return
        img, vs = _vs(context)
        if img is None:
            layout.label(text="画像を開いてください")
            return
        if not vs.enabled:
            if vs.paint_owner:
                # ブラシで描いている間に出ているのはペイントレイヤーの画像。ここで有効化や
                # レイヤーの操作をしても、描いているキャンバスには届かない (2026-09-25 ユーザー報告)。
                # 描く先の切り替えだけできる一覧を出す (2026-09-26)
                draw_paint_targets(layout, img)
                return
            from . import operators
            why = operators.enable_problem(img, deep=False)
            if why:
                if "」の" in why:
                    # 「キャンバス名」の / ○○の画像です の2行に (サイドバーの幅で切れないように)
                    head, tail = why.split("」の", 1)
                    col = layout.column(align=True)
                    col.label(text=head + "」の", icon='ERROR')
                    col.label(text=tail, icon='BLANK1')
                else:
                    layout.label(text=why, icon='ERROR')
                if operators.owner_canvas(img) is not None:
                    row = layout.row()
                    row.scale_y = 1.4
                    row.operator("vstroke.show_canvas", icon='LOOP_BACK')
                return
            row = layout.row()
            row.scale_y = 1.4
            row.operator("vstroke.enable", icon='CURVE_BEZCURVE')
            _hint(row, "元の画像は、いちばん下のレイヤーになります")
            # ベクター編集にしていない普通の画像にも使える画像の処理
            box = layout.box()
            box.label(text="この画像の処理 (画素を書き換えます)", icon='IMAGE_ALPHA')
            _draw_cutoff(box, context)
            return

        if _editing(context):
            row = layout.row(align=True)
            row.label(text="編集中", icon='REC')
            row.operator("vstroke.deselect", text="選択解除", icon='X')
            if isolation(img.name, vs):
                layout.label(text="グループの中を編集中 (Esc で戻る)", icon='FILE_FOLDER')
        else:
            row = layout.row()
            row.scale_y = 1.4
            row.operator("vstroke.set_tool", text="ベクター編集を始める",
                         icon='RESTRICT_SELECT_OFF').tool = 'SELECT'

        # 不透明度と描画モード: 選んでいるものにかかる (Photoshop・Affinity と同じく一覧の上)
        ob = data.active_object(vs)
        row = layout.row(align=True)
        if ob is None:
            row.active = False
            row.label(text="不透明度: 一覧で選ぶと変えられます")
        elif ob.kind == 'ADJUST':
            row.prop(ob, "opacity", text="強さ", slider=True)
        else:
            sub = row.row(align=True)
            sub.ui_units_x = 5.0
            sub.prop(ob, "blend_mode", text="")
            row.prop(ob, "opacity", text="不透明度", slider=True)

        layout.template_list("VS_UL_objects", "", vs, "objects",
                             context.window_manager, "vstroke_list_index", rows=10)

        # 一覧の下のボタン (Illustrator・Affinity と同じく横1列。削除はいちばん右)
        bar = layout.row()
        left = bar.row(align=True)
        left.alignment = 'LEFT'
        left.menu("VS_MT_add", text="", icon='ADD')
        left.operator("vstroke.image_add", text="", icon='IMAGE_DATA')
        left.operator("vstroke.group", text="", icon='NEWFOLDER')
        left.separator()
        left.operator("vstroke.path_move", text="", icon='TRIA_UP').direction = 'UP'
        left.operator("vstroke.path_move", text="", icon='TRIA_DOWN').direction = 'DOWN'
        right = bar.row(align=True)
        right.alignment = 'RIGHT'
        right.menu("VS_MT_object", text="", icon='THREE_DOTS')
        right.operator("vstroke.path_remove", text="", icon='TRASH')


class VS_PT_paint(_VecPanel, Panel):
    """ブラシで描いている間だけ出る、戻るためのパネル。"""
    bl_label = "ペイント中"
    bl_order = 0

    @classmethod
    def poll(cls, context):
        sp = context.space_data if context else None
        im = getattr(sp, "image", None) if sp is not None else None
        return im is not None and bool(im.vstroke.paint_owner)

    def draw(self, context):
        layout = self.layout
        im = context.space_data.image
        on_mask = (state.paint or {}).get("mode") == 'LMASK'
        row = layout.row()
        if on_mask:
            row.label(text="レイヤーマスクに描いています", icon='IMAGE_ALPHA')
            _hint(row, "白で見せる・黒で隠す・灰色で半透明\n"
                       "消しゴムで消した所は、白と同じ (見える)\n"
                       "元のキャンバス: %s" % im.vstroke.paint_owner)
        else:
            row.label(text="ブラシで描いています", icon='BRUSH_DATA')
            _hint(row, "他のレイヤーも重ねて表示しています\n"
                       "描く先は「レイヤー」の一覧で切り替えられます\n"
                       "元のキャンバス: %s" % im.vstroke.paint_owner)
        row = layout.row()
        row.scale_y = 1.6
        row.operator("vstroke.paint_end", icon='LOOP_BACK')
        # 3D ビューのテクスチャペイントでも、このレイヤーに描ける (2026-10-18)
        from . import paint3d
        row = layout.row()
        if paint3d.can_paint_3d():
            row.label(text="3D ビューからも描けます", icon='VIEW3D')
            _hint(row, "ペイント中は、3D ビューでオブジェクトに直接描いた分も\n"
                       "このレイヤーに入ります (UV の位置で描かれます)\n"
                       "ベクターに戻ると、元のテクスチャペイントの設定に戻ります")
        else:
            row.active = False
            row.label(text="3D ビューからは描けません", icon='VIEW3D')
            _hint(row, "動かしたり拡大したりした画像は、UV の位置と合わないため\n"
                       "3D ビューからは描けません (イメージエディターでは描けます)")
        from . import operators
        _, ob = operators.paint_target(im)
        if on_mask:
            return
        box = layout.box()
        box.label(text="アルファ", icon='IMAGE_ALPHA')
        if ob is not None:
            _draw_paint_lock(box, ob)
        _draw_cutoff(box, context)


def _draw_paint_lock(layout, ob):
    """透明部分をロック (ペイントレイヤー)。"""
    row = layout.row(align=True)
    row.prop(ob, "paint_lock_alpha", icon='LOCKED' if ob.paint_lock_alpha else 'UNLOCKED')
    sub = row.row(align=True)
    sub.active = ob.paint_lock_alpha
    sub.prop(ob, "paint_lock_threshold", text="しきい値", slider=True)


def _draw_cutoff(layout, context):
    """しきい値より薄い所を消す (画素を書き換える。Undo できる)。"""
    ts = context.window_manager.vstroke_tool
    row = layout.row(align=True)
    row.prop(ts, "cut_threshold", slider=True)
    row.operator("vstroke.alpha_cutoff", text="薄い所を消す", icon='IMAGE_ALPHA')


def _draw_adjust_body(layout, ob):
    """色調補正のつまみ (その画像・そのレイヤーの中身だけにかかる。元のものは変えない)。"""
    col = layout.column(align=True)
    col.prop(ob, "adj_exposure", slider=True)
    col.prop(ob, "adj_brightness", slider=True)
    col.prop(ob, "adj_contrast", slider=True)
    col = layout.column(align=True)
    col.label(text="レベル補正")
    row = col.row(align=True)
    row.prop(ob, "adj_black", slider=True)
    row.prop(ob, "adj_gamma")
    row.prop(ob, "adj_white", slider=True)
    col = layout.column(align=True)
    col.prop(ob, "adj_hue", slider=True)
    col.prop(ob, "adj_saturation", slider=True)
    col.prop(ob, "adj_lightness", slider=True)
    col.prop(ob, "adj_temperature", slider=True)
    layout.prop(ob, "adj_invert")
    if ob.kind != 'ADJUST':
        layout.prop(ob, "adj_alpha_cut", slider=True)


def _draw_adjust(layout, ob, closed=True):
    """色調補正の欄 (開け閉めできる。見出しの右に「元に戻す」)。"""
    header, body = layout.panel("vs_adjust_%s" % ob.kind.lower(), default_closed=closed)
    row = header.row(align=True)
    row.label(text="色調補正", icon='MODIFIER')
    if data.has_adjust(ob):
        row.operator("vstroke.image_adjust_reset", text="", icon='LOOP_BACK', emboss=False)
    if ob.kind in {'LAYER', 'GROUP'}:
        _hint(row, "中身をまとめた絵にかかります (下のレイヤーには効きません)\n"
                   "下のレイヤーまで補正するなら、調整レイヤーを使います")
    elif data.is_paint_layer(ob) and data.has_adjust(ob):
        _hint(row, "描いている間は、補正前の色で表示されます")
    if body is not None:
        _draw_adjust_body(body, ob)


# -----------------------------------------------------------------------------
# 塗りと線 (塗り / 線 / 効果 の見出しに分ける)
# -----------------------------------------------------------------------------
# 2026-10-17: はじめは Illustrator のアピアランス (塗り・線・効果を1本の一覧に混ぜ、
# 行を開くと詳細) にする案だったが、ユーザー「直感的な UI は譲れない」で見直した。
# 種類ごとに見出しを付け、よく使う設定は最初から見せる。並びの決まり
# (上ほど手前) を知らなくても読めるように、同じ種類が1つのときは並べ替えのボタンを出さない。

CAP_ICONS = (('BUTT', "cap_butt", "なし"), ('ROUND', "cap_round", "丸"),
             ('SQUARE', "cap_square", "四角"))
JOIN_ICONS = (('MITER', "join_miter", "尖"), ('ROUND', "join_round", "丸"),
              ('BEVEL', "join_bevel", "切"))
ALIGN_ICONS = (('INSIDE', "align_inside", "内"), ('CENTER', "align_center", "中"),
               ('OUTSIDE', "align_outside", "外"))


def _enum_buttons(layout, index, p, prop, values):
    """塗り/線の設定を、絵の付いたボタンを並べて選ぶ (押されているのが今の設定)。"""
    cur = getattr(p, prop)
    row = layout.row(align=True)
    for value, icon_name, short in values:
        op = _icon_button(row, "vstroke.paint_set", icon_name, short, depress=(cur == value))
        op.index = index
        op.prop = prop
        op.value = value
    return row


def _indent(layout):
    """1段下げた列 (行の下に付く細かい設定用)。"""
    row = layout.row()
    row.separator(factor=1.2)
    return row.column()


def _on_ramp_commit(paint):
    """カラーランプで編集した塗り/線を「選んでいる塗り/線」にする
    (続けて G を押したとき、キャンバスで同じものを動かせるように)。"""
    ob = data.object_of_paint(paint)
    if ob is None:
        return
    for k, p in enumerate(ob.paints):
        if p == paint:
            ob.active_paint = k
            return


def _paint_getter(img_name, uid, index):
    """ramp_sync が後で塗り/線を取り直すための関数 (Undo で参照が変わるため名前と番号で持つ)。"""
    def get():
        img = bpy.data.images.get(img_name)
        if img is None or not img.vstroke.enabled:
            return None
        k = data.index_of_uid(img.vstroke, uid)
        if k < 0:
            return None
        ob = img.vstroke.objects[k]
        return ob.paints[index] if 0 <= index < len(ob.paints) else None
    return get


def _draw_gradient(layout, ob, i, p):
    """グラデーションの分岐点。Blender のカラーランプで編集する (ramp_sync)。
    印のドラッグ・+/−・色の選択がそのまま使える。ランプの準備ができるまでの一瞬は数値の行。"""
    from . import ramp_sync
    box = layout.box()
    img = ob.id_data
    name = ramp_sync.PREFIX + str(i)
    owner = "%s|%d|%d" % (img.name, ob.uid, i)
    ramp_sync.want(name, owner, _paint_getter(img.name, ob.uid, i))
    if ramp_sync.is_ready(name, owner):
        box.template_color_ramp(ramp_sync.holder_for_draw(name), ramp_sync.RAMP_PROP,
                                expand=True)
    else:
        col = box.column(align=True)
        for k, st in enumerate(p.stops):
            row = col.row(align=True)
            row.prop(st, "position", text="")
            row.prop(st, "color", text="")
    # 押すと、この塗り/線をキャンバスのグラデーションツールで動かす。いま動かしている
    # ものは押された見た目にする (塗りと線の両方がグラデーションのときに分かるように)
    from . import gradient_tool
    cur = state.current_tool.name if state.current_tool is not None else ""
    gob, gi = gradient_tool.target_index(img.vstroke)
    here = cur == 'GRADIENT' and gob is not None and gob.uid == ob.uid and gi == i
    row = box.row(align=True)
    row.operator("vstroke.gradient_canvas", icon='MOD_HUE_SATURATION',
                 depress=here).index = i
    header, body = box.panel("vs_grad_pos_%d" % i, default_closed=True)
    header.label(text="位置を数値で")
    if body is not None:
        col = body.column(align=True)
        col.prop(p, "g_start", text="始点" if p.paint_type == 'LINEAR' else "中心")
        col.prop(p, "g_end", text="終点" if p.paint_type == 'LINEAR' else "外周")


def _paint_row_tail(row, ob, i, p, many):
    """行の右側: 並べ替え (同じ種類が2つ以上のとき) ・目・削除。"""
    if many:
        sub = row.row(align=True)
        op = sub.operator("vstroke.paint_move", text="", icon='TRIA_UP')
        op.direction = 'UP'
        op.index = i
        op = sub.operator("vstroke.paint_move", text="", icon='TRIA_DOWN')
        op.direction = 'DOWN'
        op.index = i
    row.prop(p, "enabled", text="", emboss=False,
             icon='HIDE_OFF' if p.enabled else 'HIDE_ON')
    row.operator("vstroke.paint_remove", text="", icon='REMOVE').index = i


def _section_head(layout, label, icon_kw, add_kind=None, hint=None):
    row = layout.row(align=True)
    row.label(text=label, **icon_kw)
    if hint:
        _hint(row, hint)
    if add_kind:
        row.operator("vstroke.paint_add", text="", icon='ADD').kind = add_kind
    return row


def _draw_fills(layout, ob):
    idx = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL'][::-1]   # 手前を上に
    many = len(idx) > 1
    _section_head(layout, "塗り", icons.kw("fill", 'SHADING_SOLID'), 'FILL',
                  "上にあるものほど手前に描かれます" if many else None)
    if not idx:
        sub = layout.row()
        sub.active = False
        sub.label(text="塗りなし (+ で追加)")
    for i in idx:
        p = ob.paints[i]
        row = layout.row(align=True)
        # 塗り方は文字のドロップダウン (絵だけのボタンでは、グラデーションかどうか
        # 分かりにくかった。2026-10-17 ユーザー要望)。単色のときは色をその左に
        if p.paint_type == 'SOLID':
            row.prop(p, "color", text="")
        row.prop(p, "paint_type", text="")
        _paint_row_tail(row, ob, i, p, many)
        if p.paint_type != 'SOLID':
            _draw_gradient(_indent(layout), ob, i, p)
    if idx and ob.kind == 'PATH':
        row = layout.row(align=True)
        row.label(text="塗りの規則")
        row.prop(ob, "fill_rule", text="")


def _draw_strokes(layout, ob):
    idx = [k for k, p in enumerate(ob.paints) if p.kind == 'STROKE'][::-1]
    many = len(idx) > 1
    _section_head(layout, "線", icons.kw("stroke", 'SHADING_WIRE'), 'STROKE',
                  "上にあるものほど手前に描かれます" if many else None)
    if not idx:
        sub = layout.row()
        sub.active = False
        sub.label(text="線なし (+ で追加)")
    fills = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
    can_align = data.can_align_stroke(ob)
    for i in idx:
        p = ob.paints[i]
        # 1行目は塗りと同じ形 (色・塗り方のドロップダウン・目・削除)。線幅はその下
        row = layout.row(align=True)
        if p.paint_type == 'SOLID':
            row.prop(p, "color", text="")
        row.prop(p, "paint_type", text="")
        _paint_row_tail(row, ob, i, p, many)

        col = _indent(layout)
        col.prop(p, "width", text="線幅")
        r = col.row(align=True)
        r.label(text="位置")
        sub = _enum_buttons(r, i, p, 'align', ALIGN_ICONS)
        if not can_align:
            sub.active = False
        r.separator()
        r.label(text="端")
        _enum_buttons(r, i, p, 'cap', CAP_ICONS)
        r = col.row(align=True)
        r.label(text="角")
        _enum_buttons(r, i, p, 'join', JOIN_ICONS)
        if p.join == 'MITER':
            col.prop(p, "miter_limit")
        r = col.row(align=True)
        r.prop(p, "dash_enable")
        if fills:
            under = i < fills[0]
            op = r.operator("vstroke.paint_move", text="塗りの下に描く", depress=under)
            op.direction = 'ABOVE_FILL' if under else 'BELOW_FILL'
            op.index = i
        if p.dash_enable:
            dc = col.column(align=True)
            for k in range(3):
                rr = dc.row(align=True)
                rr.prop(p, "dash", index=k * 2, text="線分" if k == 0 else "")
                rr.prop(p, "dash", index=k * 2 + 1, text="間隔" if k == 0 else "")
            col.prop(p, "dash_offset")
        if p.paint_type != 'SOLID':
            _draw_gradient(col, ob, i, p)


class VS_MT_fx_add(Menu):
    """「効果」の + メニュー (まだ付けていない効果)。"""
    bl_idname = "VS_MT_fx_add"
    bl_label = "効果を追加"

    def draw(self, context):
        from . import operators
        layout = self.layout
        ob = _active(context)
        if ob is None:
            return
        rest = [f for f in operators.fx_available(ob) if not operators.fx_on(ob, f[0])]
        if not rest:
            layout.label(text="すべて付いています")
        for name, label, icon, _ in rest:
            op = layout.operator("vstroke.fx_set", text=label, icon=icon)
            op.name = name
            op.on = True


def _draw_fx_body(col, ob, name):
    if name == 'fx_shadow_enable':
        col.prop(ob, "fx_shadow_offset")
        row = col.row(align=True)
        row.prop(ob, "fx_shadow_blur")
        sub = row.row(align=True)
        sub.ui_units_x = 2.0
        sub.prop(ob, "fx_shadow_color", text="")
    elif name == 'fx_blur_enable':
        col.prop(ob, "fx_blur_amount")
    elif name == 'fx_glow_enable':
        row = col.row()
        row.prop(ob, "fx_glow_kind", expand=True)
        row = col.row(align=True)
        row.prop(ob, "fx_glow_size")
        sub = row.row(align=True)
        sub.ui_units_x = 2.0
        sub.prop(ob, "fx_glow_color", text="")
        if ob.kind in {'GROUP', 'LAYER'} and ob.fx_glow_kind == 'INNER':
            col.label(text="内側の光彩は、パスと図形だけに効きます", icon='INFO')
    elif name == 'fx_mirror_enable':
        row = col.row()
        row.prop(ob, "fx_mirror_mode", expand=True)
    elif name == 'fx_grain_enable':
        col.prop(ob, "fx_grain_amount", slider=True)
        col.prop(ob, "fx_grain_size")
        col.prop(ob, "fx_grain_mono")
    elif name == 'corner_round':
        col.prop(ob, "corner_round", text="丸み")


def _draw_effects(layout, ob):
    """効果: 付けているものだけを並べる。追加は + から (外しても数値は覚えている)。"""
    from . import operators
    row = layout.row(align=True)
    row.label(text="効果", icon='SHADERFX')
    row.menu("VS_MT_fx_add", text="", icon='ADD')
    on = [f for f in operators.fx_available(ob) if operators.fx_on(ob, f[0])]
    if not on:
        sub = layout.row()
        sub.active = False
        sub.label(text="効果なし (+ で追加)")
    for name, label, icon, _ in on:
        header, body = layout.panel("vs_fx_" + name, default_closed=False)
        hr = header.row(align=True)
        hr.label(text=label, icon=icon)
        if name == 'fx_mirror_enable':
            _hint(hr, "キャンバスの中心で反転します (元の絵は変えません)")
        op = hr.operator("vstroke.fx_set", text="", icon='REMOVE', emboss=False)
        op.name = name
        op.on = False
        if body is not None:
            _draw_fx_body(body.column(), ob, name)


class VS_PT_appearance(_VecPanel, Panel):
    """塗りと線 (パス・図形・文字)。"""
    bl_label = "塗りと線"
    bl_order = 2

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        ob = _active(context)
        return ob is not None and ob.kind in {'PATH', 'SHAPE', 'TEXT'}

    def draw(self, context):
        img, vs = _vs(context)
        layout = self.layout
        ob = data.active_object(vs)
        if ob is None:
            return
        if data.is_clip_path(vs, ob.uid):
            row = layout.row()
            row.label(text="マスクの形です", icon='MOD_MASK')
            _hint(row, "塗り・線の濃さ (アルファ) が、そのまま中身の見える濃さになります")
        if ob.kind == 'PATH' and len(ob.subpaths) > 0:
            layout.prop(ob.subpaths[0], "closed")
        _draw_fills(layout.column(), ob)
        layout.separator()
        _draw_strokes(layout.column(), ob)
        layout.separator()
        _draw_effects(layout.column(), ob)


class VS_PT_object(_VecPanel, Panel):
    """画像・レイヤー・グループ・調整レイヤーの設定 (見出しは選んでいるものの名前)。"""
    bl_label = ""
    bl_order = 2

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        ob = _active(context)
        return ob is not None and ob.kind in {'IMAGE', 'LAYER', 'GROUP', 'ADJUST'}

    def draw_header(self, context):
        ob = _active(context)
        if ob is not None:
            self.layout.label(text=ob.name, icon=_kind_icon(ob))

    def draw(self, context):
        img, vs = _vs(context)
        layout = self.layout
        ob = data.active_object(vs)
        if ob is None:
            return
        if ob.kind == 'ADJUST':
            row = layout.row()
            row.label(text="下にあるもの全部に補正をかけます")
            _hint(row, "元の絵は変えません\n"
                       "かかり具合は、レイヤーの上の「強さ」とレイヤーマスクで変えられます")
            _draw_adjust(layout, ob, closed=False)
            return
        if ob.kind in {'LAYER', 'GROUP'}:
            if ob.kind == 'LAYER':
                layout.prop(ob, "layer_color")
            elif ob.clip:
                row = layout.row()
                row.label(text="最前面の子の形で切り抜いています", icon='MOD_MASK')
                row.operator("vstroke.clip_release", text="", icon='X')
            _draw_adjust(layout, ob)
            layout.separator()
            _draw_effects(layout.column(), ob)
            return
        # 置いた画像・ペイントレイヤー
        paint_layer = data.is_paint_layer(ob)
        row = layout.row()
        row.scale_y = 1.4
        if paint_layer:
            row.operator("vstroke.paint_begin", icon='BRUSH_DATA')
        else:
            # 置いた画像にも直接描ける (元の画像に描き、変形は描き直すときにかかる。
            # 2026-09-26 ユーザー要望)。画像をそのまま残したいときのために、
            # 上に新しいレイヤーを作って描く方も残す
            row.operator("vstroke.paint_begin", text="この画像に描く", icon='BRUSH_DATA')
            if data.paint_placement(ob, *img.size) == 'SOLO':
                _hint(row, "拡大・回転しているので、描く間はこの画像だけが見えます")
            layout.operator("vstroke.paint_begin", text="上に新しいレイヤーを作って描く",
                            icon='ADD').new_layer = True
        w, h = data.image_size(ob)
        row = layout.row()
        row.label(text="%s  (%d × %d px)" % (data.image_name(ob), w, h))
        if ob.image is not None and ob.image.packed_file is None:
            row = layout.row()
            row.label(text="ファイルへのリンクです", icon='LINKED')
            _hint(row, "元のファイルを動かすと消えます。埋め込むと .blend の中に入ります")
            row.operator("vstroke.image_pack", text="埋め込む", icon='PACKAGE')
        if paint_layer:
            _draw_paint_lock(layout, ob)
        if not paint_layer:
            _draw_crop(layout, img, ob)
        if data.can_distort(ob) and not data.has_crop(ob):
            row = layout.row()
            row.label(text=keys.fmt("{CMD}+角のドラッグで遠近変形"), icon='MOD_LATTICE')
            if ob.img_quad_on:
                row.operator("vstroke.image_distort_reset", text="", icon='LOOP_BACK')
        _draw_adjust(layout, ob)
        layout.separator()
        _draw_effects(layout.column(), ob)


def _draw_crop(layout, img, ob):
    """トリミング (置いた画像)。画素は消さず、見せる範囲だけを決める。
    入口のボタンはいつも見せ、数値だけを折りたたむ (閉じた欄の中だと見つけにくい)。"""
    editing = state.crop_edit == (img.name, ob.uid)
    row = layout.row(align=True)
    row.operator("vstroke.crop_edit", icon='SELECT_SET', depress=editing,
                 text="トリミングを終える" if editing else "キャンバスでトリミング")
    if data.has_crop(ob):
        row.operator("vstroke.crop_reset", text="", icon='LOOP_BACK')
    _hint(row, "枠の角や辺をドラッグして、見せる範囲を決めます\n"
               "Enter か Esc で終わります。画素は消さないので、いつでも元に戻せます")
    header, body = layout.panel("vs_crop_values", default_closed=True)
    header.label(text="トリミングの数値 (切り取る幅)")
    if body is None:
        return
    col = body.column(align=True)
    r = col.row(align=True)
    r.prop(ob, "crop_left")
    r.prop(ob, "crop_right")
    r = col.row(align=True)
    r.prop(ob, "crop_top")
    r.prop(ob, "crop_bottom")


class VS_PT_mask(_VecPanel, Panel):
    """レイヤーマスク (Photoshop と同じ。白で見せる・黒で隠す)。付いているときだけ出す。
    追加は一覧の「+」から。"""
    bl_label = "レイヤーマスク"
    bl_order = 4

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        ob = _active(context)
        return ob is not None and ob.mask_image is not None

    def draw_header_preset(self, context):
        hint = "白で見せる・黒で隠す・灰色で半透明 (ブラシで描いて調整)"
        ob = _active(context)
        if ob is not None and (ob.kind in {'PATH', 'SHAPE', 'TEXT', 'GROUP'}
                               or data.can_distort(ob)):
            hint += "\nマスクはキャンバスに固定です (動かしても付いてきません)"
        _hint(self.layout, hint)

    def draw(self, context):
        img, vs = _vs(context)
        layout = self.layout
        ob = data.active_object(vs)
        if ob is None:
            return
        row = layout.row(align=True)
        row.prop(ob, "mask_enable", text="マスクを使う", toggle=True, icon='IMAGE_ALPHA')
        row.operator("vstroke.mask_remove", text="", icon='TRASH')
        row = layout.row(align=True)
        row.scale_y = 1.3
        op = row.operator("vstroke.paint_begin", text="マスクに描く", icon='BRUSH_DATA',
                          depress=ob.mask_target)
        op.target = 'MASK'
        if ob.kind == 'IMAGE':
            op = row.operator("vstroke.paint_begin", text="中身に描く", icon='IMAGE_DATA',
                              depress=not ob.mask_target)
            op.target = 'CONTENT'
        if ob.mask_target:
            layout.label(text="ブラシを選ぶと、マスクに描きます", icon='INFO')


class VS_PT_text(_VecPanel, Panel):
    bl_label = "文字"
    bl_order = 3

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        img, vs = _vs(context)
        ob = data.active_object(vs)
        cur = state.current_tool.name if state.current_tool is not None else ""
        return (ob is not None and ob.kind == 'TEXT') or cur == 'TEXT'

    def draw(self, context):
        from . import fonts
        img, vs = _vs(context)
        layout = self.layout
        ob = data.active_object(vs)
        if ob is None or ob.kind != 'TEXT':
            col = layout.column(align=True)
            col.label(text="キャンバスをドラッグして枠を作ると")
            col.label(text="文字を入れられます (クリックだけでは作りません)")
            ts = context.window_manager.vstroke_tool
            layout.prop(ts, "text_vertical")
            if ob is not None and ob.kind in {'PATH', 'SHAPE'}:
                box = layout.box()
                box.label(text="選んでいる形を文字の入れ物にする")
                box.operator("vstroke.text_container", text="枠の中に流し込む",
                             icon='MESH_PLANE').mode = 'AREA'
                box.operator("vstroke.text_container", text="線に沿わせる",
                             icon='CURVE_BEZCURVE').mode = 'PATH'
            return
        if not fonts.available():
            col = layout.column()
            col.alert = True
            col.label(text="文字のライブラリを読み込めません", icon='ERROR')
            return

        box = layout.box()
        box.label(text="文字 (ここは日本語変換が使えます)")
        col = box.column(align=True)
        for i, ln in enumerate(ob.text_lines):
            row = col.row(align=True)
            row.prop(ln, "text", text="")
            row.operator("vstroke.text_line_remove", text="", icon='X').index = i
        box.operator("vstroke.text_line_add", text="行を追加", icon='ADD')

        row = layout.row(align=True)
        row.label(text={'POINT': "点文字", 'AREA': "エリア文字",
                        'PATH': "パス上文字"}[ob.text_kind], icon='FONT_DATA')
        row.prop(ob, "text_vertical", toggle=True)
        if ob.text_kind == 'AREA':
            col = layout.column(align=True)
            col.prop(ob, "text_box", index=0, text="枠の幅")
            col.prop(ob, "text_box", index=1, text="枠の高さ")
            col.prop(ob, "text_box_align", text="枠の中")
            if text.overflowing(ob):
                sub = layout.column()
                sub.alert = True
                sub.label(text="文字が枠に入りきっていません", icon='ERROR')
        elif ob.text_kind == 'PATH':
            col = layout.column(align=True)
            col.prop(ob, "text_path_offset")
            col.prop(ob, "text_path_align", text="")
            col.prop(ob, "text_path_flip")
            if text.overflowing(ob):
                sub = layout.column()
                sub.alert = True
                sub.label(text="文字がパスより長くなっています", icon='ERROR')

        wm = context.window_manager
        # 書体・大きさ・字間は「選んでいる文字」にだけ効く (Affinity と同じ)
        _, ranges = data.selected_char_ranges()
        attr = vs.text_attr
        if not ranges:
            layout.label(text="文字ツールで文字を選ぶと変えられます",
                         icon='INFO')
            # (カーソルだけ置いているときは、下のカーニングが使える)
        col = layout.column(align=True)
        col.active = bool(ranges)
        if len(wm.vstroke_font_families):
            col.prop_search(attr, "font_family", wm, "vstroke_font_families",
                            text="書体", icon='FONT_DATA')
            col.prop(attr, "font_style_choice", text="スタイル")
        else:
            col.prop(attr, "font_family")
            col.prop(attr, "font_style")
        col.prop(attr, "font_size")
        col.prop(attr, "tracking")
        col = layout.column(align=True)
        col.active = bool(ranges)
        col.prop(attr, "scale_x")
        col.prop(attr, "scale_y")
        # カーニングは文字を選ばず、文字と文字の間にカーソルを置いたときに使う
        row = layout.row(align=True)
        row.active = data.caret_target() is not None
        row.prop(attr, "kerning")
        _hint(row, keys.fmt("文字と文字の間にカーソルを置くと、その2文字の間を詰める・空ける\n"
                            "{ALT}+← / → でも変えられます (1回で 20)"))
        if fonts.resolve_family(ob.font_family) == "":
            sub = layout.column()
            sub.alert = True
            sub.label(text="この書体はこのパソコンにありません", icon='ERROR')
        col = layout.column(align=True)
        col.prop(ob, "line_spacing")            # 行送りと行揃えは文字全体の設定
        col.prop(ob, "text_align", text="行揃え")
        row = layout.row(align=True)
        row.operator("vstroke.text_outline", icon='OUTLINER_OB_CURVE')
        row.operator("vstroke.font_refresh", text="", icon='FILE_REFRESH')


class VS_PT_transform(_VecPanel, Panel):
    """変形 (選んでいるときだけ出す。Illustrator のプロパティパネルと同じく上の方に)。"""
    bl_label = "変形"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        img, vs = _vs(context)
        if transform.selected_items(vs):
            return True
        ob = data.active_object(vs)
        return ob is not None and ob.kind not in {'ADJUST', 'LAYER'}

    def draw(self, context):
        img, vs = _vs(context)
        layout = self.layout
        items = transform.selected_items(vs)
        ob = data.active_object(vs)
        n = len(items) if items else 1
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(vs.xform, "x")
        row.prop(vs.xform, "y")
        row = layout.row(align=True)
        sub = row.column(align=True)
        sub.prop(vs.xform, "w", text="幅")
        sub.prop(vs.xform, "h", text="高さ")
        # 縦横比の鎖 (Illustrator・Affinity と同じく幅と高さの横)
        row.prop(vs, "keep_ratio", text="", icon='LINKED' if vs.keep_ratio else 'UNLINKED')
        if n == 1:
            layout.prop(vs.xform, "angle")
        col = layout.column(align=True)
        col.prop(vs, "scale_strokes")
        col.prop(vs, "scale_corners")
        if ob is not None and ob.kind == 'PATH':
            from . import corners as _corners
            refs = data._corner_refs(vs)
            if refs:
                box = layout.box()
                n = sum(1 for _ in refs)
                sel = any(p.select for sp in ob.subpaths for p in sp.points)
                row = box.row()
                row.label(text="角 (%s%d か所)" % ("選択中 " if sel else "", n))
                _hint(row, "キャンバスの丸印をドラッグしても変えられます\n"
                           "ペンツールで角の点を選ぶと、その角だけ変えられます")
                box.prop(vs.corner, "radius", text="丸み")
                row = box.row(align=True)
                cur = _corners.common_type(vs, refs)
                for kind, label, _desc in data.CORNER_TYPES:
                    row.operator("vstroke.corner_type", text=label,
                                 depress=(cur == kind)).kind = kind
                _draw_corner_list(box, context, ob)

        if ob is not None and ob.kind == 'SHAPE':
            box = layout.box()
            box.label(text="図形のパラメーター")
            box.prop(ob, "shape_type", text="")
            if ob.shape_type == 'RECT':
                box.prop(ob, "corner_radius")
            elif ob.shape_type == 'POLYGON':
                box.prop(ob, "sides")
            elif ob.shape_type == 'STAR':
                box.prop(ob, "star_points")
                box.prop(ob, "inner_ratio")
            box.operator("vstroke.shape_to_path", icon='CURVE_BEZCURVE')


def _draw_corner_list(layout, context, ob):
    """各角の丸み (最初は閉じている)。角ごとに % で変えられる。
    開いている間は、キャンバスの角に同じ番号が出る (overlay.draw_corner_labels)。
    2026-10-18 ユーザー要望「角の丸みを値で調整したい」。"""
    from . import corners as _corners
    wm = context.window_manager
    is_open = wm.vstroke_corner_list
    row = layout.row()
    sub = row.row()
    sub.alignment = 'LEFT'          # 見出しは左に寄せる (開閉の三角と並べて、ほかの欄と同じ見た目)
    sub.prop(wm, "vstroke_corner_list", text="各角の丸み", emboss=False,
             icon='DISCLOSURE_TRI_DOWN' if is_open else 'DISCLOSURE_TRI_RIGHT')
    if not is_open:
        return
    _hint(row, "開いている間は、キャンバスの角に同じ番号が出ます\n"
               "100% は、その角で丸められる限界 (丸印をいちばん外までドラッグしたとき)")
    col = layout.column(align=True)
    for label, si, pi, _co, _a, _b in _corners.labeled_corners(ob):
        r = col.row(align=True)
        split = r.split(factor=0.3, align=True)
        split.label(text="角 %s" % label)
        split.prop(ob.subpaths[si].points[pi], "corner_pct", text="", slider=True)


def _shape_count(vs):
    m = data.uid_map(vs)
    return sum(1 for u in transform.selected_items(vs) if m[u].kind in {'PATH', 'SHAPE'})


class VS_PT_align(_VecPanel, Panel):
    """整列 (選んでいるときだけ)。パスかたちを2つ以上選ぶとパスファインダーも出る。"""
    bl_label = ""
    bl_order = 5

    @classmethod
    def poll(cls, context):
        if not _VecPanel.poll(context):
            return False
        img, vs = _vs(context)
        return bool(transform.selected_items(vs))

    def draw_header(self, context):
        img, vs = _vs(context)
        two = _shape_count(vs) >= 2
        self.layout.label(text="整列・パスファインダー" if two else "整列")

    def draw(self, context):
        img, vs = _vs(context)
        layout = self.layout
        n = len(transform.selected_items(vs))
        # 何に合わせて揃えるか。見出しと説明を付ける (切り替えだけでは何のことか
        # 分からなかった。2026-10-18 ユーザー指摘)。1つだけのときは揃える相手がいないので
        # いつもキャンバスに合わせる (切り替えは出さない)
        row = layout.row()
        if n >= 2:
            row.label(text="基準")
            sub = row.row()
            sub.scale_x = 2.5
            sub.prop(vs, "align_to", expand=True)
            _hint(row, "選択範囲: 選んだもの同士で揃えます\n"
                       "  (左揃えなら、いちばん左にあるものの左端に合わせる)\n"
                       "画像: キャンバス全体に合わせます\n"
                       "  (左揃えならキャンバスの左端、中央ならキャンバスの真ん中)")
        else:
            row.label(text="キャンバスに合わせて揃えます")
            _hint(row, "1つだけ選んでいるときは、キャンバス全体に合わせます\n"
                       "2つ以上選ぶと、選んだもの同士でも揃えられます")
        row = layout.row(align=True)
        for mode, icon in (('LEFT', 'ALIGN_LEFT'), ('HCENTER', 'ALIGN_CENTER'),
                           ('RIGHT', 'ALIGN_RIGHT')):
            row.operator("vstroke.align", text="", icon=icon).mode = mode
        row.separator()
        for mode, icon in (('TOP', 'ALIGN_TOP'), ('VCENTER', 'ALIGN_MIDDLE'),
                           ('BOTTOM', 'ALIGN_BOTTOM')):
            row.operator("vstroke.align", text="", icon=icon).mode = mode
        # 分布 (間隔をそろえる) は、両端を動かさずに間を並べ直すので 3つ以上のときだけ出す
        if n >= 3:
            row = layout.row()
            row.label(text="間隔をそろえる")
            _hint(row, "水平に分布: いちばん左と右はそのままにして、間にあるものを\n"
                       "  左右の中心が等間隔になるように並べ直します\n"
                       "垂直に分布: 同じことを上下方向に行います")
            row = layout.row(align=True)
            row.operator("vstroke.align", text="水平に分布").mode = 'DIST_H'
            row.operator("vstroke.align", text="垂直に分布").mode = 'DIST_V'
        if _shape_count(vs) < 2:
            return
        layout.separator()
        row = layout.row()
        row.label(text="パスファインダー")
        _hint(row, keys.fmt("押した時点で形が確定します ({C}Z で戻せます)\n"
                            "ボタンにマウスを乗せると、それぞれの説明が出ます"))
        # 絵だけのボタンは小さくて見分けにくいので、絵と名前を並べる (直感を優先)
        for group in (('UNITE', 'MINUS_FRONT', 'INTERSECT', 'EXCLUDE', 'MINUS_BACK'),
                      ('DIVIDE', 'TRIM', 'MERGE', 'CROP', 'OUTLINE')):
            grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
            for mode in group:
                i = icons.icon_id("pf_" + mode.lower())
                kw = {"icon_value": i} if i else {}
                grid.operator("vstroke.pathfinder", text=pathops.MODE_NAMES[mode],
                              **kw).mode = mode


# -----------------------------------------------------------------------------
# 操作方法 (レイヤーの見出しの ? から開く小窓。今のツールの分だけを出す)
# -----------------------------------------------------------------------------

HELP = (
    ('BASICS', "基本", (
        "左のツールバーか、キーでツールを切り替えます",
        "  V 選択 / P ペン / M 矩形 / L 楕円 / G グラデ / T 文字",
        "上のバーに、今のツールの設定と",
        "塗り・線・線幅・不透明度が出ます",
        "レイヤーの一覧は、上にあるものほど前面です",
        "一覧の右の丸: 選ぶ ({CMD}+クリック: 追加 / Shift: まとめて)",
        "一覧の下の +: レイヤー・ペイントレイヤー・調整レイヤー・マスクの追加",
        "一覧の下の …: あまり使わない操作と書き出し",
    )),
    ('SELECT', "選択ツール (V)", (
        "クリック: 選択 / Shift+クリック: 追加・解除",
        "何もない所からドラッグ: 囲んで選択",
        "ドラッグ: 移動 (Shift: 45°刻み / Alt: 複製)",
        "四隅・辺の□: 拡大縮小",
        "  (Shift: 縦横比を保つ / Alt: 中心から)",
        "角の少し外側: 回転 (Shift: 45°刻み)",
        "ダブルクリック: グループの中に入る /",
        "  文字なら打ち直し (アドオンの設定でオンにすると",
        "  パスや図形はペンで点を編集)",
        "{C}C / {C}X / {C}V: コピー / 切り取り / 貼り付け",
        "  (貼り付けは元と同じ場所。別のテクスチャにも貼れます。",
        "   そのテクスチャの外に出てしまうときは真ん中へ寄せます)",
        "{C}G / {C}{S}G: グループ化 / 解除",
        "{C}7 / {C}{A}7: マスク作成 / 解除",
        "  (1つだけ選ぶと、すぐ下のものを切り抜きます)",
        "{C}] / {C}[: 前面へ / 背面へ (Shift も押すと最前面・最背面)",
        "{C}{S}O: 文字をパスに変換 (アウトライン化)",
        "矢印キー: 1px 移動 (Shift: 10px)",
        "X / Delete: 削除  A / Alt+A: 全選択 / 解除",
        "画像を1つ選んで {CMD}+角をドラッグ: 遠近変形",
        "画像のトリミング: サイドバーの画像の欄か右クリックの「キャンバスでトリミング」",
        "  枠の角・辺をドラッグ。Enter / Esc で終わる (画素は消さないので元に戻せる)",
        "  角は他の図形の頂点やキャンバスの角に吸い付く",
    )),
    ('PEN', "ペンツール (P)", (
        "何も選択せずクリック: 新しいパスを開始",
        "クリック: 選択中の端点に繋げて点を追加",
        "  (ドラッグすると曲線の点になる)",
        "端点を選択→別の端点をクリック:",
        "  別パスなら接続 / 同じパスなら閉じる",
        "Shift+クリック: 前の点から 0°・45°・90°… の8方向に固定して点を置く",
        "点をドラッグ: 移動",
        "  ドラッグ中に Shift: 横・縦・45° の向きに固定",
        "  (ハンドルも同じ。Shift+クリックは選択の追加)",
        "一覧の「…」: 点で切る / 向きを反転 / 角・滑らかの切替",
        "ハンドルをドラッグ: 曲がり具合",
        "{ALT}+ハンドル: 片側だけ",
        "選択中の端点をもう一度クリック:",
        "  次の線を直線に(片側のハンドルを消す)",
        "{ALT}+点ドラッグ: ハンドルを引出す",
        "線の上をクリック: そこに点を足す",
        "図形の頂点をクリック: パスに変換 (確認あり)",
        "X / Delete: 選択点を削除  C: 開閉  F: 塗りの切替",
        "角の点を選ぶと、サイドバーの「変形 > 角」でその角だけ丸められる",
    )),
    ('PENCIL', "鉛筆ツール", (
        "ドラッグ: 描く (描きながら曲線になる)",
        "描き始めの近くで離す: 閉じた形にする",
        "選んでいるパスの端から描く: 続きを描く",
        "上のバーの「滑らかさ」: 0 で手の動きに忠実、1 で滑らか",
    )),
    ('SHAPE', "図形ツール (M: 矩形 / L: 楕円)", (
        "ドラッグ: 作成 (Shift: 正方形・正円 / Alt: 中心から)",
        "多角形・星は中心からドラッグ",
        "クリックだけ: 大きさを聞く小窓が出ます",
    )),
    ('TEXT', "文字ツール (T)", (
        "ドラッグ: 枠を作って文字を入れる",
        "  (クリックだけでは何も作りません)",
        "図形・パスの線をクリック:",
        "  閉じた形→中に流し込む / 開いたパス→線に沿わせる",
        "キャンバスでは英数字をそのまま打てる",
        "日本語は {C}V で貼り付けるか、サイドバーの「文字」欄に入力",
        "字の上をドラッグ: 範囲を選ぶ (二度押しでその単語)",
        "Shift+矢印: 範囲を伸ばす  {C}A: 全部選ぶ",
        "書体・スタイル・大きさ・字間・水平/垂直比率は「選んだ文字」にだけ効きます",
        "  (何も選んでいないと変えられません)",
        "{C}C / {C}X / {C}V: 選んだ文字をコピー / 切り取り / 貼り付け",
        "文字と文字の間にカーソルを置いて {ALT}+← / →: その2文字の間を詰める・空ける",
        "  (カーニング。サイドバーの「カーニング」で数値でも変えられる)",
        "矢印: カーソル移動  Esc: 編集をやめる",
    )),
    ('GRADIENT', "グラデーションツール (G)", (
        "ドラッグ: 向きと長さを決める (Shift: 45°刻み)",
        "端の丸: 始点・終点を動かす",
        "途中の四角: 分岐点を動かす",
        "線の上を二度押し: その場所に分岐点を足す",
    )),
    ('BRUSH', "ブラシで描く (ペイントレイヤー)", (
        "左のツールバーの「ブラシ」を選ぶだけで描き始められます",
        "  (ペイントレイヤーが無ければ自動で作ります)",
        "  (別のツールを選ぶと、自動でベクターに戻ります)",
        "描いている間も、他のレイヤーはそのまま見えます",
        "Blender のブラシ機能がそのまま全部使えます",
        "描いている間も、「レイヤー」の一覧で名前を押すと",
        "  描く先のレイヤーが変わります (半分塗りの四角はマスク)",
        "  {C}Z で切り替えも戻せます",
        "「ベクターに戻る」でベクター編集に戻ります",
        "不透明度・描画モード・マスク・効果も同じように効きます",
    )),
    ('LAYERS', "マスク・調整レイヤー", (
        "レイヤーマスク: 一覧の + から追加",
        "  「マスクに描く」でブラシで描く: 白で見せる・黒で隠す",
        "  (灰色で半透明。消しゴムで消した所は白と同じ)",
        "  一覧の半分塗りの四角: マスクのオン/オフ",
        "調整レイヤー: 一覧の + から追加 (選んでいるレイヤーのすぐ上)",
        "  下にあるものすべてに色調補正をかける (元の絵は変えない)",
        "  「強さ」とレイヤーマスクで、かかり具合を変えられる",
        "  PDF では、それより下が1枚の画像になります",
    )),
    ('ARRANGE', "整列・パスファインダー・角", (
        "選んでいるときだけ、サイドバーに「整列」が出ます",
        "整列の基準: 選択範囲 (選んだもの同士) / 画像 (キャンバス全体)",
        "  1つだけ選んでいるときは、いつもキャンバスに合わせる",
        "間隔をそろえる (分布): 3つ以上選ぶと出ます",
        "  両端はそのままで、間のものを等間隔に並べ直す",
        "パスファインダー: パスか図形を2つ以上選ぶと出ます",
        "  (押した時点で形が確定。{C}Z で戻せます)",
        "角の丸め: 選択ツールでパスを選ぶと、角に丸印が出る",
        "  丸印をドラッグすると丸みが変わる",
        "  サイドバーの「変形 > 角」で数値と形 (丸/面取り/内側の丸)",
    )),
    ('FILES', "読み込み・書き出し・スナップ", (
        "画像・SVG を読み込む: 一覧の下の画像ボタン (または +)",
        "  複数まとめて・混ぜて選べます",
        "  SVG は編集できる形 (パス・グループ) で読み込みます",
        "  (キャンバスの左上に、元の大きさで置きます)",
        "書き出し: 一覧の「…」か、イメージエディターの「画像」メニュー",
        "  SVG: Illustrator などで開いて編集できる",
        "  PDF: そのまま印刷・共有できる",
        "スナップ: ヘッダー右端のボタンでオン/オフ",
        "  キャンバスの端・中心、他のオブジェクトの端・中心に合う",
        "  Shift を押している間は吸い付かない",
    )),
    ('COMMON', "共通", (
        "Enter / Esc: 選択解除",
        "何も選択していない時に Esc: 終了",
        "右クリック: メニュー",
        "  (選んでいるものに合わせた操作。いちばん下で終了)",
        "  ドラッグの途中の右クリックは、その操作の取り消し",
    )),
)
_HELP_MAP = {k: (name, lines) for k, name, lines in HELP}
_TOOL_TOPIC = {'SELECT': 'SELECT', 'PEN': 'PEN', 'PENCIL': 'PENCIL', 'SHAPE': 'SHAPE',
               'TEXT': 'TEXT', 'GRADIENT': 'GRADIENT', 'BRUSH': 'BRUSH'}


def _current_tool_key(context):
    """いま選んでいる左ツールバーのツール (SELECT・PEN など。分からなければ "")。"""
    try:
        sp = context.space_data
        tool = context.workspace.tools.from_space_image_mode(sp.mode, create=False)
        if tool is not None:
            return tools.TOOL_NAMES.get(tool.idname, "")
    except Exception:
        pass
    cur = state.current_tool
    return getattr(cur, "name", "") if cur is not None else ""


class VS_PT_help(Panel):
    """操作方法の小窓 (レイヤーの見出しの ? から)。"""
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'HEADER'
    bl_label = "操作方法"
    bl_ui_units_x = 19

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        layout.prop(wm, "vstroke_help_topic", text="")
        topic = wm.vstroke_help_topic
        topics = [topic]
        if topic == 'AUTO':
            topics = [_TOOL_TOPIC.get(_current_tool_key(context), 'BASICS'), 'COMMON']
        for k in topics:
            name, lines = _HELP_MAP[k]
            layout.separator()
            layout.label(text=name, icon='HELP')
            col = layout.column(align=True)
            for line in lines:
                col.label(text=keys.fmt(line))      # キーの書き方はパソコンに合わせる


# 選択肢は固定の並びで持つ (関数で毎回作ると、Blender 側で文字が化けることがある)
HELP_TOPICS = [('AUTO', "今のツール", "いま選んでいるツールの操作")] + [
    (k, name, "") for k, name, _ in HELP]


classes = (VS_AddonPrefs, VS_OT_set_tool, VS_UL_objects, VS_UL_paint_targets,
           VS_MT_add, VS_MT_object, VS_MT_fx_add, VS_MT_arrange, VS_MT_pathfinder, VS_MT_context,
           VS_PT_paint, VS_PT_main, VS_PT_transform, VS_PT_appearance, VS_PT_object,
           VS_PT_text, VS_PT_mask, VS_PT_align, VS_PT_help)


def draw_header_button(self, context):
    """イメージエディターのヘッダー右端: UV・枠線・スナップのオン/オフ (アイコンだけ)。

    2026-09-25 ユーザー要望: 枠線のボタンが2か所 (この段と、ツールの設定の段) にあったので
    この段だけにまとめ、スナップもここへ。文字は出さず、ヘッダーのいちばん右に置く
    (Blender のヘッダーの項目のあとに足すので右端になる)。
    枠線のアイコンは、Blender のオーバーレイのボタン (OVERLAY) と見分けられるものにした。"""
    sp = context.space_data
    img = getattr(sp, "image", None) if sp is not None else None
    if img is None or not img.vstroke.enabled:
        return
    ts = context.window_manager.vstroke_tool
    row = self.layout.row(align=True)
    row.prop(ts, "show_uv", text="", icon='UV', toggle=True)
    row.prop(ts, "show_guides", text="", icon='SHADING_BBOX', toggle=True)
    row.prop(ts, "snap_enable", text="", toggle=True,
             icon='SNAP_ON' if ts.snap_enable else 'SNAP_OFF')


def draw_image_menu(self, context):
    """イメージエディターの「画像」メニューに、SVG / PDF の書き出しを足す
    (Illustrator の「ファイル → 書き出し」にあたる)。"""
    sp = context.space_data
    img = getattr(sp, "image", None) if sp is not None else None
    if img is None or not img.vstroke.enabled:
        return
    layout = self.layout
    layout.separator()
    layout.operator("vstroke.export", text="ベクターを SVG で書き出す…", icon='EXPORT').fmt = 'SVG'
    layout.operator("vstroke.export", text="ベクターを PDF で書き出す…", icon='EXPORT').fmt = 'PDF'


def register():
    from . import ramp_sync
    if _on_ramp_commit not in ramp_sync.on_commit:
        ramp_sync.on_commit.append(_on_ramp_commit)
    for c in classes:
        bpy.utils.register_class(c)
    wm = bpy.types.WindowManager
    wm.vstroke_list_index = bpy.props.IntProperty(
        name="選んでいるもの", description="押した行を選ぶ (Undo の履歴には入りません)",
        get=_get_list_index, set=_set_list_index)
    # ペイント中の一覧は行を選んでも何もしない (名前のボタンで切り替える)。並べるためだけの値
    wm.vstroke_paint_target_index = bpy.props.IntProperty(
        name="描く先", description="名前を押すと、描く先が変わります", default=-1)
    wm.vstroke_corner_list = bpy.props.BoolProperty(
        name="各角の丸み", default=False,
        description="角ごとの丸みを % で変える欄を開く (キャンバスの角に番号が出ます)")
    wm.vstroke_help_topic = bpy.props.EnumProperty(
        name="操作方法", description="見たい操作を選ぶ", items=HELP_TOPICS, default='AUTO')
    bpy.types.IMAGE_HT_header.append(draw_header_button)
    bpy.types.IMAGE_MT_image.append(draw_image_menu)


def unregister():
    from . import ramp_sync
    if _on_ramp_commit in ramp_sync.on_commit:
        ramp_sync.on_commit.remove(_on_ramp_commit)
    for menu, fn in ((bpy.types.IMAGE_HT_header, draw_header_button),
                     (bpy.types.IMAGE_MT_image, draw_image_menu)):
        try:
            menu.remove(fn)
        except Exception:
            pass
    for name in ("vstroke_list_index", "vstroke_paint_target_index", "vstroke_help_topic",
                 "vstroke_corner_list"):
        try:
            delattr(bpy.types.WindowManager, name)
        except Exception:
            pass
    for c in reversed(classes):
        bpy.utils.unregister_class(c)

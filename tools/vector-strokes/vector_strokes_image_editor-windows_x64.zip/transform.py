# SPDX-License-Identifier: GPL-3.0-or-later
"""オブジェクトの変形 (移動・回転・拡大縮小)、整列、図形 -> パス変換、
サイドバーの位置・大きさ欄の計算。

変形はいつも「ドラッグ開始時の状態 (スナップショット)」に行列を掛けて求める。
こうすると、ドラッグ中に何度計算しても誤差が溜まらない。
"""

import math

import numpy as np

from . import data, geometry, render

G = geometry


# -----------------------------------------------------------------------------
# 選択
# -----------------------------------------------------------------------------

def selected_items(vs):
    """選択中のオブジェクトの uid (祖先が選択されているもの・レイヤーは除く)。並び順。"""
    m = data.uid_map(vs)
    sel = {ob.uid for ob in vs.objects if ob.select and ob.kind != 'LAYER'}
    return [ob.uid for ob in vs.objects
            if ob.uid in sel and not set(data.ancestors(vs, ob.uid, m)) & sel]


def leaf_objects(vs, uids):
    """uids とその子孫のうち、形を持つもの (パス・図形)。"""
    ch = data.children_map(vs)
    m = data.uid_map(vs)
    out = []
    seen = set()
    for u in uids:
        for v in [u] + data.descendants(vs, u, ch):
            if v not in seen and m[v].kind in {'PATH', 'SHAPE', 'TEXT', 'IMAGE'}:
                seen.add(v)
                out.append(m[v])
    return out


def items_polylines(vs, uids):
    """範囲を測るための折れ線。クリップグループはマスクの形だけで測る (Illustrator と同じ)。"""
    ch = data.children_map(vs)
    m = data.uid_map(vs)
    polys = []

    def walk(u):
        ob = m[u]
        if not ob.visible and u not in uids:
            return
        if ob.kind in {'GROUP', 'LAYER'}:
            kids = ch.get(u, [])
            if ob.clip and kids:
                walk(kids[-1])
            else:
                for k in kids:
                    walk(k)
        else:
            polys.extend(G.polylines(G.object_subpaths(ob)))
            # エリア文字・パス上文字は、枠 (パス) も範囲に入れる
            polys.extend(G.polylines(G.text_frame_subpaths(ob)))
    for u in uids:
        if u in m:
            walk(u)
    return polys


def frame_angle(vs, uids):
    """選択枠の傾き: 1つだけ選んでいればその角度、複数なら 0。"""
    if len(uids) == 1:
        return vs.objects[data.index_of_uid(vs, uids[0])].rotation
    return 0.0


def selection_frame(vs, uids):
    """選択枠: (角度, (x0, y0, x1, y1) 枠の座標系での範囲)。無ければ None。"""
    ang = frame_angle(vs, uids)
    b = G.bounds_in_frame(items_polylines(vs, uids), ang)
    if b is None:
        return None
    return ang, b


def frame_point(ang, b, fx, fy):
    """枠上の点 (fx, fy は -1..1、0 が中央) の画像座標。"""
    x = (b[0] + b[2]) / 2 + fx * (b[2] - b[0]) / 2
    y = (b[1] + b[3]) / 2 + fy * (b[3] - b[1]) / 2
    return G.frame_to_world(ang, (x, y))


# -----------------------------------------------------------------------------
# スナップショットと行列の適用
# -----------------------------------------------------------------------------

def snapshot(vs, uids):
    ch = data.children_map(vs)
    m = data.uid_map(vs)
    snap = {}
    for u in uids:
        for v in [u] + data.descendants(vs, u, ch):
            ob = m[v]
            snap[v] = {
                "kind": ob.kind,
                "rotation": ob.rotation,
                "paints": [(p.width, tuple(p.g_start), tuple(p.g_end)) for p in ob.paints],
                "subpaths": [G.subpath_tuple(sp) for sp in ob.subpaths],
                "center": tuple(ob.center),
                "size": tuple(ob.size),
                "text_origin": tuple(ob.text_origin),
                "text_mat": tuple(ob.text_mat),
                "text_kind": ob.text_kind,
                "text_box": tuple(ob.text_box),
                "img_origin": tuple(ob.img_origin),
                "img_mat": tuple(ob.img_mat),
                "img_quad_on": bool(ob.img_quad_on),
                "img_quad": tuple(ob.img_quad),
                # 角の丸み (px)。拡大縮小に合わせて変えるので元の値を覚える
                "corner_r": [[float(p.corner_radius) for p in sp.points] for sp in ob.subpaths],
                "shape_corner": float(ob.corner_radius),
                "corner_round": float(ob.corner_round),
            }
    return snap


def _write_radii(ob, radii, k):
    """角ごとの丸み (px) を書く。k は拡大縮小の倍率。"""
    for sp, rs in zip(ob.subpaths, radii):
        for p, r in zip(sp.points, rs):
            v = r * k
            if p.corner_radius != v:
                p.corner_radius = v


def _write_subpaths(ob, subpaths):
    if len(ob.subpaths) != len(subpaths) or any(
            len(sp.points) != len(pts) for sp, (pts, _) in zip(ob.subpaths, subpaths)):
        ob.subpaths.clear()
        for pts, closed in subpaths:
            sp = ob.subpaths.add()
            for _ in pts:
                sp.points.add()
    for sp, (pts, closed) in zip(ob.subpaths, subpaths):
        for p, (co, hl, hr) in zip(sp.points, pts):
            p.co, p.handle_left, p.handle_right = co, hl, hr
        sp.closed = closed


write_subpaths = _write_subpaths   # 他のモジュールから使う


def restore(vs, snap):
    m = data.uid_map(vs)
    with render.suspended():
        for uid, s in snap.items():
            ob = m.get(uid)
            if ob is None:
                continue
            ob.kind = s["kind"]
            ob.rotation = s["rotation"]
            for p, (w, gs, ge) in zip(ob.paints, s["paints"]):
                p.width, p.g_start, p.g_end = w, gs, ge
            ob.center = s["center"]
            ob.size = s["size"]
            ob.text_origin = s["text_origin"]
            ob.text_mat = s["text_mat"]
            ob.text_box = s["text_box"]
            ob.img_origin = s["img_origin"]
            ob.img_mat = s["img_mat"]
            ob.img_quad = s["img_quad"]
            ob.img_quad_on = s["img_quad_on"]
            if s["kind"] in {'PATH', 'TEXT'}:
                # 文字の場合の subpaths は、エリア文字の枠 / パス上文字のパス
                _write_subpaths(ob, s["subpaths"])
                _write_radii(ob, s["corner_r"], 1.0)
            elif len(ob.subpaths):
                ob.subpaths.clear()
            ob.corner_radius = s["shape_corner"]
            ob.corner_round = s["corner_round"]


def _rotated_angle(M, ang):
    v = G.apply_vec(M, (math.cos(ang), math.sin(ang)))
    return math.atan2(v[1], v[0]) if abs(v[0]) + abs(v[1]) > 1e-12 else ang


def shape_to_path(ob):
    """図形を普通のパスに変換する (見た目は同じ)。"""
    subs = G.shape_subpaths(ob)
    with render.suspended():
        ob.kind = 'PATH'
        _write_subpaths(ob, subs)


def apply_matrix(vs, snap, M, scale_strokes=False, scale_corners=False):
    """スナップショットの状態に行列 M を掛けた状態にする。

    scale_corners: 角の丸み (角ごとの丸み・矩形の角の半径・効果の「角を丸くする」) も
    同じ割合で変える。丸みは px で持っているので、変えないと大きさを変えたときに
    丸みの見え方が変わってしまう (2026-10-18 ユーザー指摘)"""
    restore(vs, snap)
    m = data.uid_map(vs)
    k = G.linear_scale_factor(M)
    kc = k if scale_corners else 1.0
    with render.suspended():
        for uid, s in snap.items():
            ob = m.get(uid)
            if ob is None:
                continue
            # グラデーションの位置も一緒に動かす。線幅は設定しだい
            for p, (w, gs, ge) in zip(ob.paints, s["paints"]):
                p.g_start = G.apply(M, gs)
                p.g_end = G.apply(M, ge)
                if scale_strokes and p.kind == 'STROKE':
                    p.width = w * k
            if kc != 1.0 and ob.kind in {'PATH', 'SHAPE'}:
                ob.corner_round = s["corner_round"] * kc
            if ob.kind == 'PATH':
                _write_subpaths(ob, [(G.transform_points(pts, M), closed)
                                     for pts, closed in s["subpaths"]])
                if kc != 1.0:
                    _write_radii(ob, s["corner_r"], kc)
                ob.rotation = _rotated_angle(M, s["rotation"])
            elif ob.kind == 'TEXT':
                _apply_text(ob, s, M)
            elif ob.kind == 'IMAGE':
                a, b, c, d = s["img_mat"]
                L = M[:2, :2] @ np.array([[a, c], [b, d]], np.float64)
                ob.img_mat = (L[0, 0], L[1, 0], L[0, 1], L[1, 1])
                ob.img_origin = G.apply(M, s["img_origin"])
                ob.rotation = math.atan2(L[1, 0], L[0, 0])
                if s["img_quad_on"]:
                    q = s["img_quad"]
                    ob.img_quad = [c for i in range(4)
                                   for c in G.apply(M, (q[2 * i], q[2 * i + 1]))]
            elif ob.kind == 'SHAPE':
                w, h = s["size"]
                L = M[:2, :2] @ G.rotate(s["rotation"])[:2, :2] @ np.diag([w, h])
                a, b = L[:, 0], L[:, 1]
                na, nb = float(np.hypot(*a)), float(np.hypot(*b))
                if na > 1e-9 and nb > 1e-9 and abs(float(a @ b)) <= 1e-6 * na * nb:
                    # 回転と拡大縮小だけで表せる -> 図形のまま
                    ob.center = G.apply(M, s["center"])
                    ob.rotation = math.atan2(a[1], a[0])
                    ob.size = (na, (a[0] * b[1] - a[1] * b[0]) / na)
                    if kc != 1.0:
                        ob.corner_radius = s["shape_corner"] * kc
                else:
                    # 斜めに歪む -> パスに変換 (Illustrator と同じ)
                    shape_to_path(ob)
                    _write_subpaths(ob, [(G.transform_points(pts, M), closed)
                                         for pts, closed in G.object_subpaths(ob)])
                    ob.rotation = _rotated_angle(M, s["rotation"])
            else:
                ob.rotation = _rotated_angle(M, s["rotation"])


def _apply_text(ob, s, M):
    """文字への変形。
    - 点文字・パス上文字: 「組み方はそのまま、置き方だけ変える」(Illustrator と同じ)
    - エリア文字を文字の軸に沿って拡大縮小したとき: 枠だけ変えて、文字は流し直す
      (文字の大きさは変えない。Illustrator と同じ)"""
    a, b, c, d = s["text_mat"]
    A = np.array([[a, c], [b, d]], np.float64)
    L = M[:2, :2] @ A
    if s["text_kind"] == 'AREA':
        try:
            local = np.linalg.inv(A) @ M[:2, :2] @ A
        except np.linalg.LinAlgError:
            local = None
        if local is not None:
            sx, sy = abs(float(local[0, 0])), abs(float(local[1, 1]))
            shear = abs(float(local[0, 1])) + abs(float(local[1, 0]))
            if shear <= 1e-6 * max(sx + sy, 1.0) and sx > 1e-9 and sy > 1e-9:
                # 文字の軸に沿った拡大縮小 -> 枠の大きさを変える
                ob.text_box = (max(s["text_box"][0] * sx, 1.0),
                               max(s["text_box"][1] * sy, 1.0))
                if len(s["subpaths"]):
                    S = np.array([[sx, 0.0, 0.0], [0.0, sy, 0.0], [0.0, 0.0, 1.0]])
                    _write_subpaths(ob, [(G.transform_points(pts, S), closed)
                                         for pts, closed in s["subpaths"]])
                ob.text_origin = G.apply(M, s["text_origin"])
                ob.rotation = s["rotation"]
                return
    ob.text_mat = (L[0, 0], L[1, 0], L[0, 1], L[1, 1])
    ob.text_origin = G.apply(M, s["text_origin"])
    ob.rotation = math.atan2(L[1, 0], L[0, 0])


def transform_items(vs, uids, M, scale_strokes=None, scale_corners=None):
    """uids (と子孫) に行列 M をその場で適用する。"""
    if scale_strokes is None:
        scale_strokes = vs.scale_strokes
    if scale_corners is None:
        scale_corners = vs.scale_corners
    apply_matrix(vs, snapshot(vs, uids), M, scale_strokes, scale_corners)


def scale_matrix(ang, anchor, sx, sy):
    """傾き ang の枠の軸に沿って、点 anchor を中心に拡大縮小する行列。"""
    return G.about(G.compose(G.rotate(ang), G.scale(sx, sy), G.rotate(-ang)), *anchor)


# -----------------------------------------------------------------------------
# サイドバーの位置・大きさ・角度
# -----------------------------------------------------------------------------

def _proxy_items(vs):
    items = selected_items(vs)
    if not items:
        ob = data.active_object(vs)
        items = [ob.uid] if ob is not None and ob.kind not in {'LAYER', 'ADJUST'} else []
    return items


def proxy_get(img, key):
    if img is None:
        return 0.0
    vs = img.vstroke
    items = _proxy_items(vs)
    fr = selection_frame(vs, items) if items else None
    if fr is None:
        return 0.0
    ang, b = fr
    if key in ("x", "y"):
        c = frame_point(ang, b, 0, 0)
        return c[0] if key == "x" else c[1]
    if key == "w":
        return b[2] - b[0]
    if key == "h":
        return b[3] - b[1]
    return ang if len(items) == 1 else 0.0


def proxy_set(img, key, value):
    if img is None:
        return
    vs = img.vstroke
    items = _proxy_items(vs)
    fr = selection_frame(vs, items) if items else None
    if fr is None:
        return
    ang, b = fr
    c = frame_point(ang, b, 0, 0)
    if key in ("x", "y"):
        d = (value - c[0], 0.0) if key == "x" else (0.0, value - c[1])
        M = G.translate(*d)
    elif key in ("w", "h"):
        w, h = b[2] - b[0], b[3] - b[1]
        old = w if key == "w" else h
        if old < 1e-9:
            return
        f = value / old
        sx, sy = (f, 1.0) if key == "w" else (1.0, f)
        if vs.keep_ratio:
            sx = sy = f
        M = scale_matrix(ang, c, sx, sy)
    else:
        cur = ang if len(items) == 1 else 0.0
        M = G.about(G.rotate(value - cur), *c)
    transform_items(vs, items, M)
    render.render_image(img)


# -----------------------------------------------------------------------------
# 整列・分布
# -----------------------------------------------------------------------------

ALIGN_MODES = ('LEFT', 'HCENTER', 'RIGHT', 'TOP', 'VCENTER', 'BOTTOM', 'DIST_H', 'DIST_V')


def align(img, mode):
    vs = img.vstroke
    items = selected_items(vs)
    if not items:
        return False
    boxes = {u: G.bounds_in_frame(items_polylines(vs, [u])) for u in items}
    items = [u for u in items if boxes[u] is not None]
    if not items:
        return False
    if mode in ('DIST_H', 'DIST_V'):
        if len(items) < 3:
            return False
        ax = 0 if mode == 'DIST_H' else 1
        cen = {u: (boxes[u][ax] + boxes[u][ax + 2]) / 2 for u in items}
        order = sorted(items, key=lambda u: cen[u])
        first, last = cen[order[0]], cen[order[-1]]
        for i, u in enumerate(order[1:-1], 1):
            target = first + (last - first) * i / (len(order) - 1)
            d = target - cen[u]
            transform_items(vs, [u], G.translate(d, 0) if ax == 0 else G.translate(0, d))
        render.render_image(img)
        return True
    if vs.align_to == 'IMAGE' or len(items) == 1:
        w, h = img.size
        ref = (0.0, 0.0, float(w), float(h))
    else:
        bs = [boxes[u] for u in items]
        ref = (min(b[0] for b in bs), min(b[1] for b in bs),
               max(b[2] for b in bs), max(b[3] for b in bs))
    for u in items:
        b = boxes[u]
        dx = dy = 0.0
        if mode == 'LEFT':
            dx = ref[0] - b[0]
        elif mode == 'RIGHT':
            dx = ref[2] - b[2]
        elif mode == 'HCENTER':
            dx = (ref[0] + ref[2]) / 2 - (b[0] + b[2]) / 2
        elif mode == 'BOTTOM':
            dy = ref[1] - b[1]
        elif mode == 'TOP':
            dy = ref[3] - b[3]
        elif mode == 'VCENTER':
            dy = (ref[1] + ref[3]) / 2 - (b[1] + b[3]) / 2
        if dx or dy:
            transform_items(vs, [u], G.translate(dx, dy))
    render.render_image(img)
    return True

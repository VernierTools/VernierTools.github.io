# SPDX-License-Identifier: GPL-3.0-or-later
"""Mac / Windows のキーの違いを吸収する。

- Mac の「delete」キーは Blender では BACK_SPACE として届く。
- Mac では Ctrl の代わりに ⌘ (Blender では oskey) を使う。
"""

import sys

IS_MAC = sys.platform == "darwin"

DELETE_KEYS = {'X', 'DEL', 'BACK_SPACE'}
CONFIRM_KEYS = {'RET', 'NUMPAD_ENTER'}


def command_mod(event):
    """Ctrl (Windows) または ⌘ (Mac) が押されているか。"""
    return bool(event.ctrl or event.oskey)


# 画面に出すキーの書き方は、使っているパソコンに合わせる (Mac とは限らない。
# 2026-10-17 ユーザー指摘)。文の中に次の印を書いて fmt() を通す:
#   {C} {S} {A}     キーとの組み合わせ   Mac: ⌘G ⇧ ⌥ / それ以外: Ctrl+G Shift+ Alt+
#   {CMD} {ALT}     「+ドラッグ」などに付ける単独の名前   Mac: ⌘ ⌥ / それ以外: Ctrl Alt
_MAC = {"{CMD}": "⌘", "{ALT}": "⌥", "{C}": "⌘", "{S}": "⇧", "{A}": "⌥"}
_PC = {"{CMD}": "Ctrl", "{ALT}": "Alt", "{C}": "Ctrl+", "{S}": "Shift+", "{A}": "Alt+"}


def fmt(text):
    for k, v in (_MAC if IS_MAC else _PC).items():
        text = text.replace(k, v)
    return text

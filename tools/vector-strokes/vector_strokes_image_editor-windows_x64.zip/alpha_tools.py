# SPDX-License-Identifier: GPL-3.0-or-later
"""アルファ (透明度) の道具。ユーザーのアドオン2つを統合したもの (2026-09-25 ユーザー要望)。

1. しきい値より薄い所を消す (元: Alpha Threshold Cutoff)
   - 画素を直接書き換える。ブラシモードで描いているペイントレイヤーと、ベクター編集にしていない
     普通の画像に使える。キャンバス (ベクター編集の合成結果) には使わない
     (次の描き直しで消える。キャンバスには色調補正の「アルファのしきい値」を使う)
   - Undo: 画素は Blender の「全体の Undo」に入らないので、元のアドオンと同じく
     シーンの通し番号 (vstroke_pixel_serial。これは Undo で戻る) を1つ進めておき、
     Undo のあとに番号と合うように画素を戻す / かけ直す (reconcile)

2. 透明部分をロック (元: Alpha Paint Lock)
   - ペイントレイヤーごとのオン/オフ。ブラシで描き始めたとき (または描いている途中で
     オンにしたとき) に、アルファがしきい値より小さい画素を「守る所」として覚える
   - Blender の筆は C で動くので、描くこと自体は止められない。そこで
     描いている間は: 画面に貼るとき、守る所には覚えておいた元の絵を見せる (overlay)
     ベクターに戻るとき・保存の前・ロックを切ったとき: 守る所の画素を元に戻す (enforce)
     元のアドオンの「0.2 秒ごとに戻す見張り」は要らない (描いたものが一瞬出て消える見え方もない)
"""

import bpy
import numpy as np
from bpy.app.handlers import persistent

from . import state

MAX_HISTORY = 32
_history = []          # しきい値で消した記録 (古い順)
_suspend = {"on": False}

# 透明部分のロック: いま描いているレイヤーの「守る所」と、その元の絵。
# alpha0 は描き始めた (ロックした) ときのアルファ。しきい値を変えたとき、守る所を
# 「今の絵」ではなくこちらで決め直す (今の絵には、守る所に塗った分が入っているため)
_lock = {"layer": "", "mask": None, "orig": None, "byte": False, "alpha0": None}


# -----------------------------------------------------------------------------
# 共通
# -----------------------------------------------------------------------------

def read_rgba(im):
    w, h = im.size
    if w <= 0 or h <= 0 or im.channels != 4:
        return None
    arr = np.empty(w * h * 4, np.float32)
    im.pixels.foreach_get(arr)
    return arr.reshape(h, w, 4)


def write_rgba(im, arr):
    im.pixels.foreach_set(np.ascontiguousarray(arr, np.float32).ravel())
    im.update()
    from . import paint_preview, render
    render.clear_cache(im.name)
    paint_preview.request()          # 描いているレイヤーなら、3D ビューにも反映する
    try:
        render.tag_redraw_all()
    except Exception:
        pass


def cutoff_target(context):
    """しきい値で消す相手の画像と、使えないときの理由。
    ブラシで描いているレイヤー、またはベクター編集にしていない普通の画像。"""
    from . import operators
    sp = getattr(context, "space_data", None)
    im = getattr(sp, "image", None) if sp is not None else None
    if im is None:
        return None, "画像を開いてください"
    if im.vstroke.paint_owner:
        return im, ""                            # ブラシで描いているペイントレイヤー
    if im.vstroke.enabled:
        return None, ("ベクター編集のキャンバスには、色調補正の「アルファのしきい値」を"
                      "使ってください")
    if im.name.startswith(operators.BACKDROP_PREFIX) or operators._inner_role(im):
        return None, "このアドオンが中で使っている画像です"
    if im.source not in {'FILE', 'GENERATED'} or im.channels != 4:
        return None, "アルファのある静止画像 (RGBA) だけに使えます"
    return im, ""


# -----------------------------------------------------------------------------
# 1. しきい値より薄い所を消す (Undo つき)
# -----------------------------------------------------------------------------

class _Edit:
    __slots__ = ("serial", "scene", "image", "size", "idx", "old_alpha", "applied")

    def __init__(self, serial, scene, image, size, idx, old_alpha):
        self.serial, self.scene, self.image = serial, scene, image
        self.size, self.idx, self.old_alpha = size, idx, old_alpha
        self.applied = True


def _serial(scene):
    try:
        return int(scene.vstroke_pixel_serial)
    except Exception:
        return 0


def cut_below(im, threshold):
    """アルファがしきい値より小さい (まだ透明でない) 画素を透明にする。
    戻り値: (変えた画素の番号, 元のアルファ)。変えるものが無ければ (None, None)"""
    arr = read_rgba(im)
    if arr is None:
        return None, None
    flat = arr.reshape(-1, 4)
    a = flat[:, 3]
    idx = np.flatnonzero((a < float(threshold)) & (a > 0.0)).astype(np.uint32)
    if len(idx) == 0:
        return None, None
    old = a[idx].copy()
    flat[idx, 3] = 0.0
    _suspend["on"] = True
    try:
        write_rgba(im, arr)
    finally:
        _suspend["on"] = False
    return idx, old


def record(scene, im, idx, old_alpha):
    """Undo のための記録。シーンの通し番号を進める (その値が Undo の段に入る)。"""
    serial = _serial(scene) + 1
    scene.vstroke_pixel_serial = serial
    _history.append(_Edit(serial, scene.name, im.name, tuple(im.size), idx, old_alpha))
    while len(_history) > MAX_HISTORY:
        _history.pop(0)
    return serial


def reconcile():
    """Undo / やり直しのあと、通し番号に合わせて画素を戻す / かけ直す。"""
    if _suspend["on"] or not _history:
        return
    try:
        scene = bpy.context.scene
    except Exception:
        return
    if scene is None:
        return
    cur = _serial(scene)
    todo = {}
    for e in _history:
        if e.scene != scene.name:
            continue
        want = e.serial <= cur
        if want != e.applied:
            todo.setdefault(e.image, []).append(e)
    _suspend["on"] = True
    try:
        for name, edits in todo.items():
            im = bpy.data.images.get(name)
            if im is None:
                continue
            edits = [e for e in edits if e.size == tuple(im.size)]
            arr = read_rgba(im) if edits else None
            if arr is None:
                continue
            flat = arr.reshape(-1, 4)
            for e in sorted((e for e in edits if e.applied), key=lambda e: -e.serial):
                flat[e.idx, 3] = e.old_alpha          # 新しいものから戻す
                e.applied = False
            for e in sorted((e for e in edits if not e.applied and e.serial <= cur),
                            key=lambda e: e.serial):
                flat[e.idx, 3] = 0.0                  # 古いものからかけ直す
                e.applied = True
            write_rgba(im, arr)
    except Exception as ex:
        print("[Vector Strokes] しきい値の Undo に失敗:", ex)
    finally:
        _suspend["on"] = False


class VS_OT_alpha_cutoff(bpy.types.Operator):
    """アルファがしきい値より小さい所を、完全に透明にする (画素を書き換える。Undo できます)"""
    bl_idname = "vstroke.alpha_cutoff"
    bl_label = "しきい値より薄い所を消す"
    # Undo の段は自分で積む ('UNDO' に任せない)。ペイントモードでは Blender が「画像の段」として
    # 積もうとし、筆で描いていないので空とみなされて段ができない。すると Undo が
    # 「ペイントを始める」の前まで戻り、ペイントから抜けてしまった (実測。tests/ui_alpha.py)
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        im, why = cutoff_target(context)
        if im is None:
            cls.poll_message_set(why)
        return im is not None

    def execute(self, context):
        im, why = cutoff_target(context)
        if im is None:
            self.report({'ERROR'}, why)
            return {'CANCELLED'}
        t = context.window_manager.vstroke_tool.cut_threshold
        idx, old = cut_below(im, t)
        if idx is None:
            # 何も変えないときは Undo の段を積まない
            self.report({'INFO'}, "しきい値 (%.2f) より薄い所はありません" % t)
            return {'CANCELLED'}
        record(context.scene, im, idx, old)
        from . import session
        session.push_undo(getattr(context, "window", None), getattr(context, "area", None),
                          "薄い所を消す")
        self.report({'INFO'}, "%d 画素を透明にしました" % len(idx))
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# 2. 透明部分をロック (ブラシモード)
# -----------------------------------------------------------------------------

def lock_active():
    return bool(_lock["layer"]) and _lock["mask"] is not None


def begin_lock(ob):
    """描き始め (またはロックをオンにしたとき): 守る所を覚える。"""
    drop_lock()
    im = getattr(ob, "image", None)
    if im is None or not getattr(ob, "paint_lock_alpha", False):
        return False
    arr = read_rgba(im)
    if arr is None:
        return False
    byte = not im.is_float
    # 元のアルファ (8bit の画像は 8bit のまま。4096px で 16MB)
    alpha0 = (np.round(arr[..., 3] * 255.0).astype(np.uint8) if byte
              else arr[..., 3].copy())
    _lock.update(layer=im.name, alpha0=alpha0, byte=byte)
    _set_mask(arr, ob.paint_lock_threshold)
    return True


def _alpha0():
    a = _lock["alpha0"]
    return a.astype(np.float32) / np.float32(255.0) if _lock["byte"] else a


def _set_mask(arr, threshold):
    """元のアルファがしきい値より小さい所を「守る所」にして、その画素 (今の絵) を覚える。"""
    mask = _alpha0() < float(threshold)
    # 守る所の画素だけを持つ。8bit の画像は 8bit のまま (値は k/255 なので戻しても同じ。
    # 全部 float で持つと 4096px で 256MB になる)
    vals = arr[mask]
    if _lock["byte"]:
        vals = np.round(vals * 255.0).astype(np.uint8)
    _lock.update(mask=mask, orig=vals)
    _clear_render_cache()


def relock(ob):
    """描いている途中でしきい値を変えた: 守る所を決め直す。
    まず今守っている所を元に戻し (そこに塗った分は捨てる)、それから描き始めたときの
    アルファで新しい守る所を決める。新しく守る所に、それまでに塗った分はそのまま残る。
    0.33.3 までは今の絵から決め直していたので、しきい値を下げると守る所に塗った分が
    出てきて、そのまま確定してしまった (2026-10-05 ユーザー報告)。"""
    im = getattr(ob, "image", None)
    if im is None or not lock_active() or _lock["layer"] != im.name:
        return begin_lock(ob)
    enforce_lock()
    arr = read_rgba(im)
    if arr is None or arr.shape[:2] != _lock["alpha0"].shape:
        return begin_lock(ob)
    _set_mask(arr, ob.paint_lock_threshold)
    return True


def _clear_render_cache():
    """描き直しのときに読む控えを捨てる (守る所が変わったので、差し替え方も変わる)。"""
    if _lock["layer"]:
        from . import render
        render.clear_cache(_lock["layer"])


def locked_pixels(layer_name):
    """そのレイヤーの透明部分をロックしていれば (守る所, 覚えておいた元の画素)。無ければ None。
    (paint_preview が、守る所に元の絵を見せるのに使う)"""
    if not lock_active() or _lock["layer"] != layer_name:
        return None
    return _lock["mask"], _orig()


def _orig():
    v = _lock["orig"]
    return v.astype(np.float32) / np.float32(255.0) if _lock["byte"] else v


def enforce_lock():
    """守る所の画素を、覚えておいた元の絵に戻す。戻した画素の数を返す。"""
    if not lock_active():
        return 0
    im = bpy.data.images.get(_lock["layer"])
    if im is None:
        return 0
    arr = read_rgba(im)
    if arr is None or arr.shape[:2] != _lock["mask"].shape:
        return 0
    m = _lock["mask"]
    orig = _orig()
    changed = int(np.any(arr[m] != orig, axis=1).sum())
    if changed:
        arr[m] = orig
        write_rgba(im, arr)
    return changed


def drop_lock():
    _clear_render_cache()
    _lock.update(layer="", mask=None, orig=None, byte=False, alpha0=None)


def lock_display_images(img_dst, clip_alpha=None):
    """描いている間に画面へ貼る2枚: (描ける所のアルファ, 守る所の元の絵) の画像の名前。
    どちらも描いているレイヤーの画像と同じ大きさ (キャンバスとは限らない)。
    clip_alpha (キャンバスの大きさ) は、大きさが同じとき = ぴったり重なっているときだけ掛ける。"""
    from . import operators
    if not lock_active():
        return "", ""
    free = (~_lock["mask"]).astype(np.float32)
    if clip_alpha is not None and clip_alpha.shape == free.shape:
        free = free * clip_alpha
    free_name = operators._make_alpha_image(img_dst, free, "lockfree")
    # レイヤーの画像の大きさで作る (画面ではレイヤーの画像と同じ四角に貼る)
    h, w = _lock["mask"].shape
    keep = np.zeros((h, w, 4), np.float32)
    keep[_lock["mask"]] = _orig()
    name = operators.BACKDROP_PREFIX + "lockkeep"
    old = bpy.data.images.get(name)
    if old is not None and tuple(old.size) != (w, h):
        bpy.data.images.remove(old)
        old = None
    im = old or bpy.data.images.new(name, w, h, alpha=True, float_buffer=True)
    im.pixels.foreach_set(keep.ravel())
    im.update()
    return free_name, im.name


def lock_changed(ob, context):
    """ペイントレイヤーの「透明部分をロック」を切り替えた (描いている途中でも効く)。"""
    info = state.paint
    if not info or info.get("uid") != ob.uid:
        return
    from . import operators
    if ob.paint_lock_alpha:
        relock(ob)              # もうロック中ならしきい値の変更。そうでなければ描き始めと同じ
    else:
        enforce_lock()          # ロック中に描いた分は、守る所には入れない
        drop_lock()
    operators.refresh_lock_display()


# -----------------------------------------------------------------------------
# 登録
# -----------------------------------------------------------------------------

@persistent
def _on_load(*args):
    _history.clear()
    drop_lock()


def register():
    bpy.utils.register_class(VS_OT_alpha_cutoff)
    bpy.types.Scene.vstroke_pixel_serial = bpy.props.IntProperty(
        default=0, options={'HIDDEN'},
        description="しきい値で消した回数 (Undo で画素を戻すための目印)")
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    _history.clear()
    drop_lock()
    try:
        del bpy.types.Scene.vstroke_pixel_serial
    except Exception:
        pass
    bpy.utils.unregister_class(VS_OT_alpha_cutoff)

# SPDX-License-Identifier: GPL-3.0-or-later
"""下地画像 + 全オブジェクトを Skia で合成し、Image.pixels に書き込む。

Skia と Blender の違いの扱い:
- 上下: Blender の pixels は下の行から並ぶ。Skia のバッファの行0 を「画像の下端」として
  そのまま使い、図形は Blender と同じ座標 (原点左下) で描く。バッファの並べ替えは不要。
  (文字など向きのあるものは、描くときに局所的に上下反転させる)
- アルファ: Skia は乗算済み。Blender のバイト画像はストレート、float 画像は乗算済み。
- 色空間: 色は sRGB 値で保存。バイト画像は sRGB 値のまま合成 (v0.3.x と同じ)、
  float 画像はリニアに変換して合成する。
作業用バッファは常に RGBA float32 (乗算済み) で、元画像の精度を落とさない。
"""

import contextlib
import math

import bpy
import numpy as np

from . import data, geometry, state

try:
    import skia
    SKIA_ERROR = ""
except Exception as e:  # wheel が入っていない等
    skia = None
    SKIA_ERROR = str(e)

# 下地 (base image name) -> dict(key=(w, h, is_float), premul=(h,w,4), straight=(h,w,4)|None)
_base_cache = {}
# 読み込んだ画像 (name, リニアか, w, h) -> skia.Image
_placed_cache = {}
_busy = {"render": False, "suspend": 0}


def available():
    return skia is not None


@contextlib.contextmanager
def suspended():
    """この中ではプロパティ変更による自動再描画を止める。"""
    _busy["suspend"] += 1
    try:
        yield
    finally:
        _busy["suspend"] -= 1


def clear_cache(name=None):
    if name is None:
        _base_cache.clear()
        _placed_cache.clear()
    else:
        _base_cache.pop(name, None)
        for key in [k for k in _placed_cache if k[0] == name]:
            _placed_cache.pop(key, None)


def _hue_sat_matrix(hue, sat):
    """色相を回し彩度を変える 3x3 の行列 (明るさを保つ。SVG の hueRotate / saturate と同じ)。
    HSV に変換するより軽い (大きな写真でもスライダーがもたつかないように)。"""
    a = hue * 2.0 * math.pi
    c, s_ = math.cos(a), math.sin(a)
    rot = np.array([
        [0.213 + c * 0.787 - s_ * 0.213, 0.715 - c * 0.715 - s_ * 0.715, 0.072 - c * 0.072 + s_ * 0.928],
        [0.213 - c * 0.213 + s_ * 0.143, 0.715 + c * 0.285 + s_ * 0.140, 0.072 - c * 0.072 - s_ * 0.283],
        [0.213 - c * 0.213 - s_ * 0.787, 0.715 - c * 0.715 + s_ * 0.715, 0.072 + c * 0.928 + s_ * 0.072],
    ], np.float64)
    k = 1.0 + sat
    satm = np.array([
        [0.213 + 0.787 * k, 0.715 - 0.715 * k, 0.072 - 0.072 * k],
        [0.213 - 0.213 * k, 0.715 + 0.285 * k, 0.072 - 0.072 * k],
        [0.213 - 0.213 * k, 0.715 - 0.715 * k, 0.072 + 0.928 * k],
    ], np.float64)
    return (satm @ rot).astype(np.float32)


def adjust_rgb(rgb, vals):
    """画像補正を計算する。rgb は sRGB の値 (見た目どおりの明るさ)、0〜1。
    vals は data.adjust_values の結果。順番: 露光量 → レベル補正 → 明るさ・コントラスト
    → 色温度 → 色相・彩度・明度 → 反転 (Photoshop の調整の並びに近い)。"""
    v = dict(vals)
    rgb = np.clip(rgb.astype(np.float32), 0.0, 1.0)
    if v["exposure"]:
        rgb = _linear_to_srgb(_srgb_to_linear_arr(rgb) * (2.0 ** v["exposure"]))
    if v["black"] or v["white"] != 1.0 or v["gamma"] != 1.0:
        span = max(v["white"] - v["black"], 1e-4)
        rgb = np.clip((rgb - v["black"]) / span, 0.0, 1.0) ** (1.0 / max(v["gamma"], 1e-3))
    if v["brightness"] or v["contrast"]:
        k = math.tan((min(max(v["contrast"], -0.999), 0.999) + 1.0) * math.pi / 4.0)
        rgb = np.clip((rgb - 0.5) * k + 0.5 + v["brightness"], 0.0, 1.0)
    if v["temperature"]:
        t = v["temperature"] * 0.3
        rgb = np.clip(rgb * np.array([1.0 + t, 1.0, 1.0 - t], np.float32), 0.0, 1.0)
    if v["hue"] or v["saturation"]:
        rgb = np.clip(rgb @ _hue_sat_matrix(v["hue"], v["saturation"]).T, 0.0, 1.0)
    L = v["lightness"]
    if L > 0:
        rgb = rgb + (1.0 - rgb) * L
    elif L < 0:
        rgb = rgb * (1.0 + L)
    if v["invert"]:
        rgb = 1.0 - rgb
    return np.clip(rgb, 0.0, 1.0).astype(np.float32)


def placed_image(im, linear, adj=None):
    """読み込んだ画像を Skia の画像にする (重いのでキャッシュする)。
    adj は画像補正の値 (data.adjust_values)。補正はここで計算する (元の画像は変えない)。"""
    if im is None or skia is None:
        return None
    try:
        w, h = im.size
    except Exception:
        return None
    if w <= 0 or h <= 0:
        return None
    key = (im.name, bool(linear), w, h, adj)
    got = _placed_cache.get(key)
    if got is not None:
        return got
    try:
        arr = np.empty(w * h * 4, np.float32)
        im.pixels.foreach_get(arr)
        arr = arr.reshape(h, w, 4)
        _apply_lock(im.name, arr)
        if adj is None and im.is_float and linear:
            # float の画像を float のキャンバスに描くときは、8bit にせずそのまま使う
            # (元の画像が EXR などでも、有効化しただけで色が丸められたり 1 で頭打ちに
            #  ならないように。Blender の float の pixels は乗算済み・リニア)
            out = skia.Image.fromarray(np.ascontiguousarray(arr),
                                       skia.ColorType.kRGBA_F32_ColorType,
                                       skia.AlphaType.kPremul_AlphaType)
            for k in [k for k in _placed_cache if k[:4] == key[:4] and k != key]:
                _placed_cache.pop(k, None)
            _placed_cache[key] = out
            return out
        if adj is not None:
            arr = _adjusted_straight(arr, im.is_float, linear, adj)
        elif im.is_float:
            # float 画像は乗算済み・リニア -> ストレートに戻す
            a = arr[..., 3:4]
            rgb = np.divide(arr[..., :3], a, out=np.zeros_like(arr[..., :3]), where=a > 1e-8)
            arr = np.concatenate([rgb, a], axis=2)
            if not linear:
                arr = np.concatenate([_linear_to_srgb(arr[..., :3]), arr[..., 3:4]], axis=2)
        elif linear:
            # バイト画像は sRGB の値。リニアで合成するときは変換する
            arr = np.concatenate([_srgb_to_linear_arr(arr[..., :3]), arr[..., 3:4]], axis=2)
        data8 = np.ascontiguousarray(
            (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8))
        out = skia.Image.fromarray(data8, skia.ColorType.kRGBA_8888_ColorType,
                                   skia.AlphaType.kUnpremul_AlphaType)
    except Exception as e:
        print("[Vector Strokes] 画像を読み込めません:", getattr(im, "name", "?"), e)
        out = None
    # 同じ画像の、補正の値が違う古い結果は捨てる (スライダーを動かすたびに溜まらないように)
    for k in [k for k in _placed_cache if k[:4] == key[:4] and k != key]:
        _placed_cache.pop(k, None)
    _placed_cache[key] = out
    return out


def mask_values(im, w, h):
    """レイヤーマスクの画像を「見える濃さ」(h, w) にする (0 = 隠れる、1 = 見える)。
    白黒の明るさ (sRGB の値) を使い、透明な所は白 (見える) と同じにする。
    キャンバスと大きさが違えば、近い画素を拾って合わせる。重いのでキャッシュする。"""
    if im is None:
        return None
    try:
        iw, ih = im.size
    except Exception:
        return None
    if iw <= 0 or ih <= 0 or w <= 0 or h <= 0:
        return None
    key = (im.name, "mask", int(w), int(h))
    got = _placed_cache.get(key)
    if got is not None:
        return got
    try:
        arr = np.empty(iw * ih * 4, np.float32)
        im.pixels.foreach_get(arr)
        arr = arr.reshape(ih, iw, 4)
    except Exception as e:
        print("[Vector Strokes] マスクを読み込めません:", getattr(im, "name", "?"), e)
        return None
    a = arr[..., 3]
    rgb = arr[..., :3]
    if im.is_float:
        # float 画像は乗算済み・リニア -> ストレートの sRGB
        rgb = np.divide(rgb, a[..., None], out=np.zeros_like(rgb), where=a[..., None] > 1e-8)
        rgb = _linear_to_srgb(rgb)
    lum = rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722
    v = np.clip(1.0 - np.clip(a, 0.0, 1.0) * (1.0 - np.clip(lum, 0.0, 1.0)), 0.0, 1.0)
    if (iw, ih) != (w, h):
        ys = np.minimum((np.arange(h) * ih) // h, ih - 1)
        xs = np.minimum((np.arange(w) * iw) // w, iw - 1)
        v = v[np.ix_(ys, xs)]
    v = np.ascontiguousarray(v, np.float32)
    _placed_cache[key] = v
    return v


def mask_image(im, w, h):
    """レイヤーマスクを、切り抜きに使う Skia の画像 (アルファだけ) にする。"""
    if skia is None or im is None:
        return None
    key = (im.name, "mask_sk", int(w), int(h))
    got = _placed_cache.get(key)
    if got is not None:
        return got
    v = mask_values(im, w, h)
    if v is None:
        return None
    a8 = np.ascontiguousarray((v * 255.0 + 0.5).astype(np.uint8))
    try:
        out = skia.Image.fromarray(a8, skia.ColorType.kAlpha_8_ColorType)
    except Exception as e:
        print("[Vector Strokes] マスクを作れません:", e)
        return None
    _placed_cache[key] = out
    return out


def adjust_layer_step(vs, ob, w, h):
    """調整レイヤーのかけ方 (補正の値, 強さ)。強さは不透明度とマスクを掛けた (h, w) か数。
    何もしない (非表示・補正なし・不透明度 0) なら None。"""
    if ob is None or ob.kind != 'ADJUST' or not ob.visible or ob.opacity <= 0.0:
        return None
    vals = data.adjust_values(ob)
    if vals is None:
        return None
    k = float(ob.opacity)
    if data.has_mask(ob):
        mv = mask_values(ob.mask_image, w, h)
        if mv is not None:
            k = mv * k
    return vals, k


def apply_adjust_layer(buf, vals, k, linear):
    """ここまでに描いた絵 (buf。乗算済み) 全体に、調整レイヤーの補正をかける (その場で)。
    k は強さ (1 なら補正後そのもの、0 なら元のまま。画素ごとの配列でもよい)。"""
    if not isinstance(k, np.ndarray) and k >= 1.0:
        post_process(buf, 0, 0, linear, vals)
        return
    orig = buf.copy()
    post_process(buf, 0, 0, linear, vals)
    kk = k[..., None] if isinstance(k, np.ndarray) else k
    buf -= orig
    buf *= kk
    buf += orig


def adjust_alpha(a, vals):
    """アルファのしきい値: それより薄い所を透明にする (それ以外のアルファはそのまま)。"""
    t = float(dict(vals).get("alpha_cut", 0.0))
    if t <= 0.0:
        return a
    return np.where(a < t, np.float32(0.0), a).astype(np.float32)


def _adjusted_straight(arr, is_float, linear, adj):
    """画像の配列 (Blender の pixels そのまま) に補正をかけて、ストレートの配列にする。
    補正は見た目どおりの sRGB の値で計算し、必要ならリニアに戻す。"""
    if is_float:
        a = arr[..., 3:4]
        rgb = np.divide(arr[..., :3], a, out=np.zeros_like(arr[..., :3]), where=a > 1e-8)
        rgb = _linear_to_srgb(rgb)
    else:
        a = arr[..., 3:4]
        rgb = arr[..., :3]
    rgb = adjust_rgb(rgb, adj)
    a = adjust_alpha(a, adj)
    if linear:
        rgb = _srgb_to_linear_arr(rgb)
    return np.concatenate([rgb, a], axis=2)


def _srgb_to_linear_arr(a):
    a = np.clip(a, 0.0, 1.0)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)


def _linear_to_srgb(a):
    a = np.clip(a, 0.0, 1.0)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * (a ** (1.0 / 2.4)) - 0.055)


def srgb_to_linear(c):
    c = float(c)
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _empty_arrays(w, h, is_float):
    """下地が無いキャンバス (v0.28.3 より後に有効化したもの) は、透明から重ねる。
    元の画像は、いちばん下のペイントレイヤーとして描かれる。"""
    key = (w, h, is_float)
    cached = _base_cache.get("")
    if cached is not None and cached["key"] == key:
        return cached
    zero = np.zeros((h, w, 4), np.float32)
    entry = {"key": key, "premul": zero, "straight": None if is_float else zero}
    _base_cache[""] = entry
    return entry


def _apply_lock(name, arr):
    """透明部分をロックして描いている画像なら、守る所を覚えておいた元の絵に差し替える (その場で)。
    描いている間の描き直し (3D ビューへの反映・設定の変更など) で、守る所に塗った分
    (ベクターに戻るときに消える) が見えないように。arr は Blender の pixels と同じ並び (h, w, 4)。"""
    from . import alpha_tools
    lk = alpha_tools.locked_pixels(name)
    if lk is not None and lk[0].shape == arr.shape[:2]:
        arr[lk[0]] = lk[1]


def _base_arrays(base, is_float):
    w, h = base.size
    key = (w, h, is_float)
    cached = _base_cache.get(base.name)
    if cached is not None and cached["key"] == key:
        return cached
    arr = np.empty(w * h * 4, np.float32)
    base.pixels.foreach_get(arr)
    arr = arr.reshape(h, w, 4)
    _apply_lock(base.name, arr)
    if is_float:
        entry = {"key": key, "premul": arr, "straight": None}  # float は元から乗算済み
    else:
        premul = arr.copy()
        premul[..., :3] *= premul[..., 3:4]
        entry = {"key": key, "premul": premul, "straight": arr}
    _base_cache[base.name] = entry
    return entry


# -----------------------------------------------------------------------------
# Skia の図形
# -----------------------------------------------------------------------------

def skia_path(ob):
    """オブジェクトの形を1つの skia.Path にする。点が無ければ None。"""
    path = skia.Path()
    path.setFillType(skia.PathFillType.kEvenOdd if ob.fill_rule == 'EVENODD'
                     else skia.PathFillType.kWinding)
    empty = True
    for pts, closed in geometry.object_subpaths(ob):
        n = len(pts)
        if n == 0:
            continue
        empty = False
        c0 = pts[0][0]
        path.moveTo(*c0)
        if n == 1:
            path.lineTo(*c0)  # 1点だけでも丸い点として描く
            continue
        for p0, p1, p2, p3 in geometry.iter_segments_t(pts, closed):
            if geometry.is_straight(p0, p1, p2, p3):
                path.lineTo(*p3)
            else:
                path.cubicTo(*p1, *p2, *p3)
        if closed:
            path.close()
    return None if empty else path


def _color(c, linear):
    r, g, b, a = (float(v) for v in c)
    if linear:
        r, g, b = srgb_to_linear(r), srgb_to_linear(g), srgb_to_linear(b)
    return skia.Color4f(r, g, b, a)


_CAPS = {'BUTT': "kButt_Cap", 'ROUND': "kRound_Cap", 'SQUARE': "kSquare_Cap"}
_JOINS = {'MITER': "kMiter_Join", 'ROUND': "kRound_Join", 'BEVEL': "kBevel_Join"}


def _shader(p, linear):
    """グラデーションの場合の塗り方を作る。単色なら None。"""
    if p.paint_type == 'SOLID':
        return None
    stops = data.sorted_stops(p)
    if len(stops) < 2:
        return None
    colors = [_color(st.color, linear) for st in stops]
    positions = [float(st.position) for st in stops]
    a, b = skia.Point(*p.g_start), skia.Point(*p.g_end)
    if p.paint_type == 'RADIAL':
        r = max(math.hypot(b.x() - a.x(), b.y() - a.y()), 1e-4)
        return skia.GradientShader.MakeRadial(center=a, radius=r, colors=colors,
                                              positions=positions)
    return skia.GradientShader.MakeLinear(points=[a, b], colors=colors, positions=positions)


def _dash_effect(p):
    """破線の設定。使わないなら None。"""
    if not p.dash_enable:
        return None
    vals = [float(v) for v in p.dash]
    intervals = []
    for i in range(0, 6, 2):
        on, off = vals[i], vals[i + 1]
        if on > 0.0:
            intervals += [on, max(off, 0.01)]
    if not intervals:
        return None
    try:
        return skia.DashPathEffect.Make(intervals, float(p.dash_offset))
    except Exception:
        return None


def _to_color_int(c, linear):
    """エフェクト用の色 (Skia の 32bit カラー)。"""
    r, g, b, a = (float(v) for v in c)
    if linear:
        r, g, b = srgb_to_linear(r), srgb_to_linear(g), srgb_to_linear(b)
    q = lambda v: max(0, min(255, int(round(v * 255))))   # noqa: E731
    return skia.ColorSetARGB(q(a), q(r), q(g), q(b))


def corner_effect(ob):
    """「角を丸くする」の設定。使わないなら None。"""
    r = getattr(ob, "corner_round", 0.0)
    return skia.CornerPathEffect.Make(float(r)) if r > 0.0 else None


def image_filter(ob, linear):
    """ドロップシャドウ・ぼかし・外側の光彩をまとめた画像フィルター。無ければ None。"""
    f = None
    if ob.fx_blur_enable and ob.fx_blur_amount > 0.0:
        sg = float(ob.fx_blur_amount) * 0.5
        f = skia.ImageFilters.Blur(sg, sg, input=f)
    if ob.fx_glow_enable and ob.fx_glow_kind == 'OUTER' and ob.fx_glow_size > 0.0:
        sg = float(ob.fx_glow_size) * 0.5
        f = skia.ImageFilters.DropShadow(0.0, 0.0, sg, sg,
                                         _to_color_int(ob.fx_glow_color, linear), input=f)
    if ob.fx_shadow_enable:
        sg = float(ob.fx_shadow_blur) * 0.5
        f = skia.ImageFilters.DropShadow(
            float(ob.fx_shadow_offset[0]), float(ob.fx_shadow_offset[1]), sg, sg,
            _to_color_int(ob.fx_shadow_color, linear), input=f)
    return f


def make_paint(p, linear, corner=None):
    """塗り/線の設定から skia.Paint を作る。"""
    sk = skia.Paint(AntiAlias=True)
    sh = _shader(p, linear)
    if sh is not None:
        sk.setShader(sh)   # 色と不透明度は分岐点ごとに持つ
    else:
        sk.setColor4f(_color(p.color, linear))
    if p.kind == 'STROKE':
        sk.setStyle(skia.Paint.kStroke_Style)
        sk.setStrokeWidth(float(p.width))
        sk.setStrokeCap(getattr(skia.Paint, _CAPS.get(p.cap, "kRound_Cap")))
        sk.setStrokeJoin(getattr(skia.Paint, _JOINS.get(p.join, "kRound_Join")))
        sk.setStrokeMiter(float(p.miter_limit))
        d = _dash_effect(p)
        if d is not None and corner is not None:
            sk.setPathEffect(skia.PathEffect.MakeCompose(d, corner))  # 角を丸めてから破線に
        elif d is not None:
            sk.setPathEffect(d)
        elif corner is not None:
            sk.setPathEffect(corner)
    else:
        sk.setStyle(skia.Paint.kFill_Style)
        if corner is not None:
            sk.setPathEffect(corner)
    return sk


_BLEND = {
    'DARKEN': "kDarken", 'MULTIPLY': "kMultiply", 'COLOR_BURN': "kColorBurn",
    'LIGHTEN': "kLighten", 'SCREEN': "kScreen", 'COLOR_DODGE': "kColorDodge",
    'OVERLAY': "kOverlay", 'SOFT_LIGHT': "kSoftLight", 'HARD_LIGHT': "kHardLight",
    'DIFFERENCE': "kDifference", 'EXCLUSION': "kExclusion", 'HUE': "kHue",
    'SATURATION': "kSaturation", 'COLOR': "kColor", 'LUMINOSITY': "kLuminosity",
}


def _union(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


# -----------------------------------------------------------------------------
# 描いたあとの画素にかける処理 (レイヤーの色調補正・粒子)
# -----------------------------------------------------------------------------
# Skia だけでは作れない (Python から自前の合成を使えない) ので、その部分だけ別の紙に描いて
# numpy で処理してから貼り戻す。画像の補正と同じ計算 (adjust_rgb) を使う。

def _hash01(x, y, seed):
    """画素の位置ごとに決まる 0〜1 の乱数 (何度描いても同じ粒になる)。"""
    h = (x.astype(np.uint32) * np.uint32(374761393) + y.astype(np.uint32) * np.uint32(668265263)
         + np.uint32(seed) * np.uint32(2246822519))
    h = (h ^ (h >> np.uint32(13))) * np.uint32(1274126177)
    h = h ^ (h >> np.uint32(16))
    return h.astype(np.float32) / np.float32(4294967296.0)


def grain_noise(x0, y0, w, h, size, seed):
    """画像の座標 (x0, y0) から w×h の範囲の粒 (-0.5〜0.5)。
    size が 1 なら画素ごと、大きければその間隔の点をなめらかにつなぐ。
    (取っておいても 30ms ほどしか速くならず、4096px で 64MB 使うので毎回作る)"""
    return _grain_noise(x0, y0, w, h, size, seed)


def _grain_noise(x0, y0, w, h, size, seed):
    xs = np.arange(x0, x0 + w, dtype=np.float32)
    ys = np.arange(y0, y0 + h, dtype=np.float32)
    s = max(float(size), 1.0)
    if s <= 1.0:
        gx, gy = np.meshgrid(xs.astype(np.int64), ys.astype(np.int64))
        return _hash01(gx, gy, seed) - 0.5
    fx, fy = xs / s, ys / s
    ix, iy = np.floor(fx).astype(np.int64), np.floor(fy).astype(np.int64)
    tx, ty = fx - ix, fy - iy
    tx = tx * tx * (3.0 - 2.0 * tx)          # なめらかにつなぐ
    ty = ty * ty * (3.0 - 2.0 * ty)
    X0, Y0 = np.meshgrid(ix, iy)
    TX, TY = np.meshgrid(tx, ty)
    a = _hash01(X0, Y0, seed)
    b = _hash01(X0 + 1, Y0, seed)
    c = _hash01(X0, Y0 + 1, seed)
    d = _hash01(X0 + 1, Y0 + 1, seed)
    top = a + (b - a) * TX
    bot = c + (d - c) * TX
    v = top + (bot - top) * TY
    # つなぐと揺れが小さくなるので、同じくらいの強さに戻す
    return (v - 0.5) * 1.6


def post_process(arr, x0, y0, linear, adj=None, grain=None):
    """描いた絵 (乗算済み。linear ならリニア) に色調補正と粒子をかける (その場で書き換える)。
    grain は (強さ, 大きさ, モノクロか, 種)。計算は見た目どおりの sRGB の値で行う。"""
    a = arr[..., 3:4].copy()
    rgb = np.divide(arr[..., :3], a, out=np.zeros_like(arr[..., :3]), where=a > 1e-8)
    if linear:
        rgb = _linear_to_srgb(rgb)
    if adj is not None:
        rgb = adjust_rgb(rgb, adj)
        a = adjust_alpha(a, adj)
        arr[..., 3:4] = a
    if grain is not None:
        amount, size, mono, seed = grain
        h, w = arr.shape[:2]
        if mono:
            n = grain_noise(x0, y0, w, h, size, seed)[..., None]
        else:
            n = np.stack([grain_noise(x0, y0, w, h, size, seed + k) for k in range(3)],
                         axis=2)
        rgb = np.clip(rgb + n * float(amount), 0.0, 1.0)
    if linear:
        rgb = _srgb_to_linear_arr(rgb)
    arr[..., :3] = rgb * a


def adjust_parts(vals, n=128):
    """色調補正を、SVG のフィルターで書ける3つに分ける (書き出し用)。
    戻り値: (前半の表 [R, G, B], 色相・彩度の 3x3 行列 or None, 後半の表 or None)
    前半 = 露光量・レベル補正・明るさ・コントラスト・色温度 (色ごとの曲線)、
    後半 = 明度・反転。adjust_rgb と同じ順番・同じ計算。"""
    v = dict(vals)
    ramp = np.linspace(0.0, 1.0, n + 1, dtype=np.float32)
    rgb = np.stack([ramp] * 3, axis=1)
    pre_vals = dict(v, hue=0.0, saturation=0.0, lightness=0.0, invert=False)
    pre = adjust_rgb(rgb, tuple(pre_vals.items()))
    tables = [pre[:, k] for k in range(3)]
    mat = _hue_sat_matrix(v["hue"], v["saturation"]) if (v["hue"] or v["saturation"]) else None
    post = None
    if v["lightness"] or v["invert"]:
        only = {k: d for k, d in data.ADJUST_DEFAULTS}
        only.update(lightness=v["lightness"], invert=v["invert"])
        post = adjust_rgb(rgb, tuple(only.items()))[:, 0]
    return tables, mat, post


def post_settings(ob):
    """その オブジェクトにかける (色調補正, 粒子, ミラーの向き)。無いものは None。
    画像の補正は画像を読むときにかける (placed_image) ので、ここではレイヤーとグループだけ。"""
    adj = data.adjust_values(ob) if ob.kind in {'GROUP', 'LAYER'} else None
    grain = None
    if data.has_grain(ob):
        grain = (float(ob.fx_grain_amount), float(ob.fx_grain_size), bool(ob.fx_grain_mono),
                 int(ob.uid) * 7919 % 100003)
    mirror = ob.fx_mirror_mode if data.has_mirror(ob) else None
    return adj, grain, mirror


def apply_mirror(arr, x0, y0, W, H, mode):
    """配列 (キャンバスの (x0, y0) から) の中で、片側を反対側へ反転して写す (その場で書き換える)。
    軸はキャンバスの中心。幅が奇数なら真ん中の列はそのまま (元のアドオンと同じ)。
    行 0 が画像の下 (Blender と同じ) なので、「上」は y の大きい方。"""
    h, w = arr.shape[:2]
    if mode in {'L2R', 'R2L'}:
        pos = np.arange(x0, x0 + w)
        dest = pos >= (W + 1) // 2 if mode == 'L2R' else pos < W // 2
        idx = np.nonzero(dest)[0]
        src = (W - 1 - pos[idx]) - x0
        ok = (src >= 0) & (src < w)
        new = np.zeros((h, len(idx), 4), np.float32)
        new[:, ok] = arr[:, src[ok]]
        arr[:, idx] = new
    else:
        pos = np.arange(y0, y0 + h)
        dest = pos < H // 2 if mode == 'T2B' else pos >= (H + 1) // 2
        idx = np.nonzero(dest)[0]
        src = (H - 1 - pos[idx]) - y0
        ok = (src >= 0) & (src < h)
        new = np.zeros((len(idx), w, 4), np.float32)
        new[ok] = arr[src[ok]]
        arr[idx] = new


class _Drawer:
    """オブジェクトの木を、親から子へ順に描く。
    不透明度・描画モードがあるものは、いったん別の層に描いてから合成する
    (グループなら中身全体を1枚として半透明にする。Illustrator と同じ)。"""

    def __init__(self, canvas, vs, linear):
        self.canvas = canvas
        self.vs = vs
        self.linear = linear
        self.m = data.uid_map(vs)
        self.ch = data.children_map(vs)
        self.bounds = None
        self.only = None      # 書き出しで「選んだものだけ」にするときに使う
        self._mask_depth = 0  # マスクの形を描いている間は「選んだものだけ」の絞り込みを外す
        self.unclip = set()   # 切り抜きを一時的にやめるクリップグループ (ペイント中の表示用)
        self.skip = set()     # 描かないもの (下に敷いた元の画像。plain_original)
        self.unmask = set()   # レイヤーマスクをかけずに描くもの (マスクを描いている間の表示用)
        self._paths = {}

    def path(self, ob):
        if ob.uid not in self._paths:
            self._paths[ob.uid] = skia_path(ob)
        return self._paths[ob.uid]

    def node_bounds(self, uid):
        """描いたときに色が付く範囲 (線の太さ込み。ミラーなら反対側も)。"""
        b = self._node_bounds(uid)
        ob = self.m[uid]
        if b is not None and data.has_mirror(ob):
            W, H = self.vs.id_data.size
            b = _union(b, data.mirror_rect(b, ob.fx_mirror_mode, W, H))
        return b

    def _node_bounds(self, uid):
        ob = self.m[uid]
        if not ob.visible or uid in self.skip:
            return None
        if ob.kind in {'GROUP', 'LAYER'}:
            kids = self.ch.get(uid, [])
            if ob.clip and kids and uid not in self.unclip:
                # 見える範囲はマスクの形 (線の太さ込み) まで。何も塗っていなければ何も見えない
                b = self.node_bounds(kids[-1])
                if b is None:
                    return None
                m = data.effect_margin(ob)
                return (b[0] - m, b[1] - m, b[2] + m, b[3] + m)
            b = None
            for k in kids:
                b = _union(b, self.node_bounds(k))
            if b is not None:
                m = data.effect_margin(ob)
                b = (b[0] - m, b[1] - m, b[2] + m, b[3] + m)
            return b
        p = self.path(ob)
        if p is None:
            return None
        if ob.kind != 'IMAGE' and not (data.has_fill(ob) or data.has_stroke(ob)):
            return None
        r = p.getBounds()
        pad = data.stroke_extent(ob) + data.effect_margin(ob) + 1.0
        return (r.left() - pad, r.top() - pad, r.right() + pad, r.bottom() + pad)

    def draw_children(self, uid):
        kids = self.ch.get(uid, [])
        ob = self.m.get(uid)
        if ob is not None and ob.clip and kids and uid not in self.unclip:
            self.draw_clipped(kids[:-1], kids[-1])
            return
        for k in kids:
            self.draw(k)

    def draw_clipped(self, content, mask_uid):
        """クリッピングマスク: 中身を、マスクの「見た目のアルファ」で切り抜く。

        マスクの形の塗りと線の濃さ (アルファ) がそのまま「見える濃さ」になる
        (Photoshop のクリッピングマスクと同じ)。塗りのアルファが 0 で線が 1 なら、
        線の上だけ中身が見える。どんな種類のオブジェクトでもマスクにできる
        (画像・ペイントレイヤー・グループは、描かれたものの透明度がそのまま使われる)。
        マスクの形そのものは画面には描かない。"""
        mb = self.node_bounds(mask_uid)
        if mb is None:
            return          # 何も塗られていない / 非表示 = 何も通さない
        rect = skia.Rect.MakeLTRB(mb[0] - 1, mb[1] - 1, mb[2] + 1, mb[3] + 1)
        self.canvas.saveLayer(rect, None)          # 中身だけを別の層に描く
        for k in content:
            self.draw(k)
        cut = skia.Paint()
        cut.setBlendMode(skia.BlendMode.kDstIn)    # 中身 × マスクのアルファ
        self.canvas.saveLayer(rect, cut)
        self._mask_depth += 1
        try:
            self.draw(mask_uid, as_mask=True)
        finally:
            self._mask_depth -= 1
        self.canvas.restore()
        self.canvas.restore()

    def draw(self, uid, as_mask=False):
        ob = self.m[uid]
        if not ob.visible or uid in self.skip:
            return
        if self.only is not None and self._mask_depth == 0 and uid not in self.only:
            return
        b = self.node_bounds(uid)
        if b is None:
            return
        # マスクの形は「アルファ」だけが要る。描画モードや影は関係ないので使わない
        fx = None if as_mask else image_filter(ob, self.linear)
        blend = 'NORMAL' if as_mask else ob.blend_mode
        # レイヤーマスク: 別の層に描いてから、マスクの濃さで削る (効果・描画モードはそのあと。
        # Photoshop と同じく、影などはマスクで削った形に付く)
        lmask = None
        if data.has_mask(ob) and uid not in self.unmask:
            W, H = self.vs.id_data.size
            lmask = mask_image(ob.mask_image, W, H)
        needs_layer = (ob.opacity < 1.0 or blend != 'NORMAL' or fx is not None
                       or lmask is not None)
        if needs_layer:
            if ob.opacity <= 0.0:
                return
            paint = skia.Paint()
            paint.setAlphaf(float(ob.opacity))
            if fx is not None:
                paint.setImageFilter(fx)
            if blend in _BLEND:
                paint.setBlendMode(getattr(skia.BlendMode, _BLEND[blend]))
            rect = skia.Rect.MakeLTRB(b[0] - 1, b[1] - 1, b[2] + 1, b[3] + 1)
            self.canvas.saveLayer(rect, paint)
        adj, grain, mirror = (None, None, None) if as_mask else post_settings(ob)
        if adj is not None or grain is not None or mirror is not None:
            self.draw_post(ob, b, adj, grain, mirror)
        elif ob.kind in {'GROUP', 'LAYER'}:
            self.draw_children(uid)
        else:
            self.draw_leaf(ob)
        if lmask is not None:
            cut = skia.Paint()
            cut.setBlendMode(skia.BlendMode.kDstIn)
            W, H = self.vs.id_data.size
            self.canvas.drawImageRect(lmask, skia.Rect.MakeXYWH(0, 0, W, H),
                                      skia.SamplingOptions(), cut)
        # 色が付いた範囲を覚えておく (エフェクトのはみ出しも含める)
        self.bounds = _union(self.bounds, b)
        if needs_layer:
            self.canvas.restore()

    def draw_post(self, ob, b, adj, grain, mirror=None):
        """別の紙に描いて、色調補正・粒子をかけてから貼る。
        貼るのは今のキャンバスの上なので、不透明度・描画モード・影などはこのあと普通にかかる。"""
        W, H = self.vs.id_data.size
        x0 = max(int(math.floor(b[0])) - 1, 0)
        y0 = max(int(math.floor(b[1])) - 1, 0)
        x1 = min(int(math.ceil(b[2])) + 1, int(W))
        y1 = min(int(math.ceil(b[3])) + 1, int(H))
        if x1 <= x0 or y1 <= y0:
            return
        w, h = x1 - x0, y1 - y0
        work = np.zeros((h, w, 4), np.float32)
        info = skia.ImageInfo.Make(w, h, skia.ColorType.kRGBA_F32_ColorType,
                                   skia.AlphaType.kPremul_AlphaType)
        surface = skia.Surface.MakeRasterDirect(info, work, w * 16)
        sub = _Drawer(surface.getCanvas(), self.vs, self.linear)
        sub.only, sub.unclip, sub.skip = self.only, self.unclip, self.skip
        sub.unmask = self.unmask
        sub._mask_depth = self._mask_depth
        sub.canvas.translate(-x0, -y0)
        if ob.kind in {'GROUP', 'LAYER'}:
            sub.draw_children(ob.uid)
        else:
            sub.draw_leaf(ob)
        del surface
        if mirror is not None:
            apply_mirror(work, x0, y0, int(W), int(H), mirror)
        if adj is not None or grain is not None:
            post_process(work, x0, y0, self.linear, adj, grain)
        im = skia.Image.fromarray(work, skia.ColorType.kRGBA_F32_ColorType,
                                  skia.AlphaType.kPremul_AlphaType)
        self.canvas.drawImage(im, float(x0), float(y0))

    def draw_leaf(self, ob):
        """塗りと線を、下にあるものから順に描く (画像はそのまま描く)。"""
        if ob.kind == 'IMAGE':
            self.draw_image(ob)
            return
        path = self.path(ob)
        corner = corner_effect(ob)
        for p in ob.paints:
            if not p.enabled or (p.kind == 'STROKE' and p.width <= 0.0):
                continue
            sk = make_paint(p, self.linear, corner)
            if (p.kind == 'STROKE' and p.align != 'CENTER'
                    and data.can_align_stroke(ob)):
                # 内側/外側: 2倍の太さで描いて、パスの内か外だけを残す
                sk.setStrokeWidth(float(p.width) * 2.0)
                op = (skia.ClipOp.kIntersect if p.align == 'INSIDE'
                      else skia.ClipOp.kDifference)
                self.canvas.save()
                self.canvas.clipPath(path, op, True)
                self.canvas.drawPath(path, sk)
                self.canvas.restore()
            else:
                self.canvas.drawPath(path, sk)
        self.draw_inner_glow(ob, path, corner)

    def draw_image(self, ob):
        """読み込んだ画像を、置かれた位置・大きさで描く。"""
        im = placed_image(ob.image, self.linear, data.adjust_values(ob))
        if im is None:
            return
        w, h = data.image_size(ob)
        self.canvas.save()
        self.canvas.concat(image_skia_matrix(ob, w, h))
        if data.has_crop(ob) and not _crop_editing(ob):
            # トリミング: 元の画像の画素の座標で切り抜く (遠近変形していても同じ)
            x0, y0, x1, y1 = data.crop_rect_px(ob)
            self.canvas.clipRect(skia.Rect.MakeLTRB(x0, y0, x1, y1), True)
        paint = skia.Paint(AntiAlias=True)
        self.canvas.drawImageRect(im, skia.Rect.MakeXYWH(0, 0, w, h),
                                  skia.SamplingOptions(skia.FilterMode.kLinear), paint)
        self.canvas.restore()

    def draw_inner_glow(self, ob, path, corner):
        """内側の光彩: 形の内側だけに、ぼかした縁を描く。"""
        if not (ob.fx_glow_enable and ob.fx_glow_kind == 'INNER' and ob.fx_glow_size > 0):
            return
        size = float(ob.fx_glow_size)
        sk = skia.Paint(AntiAlias=True, Style=skia.Paint.kStroke_Style,
                        StrokeWidth=size * 2.0)
        sk.setColor4f(_color(ob.fx_glow_color, self.linear))
        sk.setMaskFilter(skia.MaskFilter.MakeBlur(skia.BlurStyle.kNormal_BlurStyle,
                                                  max(size * 0.5, 0.1)))
        if corner is not None:
            sk.setPathEffect(corner)
        self.canvas.save()
        self.canvas.clipPath(path, skia.ClipOp.kIntersect, True)
        self.canvas.drawPath(path, sk)
        self.canvas.restore()


def _crop_editing(ob):
    """キャンバスでトリミングを調整している最中か (その間は全体を見せ、外側は暗く重ねる)。"""
    from . import state
    cur = state.crop_edit
    if cur is None:
        return False
    try:
        return cur[0] == ob.id_data.name and cur[1] == ob.uid
    except Exception:
        return False


def image_skia_matrix(ob, w, h):
    """画像の画素 (左下が原点) -> 画像座標 の Skia の行列。遠近変形なら4隅に合わせる。"""
    if getattr(ob, "img_quad_on", False):
        m = skia.Matrix()
        src = [skia.Point(0, 0), skia.Point(w, 0), skia.Point(w, h), skia.Point(0, h)]
        dst = [skia.Point(float(x), float(y)) for x, y in data.image_corners(ob)]
        if m.setPolyToPoly(src, dst):
            return m
    a = data.image_matrix(ob)
    return skia.Matrix.MakeAll(float(a[0, 0]), float(a[0, 1]), float(a[0, 2]),
                               float(a[1, 0]), float(a[1, 1]), float(a[1, 2]), 0.0, 0.0, 1.0)


def draw_objects(canvas, vs, linear, only=None, unclip=None, skip=None, buf=None,
                 unmask=None):
    """全オブジェクトを canvas に描く。戻り値: 描いた範囲 (x0, y0, x1, y1) または None
    only に uid の集合を渡すと、その中のものだけ描く (書き出しの「選んだものだけ」用)。
    unclip に渡したクリップグループは、切り抜かずに描く (マスクを描いている間の表示用)。
    unmask に渡したものは、レイヤーマスクをかけずに描く (同上)。

    調整レイヤー (最上位の ADJUST) は、そこまでに描いた絵全体に補正をかける。
    buf は canvas の中身そのものの配列 (キャンバスの大きさ・乗算済み。MakeRasterDirect の配列)。
    buf が無い canvas (PDF など) では、最後の調整レイヤーまでを別の配列に描いて、
    1枚の画像として貼る (その下にあるものは画像になる)。"""
    d = _Drawer(canvas, vs, linear)
    d.only = only
    d.unclip = set(unclip or ())
    d.skip = set(skip or ())
    d.unmask = set(unmask or ())
    W, H = vs.id_data.size
    tops = d.ch.get(0, [])
    steps = {}
    for uid in tops:
        ob = d.m[uid]
        if ob.kind != 'ADJUST' or uid in d.skip or (only is not None and uid not in only):
            continue
        st = adjust_layer_step(vs, ob, W, H)
        if st is not None:
            steps[uid] = st
    if steps and buf is None:
        last = max(tops.index(u) for u in steps)
        work = np.zeros((H, W, 4), np.float32)
        info = skia.ImageInfo.Make(W, H, skia.ColorType.kRGBA_F32_ColorType,
                                   skia.AlphaType.kPremul_AlphaType)
        surface = skia.Surface.MakeRasterDirect(info, work, W * 16)
        below = set(tops[:last + 1])
        sub_only = {u for u in d.m if _top_of(d.m, u) in below}
        if only is not None:
            sub_only &= set(only)
        b = draw_objects(surface.getCanvas(), vs, linear, only=sub_only, unclip=unclip,
                         skip=skip, buf=work, unmask=unmask)
        del surface
        if b is not None:
            im = skia.Image.fromarray(work, skia.ColorType.kRGBA_F32_ColorType,
                                      skia.AlphaType.kPremul_AlphaType)
            canvas.drawImage(im, 0.0, 0.0)
            d.bounds = _union(d.bounds, b)
        tops = tops[last + 1:]
    for uid in tops:
        st = steps.get(uid)
        if st is not None:
            apply_adjust_layer(buf, st[0], st[1], linear)
            d.bounds = (0.0, 0.0, float(W), float(H))
            continue
        d.draw(uid)
    return d.bounds


def _top_of(m, uid):
    """uid を含む最上位のもの (レイヤー・調整レイヤー) の uid。"""
    seen = set()
    while uid in m and m[uid].parent_uid in m and uid not in seen:
        seen.add(uid)
        uid = m[uid].parent_uid
    return uid


def compose(vs, base_entry, w, h, is_float, skip=None):
    """下地 + 図形 を合成した配列 (h, w, 4) を返す。Blender の pixels にそのまま書ける形式。
    skip: 描かないもの (下地として敷いた元の画像)。"""
    work = base_entry["premul"].copy()
    info = skia.ImageInfo.Make(w, h, skia.ColorType.kRGBA_F32_ColorType,
                               skia.AlphaType.kPremul_AlphaType)
    surface = skia.Surface.MakeRasterDirect(info, work, w * 16)
    bounds = draw_objects(surface.getCanvas(), vs, linear=is_float, skip=skip, buf=work)
    del surface
    if is_float:
        return work
    # バイト画像: 乗算済み -> ストレート。変化した範囲だけ計算し、他は下地をそのまま使う
    out = base_entry["straight"].copy()
    if bounds is not None:
        x0 = max(int(np.floor(bounds[0])) - 2, 0)
        y0 = max(int(np.floor(bounds[1])) - 2, 0)
        x1 = min(int(np.ceil(bounds[2])) + 2, w)
        y1 = min(int(np.ceil(bounds[3])) + 2, h)
        if x0 < x1 and y0 < y1:
            sub = work[y0:y1, x0:x1]
            a = sub[..., 3:4]
            # 完全に透明なピクセルは下地の色を残す
            rgb = np.divide(sub[..., :3], a, out=out[y0:y1, x0:x1, :3].copy(), where=a > 1e-8)
            np.clip(rgb, 0.0, 1.0, out=rgb)
            out[y0:y1, x0:x1, :3] = rgb
            out[y0:y1, x0:x1, 3] = sub[..., 3]
    return out


# -----------------------------------------------------------------------------
# 画像への反映
# -----------------------------------------------------------------------------

def tag_redraw_all():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {'IMAGE_EDITOR', 'VIEW_3D'}:
                area.tag_redraw()


def composite_layers(img, uids, with_base=True, unclip=None, unmask=None):
    """選んだオブジェクトだけを合成した配列 (h, w, 4) を返す (ストレート RGBA)。
    ペイント中に「他のレイヤー」を正しく見せるために使う。
    unclip: 切り抜かずに描くクリップグループの uid (マスクそのものを描いている間は、
    まだ描き途中のマスクで中身が消えて見えないように、切り抜きをやめて全体を見せる)。"""
    if img is None or skia is None:
        return None
    vs = img.vstroke
    w, h = img.size
    if w <= 0 or h <= 0:
        return None
    if with_base and vs.base_image is not None:
        entry = _base_arrays(vs.base_image, img.is_float)
        work = entry["premul"].copy()
    else:
        work = np.zeros((h, w, 4), np.float32)
    if not with_base:
        # 元の画像はいまは「背景」レイヤーのペイントレイヤー。下地と同じく含めない
        uids = set(uids) - {ob.uid for ob in vs.objects if data.is_original(ob)}
    info = skia.ImageInfo.Make(w, h, skia.ColorType.kRGBA_F32_ColorType,
                               skia.AlphaType.kPremul_AlphaType)
    surface = skia.Surface.MakeRasterDirect(info, work, w * 16)
    draw_objects(surface.getCanvas(), vs, linear=img.is_float, only=uids, unclip=unclip,
                 buf=work, unmask=unmask)
    del surface
    a = work[..., 3:4]
    rgb = np.divide(work[..., :3], a, out=np.zeros_like(work[..., :3]), where=a > 1e-8)
    return np.concatenate([np.clip(rgb, 0.0, 1.0), a], axis=2)


def mask_alpha(img, vs, mask_uid):
    """クリッピングマスクの形 (mask_uid) の見た目のアルファ (h, w)。切り抜きの強さそのもの。"""
    w, h = img.size
    work = np.zeros((h, w, 4), np.float32)
    info = skia.ImageInfo.Make(w, h, skia.ColorType.kRGBA_F32_ColorType,
                               skia.AlphaType.kPremul_AlphaType)
    surface = skia.Surface.MakeRasterDirect(info, work, w * 16)
    d = _Drawer(surface.getCanvas(), vs, img.is_float)
    d._mask_depth = 1
    d.draw(mask_uid, as_mask=True)
    del surface
    return work[..., 3].copy()


def clip_alpha(img, vs, uid):
    """uid を切り抜いている祖先のクリップグループ (uid 自身がマスクの形のものは除く) の
    マスクのアルファを掛け合わせたもの (h, w)。切り抜かれていなければ None。
    ペイント中に、描いているレイヤーへ切り抜きを効かせて見せるために使う。"""
    if img is None or skia is None:
        return None
    m = data.uid_map(vs)
    ch = data.children_map(vs)
    out = None
    child = uid
    for a in data.ancestors(vs, uid, m):
        kids = ch.get(a, [])
        if m[a].clip and kids and kids[-1] != child:
            arr = mask_alpha(img, vs, kids[-1])
            out = arr if out is None else out * arr
        child = a
    # レイヤーマスク (自分と、自分を含むレイヤー・グループのもの) も同じように掛ける
    w, h = img.size
    for a in [uid] + data.ancestors(vs, uid, m):
        if data.has_mask(m.get(a)):
            mv = mask_values(m[a].mask_image, w, h)
            if mv is not None:
                out = mv.copy() if out is None else out * mv
    return out


def layer_split(vs, uid):
    """uid のオブジェクトより (後ろにあるもの, 前にあるもの) の uid の集合。
    どちらにも、入れ物 (レイヤー・グループ) は入れる。"""
    ch = data.children_map(vs)
    order = data.flatten_tree(ch)
    if uid not in order:
        return set(order), set()
    i = order.index(uid)
    m = data.uid_map(vs)
    kids = set([uid]) | set(data.descendants(vs, uid, ch))
    holders = set(data.ancestors(vs, uid, m))
    below = {u for u in order[:i] if u not in kids} | holders
    after = {u for u in order[i + 1:] if u not in kids} | holders
    return below, after


def _plain(ob):
    """不透明度 100%・通常の描画モード・効果なし・表示中か。"""
    if not ob.visible or ob.opacity < 1.0 or ob.blend_mode != 'NORMAL' or ob.clip:
        return False
    return not any(getattr(ob, k, False) for k in data.FX_PROPS if k.endswith("_enable"))


def plain_original(vs, w, h, is_float):
    """いちばん下に「そのまま」置かれた元の画像のレイヤー (無ければ None)。

    そのままなら、描いても配列を敷いても同じ結果になるので、配列のまま敷いて速くする。
    補正・遠近変形・移動・半透明・描画モード・効果のどれかがあれば、普通に描く。"""
    ch = data.children_map(vs)
    top = ch.get(0, [])
    if not top:
        return None
    m = data.uid_map(vs)
    lay = m[top[0]]
    if not (data.is_background_layer(lay) and _plain(lay)) or data.has_adjust(lay):
        return None
    kids = ch.get(lay.uid, [])
    if not kids:
        return None
    ob = m[kids[0]]
    im = ob.image if ob.kind == 'IMAGE' else None
    if (im is None or not data.is_original(ob) or not _plain(ob) or data.has_adjust(ob)
            or ob.img_quad_on or data.has_crop(ob)
            or tuple(im.size) != (w, h) or bool(im.is_float) != bool(is_float)
            or tuple(round(v, 9) for v in ob.img_origin) != (0.0, 0.0)
            or tuple(round(v, 9) for v in ob.img_mat) != (1.0, 0.0, 0.0, 1.0)):
        return None
    return ob


def _same_pixels(img, out, is_float):
    """img の今の画素と out が同じか。8bit の画像は 0〜255 に丸めて比べる (Blender は
    書き込むときに丸めるので、小数のまま比べると書き込んでも変わらない差で「違う」になる)。"""
    cur = np.empty(len(img.pixels), np.float32)
    img.pixels.foreach_get(cur)
    new = out.ravel()
    if cur.shape != new.shape:
        return False
    if is_float:
        return np.array_equal(cur, new)
    return np.array_equal(np.floor(cur * 255.0 + 0.5),
                          np.floor(np.clip(new, 0.0, 1.0) * 255.0 + 0.5))


def render_image(img, redraw=True, keep_clean=False):
    """下地 + 全オブジェクト を合成して img に書き込む。

    keep_clean: 描いた結果が今の画素と同じなら書き込まない。書き込むと中身が同じでも
    Blender は「変更あり」と見なし、閉じるたびに画像を保存するか聞かれる (ファイルを
    開いたときの描き直しで起きていた。2026-10-09 ユーザー報告)"""
    if img is None or _busy["render"] or skia is None:
        return
    vs = img.vstroke
    if not vs.enabled:
        return
    if data.needs_migration(vs):
        data.migrate(img)
    # 画像の大きさが変わっていたら (Blender の「画像 → リサイズ」など)、中身を合わせる
    data.sync_canvas_size(img)
    base = vs.base_image           # 移行できなかった古いデータだけが持っている
    if base is not None and tuple(base.size) != tuple(img.size):
        print("[Vector Strokes] 画像サイズと下地サイズが一致しません:", img.name)
        return
    _busy["render"] = True
    try:
        w, h = img.size
        is_float = img.is_float
        skip = None
        if base is not None:
            entry = _base_arrays(base, is_float)
        else:
            po = plain_original(vs, w, h, is_float)
            if po is not None:
                # 元の画像がそのままなら、以前の下地と同じく配列のまま敷く (速い。
                # 毎回描くと 4096px で 28ms -> 255ms になり、ドラッグがもたつく)
                entry = _base_arrays(po.image, is_float)
                skip = {po.uid}
            else:
                entry = _empty_arrays(w, h, is_float)
        out = compose(vs, entry, w, h, is_float, skip=skip)
        if keep_clean and not img.is_dirty and _same_pixels(img, out, is_float):
            return
        img.pixels.foreach_set(out.ravel())
        img.update()
        # 「この画像が変わった」を Blender に知らせる。update() だけだと、EEVEE や
        # イメージエディターは画素を直接読むので映るが、Cycles は知らせが来るまで
        # 読み直さず、3D ビューのテクスチャが古いままになる (2026-09-25 ユーザー報告。
        # 3D ビューの色を読んで、これが無いと Cycles だけ変わらないことを確かめた)
        try:
            img.update_tag()
        except Exception:
            pass
        # ペイント中なら、3D ビューへの途中経過 (paint_preview) が持つキャンバスの控えは古くなる
        if state.paint and state.paint.get("canvas") == img.name:
            from . import paint_preview
            paint_preview.canvas_rewritten()
    finally:
        _busy["render"] = False
    if redraw:
        try:
            tag_redraw_all()
        except Exception:
            pass


def request_render(img):
    """プロパティ変更時の再描画(suspended() の中では何もしない)。"""
    if _busy["suspend"] == 0:
        render_image(img)


def render_all(keep_clean=False):
    for img in bpy.data.images:
        try:
            if img.vstroke.enabled:
                render_image(img, redraw=False, keep_clean=keep_clean)
        except Exception as e:
            print("[Vector Strokes]", img.name, e)

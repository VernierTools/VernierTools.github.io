# SPDX-License-Identifier: GPL-3.0-or-later
"""サイドバーのボタンから呼ぶオペレーター。"""

import os
import sys

import bpy
import numpy as np
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       StringProperty)
from bpy.types import Operator

from . import data, edit_logic, export, keys, pathops, render, state, transform
from .select_tool import select_only
from .tool_base import isolation


def _space(context):
    return getattr(context, "space_data", None)


def _space_image(context):
    sp = context.space_data
    return getattr(sp, "image", None) if sp is not None else None


def _enabled_image(context):
    img = _space_image(context)
    return img if img is not None and img.vstroke.enabled else None


def enable_problem(img, deep=True):
    """この画像をベクター編集にできない理由 (できるなら空文字)。
    deep=False はピクセルを読み込まずに調べる (クリックのたびに呼ばれる poll 用)。"""
    if img is None:
        return "画像がありません"
    if img.source not in {'FILE', 'GENERATED'}:
        return "静止画像(ファイル/生成画像)のみ対応しています"
    w, h = img.size
    if w == 0 or h == 0 or (deep and len(img.pixels) == 0):
        return "画像のピクセルを読み込めません"
    # このアドオンが中で使っている画像は、それ自体をキャンバスにしない。
    # ペイント中に表示しているのはペイントレイヤーの画像なので、以前はサイドバーに
    # 「ベクター編集を有効化」が出て押せてしまい、レイヤーの中に別のキャンバスができて
    # 何をしても反映されなくなった (2026-09-25 ユーザー報告)
    if img.vstroke.paint_owner:
        return "ブラシで描いている最中です (ベクターに戻ってから操作してください)"
    if img.name.startswith(BACKDROP_PREFIX):
        return "ペイント中の表示用の画像です"
    role = _inner_role(img)
    if role:
        return role
    return ""


def _inner_role(img):
    """ほかのキャンバスの部品 (下地・ペイントレイヤー) なら、その説明。"""
    for canvas in bpy.data.images:
        try:
            vs = canvas.vstroke
            if not vs.enabled or canvas == img:
                continue
            if vs.base_image == img:
                return "「%s」の下地の画像です" % canvas.name
            for ob in vs.objects:
                if ob.kind == 'IMAGE' and ob.img_paint and ob.image == img:
                    return "「%s」のペイントレイヤーの画像です" % canvas.name
                if ob.mask_image == img:
                    return "「%s」のレイヤーマスクの画像です" % canvas.name
        except Exception:
            continue
    return ""


def owner_canvas(img):
    """img がほかのキャンバスの部品 (下地・ペイントレイヤー・レイヤーマスク・ペイント中の表示用)
    なら、その持ち主のキャンバス。部品でなければ None。"""
    if img is None:
        return None
    if img.name.startswith(BACKDROP_PREFIX):
        canvas = bpy.data.images.get((state.paint or {}).get("canvas", ""))
        return canvas if canvas is not None and canvas.vstroke.enabled else None
    for canvas in bpy.data.images:
        try:
            vs = canvas.vstroke
            if not vs.enabled or canvas == img:
                continue
            if vs.base_image == img:
                return canvas
            for ob in vs.objects:
                if ((ob.kind == 'IMAGE' and ob.img_paint and ob.image == img)
                        or ob.mask_image == img):
                    return canvas
        except Exception:
            continue
    return None


class VS_OT_show_canvas(Operator):
    """この画像を使っているキャンバスを表示する (この画像はキャンバスの部品なので、直接は編集できません)"""
    bl_idname = "vstroke.show_canvas"
    bl_label = "キャンバスに戻る"

    @classmethod
    def poll(cls, context):
        sp = _space(context)
        img = getattr(sp, "image", None) if sp is not None else None
        # 描いている最中なら「ベクターに戻る」の方を使う (描いた絵の確定が要る)
        return (img is not None and not img.vstroke.paint_owner
                and owner_canvas(img) is not None)

    def execute(self, context):
        sp = _space(context)
        canvas = owner_canvas(sp.image)
        from . import session
        with session.applying():
            # 先に「表示」モードにする。ペイントモードのままキャンバスを出すと、
            # ペイントレイヤーに描き始める決まりになっている (session._settle_vector)
            try:
                sp.ui_mode = 'VIEW'
            except Exception:
                pass
            sp.image = canvas
        context.area.tag_redraw()
        self.report({'INFO'}, "「%s」を表示しました" % canvas.name)
        return {'FINISHED'}


# 有効化したときのお知らせ (警告ではないもの)。呼んだ側が画面下に出す
enable_note = {"text": ""}
BLANK_NOTE = "何も描かれていない画像なので、背景 (元の画像) を非表示にしました (一覧の目で表示できます)"


def looks_blank(img, arr=None):
    """何も描かれていない画像か。
    - Blender が作ったまま一度も描いていない画像 (新規画像の単色・UV グリッド・カラーグリッド)
    - 全部の画素が同じ色の画像
    2026-10-19 ユーザー提案「何も編集されていなかったら自動で透明に」"""
    if img.source == 'GENERATED' and not img.is_dirty:
        return True
    if arr is None:
        w, h = img.size
        arr = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(arr)
    a = arr.reshape(-1, 4)
    if len(a) == 0:
        return True
    return bool(np.all(np.abs(a - a[0]) < 1e-6))


def enable_image(img):
    """元画像のコピーを、いちばん下のペイントレイヤーにして、ベクター編集を有効にする。
    戻り値: エラーメッセージ(成功なら空文字)。パックの失敗は警告として返す。

    v0.28.3 までは、コピーを固定の「下地」(base_image) にしていた。それだと有効化する前に
    描いた絵は、あとから描き足せない (2026-09-25 ユーザー決定でペイントレイヤーにした)。"""
    w, h = img.size
    enable_note["text"] = ""
    problem = enable_problem(img)
    if problem:
        return problem
    orig = bpy.data.images.new("%s_%s" % (img.name, data.ORIGINAL_NAME), w, h, alpha=True,
                               float_buffer=img.is_float)
    try:
        orig.colorspace_settings.name = img.colorspace_settings.name
    except Exception:
        pass
    arr = np.empty(w * h * 4, np.float32)
    img.pixels.foreach_get(arr)
    blank = looks_blank(img, arr)
    orig.pixels.foreach_set(arr)
    orig.file_format = 'OPEN_EXR' if img.is_float else 'PNG'
    warning = ""
    try:
        orig.pack()
    except Exception as e:
        warning = "元の画像のパックに失敗: %s" % e
    # どのエディターにも表示していない時に保存しても、画像(とベクターデータ)が消えないようにする
    img.use_fake_user = True
    vs = img.vstroke
    vs.schema_version = data.SCHEMA_VERSION
    with render.suspended():
        vs.enabled = True
        data.ensure_layers(vs)
        ob = data.attach_original(vs, orig)
        if blank and ob is not None:
            # 何も描かれていない: 背景を非表示にして、透明なキャンバスから始める。
            # 消さずに残すので、一覧の目でいつでも元の色に戻せる
            ob.visible = False
            enable_note["text"] = BLANK_NOTE
    data.set_active(vs, -1)          # 最初は何も選ばない (ブラシは新しいレイヤーに描く)
    render.clear_cache(orig.name)
    return warning


class VS_OT_enable(Operator):
    """この画像でベクター編集を有効化(元の画像はいちばん下のペイントレイヤーになります)"""
    bl_idname = "vstroke.enable"
    bl_label = "ベクター編集を有効化"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _space_image(context)
        if img is None:
            return False
        why = enable_problem(img, deep=False)
        if why:
            cls.poll_message_set(why)
            return False
        return True

    def execute(self, context):
        msg = enable_image(_space_image(context))
        if msg and not context.space_data.image.vstroke.enabled:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}
        # キャンバスはペイントモードのままにしない (ペイントモードにしたら、ペイントレイヤーに
        # 描く状態に入る決まり。session._settle_vector)
        from . import session
        session.canvases_to_view_mode()
        if msg:
            self.report({'WARNING'}, msg)
        if enable_note["text"]:
            self.report({'INFO'}, enable_note["text"])
        return {'FINISHED'}


class VS_OT_apply(Operator):
    """現在の見た目で画像を確定し、ベクターデータとレイヤーの画像を削除する"""
    bl_idname = "vstroke.apply"
    bl_label = "確定してベクター編集を終了"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None and not state.editing_image

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        render.render_image(img)
        base = vs.base_image
        # 元の画像・ペイントレイヤーの画像は、確定したら要らない (絵は img に焼き込まれている)
        inner = [ob.image for ob in vs.objects
                 if data.is_paint_layer(ob) and ob.image is not None]
        inner += [ob.mask_image for ob in vs.objects if ob.mask_image is not None]
        with render.suspended():
            vs.objects.clear()
            vs.enabled = False
            vs.base_image = None
        for im in ([base] if base is not None else []) + inner:
            try:
                if im.users == 0 or (im.users == 1 and im.use_fake_user):
                    render.clear_cache(im.name)
                    bpy.data.images.remove(im)
            except (ReferenceError, RuntimeError):
                pass
        render.clear_cache()
        return {'FINISHED'}


class VS_OT_refresh(Operator):
    """画像を読み直して再描画"""
    bl_idname = "vstroke.refresh"
    bl_label = "再描画"

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        img = _enabled_image(context)
        render.clear_cache()           # 下地・置いた画像・ペイントレイヤーを読み直す
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_path_add(Operator):
    """空のパスを追加(次に何もない場所をクリックすると、このパスに点が入る)"""
    bl_idname = "vstroke.path_add"
    bl_label = "パスを追加"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        oi = data.new_object(vs, style_from=data.style_source(vs),
                             parent_uid=isolation(img.name, vs))
        vs.objects[oi].subpaths.add()
        data.set_active(vs, oi)
        edit_logic.deselect_all(vs)
        render.tag_redraw_all()
        return {'FINISHED'}


class VS_OT_deselect(Operator):
    """点とオブジェクトの選択を解除(次のクリックは新しいパスになる)"""
    bl_idname = "vstroke.deselect"
    bl_label = "選択解除"

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        vs = _enabled_image(context).vstroke
        edit_logic.deselect_all(vs)
        for ob in vs.objects:
            ob.select = False
        render.tag_redraw_all()
        return {'FINISHED'}


class VS_OT_path_remove(Operator):
    """アクティブなオブジェクトを削除(グループなら中身も)"""
    bl_idname = "vstroke.path_remove"
    bl_label = "削除"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and data.active_object(img.vstroke) is not None

    def invoke(self, context, event):
        vs = _enabled_image(context).vstroke
        ob = data.active_object(vs)
        if ob.kind == 'LAYER' and data.children_map(vs).get(ob.uid):
            return context.window_manager.invoke_confirm(
                self, event, title="レイヤーを削除しますか？",
                message="「%s」と、その中のものがすべて削除されます。" % ob.name,
                confirm_text="削除する")
        return self.execute(context)

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        data.remove_objects(vs, [data.active_object(vs).uid])
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_path_move(Operator):
    """重なり順を変更(同じグループの中で1つずつ)"""
    bl_idname = "vstroke.path_move"
    bl_label = "重なり順を変更"
    bl_options = {'REGISTER', 'UNDO'}
    direction: StringProperty(default='UP')

    @classmethod
    def poll(cls, context):
        return VS_OT_path_remove.poll(context)

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        # UP = 前面 (一覧の上 = 後に描画)
        if not data.move_in_siblings(vs, data.active_object(vs).uid,
                                     1 if self.direction == 'UP' else -1):
            return {'CANCELLED'}     # 端なので動かない (Undo の空の段を積まない)
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_group(Operator):
    """選択中のオブジェクトをグループにする"""
    bl_description = keys.fmt("選択中のオブジェクトをグループにする ({C}G)")
    bl_idname = "vstroke.group"
    bl_label = "グループ化"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(transform.selected_items(img.vstroke))

    def execute(self, context):
        vs = _enabled_image(context).vstroke
        g = data.group(vs, transform.selected_items(vs))
        select_only(vs, [g])
        render.tag_redraw_all()
        return {'FINISHED'}


class VS_OT_ungroup(Operator):
    """選択中のグループを解除する"""
    bl_description = keys.fmt("選択中のグループを解除する ({C}{S}G)")
    bl_idname = "vstroke.ungroup"
    bl_label = "グループ解除"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None:
            return False
        vs = img.vstroke
        m = data.uid_map(vs)
        return any(m[u].kind == 'GROUP' for u in transform.selected_items(vs))

    def execute(self, context):
        vs = _enabled_image(context).vstroke
        kids = []
        for u in transform.selected_items(vs):
            if vs.objects[data.index_of_uid(vs, u)].kind == 'GROUP':
                kids += data.ungroup(vs, u)
            else:
                kids.append(u)
        select_only(vs, kids)
        render.tag_redraw_all()
        return {'FINISHED'}


ALIGN_ITEMS = (
    ('LEFT', "左揃え", "左端を揃える"),
    ('HCENTER', "水平方向中央", "左右の中央を揃える"),
    ('RIGHT', "右揃え", "右端を揃える"),
    ('TOP', "上揃え", "上端を揃える"),
    ('VCENTER', "垂直方向中央", "上下の中央を揃える"),
    ('BOTTOM', "下揃え", "下端を揃える"),
    ('DIST_H', "水平方向に分布", "左右の中心が等間隔になるように並べる (3つ以上)"),
    ('DIST_V', "垂直方向に分布", "上下の中心が等間隔になるように並べる (3つ以上)"),
)


class VS_OT_align(Operator):
    """選択中のオブジェクトを揃える・等間隔に並べる"""
    bl_idname = "vstroke.align"
    bl_label = "整列"
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=ALIGN_ITEMS)

    @classmethod
    def description(cls, context, props):
        return {k: d for k, _, d in ALIGN_ITEMS}.get(props.mode, "")

    @classmethod
    def poll(cls, context):
        return VS_OT_group.poll(context)

    def execute(self, context):
        if not transform.align(_enabled_image(context), self.mode):
            return {'CANCELLED'}
        return {'FINISHED'}


class VS_OT_layer_add(Operator):
    """新しいレイヤーを最前面に追加する (以後、描いたものはこのレイヤーに入る)"""
    bl_idname = "vstroke.layer_add"
    bl_label = "新規レイヤー"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        vs = _enabled_image(context).vstroke
        i = data.new_object(vs, kind='LAYER')
        data.set_active(vs, i)
        render.tag_redraw_all()
        return {'FINISHED'}


class VS_OT_adjust_add(Operator):
    """調整レイヤーを追加する (下にあるものすべてに色調補正をかける。元の絵は変えない)"""
    bl_idname = "vstroke.adjust_add"
    bl_label = "調整レイヤーを追加"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        act = data.active_object(vs)
        above = render._top_of(data.uid_map(vs), act.uid) if act is not None else 0
        i = data.new_object(vs, kind='ADJUST')
        uid = vs.objects[i].uid
        # 選んでいるもの (を含むレイヤー) のすぐ上に置く (Photoshop と同じ)。
        # 何も選んでいなければ最前面
        ch = data.children_map(vs)
        tops = ch.get(0, [])
        if above and above in tops and uid in tops:
            tops.remove(uid)
            tops.insert(tops.index(above) + 1, uid)
            data.reorder(vs, data.flatten_tree(ch))
        data.set_active(vs, data.index_of_uid(vs, uid))
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_mask_add(Operator):
    """レイヤーマスクを追加する (白で見せる・黒で隠す。ブラシで描いて調整する)"""
    bl_idname = "vstroke.mask_add"
    bl_label = "レイヤーマスクを追加"
    bl_options = {'REGISTER', 'UNDO'}
    fill: EnumProperty(name="最初の状態", default='WHITE',
                       items=(('WHITE', "すべて表示", "白で塗ったマスク (最初は何も隠さない)"),
                              ('BLACK', "すべて隠す", "黒で塗ったマスク (最初は全部隠れる)")))

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        if ob is None:
            return False
        if ob.mask_image is not None:
            cls.poll_message_set("もうマスクがあります")
            return False
        return True

    def execute(self, context):
        img = _enabled_image(context)
        ob = data.active_object(img.vstroke)
        w, h = img.size
        # 色は generated_color で付ける (Undo で画像が作り直されても同じ色になる)
        im = data.new_canvas_part(img, "%s_%s_マスク" % (img.name, ob.name), w, h)
        im.generated_color = (1.0, 1.0, 1.0, 1.0) if self.fill == 'WHITE' else (0.0, 0.0, 0.0, 1.0)
        ob.mask_image = im
        ob.mask_enable = True
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_mask_remove(Operator):
    """レイヤーマスクを外す (何も隠さない状態に戻る)"""
    bl_idname = "vstroke.mask_remove"
    bl_label = "レイヤーマスクを削除"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.mask_image is not None

    def execute(self, context):
        img = _enabled_image(context)
        ob = data.active_object(img.vstroke)
        # 画像そのものは消さない (Undo で戻せるように。どこからも使われなければ保存時に消える)
        ob.mask_image = None
        ob.mask_target = False
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_clip_make(Operator):
    """選んだ形で切り抜く。1つだけ選んだときは、すぐ下にあるものを切り抜きます"""
    bl_description = keys.fmt("選んだ形で切り抜く ({C}7)。"
                              "1つだけ選んだときは、すぐ下にあるものを切り抜きます")
    bl_idname = "vstroke.clip_make"
    bl_label = "クリッピングマスクを作成"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None or not transform.selected_items(img.vstroke):
            if img is not None:
                cls.poll_message_set("マスクにする形を選んでください")
            return False
        return True

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        g = data.make_clip(vs, transform.selected_items(vs))
        if isinstance(g, str):
            self.report({'WARNING'}, g)
            return {'CANCELLED'}
        select_only(vs, [g])
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_clip_release(Operator):
    """クリッピングマスクを解除する (マスクの形は元の線・塗りに戻る)"""
    bl_description = keys.fmt("クリッピングマスクを解除する (マスクの形は元の線・塗りに戻る) "
                              "({C}{A}7)")
    bl_idname = "vstroke.clip_release"
    bl_label = "クリッピングマスクを解除"
    bl_options = {'REGISTER', 'UNDO'}

    @staticmethod
    def _targets(vs):
        m = data.uid_map(vs)
        out = [u for u in transform.selected_items(vs) if m[u].clip]
        act = data.active_object(vs)
        if not out and act is not None and act.clip:
            out = [act.uid]
        return out

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(cls._targets(img.vstroke))

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        with render.suspended():
            for u in self._targets(vs):
                vs.objects[data.index_of_uid(vs, u)].clip = False
        render.render_image(img)
        return {'FINISHED'}


def select_similar(vs, mode):
    """アクティブなものと mode が同じものを選ぶ。戻り値: 選んだ数 (0 なら何もしない)。"""
    act = data.active_object(vs)
    if act is None:
        return 0
    img = vs.id_data
    uids = data.similar_uids(vs, act.uid, mode, isolation(img.name, vs) if img else 0)
    if not uids:
        return 0
    select_only(vs, [u for u in uids if u != act.uid] + [act.uid])   # アクティブはそのまま
    return len(uids)


class VS_OT_select_similar(Operator):
    """アクティブなオブジェクトと、塗り・線などが同じものをまとめて選ぶ
    (Illustrator の「選択 → 共通」)"""
    bl_idname = "vstroke.select_similar"
    bl_label = "共通"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(name="比べるもの", items=data.SIMILAR_MODES)

    @classmethod
    def description(cls, context, props):
        return dict((k, d) for k, _, d in data.SIMILAR_MODES).get(props.mode, "")

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None:
            return False
        act = data.active_object(img.vstroke)
        if act is None or act.kind not in data.LEAF_KINDS:
            cls.poll_message_set("比べる元になるオブジェクトを選んでください")
            return False
        return True

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        n = select_similar(vs, self.mode)
        if n == 0:
            label = dict((k, l) for k, l, _ in data.SIMILAR_MODES).get(self.mode, "")
            self.report({'INFO'}, "「%s」で比べられるものがありません" % label)
            return {'CANCELLED'}
        self.report({'INFO'}, "%d 個を選びました" % n)
        render.tag_redraw_all()
        return {'FINISHED'}


def reset_adjust(ob):
    """画像補正をすべて元に戻す。"""
    with render.suspended():
        for name, default in data.ADJUST_DEFAULTS:
            setattr(ob, "adj_" + name, default)


class VS_OT_image_adjust_reset(Operator):
    """色調補正をすべて元に戻す"""
    bl_idname = "vstroke.image_adjust_reset"
    bl_label = "補正をリセット"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        ob = data.active_object(img.vstroke) if img is not None else None
        return ob is not None and data.has_adjust(ob)

    def execute(self, context):
        img = _enabled_image(context)
        reset_adjust(data.active_object(img.vstroke))
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_arrange(Operator):
    """重なり順を変える"""
    bl_description = keys.fmt("重なり順を変える ({C}] 前面へ / {C}[ 背面へ / "
                              "Shift も押すと最前面・最背面)")
    bl_idname = "vstroke.arrange"
    bl_label = "重なり順"
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=(('FRONT', "最前面へ", ""), ('FORWARD', "前面へ", ""),
                              ('BACKWARD', "背面へ", ""), ('BACK', "最背面へ", "")))

    @classmethod
    def poll(cls, context):
        return VS_OT_group.poll(context)

    def execute(self, context):
        img = _enabled_image(context)
        if not data.arrange(img.vstroke, transform.selected_items(img.vstroke), self.mode):
            return {'CANCELLED'}     # もうその順番 (Undo の空の段を積まない)
        render.render_image(img)
        return {'FINISHED'}


# **重要**: 動的に作った選択肢は、Python 側で参照を持ち続けないと
# 文字列が捨てられて画面が文字化けする (Blender は中身をコピーしない)。
# 2026-09-21 にユーザーがレイヤー名の文字化けで発見した
_layer_items_cache = [('0', "(なし)", "")]


def _layer_items(self, context):
    global _layer_items_cache
    img = _enabled_image(context)
    if img is None:
        _layer_items_cache = [('0', "(なし)", "")]
        return _layer_items_cache
    ls = list(reversed(data.layers(img.vstroke)))  # 一覧と同じく前面が上
    _layer_items_cache = [(str(ob.uid), ob.name, "") for ob in ls] or \
        [('0', "(なし)", "")]
    return _layer_items_cache


def move_targets(vs):
    """「レイヤーへ移動」で動かすもの: 選んでいるもの。何も選んでいなければ、一覧で押している行。
    ロックしているもの (最初からロックしてある「元の画像」など) は選べないので、
    一覧で押せばそれを動かせるようにする (2026-09-27 ユーザー報告「背景を移動できない」)。"""
    items = transform.selected_items(vs)
    if items:
        return items
    act = data.active_object(vs)
    if act is not None and act.kind not in {'LAYER', 'ADJUST'}:
        return [act.uid]
    return []


class VS_OT_move_to_layer(Operator):
    """選択中のオブジェクト (選んでいなければ一覧で押している行) を、選んだレイヤーの最前面へ移す"""
    bl_idname = "vstroke.move_to_layer"
    bl_label = "レイヤーへ移動"
    bl_options = {'REGISTER', 'UNDO'}
    layer: EnumProperty(name="レイヤー", items=_layer_items)

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None:
            return False
        if move_targets(img.vstroke):
            return True
        act = data.active_object(img.vstroke)
        if act is not None and act.kind == 'LAYER':
            cls.poll_message_set("レイヤーそのものは移せません (中のものを押してください)")
        else:
            cls.poll_message_set("移すものを一覧で押してください")
        return False

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        if not data.move_to_layer(vs, move_targets(vs), int(self.layer)):
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


def _active_ob(context):
    img = _enabled_image(context)
    return data.active_object(img.vstroke) if img is not None else None


class VS_OT_paint_add(Operator):
    """塗りまたは線を追加する"""
    bl_idname = "vstroke.paint_add"
    bl_label = "追加"
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=(('FILL', "塗り", "塗りを追加"), ('STROKE', "線", "線を追加")))

    @classmethod
    def description(cls, context, props):
        return "塗りを追加" if props.kind == 'FILL' else "線を追加"

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind in {'PATH', 'SHAPE', 'TEXT'}

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        if self.kind == 'FILL':
            data.add_paint(ob, 'FILL', color=(0.8, 0.8, 0.8, 1.0))
        else:
            data.add_paint(ob, 'STROKE', color=(0.0, 0.0, 0.0, 1.0), width=8.0)
        render.render_image(img)
        return {'FINISHED'}


def _paint_index(ob, index):
    """行のボタンが指す塗り/線の番号 (-1 なら選んでいるもの)。"""
    return index if index >= 0 else ob.active_paint


class VS_OT_paint_remove(Operator):
    """この塗り/線を削除する"""
    bl_idname = "vstroke.paint_remove"
    bl_label = "削除"
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=-1, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and len(ob.paints) > 0

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        i = _paint_index(ob, self.index)
        if not (0 <= i < len(ob.paints)):
            return {'CANCELLED'}
        ob.paints.remove(i)
        ob.active_paint = min(ob.active_paint, max(len(ob.paints) - 1, 0))
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_paint_move(Operator):
    """塗り/線の重なり順を変える (上にあるものほど手前に描かれます)"""
    bl_idname = "vstroke.paint_move"
    bl_label = "並べ替え"
    bl_options = {'REGISTER', 'UNDO'}
    # UP / DOWN: 同じ種類 (塗りどうし・線どうし) の中で1つ手前・奥へ
    # BELOW_FILL / ABOVE_FILL: 線を、塗りより奥・手前へ
    direction: StringProperty(default='UP')
    index: IntProperty(default=-1, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        return {'UP': "1つ手前に描く", 'DOWN': "1つ奥に描く",
                'BELOW_FILL': "塗りより奥に描く (線の内側半分が塗りに隠れます)",
                'ABOVE_FILL': "塗りより手前に描く (ふつうの描き方)"}.get(props.direction, "")

    @classmethod
    def poll(cls, context):
        return VS_OT_paint_remove.poll(context)

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        i = _paint_index(ob, self.index)
        if not (0 <= i < len(ob.paints)):
            return {'CANCELLED'}
        kind = ob.paints[i].kind
        fills = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
        if self.direction in {'UP', 'DOWN'}:
            same = [k for k, p in enumerate(ob.paints) if p.kind == kind]
            pos = same.index(i) + (1 if self.direction == 'UP' else -1)
            if not (0 <= pos < len(same)):
                return {'CANCELLED'}     # 端なので動かない
            j = same[pos]
        elif kind == 'STROKE' and fills:
            j = fills[0] if self.direction == 'BELOW_FILL' else fills[-1]
            if (self.direction == 'BELOW_FILL' and i < j) or \
                    (self.direction == 'ABOVE_FILL' and i > j):
                return {'CANCELLED'}     # もうそこにある
        else:
            return {'CANCELLED'}
        ob.paints.move(i, j)
        ob.active_paint = j
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_paint_set(Operator):
    """塗り/線の設定を、絵の付いたボタンで切り替える"""
    bl_idname = "vstroke.paint_set"
    bl_label = "切り替え"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    index: IntProperty(default=-1, options={'SKIP_SAVE'})
    prop: StringProperty(options={'SKIP_SAVE'})
    value: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        items = {'paint_type': data.PAINT_TYPES, 'cap': data.STROKE_CAPS,
                 'join': data.STROKE_JOINS, 'align': data.STROKE_ALIGNS}.get(props.prop, ())
        head = {'cap': "端の形: ", 'join': "角の形: ", 'align': "線の位置: "}.get(props.prop, "")
        for k, name, desc in items:
            if k == props.value:
                return head + name + ("\n" + desc if desc else "")
        return ""

    @classmethod
    def poll(cls, context):
        return VS_OT_paint_remove.poll(context)

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        i = _paint_index(ob, self.index)
        if not (0 <= i < len(ob.paints)) or self.prop not in {'paint_type', 'cap', 'join', 'align'}:
            return {'CANCELLED'}
        p = ob.paints[i]
        if getattr(p, self.prop) == self.value:
            return {'CANCELLED'}         # 押しても変わらないなら Undo の段を積まない
        if self.prop == 'align' and self.value != 'CENTER' and not data.can_align_stroke(ob):
            self.report({'INFO'}, "内側・外側は閉じた形だけです")
            return {'CANCELLED'}
        setattr(p, self.prop, self.value)
        ob.active_paint = i
        render.render_image(img)
        return {'FINISHED'}


# 効果: (オンにするもの, 名前, アイコン, 付けられる種類 (None ならどれでも))
FX_LIST = (
    ('fx_shadow_enable', "ドロップシャドウ", 'SHADING_RENDERED', None),
    ('fx_blur_enable', "ぼかし", 'SMOOTHCURVE', None),
    ('fx_glow_enable', "光彩", 'LIGHT_SUN', None),
    ('fx_mirror_enable', "ミラー", 'MOD_MIRROR', None),
    ('fx_grain_enable', "粒子", 'TEXTURE', None),
    ('corner_round', "角を丸くする", 'MOD_BEVEL', {'PATH', 'SHAPE'}),
)


def fx_on(ob, name):
    v = getattr(ob, name)
    return v > 0.0 if name == 'corner_round' else bool(v)


def fx_available(ob):
    return [f for f in FX_LIST if f[3] is None or ob.kind in f[3]]


class VS_OT_fx_set(Operator):
    """効果を付ける / 外す (外しても数値は覚えています)"""
    bl_idname = "vstroke.fx_set"
    bl_label = "効果"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    name: StringProperty(options={'SKIP_SAVE'})
    on: BoolProperty(default=True, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        label = next((f[1] for f in FX_LIST if f[0] == props.name), "")
        return ("「%s」を付ける" if props.on else "「%s」を外す (数値は覚えています)") % label

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind != 'ADJUST'

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        if not any(f[0] == self.name for f in fx_available(ob)):
            return {'CANCELLED'}
        if fx_on(ob, self.name) == self.on:
            return {'CANCELLED'}
        if self.name == 'corner_round':
            ob.corner_round = 10.0 if self.on else 0.0
        else:
            setattr(ob, self.name, self.on)
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_gradient_canvas(Operator):
    """この塗り/線のグラデーションを、キャンバスで調整する (グラデーションツール G)"""
    bl_idname = "vstroke.gradient_canvas"
    bl_label = "キャンバスで調整 (G)"
    bl_options = {'INTERNAL'}
    index: IntProperty(default=-1, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _active_ob(context) is not None

    def execute(self, context):
        ob = _active_ob(context)
        if 0 <= self.index < len(ob.paints):
            ob.active_paint = self.index     # グラデーションツールが動かす対象
        bpy.ops.vstroke.set_tool(tool='GRADIENT')
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


class VS_OT_crop_edit(Operator):
    """キャンバスで画像をトリミングする (枠の角や辺をドラッグ。Enter か Esc で終わる)。
    画素は消さないので、いつでも元に戻せます"""
    bl_idname = "vstroke.crop_edit"
    bl_label = "キャンバスでトリミング"
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        if ob is None or ob.kind != 'IMAGE' or ob.image is None:
            return False
        if data.is_paint_layer(ob):
            cls.poll_message_set("ペイントレイヤーはトリミングできません")
            return False
        return True

    def execute(self, context):
        from .select_tool import end_crop_edit, select_only
        img = _enabled_image(context)
        ob = _active_ob(context)
        cur = state.crop_edit
        if cur is not None and cur == (img.name, ob.uid):
            end_crop_edit()             # もう一度押すと終わる
        else:
            vs = img.vstroke
            select_only(vs, [ob.uid])
            state.crop_edit = (img.name, ob.uid)
            render.render_image(img)    # トリミング中は全体を見せる (外側は暗く重ねる)
            # 選択ツールで操作する (ベクター編集を始めていなければ始める)
            bpy.ops.vstroke.set_tool(tool='SELECT')
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


class VS_OT_crop_reset(Operator):
    """トリミングをやめて、画像全体を見せる"""
    bl_idname = "vstroke.crop_reset"
    bl_label = "トリミングを元に戻す"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and data.has_crop(ob)

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        ob.img_crop = (0.0, 0.0, 1.0, 1.0)
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_edit_exit(Operator):
    """ベクター編集を終える (何も選んでいないときに Esc を押すのと同じ)"""
    bl_idname = "vstroke.edit_exit"
    bl_label = "ベクター編集を終了"

    @classmethod
    def poll(cls, context):
        return bool(state.editing_image)

    def execute(self, context):
        state.exit_request = True        # モーダル (edit_tool.VS_OT_edit) が次の入力で終える
        for a in context.screen.areas:
            a.tag_redraw()
        return {'FINISHED'}


class VS_OT_hint(Operator):
    """(マウスを乗せると説明が出るだけのボタン)"""
    bl_idname = "vstroke.hint"
    bl_label = ""
    bl_options = {'INTERNAL'}
    text: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        return props.text

    def execute(self, context):
        return {'CANCELLED'}


class VS_OT_stop_add(Operator):
    """グラデーションの分岐点を追加する"""
    bl_idname = "vstroke.stop_add"
    bl_label = "分岐点を追加"
    bl_options = {'REGISTER', 'UNDO'}
    paint: IntProperty(default=-1, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and any(p.paint_type != 'SOLID' for p in ob.paints)

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        i = _paint_index(ob, self.paint)
        if not (0 <= i < len(ob.paints)) or ob.paints[i].paint_type == 'SOLID':
            return {'CANCELLED'}
        p = ob.paints[i]
        ob.active_paint = i
        stops = data.sorted_stops(p)
        s = p.stops.add()
        if len(stops) >= 2:
            a, b = stops[0], stops[-1]
            s.position = (a.position + b.position) / 2
            s.color = tuple((x + y) / 2 for x, y in zip(a.color, b.color))
        p.active_stop = len(p.stops) - 1
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_stop_remove(Operator):
    """グラデーションの分岐点を削除する"""
    bl_idname = "vstroke.stop_remove"
    bl_label = "分岐点を削除"
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=-1)
    paint: IntProperty(default=-1, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and any(len(p.stops) > 2 for p in ob.paints)

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        pi = _paint_index(ob, self.paint)
        if not (0 <= pi < len(ob.paints)) or len(ob.paints[pi].stops) <= 2:
            return {'CANCELLED'}
        p = ob.paints[pi]
        i = self.index if self.index >= 0 else p.active_stop
        if 0 <= i < len(p.stops):
            p.stops.remove(i)
            p.active_stop = min(p.active_stop, max(len(p.stops) - 1, 0))
            render.render_image(img)
        return {'FINISHED'}


class VS_OT_pathfinder(Operator):
    """選んだ形どうしを組み合わせる (パスファインダー)。実行すると形が確定します"""
    bl_idname = "vstroke.pathfinder"
    bl_label = "パスファインダー"
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=[(k, n, d) for k, n, d in pathops.MODES])

    @classmethod
    def description(cls, context, props):
        return {k: "%s: %s" % (n, d) for k, n, d in pathops.MODES}.get(props.mode, "")

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None or not render.available():
            return False
        vs = img.vstroke
        m = data.uid_map(vs)
        n = sum(1 for u in transform.selected_items(vs) if m[u].kind in {'PATH', 'SHAPE'})
        if n < 2:
            cls.poll_message_set("パスか図形を2つ以上選んでください")
            return False
        return True

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        res = pathops.apply(vs, transform.selected_items(vs), self.mode)
        if isinstance(res, str):
            self.report({'WARNING'}, res)
            return {'CANCELLED'}
        if not res:
            self.report({'INFO'}, "形が残らないため、元のオブジェクトを削除しました")
        select_only(vs, res)
        render.render_image(img)
        return {'FINISHED'}


def _selected_point_refs(vs):
    """選んでいる点の ref を、後ろから順に返す (番号がずれないように)。"""
    out = []
    for ref, pt in edit_logic.iter_points(vs):
        if pt.select and data.is_editable(vs, vs.objects[ref[0]].uid):
            out.append(ref)
    return sorted(out, reverse=True)


def split_selection(vs):
    """選んでいる点でパスを切る。切れたら True。"""
    done = False
    for ref in _selected_point_refs(vs):
        if edit_logic.split_at(vs, *ref):
            done = True
    return done


def reverse_selection(vs):
    """選んでいるパスの向きを反転する。"""
    done = False
    items = transform.selected_items(vs)
    uids = set(items) | {u for it in items for u in data.descendants(vs, it)}
    for ob in vs.objects:
        if ob.kind != 'PATH' or ob.uid not in uids:
            continue
        if not data.is_editable(vs, ob.uid):
            continue
        for sp in ob.subpaths:
            if len(sp.points) >= 2:
                edit_logic.reverse_subpath(sp)
                done = True
    return done


def point_type_selection(vs, kind):
    """選んでいる点を「角」か「滑らか」にする。"""
    done = False
    for ref in _selected_point_refs(vs):
        if edit_logic.set_point_type(vs, ref, kind):
            done = True
    return done


# -----------------------------------------------------------------------------
# ペイント用のレイヤー (Blender のブラシで描く)
# -----------------------------------------------------------------------------

def add_paint_layer(vs, img_dst, name=None, above=0):
    """キャンバスと同じ大きさの、透明な「描けるレイヤー」を作る。
    above を渡すと、そのオブジェクトのすぐ上に置く (Photoshop の新規レイヤーと同じ)。
    マスクの形のすぐ上だとマスクが入れ替わってしまうので、そのときはクリップグループの上。"""
    w, h = img_dst.size
    if w <= 0 or h <= 0:
        return None
    m = data.uid_map(vs)
    if above and above in m and m[above].kind == 'ADJUST':
        above = 0               # 調整レイヤーは中身を持たない (いつもの描き込み先へ)
    if above and above in m and data.is_clip_path(vs, above):
        above = m[above].parent_uid
    parent = 0
    if above and above in m and m[above].kind != 'LAYER':
        parent = m[above].parent_uid
        par = m.get(parent)
        if par is not None and data.is_background_layer(par):
            parent = 0          # 背景には入れない (いつもの描き込み先のレイヤーへ)
    else:
        above = 0
    # 元の画像 (背景) は数えない (最初に作るのが「ペイント 2」にならないように)
    n = sum(1 for o in vs.objects if data.is_paint_layer(o) and not data.is_original(o)) + 1
    label = name or ("ペイント %d" % data.free_number(vs, "ペイント %d", n))
    im = data.new_canvas_part(img_dst, "%s_%s" % (img_dst.name, label), w, h)
    im.generated_color = (0.0, 0.0, 0.0, 0.0)
    im.pixels.foreach_set(np.zeros(w * h * 4, np.float32))
    im.update()
    oi = data.new_object(vs, kind='IMAGE', parent_uid=parent)
    ob = vs.objects[oi]
    with render.suspended():
        ob.image = im
        ob.img_paint = True
        ob.img_origin = (0.0, 0.0)          # キャンバスにぴったり重ねる
        ob.img_mat = (1.0, 0.0, 0.0, 1.0)
        ob.name = label
        uid = ob.uid
        if parent and above:
            ch = data.children_map(vs)
            sib = ch.get(parent, [])
            if uid in sib and above in sib:
                sib.remove(uid)
                sib.insert(sib.index(above) + 1, uid)
                data.reorder(vs, data.flatten_tree(ch))
    return vs.objects[data.index_of_uid(vs, uid)]


def pack_all_paint_layers():
    """ペイントレイヤーの絵をすべて .blend に埋め込む (保存の直前に呼ぶ)。"""
    done = set()
    for img in bpy.data.images:
        try:
            if not img.vstroke.enabled:
                continue
            for ob in img.vstroke.objects:
                im = getattr(ob, "image", None)
                # ペイントレイヤーと、いま描いている置いた画像 (描いた絵が保存で消えないように)
                if (ob.kind == 'IMAGE' and im is not None
                        and (data.is_paint_layer(ob) or im.vstroke.paint_owner)
                        and im.name not in done
                        and (im.is_dirty or im.packed_file is None)):
                    pack_paint_layer(ob)
                    done.add(im.name)
                mk = ob.mask_image
                if (mk is not None and mk.name not in done
                        and (mk.is_dirty or mk.packed_file is None)):
                    pack_paint_layer(ob, mk)
                    done.add(mk.name)
        except Exception as e:
            print("[Vector Strokes] ペイントレイヤーを埋め込めません:", e)
    return done


def pack_paint_layer(ob, im=None):
    """描いた絵を .blend に埋め込む (保存しても消えないように)。
    im を渡すとその画像 (レイヤーマスクなど)。無ければ ob の画像。"""
    if im is None:
        im = getattr(ob, "image", None)
    if im is None:
        return False
    try:
        im.pack()
        return True
    except Exception as e:
        print("[Vector Strokes] 画像を埋め込めません:", e)
        return False


BACKDROP_PREFIX = "vstroke_backdrop_"


def _make_alpha_image(img_dst, alpha, tag):
    """アルファだけを持つ画像 (切り抜きの強さ)。画面でシェーダーが .a を読む。
    大きさは alpha の配列の大きさ (キャンバスとは限らない。ロックの表示はレイヤーの画像の大きさ)。"""
    h, w = alpha.shape[:2]
    name = BACKDROP_PREFIX + tag
    old = bpy.data.images.get(name)
    if old is not None and tuple(old.size) != (w, h):
        bpy.data.images.remove(old)
        old = None
    im = old or bpy.data.images.new(name, w, h, alpha=True, float_buffer=True)
    arr = np.zeros((h, w, 4), np.float32)
    arr[..., 3] = alpha
    im.pixels.foreach_set(arr.ravel())
    im.update()
    return im.name


def _make_backdrop(img_dst, uids, with_base, tag, unclip=None, unmask=None):
    """他のレイヤーを1枚の画像にまとめる (画面に重ねて見せるため)。"""
    arr = render.composite_layers(img_dst, uids, with_base=with_base, unclip=unclip,
                                  unmask=unmask)
    if arr is None:
        return ""
    w, h = img_dst.size
    name = BACKDROP_PREFIX + tag
    old = bpy.data.images.get(name)
    if old is not None and tuple(old.size) != (w, h):
        bpy.data.images.remove(old)
        old = None
    im = old or bpy.data.images.new(name, w, h, alpha=True, float_buffer=img_dst.is_float)
    im.pixels.foreach_set(np.ascontiguousarray(arr, np.float32).ravel())
    im.update()
    return im.name


def drop_backdrops():
    _drop_backdrops()


def _drop_backdrops():
    for key in ("below", "above", "content", "clip", "lock_free", "lock_keep"):
        info = state.paint or {}
        im = bpy.data.images.get(info.get(key, ""))
        if im is not None:
            try:
                bpy.data.images.remove(im)
            except Exception:
                pass


def adjust_layers_above(vs, uid):
    """uid より上にある調整レイヤー (効いているもの) の uid。下から順。"""
    ch = data.children_map(vs)
    m = data.uid_map(vs)
    tops = ch.get(0, [])
    top = render._top_of(m, uid)
    if top not in tops:
        return []
    W, H = vs.id_data.size
    return [u for u in tops[tops.index(top) + 1:]
            if render.adjust_layer_step(vs, m[u], W, H) is not None]


def begin_mask_paint(vs, img_dst, ob):
    """ob のレイヤーマスクに描く準備をする。
    画面には「下の絵 → ob の中身 (いま描いているマスクで削る) → 上の絵」を重ねて見せる。"""
    im = data.ensure_own_mask(ob)
    if im is None:
        return False
    im.vstroke.paint_owner = img_dst.name
    im.vstroke.paint_uid = ob.uid
    m = data.uid_map(vs)
    below, above = render.layer_split(vs, ob.uid)
    holders = set(data.ancestors(vs, ob.uid, m))
    adj = set(adjust_layers_above(vs, ob.uid))
    inner = {ob.uid} | set(data.descendants(vs, ob.uid))
    state.paint = {
        "canvas": img_dst.name,
        "layer": im.name,
        "uid": ob.uid,
        "mode": 'LMASK',
        "placement": 'ALIGNED',
        "offset": (0.0, 0.0),
        # 上の調整レイヤーは、下の絵と中身にもかけておく (上の絵には元から入っている)
        "below": _make_backdrop(img_dst, below | adj, True, "below"),
        "above": _make_backdrop(img_dst, above, False, "above"),
        "content": _make_backdrop(img_dst, inner | holders | adj, False, "content",
                                  unmask={ob.uid}),
        "clip": "",
        "ready": False,
    }
    from . import alpha_tools, paint_preview
    alpha_tools.drop_lock()
    paint_preview.start()
    return True


def begin_paint(vs, img_dst, ob, mask=False):
    """そのレイヤーに描くために、表示をレイヤーの画像に切り替える準備をする。
    あわせて「他のレイヤー」を2枚の画像にまとめ、画面に重ねて見せられるようにする。
    mask=True なら、ob のレイヤーマスクに描く (begin_mask_paint)。"""
    if mask:
        return begin_mask_paint(vs, img_dst, ob)
    im = getattr(ob, "image", None)
    if im is None or ob.kind != 'IMAGE':
        return False
    # 同じ画像を他のオブジェクトも使っていたら (複製した写真、0.31.8 で貼り付けたレイヤーなど)、
    # 描く前に分ける。分けないと、描いた絵がもう片方にも出る
    im = data.ensure_own_image(ob)
    # 置いた画像 (写真など) にも描ける (2026-09-26 ユーザー要望。それまではペイントレイヤーだけ)。
    # 描くのは元の画像そのもの (変形前の画素) で、変形は描き直すときにいつも通りかかる。
    # 画面に周りの絵を重ねて見せられるかは、置き方で変わる (data.paint_placement)
    w, h = img_dst.size
    placement = data.paint_placement(ob, w, h)
    im.vstroke.paint_owner = img_dst.name
    im.vstroke.paint_uid = ob.uid
    if placement == 'SOLO':
        # 拡大・回転・遠近変形している: 周りの絵とは向きが合わないので、その画像だけを見せる
        # (3D ビューには paint_preview が正しい見た目で反映する)
        state.paint = {"canvas": img_dst.name, "layer": im.name, "uid": ob.uid, "mode": 'NORMAL',
                       "placement": placement, "offset": (0.0, 0.0), "below": "", "above": "",
                       "content": "", "clip": "", "ready": False}
        from . import alpha_tools, paint_preview
        alpha_tools.begin_lock(ob)
        refresh_lock_display()
        paint_preview.start()
        return True
    below, above = render.layer_split(vs, ob.uid)
    # 上にある調整レイヤーは、下の絵にもかけておく (描いているレイヤーには画面でかける。
    # overlay._paint_adjustments。上の絵には元から入っている)
    below = below | set(adjust_layers_above(vs, ob.uid))
    # クリッピングマスクは、描いている間も効かせて見せる
    #  - 切り抜かれているレイヤー ('CLIP'): 描いている絵に、マスクのアルファを掛けて貼る
    #  - マスクそのもの ('MASK'): 切り抜かれる中身を別の1枚にして、いま描いている絵のアルファを
    #    掛けて貼る (描くたびに、見える範囲が変わる)。マスク自身の色は貼らない (完成形と同じ)
    mode, clip_name, content_name = 'NORMAL', "", ""
    group = ob.parent_uid if data.is_clip_path(vs, ob.uid) else 0
    if placement != 'ALIGNED':
        # 動かしただけの画像: 切り抜きの表示は画像と位置がずれるので見せない
        # (3D ビューには切り抜いた正しい見た目が出る)
        pass
    elif group:
        mode = 'MASK'
        holders = set(data.ancestors(vs, group))
        inner = set(data.descendants(vs, group)) - {ob.uid}
        below = below - inner
        content_name = _make_backdrop(img_dst, inner | {group} | holders, False, "content",
                                      unclip={group})
    else:
        alpha = render.clip_alpha(img_dst, vs, ob.uid)
        if alpha is not None:
            mode = 'CLIP'
            clip_name = _make_alpha_image(img_dst, alpha, "clip")
    state.paint = {
        "canvas": img_dst.name,
        "layer": im.name,
        "uid": ob.uid,
        "mode": mode,
        # 画像の左下が、キャンバスのどこにあるか (周りの絵をずらして重ねる)
        "placement": placement,
        "offset": tuple(float(v) for v in ob.img_origin) if placement == 'OFFSET' else (0.0, 0.0),
        "below": _make_backdrop(img_dst, below, True, "below"),
        "above": _make_backdrop(img_dst, above, False, "above"),
        "content": content_name,
        "clip": clip_name,
        # 筆を選び終えたか。これが False の間は、見えているツールで判断しない
        # (session._settle_painting。入った直後に追い出されるのを防ぐ)
        "ready": False,
    }
    # 透明部分をロックしているレイヤーなら、守る所を覚えて、見せ方を用意する。
    # 守る所はレイヤーの画像の画素で持つので、動かした・拡大した画像でも効く
    # (0.33.0 までは、キャンバスにぴったり重なっていないと黙ってロックをやめていた。
    #  選択ツールでペイントレイヤーが少しずれただけで効かなくなっていた。2026-09-27 ユーザー報告)
    from . import alpha_tools
    alpha_tools.begin_lock(ob)
    refresh_lock_display()
    # 3D ビューにも途中経過を見せるための控え (まだ何も描いていないうちに作る)
    from . import paint_preview
    paint_preview.start()
    return True


def refresh_lock_display():
    """描いている間に画面へ貼る「透明部分のロック」の2枚を作り直す (無ければ消す)。"""
    from . import alpha_tools
    info = state.paint
    if not info:
        return
    from . import paint_preview
    paint_preview.lock_changed()
    for key in ("lock_free", "lock_keep"):
        im = bpy.data.images.get(info.get(key, ""))
        if im is not None:
            bpy.data.images.remove(im)
        info[key] = ""
    canvas = bpy.data.images.get(info.get("canvas", ""))
    if canvas is None or not alpha_tools.lock_active():
        render.tag_redraw_all()
        return
    clip = None
    clip_im = bpy.data.images.get(info.get("clip", ""))
    if info.get("mode") == 'CLIP' and clip_im is not None:
        clip = alpha_tools.read_rgba(clip_im)
        clip = clip[..., 3] if clip is not None else None
    info["lock_free"], info["lock_keep"] = alpha_tools.lock_display_images(canvas, clip)
    render.tag_redraw_all()


def paint_target(layer_img):
    """描いている画像から (キャンバス, レイヤーのオブジェクト) を探す。"""
    name = getattr(layer_img.vstroke, "paint_owner", "")
    if not name:
        return None, None
    canvas = bpy.data.images.get(name)
    if canvas is None or not canvas.vstroke.enabled:
        return None, None
    uid = int(layer_img.vstroke.paint_uid)
    i = data.index_of_uid(canvas.vstroke, uid)
    if i < 0:
        return None, None
    return canvas, canvas.vstroke.objects[i]


def end_paint(layer_img):
    """描き終わり。キャンバスを描き直す。戻り値: キャンバス or None

    絵の埋め込み (pack) と Undo の履歴への記録は、呼ぶ側 (VS_OT_paint_end) が
    ペイントモードのうちに行う。保存の直前にも念のため埋め込む (handlers.on_save_pre)。"""
    from . import alpha_tools
    alpha_tools.enforce_lock()          # 透明部分のロック: 守る所に描いた分を戻して確定
    alpha_tools.drop_lock()
    canvas, ob = paint_target(layer_img)
    layer_img.vstroke.paint_owner = ""
    layer_img.vstroke.paint_uid = 0
    _drop_backdrops()
    state.paint = None
    from . import paint3d, paint_preview
    paint_preview.drop()
    paint3d.sync()          # 3D ビューのテクスチャペイントの描き先を元に戻す
    if canvas is None:
        return None
    render.clear_cache()
    render.render_image(canvas)
    return canvas


def switch_paint(win, area, ob, mask=False):
    """ペイントモードのまま、描く先を ob (mask=True ならそのレイヤーマスク) に取り替える。
    戻り値: できなかった理由 (できたら空文字)。

    **この順番を崩さないこと** (2026-09-26 に本物の筆で試して決めた。tests は無いので、
    変えるときは実際に描いて Undo / Redo を全段確かめる):
      1. 今の絵を埋め込み、Undo の段「描いた絵を確定」を積む
      2. 描く先を取り替える (ペイントモードのまま表示の画像を差し替える)
      3. Undo の段「レイヤーを切り替え」を積む
    埋め込まない・段を積まないと、切り替えを戻す Undo で**前のレイヤーに描いた絵が消えた**
    (Blender は筆の段を、全体の状態の段をまたいで当て直さない。「ベクターに戻る」と同じ理由)。
    Undo のあとで画面を描く先に合わせるのは session.recover_after_undo。"""
    from . import alpha_tools, paint_preview, session
    info = state.paint
    if not info:
        return "ブラシで描いていません"
    canvas = bpy.data.images.get(info.get("canvas", ""))
    cur = bpy.data.images.get(info.get("layer", ""))
    if canvas is None or cur is None:
        return "描いているキャンバスが見つかりません"
    if (mask and ob.mask_image is None) or (not mask and (ob.kind != 'IMAGE' or ob.image is None)):
        return "描けるのは画像・ペイントレイヤーと、レイヤーマスクだけです"
    if ob.uid == info.get("uid") and (info.get("mode") == 'LMASK') == mask:
        return ""                               # もう描いている
    vs = canvas.vstroke
    m = data.uid_map(vs)
    if not all(m[u].visible for u in [ob.uid] + data.ancestors(vs, ob.uid, m) if u in m):
        return "非表示のレイヤーには描けません (目のアイコンで表示してから)"
    # 1. 今の絵を確定する (透明部分のロック → キャンバスへの反映 → 埋め込み → Undo の段)
    alpha_tools.enforce_lock()
    live = paint_preview.flush()
    _, cur_ob = paint_target(cur)
    if cur_ob is not None:
        pack_paint_layer(cur_ob, cur)
    session.push_undo(win, area, "描いた絵を確定")
    alpha_tools.drop_lock()
    cur.vstroke.paint_owner = ""
    cur.vstroke.paint_uid = 0
    _drop_backdrops()
    state.paint = None
    paint_preview.drop()
    # 変わったのは描いていた画像だけ。キャンバスは筆を離すたびに反映済み
    # (反映していない設定のときだけ描き直す。全部描き直すと 2048px で 0.8 秒かかる)
    render.clear_cache(cur.name)
    if not live:
        render.render_image(canvas, redraw=False)
    # 2. 取り替える
    ob.mask_target = mask
    if ob.kind not in {'LAYER', 'ADJUST'}:
        select_only(vs, [ob.uid])
    data.set_active(vs, data.index_of_uid(vs, ob.uid))
    if not begin_paint(vs, canvas, ob, mask=mask):
        return "描き始められませんでした"
    state.paint["ready"] = True            # 筆はもう選んである (選び直しを待たない)
    new_im = bpy.data.images.get(state.paint["layer"])
    with session.applying():
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                sp = a.spaces.active if a.type == 'IMAGE_EDITOR' else None
                if sp is not None and getattr(sp, "image", None) == cur:
                    sp.image = new_im
                    a.tag_redraw()
    # 3. 切り替えを Undo の履歴に積む
    session.push_undo(win, area, "レイヤーを切り替え")
    render.tag_redraw_all()
    return ""


class VS_OT_paint_switch(Operator):
    """ブラシで描いたまま、描く先をこのレイヤー (またはそのマスク) に切り替える"""
    bl_idname = "vstroke.paint_switch"
    bl_label = "描く先を切り替え"
    # Undo の段は自分で積む (switch_paint。'UNDO' に任せると順番が崩れる)
    bl_options = {'REGISTER'}
    uid: IntProperty(options={'HIDDEN', 'SKIP_SAVE'})
    target: EnumProperty(items=(('CONTENT', "中身", ""), ('MASK', "マスク", "")),
                         default='CONTENT', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        if props.target == 'MASK':
            return "このレイヤーのマスクに描く (白で見せる・黒で隠す)"
        return "このレイヤーに描く"

    @classmethod
    def poll(cls, context):
        return bool(state.paint)

    def execute(self, context):
        canvas = bpy.data.images.get(state.paint.get("canvas", ""))
        if canvas is None:
            return {'CANCELLED'}
        vs = canvas.vstroke
        i = data.index_of_uid(vs, self.uid)
        if i < 0:
            return {'CANCELLED'}
        ob = vs.objects[i]
        why = switch_paint(context.window, context.area, ob, mask=self.target == 'MASK')
        if why:
            self.report({'WARNING'}, why)
            return {'CANCELLED'}
        self.report({'INFO'}, "「%s」%sに描いています" % (
            ob.name, "のマスク" if self.target == 'MASK' else ""))
        return {'FINISHED'}


class VS_OT_paint_layer_add(Operator):
    """ブラシで描けるレイヤーを追加する (Blender のペイント機能をそのまま使えます)"""
    bl_idname = "vstroke.paint_layer_add"
    bl_label = "ペイントレイヤーを追加"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def execute(self, context):
        img = _enabled_image(context)
        act = data.active_object(img.vstroke)
        ob = add_paint_layer(img.vstroke, img, above=act.uid if act is not None else 0)
        if ob is None:
            return {'CANCELLED'}
        select_only(img.vstroke, [ob.uid])
        data.set_active(img.vstroke, data.index_of_uid(img.vstroke, ob.uid))
        render.render_image(img)
        self.report({'INFO'}, "「%s」を追加しました。描くにはボタンを押してください"
                    % ob.name)
        return {'FINISHED'}


class VS_OT_paint_begin(Operator):
    """ブラシで描く (他のレイヤーも見えたまま描けます)"""
    bl_idname = "vstroke.paint_begin"
    bl_label = "このレイヤーに描く"
    create: BoolProperty(name="無ければ作る", default=False, options={'SKIP_SAVE'})
    new_layer: BoolProperty(name="新しいレイヤーに描く", default=False, options={'SKIP_SAVE'},
                            description="選んでいる画像には描かず、すぐ上に新しいペイントレイヤーを"
                                        "作って描く")
    target: EnumProperty(
        name="描く先", default='AUTO', options={'SKIP_SAVE'},
        items=(('AUTO', "自動", "前に描いた方 (中身かマスク) に描く"),
               ('CONTENT', "中身", "レイヤーの絵に描く"),
               ('MASK', "マスク", "レイヤーマスクに描く (白で見せる・黒で隠す)")))

    @classmethod
    def description(cls, context, props):
        if props.new_layer:
            return "選んでいる画像はそのままにして、すぐ上に新しいペイントレイヤーを作って描く"
        if props.target == 'MASK':
            return "レイヤーマスクに描く (白で見せる・黒で隠す・灰色で半透明)"
        return None

    @classmethod
    def poll(cls, context):
        # create=True のときは何も選んでいなくても押せる (ボタンごとに変わるため常に True)
        return _enabled_image(context) is not None

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        # レイヤーマスクに描く (ボタンで選んだとき、または前にマスクに描いていたとき。
        # Photoshop でマスクのサムネールを選んでいる状態と同じで、ブラシを選び直しても続く)
        if ob is not None and not self.new_layer and self.target != 'CONTENT':
            want = self.target == 'MASK' or (ob.mask_target and ob.mask_image is not None)
            if want:
                if ob.mask_image is None:
                    self.report({'WARNING'}, "レイヤーマスクがありません (先に追加してください)")
                    return {'CANCELLED'}
                ob.mask_target = True
                return self._enter(context, img, ob, mask=True)
        if ob is not None and self.target == 'CONTENT':
            ob.mask_target = False
        # 描けるのは画像 (ペイントレイヤー・元の画像・置いた写真など)。
        # 置いた画像は、以前は拡大・回転で筆の位置とずれるため描けなかったが、元の画像
        # (変形前) に描いて変形は後からかける形にした (2026-09-26 ユーザー要望)。
        # 図形などを選んでいるとき・何も選んでいないとき・new_layer のときは、新しい
        # ペイントレイヤーを作る
        can_paint = ob is not None and ob.kind == 'IMAGE' and ob.image is not None
        if self.new_layer or (self.create and not can_paint):
            ob = add_paint_layer(img.vstroke, img, above=ob.uid if ob is not None else 0)
            if ob is None:
                return {'CANCELLED'}
            select_only(img.vstroke, [ob.uid])
            data.set_active(img.vstroke, data.index_of_uid(img.vstroke, ob.uid))
            render.render_image(img)
        if ob is None or ob.kind != 'IMAGE' or ob.image is None:
            self.report({'WARNING'}, "描けるのは画像とペイントレイヤーだけです (どちらかを選んでください)")
            return {'CANCELLED'}
        return self._enter(context, img, ob, mask=False)

    def _enter(self, context, img, ob, mask):
        if not begin_paint(img.vstroke, img, ob, mask=mask):
            return {'CANCELLED'}
        sp = _space(context)
        if sp is not None:
            sp.image = ob.mask_image if mask else ob.image
            try:
                sp.ui_mode = 'PAINT'
            except Exception:
                pass
        state.clear_session()
        # ペイントモードで選ばれているのがベクターのツールだと、すぐ追い出されてしまう
        # (ツールバーから入るときと同じく、ブラシを選んでおく)
        from . import session
        session.on_paint_entered(context.window, context.area)
        session.start_guard(context.window, context.area)
        render.tag_redraw_all()
        if mask:
            self.report({'INFO'}, "「%s」のレイヤーマスクに描いています (白で見せる・黒で隠す)。"
                        "終わったら「ベクターに戻る」" % ob.name)
        elif (state.paint or {}).get("placement") == 'SOLO':
            self.report({'INFO'}, "「%s」に描いています。拡大・回転しているので、描いている間は"
                        "この画像だけが見えます (3D ビューには反映されます)" % ob.name)
        else:
            self.report({'INFO'}, "「%s」に描いています。終わったら「ベクターに戻る」"
                        % ob.name)
        return {'FINISHED'}


class VS_OT_paint_guard(Operator):
    """ブラシで描いている間、入力を最初に受け取り、ツールが変わったらその場でベクターに戻る
    (session の「見張り役」の説明を参照)。入力そのものは邪魔しない"""
    bl_idname = "vstroke.paint_guard"
    bl_label = "ペイント中の見張り"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        from . import session
        if not state.paint:
            return {'CANCELLED', 'PASS_THROUGH'}     # 描き終わった
        if not state.paint.get("ready"):
            # 筆を選び終える前のクリックは止める。止めないと、Undo の段「ペイントを始める」
            # より先に筆の段が積まれ、Undo の順番が崩れる
            if event.type in {'LEFTMOUSE', 'PEN'} and event.value == 'PRESS':
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}
        if session.is_applying():
            return {'PASS_THROUGH'}
        # 筆の1画の始まりを知らせる。3D ビューへの反映 (paint_preview) はタイマーで「筆が動いて
        # いるか」を見ているが、重い場面ではタイマーが回る前に1画が終わって見逃され、
        # 次の1画まで反映されなかった
        if event.type in {'LEFTMOUSE', 'PEN'} and event.value == 'PRESS':
            from . import paint_preview
            paint_preview.note_press()
        leave, tid = session.paint_should_leave()
        if leave:
            session.leave_paint(tid)                  # その場で戻る (以後の入力はベクター編集へ)
            return {'FINISHED', 'PASS_THROUGH'}
        return {'PASS_THROUGH'}


class VS_OT_paint_end(Operator):
    """ベクター編集に戻る (描いた絵がレイヤーとして合成されます)"""
    bl_idname = "vstroke.paint_end"
    bl_label = "ベクターに戻る"
    # Undo の履歴に積むか (ツールバーから戻るときは、ツールを選び終えてから session が積む)
    push: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        sp = _space(context)
        im = getattr(sp, "image", None) if sp is not None else None
        return im is not None and bool(im.vstroke.paint_owner)

    def execute(self, context):
        sp = _space(context)
        # 戻る前に、描いた絵を確定して Undo の履歴に積む (まだペイントモードのうちに)。
        # Blender は筆の1画を「ペイントモードの中で」しか戻せない。戻ったあとに Undo すると
        # 筆の段は当て直されず、ペイントを始めた時の白紙まで戻ってしまう (実測で確認)。
        # 絵を埋め込んだ段を積んでおけば、戻ったあとの Undo でも絵は残る
        _, ob = paint_target(sp.image)
        from . import alpha_tools
        alpha_tools.enforce_lock()      # 埋め込む前に、ロックで守る所を元に戻す
        if ob is not None:
            pack_paint_layer(ob, sp.image)
            from . import session
            session.push_undo(context.window, context.area, "描いた絵を確定")
        canvas = end_paint(sp.image)
        if canvas is None:
            self.report({'WARNING'}, "戻り先のキャンバスが見つかりません")
            return {'CANCELLED'}
        sp.image = canvas
        try:
            sp.ui_mode = 'VIEW'
        except Exception:
            pass
        # 表示モード側のツールがブラシのままだと、すぐペイントに引き戻される
        # (ツールバーから戻るときの _leave_paint と同じ理由)
        from . import session, tools
        if session.active_tool_id(context, 'VIEW') == tools.TOOL_IDS['BRUSH']:
            session.set_tool(context.window, context.area, tools.TOOL_IDS['SELECT'])
        if self.push:
            # 「ベクターに戻る」を Undo の履歴に積む (積まないと、あとの Undo が
            # 戻り方を知らずに画面の表示と食い違う)
            session.push_undo(context.window, context.area, "ベクターに戻る")
            # クリックしなくても V / P などが効くように、ベクター編集をすぐ始める
            # (ツールバーから戻るときは session.leave_paint が同じことをする)
            session.start_editing(context.window, context.area, tools.TOOL_NAMES.get(
                session.active_tool_id(context, 'VIEW')))
        render.tag_redraw_all()
        return {'FINISHED'}


class VS_OT_path_split(Operator):
    """選んでいる点でパスを切る (閉じた形は開き、開いたパスは2本に分かれます)"""
    bl_idname = "vstroke.path_split"
    bl_label = "点で切る"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(_selected_point_refs(img.vstroke))

    def execute(self, context):
        img = _enabled_image(context)
        if not split_selection(img.vstroke):
            self.report({'WARNING'}, "端の点では切れません")
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_path_reverse(Operator):
    """パスの向き (始点と終点) を入れ替える"""
    bl_idname = "vstroke.path_reverse"
    bl_label = "向きを反転"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(transform.selected_items(img.vstroke))

    def execute(self, context):
        img = _enabled_image(context)
        if not reverse_selection(img.vstroke):
            self.report({'WARNING'}, "向きを変えられるパスを選んでください")
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_point_type(Operator):
    """選んでいる点を「角」か「滑らか」にする"""
    bl_idname = "vstroke.point_type"
    bl_label = "点の種類"
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(name="種類", items=(
        ('SMOOTH', "滑らかにする", "左右対称のハンドルを付ける"),
        ('CORNER', "角にする", "ハンドルを外して尖らせる")), default='SMOOTH')

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(_selected_point_refs(img.vstroke))

    def execute(self, context):
        img = _enabled_image(context)
        if not point_type_selection(img.vstroke, self.kind):
            self.report({'WARNING'}, "点を選んでください")
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_copy(Operator):
    """選択したものをコピーする"""
    bl_description = keys.fmt("選択したものをコピーする ({C}C)")
    bl_idname = "vstroke.copy"
    bl_label = "コピー"
    cut: BoolProperty(name="切り取り", default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and bool(transform.selected_items(img.vstroke))

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        items = transform.selected_items(vs)
        data.copy_objects(vs, items)
        if self.cut:
            data.remove_objects(vs, items)
            render.render_image(img)
        return {'FINISHED'}


class VS_OT_paste(Operator):
    """コピーしたものを、元と同じ場所に貼り付ける"""
    bl_description = keys.fmt("コピーしたものを、元と同じ場所に貼り付ける ({C}V)")
    bl_idname = "vstroke.paste"
    bl_label = "貼り付け"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if _enabled_image(context) is None:
            return False
        if not state.clipboard:
            cls.poll_message_set(keys.fmt("先にコピー ({C}C) してください"))
            return False
        return True

    def execute(self, context):
        img = _enabled_image(context)
        vs = img.vstroke
        made = data.paste_objects(vs, isolation(img.name, vs))
        if not made:
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_list_select(Operator):
    """押すたびに選択に追加・解除する (Shift: そこまでまとめて選ぶ)"""
    bl_idname = "vstroke.list_select"
    bl_label = "選ぶ"
    # 選ぶだけなので Undo の段にしない (キャンバスで選んだときと同じ。Illustrator も同じ)
    bl_options = {'REGISTER'}
    image: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    index: IntProperty(default=-1, options={'HIDDEN', 'SKIP_SAVE'})
    extend: BoolProperty(name="追加・解除", default=True, options={'SKIP_SAVE'})
    rng: BoolProperty(name="まとめて選ぶ", default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        # 丸は押すたびに追加・解除 (Shift を押さなくても複数選べる)
        self.extend = True
        self.rng = bool(event.shift)
        return self.execute(context)

    def execute(self, context):
        from . import ui
        img = bpy.data.images.get(self.image) if self.image else _enabled_image(context)
        if img is None or not img.vstroke.enabled:
            return {'CANCELLED'}
        vs = img.vstroke
        if not (0 <= self.index < len(vs.objects)):
            return {'CANCELLED'}
        ob = vs.objects[self.index]
        if ob.kind in {'LAYER', 'ADJUST'} or not data.is_editable(vs, ob.uid):
            return {'CANCELLED'}
        uid = ob.uid
        if self.rng:
            keep = {o.uid for o in vs.objects if o.select}
            keep.update(self._between(vs, uid))
            uids = [o.uid for o in vs.objects if o.uid in keep]
        elif self.extend:
            keep = {o.uid for o in vs.objects if o.select}
            keep.symmetric_difference_update({uid})
            uids = [o.uid for o in vs.objects if o.uid in keep]
        else:
            uids = [uid]
        select_only(vs, uids)
        data.set_active(vs, data.index_of_uid(vs, uid))
        render.tag_redraw_all()
        return {'FINISHED'}

    @staticmethod
    def _between(vs, uid):
        """今アクティブな行から、押した行までの間にあるもの (一覧の並びで数える)。"""
        from . import ui
        order = ui.display_order(vs)
        act = data.active_object(vs)
        if act is None or act.uid not in order or uid not in order:
            return [uid]
        a, b = sorted((order.index(act.uid), order.index(uid)))
        m = data.uid_map(vs)
        return [u for u in order[a:b + 1]
                if m[u].kind not in {'LAYER', 'ADJUST'} and data.is_editable(vs, u, m)]


class VS_OT_shape_to_path(Operator):
    """図形を普通のパスに変換する (点を自由に動かせるが、数値での変更はできなくなる)"""
    bl_idname = "vstroke.shape_to_path"
    bl_label = "パスに変換"
    bl_options = {'REGISTER', 'UNDO'}
    image: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    uid: IntProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def _target(self, context):
        img = bpy.data.images.get(self.image) if self.image else _enabled_image(context)
        if img is None or not img.vstroke.enabled:
            return None, None
        vs = img.vstroke
        i = data.index_of_uid(vs, self.uid) if self.uid else vs.active_index
        if 0 <= i < len(vs.objects) and vs.objects[i].kind == 'SHAPE':
            return img, vs.objects[i]
        return img, None

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        img, ob = self._target(context)
        if ob is None:
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(
            self, event, title="パスに変換しますか？",
            message="「%s」を普通のパスに変換すると、点を動かせるようになりますが、"
                    "角の半径や頂点の数などを数値で変更することはできなくなります。" % ob.name,
            confirm_text="変換する")

    def execute(self, context):
        img, ob = self._target(context)
        if ob is None:
            return {'CANCELLED'}
        transform.shape_to_path(ob)
        render.render_image(img)
        return {'FINISHED'}


def _shape_type(context):
    return context.window_manager.vstroke_tool.shape_type


class VS_OT_shape_size(Operator):
    """図形の大きさを数値で決めて作る (図形ツールでクリックしたときに出る)"""
    bl_idname = "vstroke.shape_size"
    bl_label = "図形の大きさ"
    bl_options = {'REGISTER', 'UNDO'}
    image: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    x: FloatProperty(options={'HIDDEN', 'SKIP_SAVE'})
    y: FloatProperty(options={'HIDDEN', 'SKIP_SAVE'})
    # 幅・高さ・半径は覚えておく (次にクリックしたとき同じ値が入る = Illustrator と同じ)
    width: FloatProperty(name="幅", default=100.0, min=0.1, soft_max=2000.0, subtype='PIXEL')
    height: FloatProperty(name="高さ", default=100.0, min=0.1, soft_max=2000.0, subtype='PIXEL')
    radius: FloatProperty(name="半径", default=50.0, min=0.1, soft_max=1000.0, subtype='PIXEL')
    corner_radius: FloatProperty(name="角の丸み", default=0.0, min=0.0, soft_max=500.0,
                                 subtype='PIXEL', options={'SKIP_SAVE'})
    sides: IntProperty(name="辺の数", default=6, min=3, max=64, options={'SKIP_SAVE'})
    star_points: IntProperty(name="点の数", default=5, min=3, max=64, options={'SKIP_SAVE'})
    inner_ratio: FloatProperty(name="内側の比率", default=0.5, min=0.01, max=1.0,
                               options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        ts = context.window_manager.vstroke_tool
        self.sides = ts.sides
        self.star_points = ts.star_points
        self.inner_ratio = ts.inner_ratio
        self.corner_radius = ts.corner_radius
        return context.window_manager.invoke_props_dialog(
            self, width=250, title="図形の大きさ", confirm_text="作る")

    def draw(self, context):
        t = _shape_type(context)
        col = self.layout.column(align=True)
        if t in {'POLYGON', 'STAR'}:
            col.prop(self, "radius")
            if t == 'POLYGON':
                col.prop(self, "sides")
            else:
                col.prop(self, "star_points")
                col.prop(self, "inner_ratio")
            self.layout.label(text="クリックした所が中心になります", icon='INFO')
        else:
            col.prop(self, "width")
            col.prop(self, "height")
            if t == 'ROUNDED_RECT':
                col.prop(self, "corner_radius")
            self.layout.label(text="クリックした所が左上の角になります", icon='INFO')

    def execute(self, context):
        from . import shape_tool
        img = bpy.data.images.get(self.image) if self.image else _enabled_image(context)
        if img is None or not img.vstroke.enabled:
            return {'CANCELLED'}
        vs = img.vstroke
        ts = context.window_manager.vstroke_tool
        t = ts.shape_type
        iso = isolation(img.name, vs)
        target = iso or data.current_layer(vs)
        if target and not data.is_editable(vs, target):
            self.report({'WARNING'}, "描き込み先のレイヤー (またはグループ) がロック中か非表示です")
            return {'CANCELLED'}
        with render.suspended():
            # 小窓で触った値だけツール設定に書き戻す (上のバーの表示と合わせる)
            given = self.properties.is_property_set
            if t == 'POLYGON' and given("sides"):
                ts.sides = self.sides
            elif t == 'STAR':
                if given("star_points"):
                    ts.star_points = self.star_points
                if given("inner_ratio"):
                    ts.inner_ratio = self.inner_ratio
            elif t == 'ROUNDED_RECT' and given("corner_radius"):
                ts.corner_radius = self.corner_radius
            ob = shape_tool.new_shape(vs, ts, parent_uid=iso)
            if shape_tool.from_center(ob.shape_type):
                ob.center = (self.x, self.y)
                ob.size = (self.radius * 2.0, self.radius * 2.0)
            else:
                w, h = max(float(self.width), 0.1), max(float(self.height), 0.1)
                ob.center = (self.x + w / 2.0, self.y - h / 2.0)
                ob.size = (w, h)
        select_only(vs, [ob.uid])
        data.set_active(vs, data.index_of_uid(vs, ob.uid))
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_text_line_add(Operator):
    """文字に行を追加する"""
    bl_idname = "vstroke.text_line_add"
    bl_label = "行を追加"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind == 'TEXT'

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        ob.text_lines.add()
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_text_line_remove(Operator):
    """その行を削除する"""
    bl_idname = "vstroke.text_line_remove"
    bl_label = "行を削除"
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind == 'TEXT'

    def execute(self, context):
        img = _enabled_image(context)
        ob = _active_ob(context)
        if len(ob.text_lines) <= 1:
            ob.text_lines[0].text = ""
        elif 0 <= self.index < len(ob.text_lines):
            ob.text_lines.remove(self.index)
        render.render_image(img)
        return {'FINISHED'}


def outline_text(vs, uid):
    """文字をパスに変える (アウトライン化)。戻り値: できたグループの uid (0 なら失敗)"""
    from . import text as text_mod
    i = data.index_of_uid(vs, uid)
    if i < 0 or vs.objects[i].kind != 'TEXT':
        return 0
    ob = vs.objects[i]
    chars = text_mod.char_subpaths(ob)
    if not chars:
        return 0
    parent = ob.parent_uid
    name = ob.name
    ch = data.children_map(vs)
    sib = ch.get(parent, [])
    pos = sib.index(uid) if uid in sib else len(sib)
    # スタイルは先に値でコピーしておく (オブジェクトを増やすと参照がずれるため)
    paints = [{k: (tuple(getattr(p, k)) if k in ("color", "g_start", "g_end")
                   else getattr(p, k)) for k in
               ("kind", "enabled", "paint_type", "color", "g_start", "g_end", "width",
                "cap", "join", "miter_limit", "align", "dash_enable", "dash_offset")}
              for p in ob.paints]
    stops = [[(st.position, tuple(st.color)) for st in p.stops] for p in ob.paints]
    dashes = [tuple(p.dash) for p in ob.paints]
    fx = {k: (tuple(getattr(ob, k)) if k.endswith(("color", "offset")) else getattr(ob, k))
          for k in data.FX_PROPS}
    opacity, blend = ob.opacity, ob.blend_mode
    new_uids = []
    with render.suspended():
        for c, subs in chars:
            oi = data.new_object(vs, kind='PATH', parent_uid=parent)
            nb = vs.objects[oi]
            nb.name = c if c.strip() else "文字"
            nb.fill_rule = 'NONZERO'
            nb.paints.clear()
            for pd, sd, dash in zip(paints, stops, dashes):
                np_ = nb.paints.add()
                for k, v in pd.items():
                    setattr(np_, k, v)
                np_.dash = dash
                np_.stops.clear()
                for position, color in sd:
                    st = np_.stops.add()
                    st.position, st.color = position, color
            transform.write_subpaths(nb, subs)
            new_uids.append(nb.uid)
    data.remove_objects(vs, [uid])
    g = data.group(vs, new_uids, name="%s のアウトライン" % name)
    if g:
        gi = data.index_of_uid(vs, g)
        with render.suspended():
            for k, v in fx.items():
                setattr(vs.objects[gi], k, v)
            vs.objects[gi].opacity = opacity
            vs.objects[gi].blend_mode = blend
        ch = data.children_map(vs)
        sib = ch.get(parent, [])
        if g in sib:
            sib.remove(g)
            sib.insert(min(pos, len(sib)), g)
            data.reorder(vs, data.flatten_tree(ch))
    return g


def _text_targets(vs, kinds):
    """選択中 (無ければアクティブ) の、その種類のオブジェクトの uid。"""
    m = data.uid_map(vs)
    items = [u for u in transform.selected_items(vs) if u in m and m[u].kind in kinds]
    if items:
        return items
    ob = data.active_object(vs)
    return [ob.uid] if ob is not None and ob.kind in kinds else []


def outline_selection(vs):
    """選択中の文字をアウトライン化する。戻り値: できたグループの uid のリスト"""
    made = []
    for u in _text_targets(vs, {'TEXT'}):
        g = outline_text(vs, u)
        if g:
            made.append(g)
    if made:
        select_only(vs, made)
    return made


def container_selection(vs, mode='AUTO'):
    """選択中のパス・図形を文字の入れ物にする。戻り値: 変換した uid のリスト"""
    done = []
    for u in _text_targets(vs, {'PATH', 'SHAPE'}):
        i = data.index_of_uid(vs, u)
        if i < 0:
            continue
        closed = None if mode == 'AUTO' else (mode == 'AREA')
        if data.make_text_container(vs, vs.objects[i], closed) is not None:
            done.append(u)
    if done:
        select_only(vs, done)
        data.set_active(vs, data.index_of_uid(vs, done[-1]))
    return done


class VS_OT_text_outline(Operator):
    """選んでいる文字を、編集できるパスに変換する (元の文字には戻せません)"""
    bl_idname = "vstroke.text_outline"
    bl_label = "アウトライン化"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        if img is None:
            return False
        vs = img.vstroke
        m = data.uid_map(vs)
        items = transform.selected_items(vs)
        if any(m[u].kind == 'TEXT' for u in items if u in m):
            return True
        ob = _active_ob(context)
        return ob is not None and ob.kind == 'TEXT'

    def execute(self, context):
        img = _enabled_image(context)
        if not outline_selection(img.vstroke):
            self.report({'WARNING'}, "アウトライン化できる文字がありません")
            return {'CANCELLED'}
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_text_container(Operator):
    """選んでいるパス・図形を、文字の入れ物にする"""
    bl_idname = "vstroke.text_container"
    bl_label = "文字の入れ物にする"
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=(('AUTO', "自動", "閉じた形なら中に流し込み、開いたパスなら線に沿わせる"),
                              ('AREA', "枠に流し込む", "形の中に文字を流し込む"),
                              ('PATH', "パスに沿わせる", "形の線に沿って文字を並べる")),
                       default='AUTO')

    @classmethod
    def description(cls, context, props):
        return {'AREA': "形の中に文字を流し込む (エリア文字)",
                'PATH': "形の線に沿って文字を並べる (パス上文字)"}.get(props.mode,
                                                                      "文字の入れ物にする")

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind in {'PATH', 'SHAPE'}

    def execute(self, context):
        img = _enabled_image(context)
        if not container_selection(img.vstroke, self.mode):
            self.report({'WARNING'}, "入れ物にできる形を選んでください")
            return {'CANCELLED'}
        render.render_image(img)
        self.report({'INFO'}, "サイドバーの「文字」欄に入力してください")
        return {'FINISHED'}


def place_image(vs, img_dst, image, index=0, scale_to_fit=True):
    """読み込んだ画像を、キャンバスの中に置く。戻り値: できたオブジェクト"""
    w, h = img_dst.size
    iw, ih = image.size
    if iw <= 0 or ih <= 0:
        return None
    oi = data.new_object(vs, kind='IMAGE')
    ob = vs.objects[oi]
    with render.suspended():
        ob.image = image
        ob.name = image.name
        k = 1.0
        if scale_to_fit and (iw > w * 0.9 or ih > h * 0.9):
            k = min(w * 0.9 / iw, h * 0.9 / ih)
        ob.img_mat = (k, 0.0, 0.0, k)
        # 何枚も読み込んだときは少しずつずらす (重ならないように)
        shift = 24.0 * index
        ob.img_origin = ((w - iw * k) / 2 + shift, (h - ih * k) / 2 - shift)
    return ob


class VS_OT_image_distort_reset(Operator):
    """遠近変形をやめて、ふつうの (四角い) 画像に戻す"""
    bl_idname = "vstroke.image_distort_reset"
    bl_label = "遠近変形を解除"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        ob = data.active_object(img.vstroke) if img is not None else None
        return ob is not None and ob.kind == 'IMAGE' and ob.img_quad_on

    def execute(self, context):
        img = _enabled_image(context)
        ob = data.active_object(img.vstroke)
        ob.img_quad_on = False
        render.render_image(img)
        return {'FINISHED'}


class VS_OT_svg_import(Operator):
    """SVG を、編集できる形 (パス・グループ・画像) で読み込む。
    SVG の左上をキャンバスの左上に合わせ、1 SVG 単位 = 1 ピクセルで置きます"""
    bl_idname = "vstroke.svg_import"
    bl_label = "SVG を読み込む"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.svg", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        from . import svg_import
        img = _enabled_image(context)
        vs = img.vstroke
        top, info = svg_import.import_svg(vs, img, self.filepath,
                                          parent_uid=isolation(img.name, vs))
        if top is None:
            self.report({'ERROR'}, info)
            return {'CANCELLED'}
        select_only(vs, [top])
        render.render_image(img)
        if info:
            self.report({'WARNING'}, "読み込めなかったもの: " + "、".join(
                "%s %d 個" % (k, v) for k, v in info.items()))
        else:
            self.report({'INFO'}, "SVG を読み込みました")
        return {'FINISHED'}


def import_files(vs, img, paths, embed=True, fit=True, parent_uid=0):
    """画像と SVG をまとめて読み込む (拡張子で分ける。2026-09-22 ユーザー要望で1つのボタンに)。
    画像はキャンバスの中に置き、SVG は編集できる形 (パス・グループ) で読む。
    戻り値: (作ったものの uid, 読めなかったファイル名, SVG で読まなかったもの {名前: 数})"""
    from . import svg_import
    made, failed, skipped = [], [], {}
    n_images = 0
    for path in paths:
        name = os.path.basename(path)
        if path.lower().endswith(".svg"):
            top, info = svg_import.import_svg(vs, img, path, parent_uid=parent_uid)
            if top is None:
                print("[Vector Strokes] SVG を読み込めません:", path, info)
                failed.append(name)
                continue
            made.append(top)
            for k, v in info.items():
                skipped[k] = skipped.get(k, 0) + v
            continue
        try:
            src = bpy.data.images.load(path, check_existing=True)
            if src.size[0] <= 0 or src.size[1] <= 0:
                raise RuntimeError("読み込めません")
            if embed and src.packed_file is None:
                try:
                    src.pack()
                except Exception as e:
                    print("[Vector Strokes] 埋め込めません:", path, e)
            ob = place_image(vs, img, src, n_images, fit)
            if ob is not None:
                n_images += 1
                made.append(ob.uid)
        except Exception as e:
            print("[Vector Strokes] 画像を読み込めません:", path, e)
            failed.append(name)
    return made, failed, skipped


class VS_OT_image_add(Operator):
    """画像や SVG を読み込んで、今のレイヤーに置く (複数選べます)。
    SVG は、編集できる形 (パス・グループ) で読み込みます"""
    bl_idname = "vstroke.image_add"
    bl_label = "画像・SVG を読み込む"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')
    directory: StringProperty(subtype='DIR_PATH')
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement,
                                        options={'HIDDEN', 'SKIP_SAVE'})
    filter_image: BoolProperty(default=True, options={'HIDDEN'})
    filter_folder: BoolProperty(default=True, options={'HIDDEN'})
    # 画像のほかに SVG も一覧に出す (Blender は SVG を画像として扱わないため)
    filter_glob: StringProperty(default="*.svg", options={'HIDDEN'})
    embed: BoolProperty(
        name="ファイルに埋め込む", default=True,
        description="画像を .blend の中に取り込む (元のファイルを動かしても消えません)")
    fit: BoolProperty(
        name="大きければ縮める", default=True,
        description="キャンバスより大きい画像を、収まる大きさにして置く")

    @classmethod
    def poll(cls, context):
        return _enabled_image(context) is not None

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        self.layout.prop(self, "embed")
        self.layout.prop(self, "fit")

    def _paths(self):
        if self.files and self.directory:
            out = [os.path.join(self.directory, f.name) for f in self.files if f.name]
            if out:
                return out
        return [self.filepath] if self.filepath else []

    def execute(self, context):
        img = _enabled_image(context)
        if img is None:
            return {'CANCELLED'}
        vs = img.vstroke
        made, failed, skipped = import_files(vs, img, self._paths(), self.embed, self.fit,
                                             isolation(img.name, vs))
        if not made:
            self.report({'ERROR'}, "読み込めませんでした")
            return {'CANCELLED'}
        select_only(vs, made)
        data.set_active(vs, data.index_of_uid(vs, made[-1]))
        render.clear_cache()
        render.render_image(img)
        notes = []
        if failed:
            notes.append("読み込めなかったファイル: %s" % ", ".join(failed))
        if skipped:
            notes.append("SVG で読み込めなかったもの: " + "、".join(
                "%s %d 個" % (k, v) for k, v in skipped.items()))
        if notes:
            self.report({'WARNING'}, " / ".join(notes))
        else:
            self.report({'INFO'}, "%d 個を読み込みました" % len(made))
        return {'FINISHED'}


class VS_OT_image_pack(Operator):
    """この画像を .blend の中に取り込む (元のファイルが無くなっても大丈夫にする)"""
    bl_idname = "vstroke.image_pack"
    bl_label = "ファイルに埋め込む"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return (ob is not None and ob.kind == 'IMAGE' and ob.image is not None
                and ob.image.packed_file is None)

    def execute(self, context):
        ob = _active_ob(context)
        try:
            ob.image.pack()
        except Exception as e:
            self.report({'ERROR'}, "埋め込めません: %s" % e)
            return {'CANCELLED'}
        return {'FINISHED'}


class VS_OT_corner_type(Operator):
    """選んでいる角の形を変える (点を選んでいなければ全部の角)"""
    bl_idname = "vstroke.corner_type"
    bl_label = "角の形"
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=data.CORNER_TYPES, default='ROUND')

    @classmethod
    def description(cls, context, props):
        return {'ROUND': "角を丸くする", 'BEVEL': "角を直線で切り落とす",
                'INVERTED': "角を内側にえぐる"}.get(props.kind, "")

    @classmethod
    def poll(cls, context):
        ob = _active_ob(context)
        return ob is not None and ob.kind == 'PATH'

    def execute(self, context):
        from . import corners
        img = _enabled_image(context)
        vs = img.vstroke
        refs = data._corner_refs(vs)
        if not refs:
            self.report({'WARNING'}, "丸められる角がありません")
            return {'CANCELLED'}
        with render.suspended():
            corners.set_type(vs, refs, self.kind)
            if corners.common_radius(vs, refs) <= 0.0:
                corners.set_radius(vs, refs, 20.0)   # 0 のままでは見た目が変わらないので
        render.render_image(img)
        return {'FINISHED'}


def _desktop_dir():
    """デスクトップの場所。Windows は OneDrive などに移っていて ~/Desktop が無いことが
    あるので、OS に本当の場所を聞く (2026-09-25 Windows で ~/Desktop が無く確認)。"""
    if sys.platform == "win32":
        try:
            import ctypes
            import uuid
            from ctypes import wintypes
            guid = ctypes.create_string_buffer(
                uuid.UUID("B4BFCC3A-DB2C-424C-B029-7FE99A87C641").bytes_le, 16)  # FOLDERID_Desktop
            fn = ctypes.windll.shell32.SHGetKnownFolderPath
            fn.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.HANDLE,
                           ctypes.POINTER(ctypes.c_wchar_p)]
            out = ctypes.c_wchar_p()
            if fn(guid, 0, None, ctypes.byref(out)) == 0:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                if path:
                    return path
        except Exception:
            pass
    return os.path.expanduser("~/Desktop")


def _export_dir():
    """書き出しの初期フォルダ (.blend の隣 > デスクトップ > ホーム。存在するものだけ)。"""
    for d in (bpy.path.abspath("//"), _desktop_dir()):
        if d and os.path.isdir(d):
            return d
    return os.path.expanduser("~")


class VS_OT_export(Operator):
    """ベクターデータを SVG / PDF で書き出す"""
    bl_idname = "vstroke.export"
    bl_label = "書き出し"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.svg;*.pdf", options={'HIDDEN'})
    fmt: EnumProperty(name="形式", items=export.FORMATS, default='SVG')
    include_base: BoolProperty(
        name="元の画像も含める", default=True,
        description="有効化したときの元の画像 (いちばん下のレイヤー) も一緒に書き出す "
                    "(画像として埋め込みます)")
    outline_text: BoolProperty(
        name="文字をアウトライン化", default=True,
        description="文字を形 (パス) にして書き出す。外すと文字のまま書き出すが、"
                    "開いた先に同じフォントが無いと見た目が変わる (PDF は常にアウトライン)")
    selection_only: BoolProperty(
        name="選んだものだけ", default=False,
        description="選択しているオブジェクトだけを書き出す")

    @classmethod
    def poll(cls, context):
        img = _enabled_image(context)
        return img is not None and export.available()

    def invoke(self, context, event):
        img = _enabled_image(context)
        name = bpy.path.clean_name(img.name) if img is not None else "vector"
        ext = ".pdf" if self.fmt == 'PDF' else ".svg"
        if not self.filepath or not self.filepath.endswith(ext):
            self.filepath = os.path.join(_export_dir(), name + ext)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "fmt", expand=True)
        layout.prop(self, "include_base")
        col = layout.column()
        col.enabled = self.fmt == 'SVG'
        col.prop(self, "outline_text")
        layout.prop(self, "selection_only")
        if self.fmt == 'PDF':
            layout.label(text="PDF の文字は常にアウトラインになります", icon='INFO')

    def execute(self, context):
        img = _enabled_image(context)
        if img is None:
            return {'CANCELLED'}
        path = self.filepath
        ext = ".pdf" if self.fmt == 'PDF' else ".svg"
        if not path.lower().endswith(ext):
            path = os.path.splitext(path)[0] + ext
        try:
            msg = export.export_file(img, path, self.fmt, self.include_base,
                                     self.outline_text, self.selection_only)
        except Exception as e:
            msg = str(e)
        if msg:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}
        self.report({'INFO'}, "書き出しました: %s" % os.path.basename(path))
        return {'FINISHED'}


class VS_OT_font_refresh(Operator):
    """フォントを入れ直したときに、書体の一覧を作り直す"""
    bl_idname = "vstroke.font_refresh"
    bl_label = "フォント一覧を更新"

    def execute(self, context):
        from . import fonts, text as text_mod
        fonts.clear_cache()
        fonts.scan(force=True)
        text_mod.clear_cache()
        ob = _active_ob(context)
        data.refresh_font_lists(fonts.resolve_family(ob.font_family)
                                if ob is not None and ob.kind == 'TEXT' else None,
                                force=True)
        img = _enabled_image(context)
        if img is not None:
            render.render_image(img)
        self.report({'INFO'}, "書体 %d 種類が見つかりました" % len(fonts.families()))
        return {'FINISHED'}


classes = (
    VS_OT_image_add,
    VS_OT_image_pack,
    VS_OT_corner_type,
    VS_OT_export,
    VS_OT_text_outline,
    VS_OT_text_container,
    VS_OT_text_line_add,
    VS_OT_text_line_remove,
    VS_OT_font_refresh,
    VS_OT_paint_add,
    VS_OT_paint_remove,
    VS_OT_paint_move,
    VS_OT_paint_set,
    VS_OT_fx_set,
    VS_OT_hint,
    VS_OT_edit_exit,
    VS_OT_crop_edit,
    VS_OT_crop_reset,
    VS_OT_gradient_canvas,
    VS_OT_stop_add,
    VS_OT_stop_remove,
    VS_OT_pathfinder,
    VS_OT_layer_add,
    VS_OT_adjust_add,
    VS_OT_mask_add,
    VS_OT_mask_remove,
    VS_OT_clip_make,
    VS_OT_clip_release,
    VS_OT_select_similar,
    VS_OT_image_adjust_reset,
    VS_OT_svg_import,
    VS_OT_image_distort_reset,
    VS_OT_arrange,
    VS_OT_move_to_layer,
    VS_OT_group,
    VS_OT_ungroup,
    VS_OT_align,
    VS_OT_paint_layer_add,
    VS_OT_paint_begin,
    VS_OT_paint_guard,
    VS_OT_paint_switch,
    VS_OT_paint_end,
    VS_OT_path_split,
    VS_OT_path_reverse,
    VS_OT_point_type,
    VS_OT_copy,
    VS_OT_paste,
    VS_OT_list_select,
    VS_OT_shape_to_path,
    VS_OT_shape_size,
    VS_OT_enable,
    VS_OT_show_canvas,
    VS_OT_apply,
    VS_OT_refresh,
    VS_OT_path_add,
    VS_OT_deselect,
    VS_OT_path_remove,
    VS_OT_path_move,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)

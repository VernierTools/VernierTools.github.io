# SPDX-License-Identifier: GPL-3.0-or-later
"""
Vector Strokes for Image Editor

イメージエディター上で、後から編集できるベクター図形を描き、
元画像を壊さずに(元の画像をいちばん下のレイヤーにして)画像へ描き込むアドオン。
描画には Skia (skia-python) を使う。

モジュール:
    state       実行時の共有状態・設定値
    data        保存されるデータと旧バージョンからの移行
    geometry    ベジェ計算・図形の生成・行列・座標変換・当たり判定
    transform   変形 (移動・拡大縮小・回転)・整列・図形→パス変換
    render      Skia での合成と画像への書き込み
    tool_base   編集ツール共通の土台 (Host / Tool)
    select_tool 選択ツール (オブジェクト単位)
    edit_logic  ペンツール (点単位。テスト可能)
    shape_tool  図形ツール
    pencil_tool 鉛筆ツール (手描きを曲線に)
    fit         手描きの点の並びをベジェ曲線にあてはめる
    icons       このアドオン用のアイコン
    fonts       パソコンのフォント探し
    text        文字の組み方と字形の取り出し
    text_tool   文字ツール
    export      SVG / PDF 書き出し
    svg_import  SVG の読み込み (編集できる形で)
    edit_tool   編集モードのモーダルオペレーター (ツールの切り替え)
    session     ツールとモードの切り替えの司令塔 (msgbus の合図を1か所で受ける)
    tools       左ツールバーのツール
    overlay     編集中の点・ハンドルの表示
    uv_overlay  ベクター編集中のキャンバスに UV の線を重ねる
    alpha_tools しきい値で消す・透明部分のロック (ユーザーのアドオン2つを統合)
    operators   サイドバーのボタン
    ui          サイドバーとアドオン設定
    handlers    Undo / 読み込み時の再描画
    paint_preview ペイント中の絵を、筆を離すたびにキャンバスへ反映 (3D ビューで見るため)
    ramp_sync   グラデーションの分岐点を、サイドバーのカラーランプで編集する
    paint3d     ペイント中は、3D ビューのテクスチャペイントもそのレイヤーに描く
    keys        Mac / Windows のキーの違い
    empty_hint  画像が無いのに描こうとしたら、キャンバスの上に知らせを出す
"""

from . import (alpha_tools, data, edit_tool, empty_hint, handlers, icons, operators, overlay,
               paint3d, paint_preview, ramp_sync, session, tools, ui, uv_overlay)

_modules = (icons, data, operators, alpha_tools, edit_tool, ui, tools, overlay, uv_overlay,
            session, handlers, paint_preview, ramp_sync, paint3d, empty_hint)


def register():
    for m in _modules:
        m.register()


def unregister():
    for m in reversed(_modules):
        m.unregister()

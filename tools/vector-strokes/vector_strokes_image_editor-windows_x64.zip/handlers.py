# SPDX-License-Identifier: GPL-3.0-or-later
"""Undo / やり直し / ファイル読み込み時に、画像を描き直す。"""

import bpy
from bpy.app.handlers import persistent

from . import data, render, state


@persistent
def on_undo_redo(*args):
    from . import alpha_tools, ramp_sync, session
    if ramp_sync.internal_undo():
        return      # カラーランプの空の段を消すための Undo (中身は何も変わらない)
    # しきい値で消した画素を、Undo の位置に合わせて戻す / かけ直す (alpha_tools)
    alpha_tools.reconcile()
    try:
        # ペイントを始める前まで戻ったときに、画面が「+新規 開く」にならないように
        session.recover_after_undo()
    except Exception as e:
        print("[Vector Strokes]", e)
    # 使っているツールに知らせる (文字ツールは、戻った文字にカーソルを収め直す)
    tool = state.current_tool
    if tool is not None and hasattr(tool, "after_undo"):
        try:
            tool.after_undo()
        except Exception as e:
            print("[Vector Strokes]", e)
    # 読み込んだ画像の控え (キャッシュ) を捨ててから描き直す。Undo でペイントレイヤーの
    # 絵が戻っても、控えが古いままだとキャンバスに古い絵が出続ける (実測で確認)
    render.clear_cache()
    render.render_all(keep_clean=True)
    # Blender の Undo は「今使っているツール」も元に戻す (ブラシに戻ってしまう)。
    # 編集中なら、編集用のツールに戻す
    if state.editing_image and state.current_tool is not None:
        state.tool_restore_pending = True
        from . import edit_tool
        ok = edit_tool.restore_tool_after_undo()
        edit_tool.log("Undo/やり直し: ツールを戻した=%s モーダル生存=%s"
                      % (ok, edit_tool.session_alive()))
        # Undo でモーダルが終わってしまうことがあるので、少し後に確認して再開する
        if not bpy.app.timers.is_registered(_resume_soon):
            bpy.app.timers.register(_resume_soon, first_interval=0.05)
    elif state.paint and not bpy.app.timers.is_registered(_resume_soon):
        bpy.app.timers.register(_resume_soon, first_interval=0.05)   # 見張り役の確認


def _resume_soon():
    from . import edit_tool, session
    try:
        if state.paint and state.paint.get("ready"):
            session.start_guard()           # Undo で見張り役が終わっていたら動かし直す
        edit_tool.resume_if_needed()
    except Exception as e:
        print("[Vector Strokes]", e)
    return None


def watchdog():
    """編集モードが落ちたままになっていないか、ときどき確認する。
    落ちていれば状態を畳み、可能なら再開する (以後ツールが使えなくなるのを防ぐ)。

    ツールの変更はここでは見ない (session.py が msgbus で受け取る)。
    ここで見るのは「描いていた画像が表示されなくなった」だけ。"""
    from . import edit_tool, session
    try:
        session.check_still_painting()
        if state.paint and state.paint.get("ready"):
            session.start_guard()           # Undo などで見張り役が終わっていたら動かし直す
        edit_tool.resume_if_needed()
    except Exception as e:
        print("[Vector Strokes]", e)
    check_resized()
    return 2.0


def check_resized():
    """リサイズされたキャンバスがあれば、描き直して中身を合わせる (data.sync_canvas_size)。"""
    if state.paint:
        return              # 描いている最中は触らない (戻ったときに合わせる)
    try:
        for img in bpy.data.images:
            vs = img.vstroke
            if not vs.enabled:
                continue
            cs = tuple(int(v) for v in vs.canvas_size)
            if cs != (0, 0) and cs != tuple(int(v) for v in img.size):
                render.render_image(img)
    except Exception as e:
        print("[Vector Strokes]", e)


@persistent
def on_depsgraph(scene, depsgraph):
    """画像が変わった知らせ。リサイズなら、すぐ合わせる (見回りを待たない)。"""
    if state.paint:
        return
    for u in depsgraph.updates:
        idd = getattr(u.id, "original", u.id)
        if isinstance(idd, bpy.types.Image):
            try:
                vs = idd.vstroke
                cs = tuple(int(v) for v in vs.canvas_size)
                if vs.enabled and cs != (0, 0) and cs != tuple(int(v) for v in idd.size):
                    if not bpy.app.timers.is_registered(check_resized):
                        bpy.app.timers.register(check_resized, first_interval=0.05)
                    return
            except Exception:
                pass


@persistent
def on_load(*args):
    from . import session
    session.subscribe()      # ファイルを開くと購読が切れるので、つなぎ直す
    render.clear_cache()
    state.reset()
    data.migrate_all()
    data.refresh_font_lists()
    render.render_all(keep_clean=True)
    session.canvases_to_view_mode()   # 前の版で保存した、ペイントモードのキャンバス


@persistent
def on_save_pre(*args):
    """保存の直前に、ペイントレイヤーの絵を埋め込む (埋め込まないと保存で消える)。"""
    from . import alpha_tools, operators
    try:
        alpha_tools.enforce_lock()      # 透明部分のロック: 守る所に描いた分は保存しない
        operators.pack_all_paint_layers()
    except Exception as e:
        print("[Vector Strokes]", e)


def _initial():
    # アドオンを有効にした時点で開いているファイルにも移行と再描画を行う
    try:
        data.migrate_all()
        data.refresh_font_lists()
        render.render_all(keep_clean=True)
    except Exception as e:
        print("[Vector Strokes]", e)
    return None


_HANDLERS = (
    (bpy.app.handlers.undo_post, on_undo_redo),
    (bpy.app.handlers.redo_post, on_undo_redo),
    (bpy.app.handlers.load_post, on_load),
    (bpy.app.handlers.save_pre, on_save_pre),
    (bpy.app.handlers.depsgraph_update_post, on_depsgraph),
)


def register():
    for lst, fn in _HANDLERS:
        lst.append(fn)
    bpy.app.timers.register(_initial, first_interval=0.1)
    if not bpy.app.background:
        bpy.app.timers.register(watchdog, first_interval=2.0, persistent=True)


def unregister():
    for lst, fn in _HANDLERS:
        if fn in lst:
            lst.remove(fn)
    for fn in (_initial, watchdog, _resume_soon, check_resized):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    render.clear_cache()

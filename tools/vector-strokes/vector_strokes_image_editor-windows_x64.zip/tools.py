# SPDX-License-Identifier: GPL-3.0-or-later
"""左ツールバーのツール (WorkSpaceTool): 選択・ペン・図形。

ツールを選んでキャンバスをクリックすると編集モードに入る。
Esc(何も選択していない時)や右クリックのメニューの「終了」で終わると、選ぶ前に使っていたツールに戻す。
イメージエディターの「表示」モードと「ペイント」モードの両方に登録する。
"""

import os

import bpy
from bpy.types import WorkSpaceTool

from . import state

# ツールID <-> ツール名 (ペンは段階1からの ID を引き継ぐ)
TOOL_IDS = {
    'SELECT': "vstroke.select_tool",
    'PEN': "vstroke.edit_tool",
    'PENCIL': "vstroke.pencil_tool",
    'SHAPE': "vstroke.shape_tool",
    'GRADIENT': "vstroke.gradient_tool",
    'TEXT': "vstroke.text_tool",
    'BRUSH': "vstroke.brush_tool",
}
TOOL_NAMES = {v: k for k, v in TOOL_IDS.items()}
TOOL_ID = TOOL_IDS['PEN']  # 旧名


def _keymap(name):
    return (
        ("vstroke.edit",
         {"type": 'LEFTMOUSE', "value": 'PRESS', "any": True},
         {"properties": [("from_tool", True), ("tool", name)]}),
    )


def _image_data(context):
    sp = context.space_data
    img = getattr(sp, "image", None) if sp is not None else None
    if img is None or not img.vstroke.enabled:
        return None, None
    return img, img.vstroke


def _paint_of(ob, kind):
    """一番上の塗り / 線 (無ければ None)。"""
    if ob is None or ob.kind in {'GROUP', 'LAYER'}:
        return None
    found = [p for p in ob.paints if p.kind == kind]
    return found[-1] if found else None


def _eye(row, paint):
    """塗り/線の表示・非表示 (目のアイコン。レイヤー一覧と同じ見た目)。"""
    row.prop(paint, "enabled", text="", emboss=False,
             icon='HIDE_OFF' if paint.enabled else 'HIDE_ON')


def _draw_style(layout, vs, ob):
    """上のバーの「塗り・線・線幅・不透明度」 (Illustrator のコントロールバー相当)。"""
    from . import data
    row = layout.row(align=True)
    if ob is not None and ob.kind == 'ADJUST':
        row.label(text=ob.name, icon='MODIFIER')
        row.prop(ob, "opacity", text="強さ", slider=True)
        return
    if ob is None or ob.kind in {'GROUP', 'LAYER'}:
        if ob is not None:
            row.label(text=ob.name, icon='FILE_FOLDER' if ob.kind == 'GROUP'
                      else 'RENDERLAYERS')
            row.prop(ob, "opacity", text="不透明度", slider=True)
            row.prop(ob, "blend_mode", text="")
        return
    from . import icons
    fill = _paint_of(ob, 'FILL')
    stroke = _paint_of(ob, 'STROKE')
    row.label(text="塗り", **icons.kw("fill", 'SHADING_SOLID'))
    if fill is None:
        row.operator("vstroke.paint_add", text="追加", icon='ADD').kind = 'FILL'
    else:
        if fill.paint_type == 'SOLID':
            sub = row.row()
            sub.ui_units_x = 1.6
            sub.prop(fill, "color", text="")
        else:
            row.label(text="グラデ", icon='COLOR')
        _eye(row, fill)
    row.separator()
    row.label(text="線", **icons.kw("stroke", 'SHADING_WIRE'))
    if stroke is None:
        row.operator("vstroke.paint_add", text="追加", icon='ADD').kind = 'STROKE'
    else:
        if stroke.paint_type == 'SOLID':
            sub = row.row()
            sub.ui_units_x = 1.6
            sub.prop(stroke, "color", text="")
        else:
            row.label(text="グラデ", icon='COLOR')
        sub = row.row()
        sub.ui_units_x = 3.0
        sub.prop(stroke, "width", text="")
        _eye(row, stroke)
    row = layout.row(align=True)
    row.prop(ob, "opacity", text="不透明度", slider=True)
    sub = row.row()
    sub.ui_units_x = 5.0
    sub.prop(ob, "blend_mode", text="")


def _draw_shape_opts(layout, ts):
    layout.prop(ts, "shape_type", text="")
    if ts.shape_type == 'ROUNDED_RECT':
        layout.prop(ts, "corner_radius", text="角")
    elif ts.shape_type == 'POLYGON':
        layout.prop(ts, "sides", text="辺")
    elif ts.shape_type == 'STAR':
        layout.prop(ts, "star_points", text="頂点")
        layout.prop(ts, "inner_ratio", text="内側")


def _draw_text_opts(context, layout, ob, ts):
    from . import fonts
    wm = context.window_manager
    if ob is None or ob.kind != 'TEXT':
        layout.prop(ts, "text_vertical", text="縦書き", toggle=True)
        return
    from . import data
    vs = ob.id_data.vstroke
    attr = vs.text_attr
    _, ranges = data.selected_char_ranges()
    row = layout.row(align=True)
    row.active = bool(ranges)       # 文字を選んでいないときは触れない (Affinity と同じ)
    if len(wm.vstroke_font_families):
        sub = row.row()
        sub.ui_units_x = 8.0
        sub.prop_search(attr, "font_family", wm, "vstroke_font_families", text="",
                        icon='FONT_DATA')
        sub = row.row()
        sub.ui_units_x = 4.0
        sub.prop(attr, "font_style_choice", text="")
    else:
        row.prop(attr, "font_family", text="")
    sub = row.row()
    sub.ui_units_x = 3.5
    sub.prop(attr, "font_size", text="")
    if data.caret_target() is not None:
        # 文字と文字の間にカーソルだけ置いているとき: その2文字の間 (カーニング)
        sub = layout.row(align=True)
        sub.ui_units_x = 6.0
        sub.prop(attr, "kerning", text="カーニング")
    row = _draw_text_align(layout, ob)
    row.prop(ob, "text_vertical", text="縦", toggle=True)


def _draw_text_align(layout, ob):
    """文字のそろえ方 (行揃えと、エリア文字なら枠の中の位置)。文字全体の設定なので、
    文字を選んでいなくても変えられる。選択ツールで文字を選んだときも出す
    (2026-10-18 ユーザー要望)。"""
    row = layout.row(align=True)
    sub = row.row()
    sub.ui_units_x = 5.0
    sub.prop(ob, "text_align", text="")        # 左/中央/右 はドロップダウンで
    if ob.text_kind == 'AREA':
        sub = row.row()
        sub.ui_units_x = 5.0
        sub.prop(ob, "text_box_align", text="")
    return row


def _draw_not_enabled(context, layout):
    """まだベクター編集にしていない画像を開いているときの案内。"""
    from . import operators
    sp = context.space_data
    img = getattr(sp, "image", None) if sp is not None else None
    why = operators.enable_problem(img, deep=False) if img is not None else "画像を開いてください"
    if why:
        layout.label(text=why, icon='ERROR')
        if img is not None and operators.owner_canvas(img) is not None:
            layout.operator("vstroke.show_canvas", icon='LOOP_BACK')
    else:
        layout.label(text="キャンバスをクリックすると、この画像のベクター編集を始めます"
                          " (元の画像はいちばん下のレイヤーになります)", icon='INFO')


def _draw_tool_settings(name):
    """左ツールバーのツールごとに、上のバーへ出す設定。"""

    def draw(context, layout, tool):
        from . import data
        # ここで切り替えの合図を出してはいけない (描かれたかどうかは当てにならない)。
        # ツールが変わったことは session.py が msgbus で受け取る
        img, vs = _image_data(context)
        ts = context.window_manager.vstroke_tool
        if vs is None:
            _draw_not_enabled(context, layout)
            return
        if name == 'BRUSH':
            layout.label(text="ブラシで描きます (他のツールを押すとベクターに戻ります)",
                         icon='BRUSH_DATA')
            return
        ob = data.active_object(vs)
        if name == 'SHAPE':
            _draw_shape_opts(layout.row(align=True), ts)
            layout.separator()
        elif name == 'PENCIL':
            sub = layout.row(align=True)
            sub.ui_units_x = 8.0
            sub.prop(ts, "pencil_smooth", text="滑らかさ", slider=True)
            layout.separator()
        elif name == 'TEXT':
            _draw_text_opts(context, layout, ob, ts)
            layout.separator()
        elif name == 'SELECT' and ob is not None and ob.kind == 'TEXT':
            _draw_text_align(layout, ob)
            layout.separator()
        elif name == 'GRADIENT':
            # いまキャンバスで動かしているのが塗りか線かを出す (サイドバーの
            # 「キャンバスで調整」で切り替える)
            from . import gradient_tool, icons
            gob, gi = gradient_tool.target_index(vs)
            if gob is not None:
                p = gob.paints[gi]
                fill = p.kind == 'FILL'
                sub = layout.row(align=True)
                sub.label(text="塗り" if fill else "線",
                          **icons.kw("fill" if fill else "stroke",
                                     'SHADING_SOLID' if fill else 'SHADING_WIRE'))
                sub2 = sub.row(align=True)
                sub2.ui_units_x = 8.0
                sub2.prop(p, "paint_type", text="")
                layout.separator()
        _draw_style(layout, vs, ob)
        # 枠線・スナップのボタンは、1つ上の段 (エディターのヘッダー) の右端にある
        # (2026-09-25 ユーザー要望で1か所にまとめた。ui.draw_header_button)
    return draw


_DEFS = (
    ('SELECT', "選択", "オブジェクトを選んで移動・拡大縮小・回転する (V)", "ops.generic.select"),
    ('PEN', "ペン", "パスを描く・点を編集する (P)", "ops.curve.pen"),
    ('PENCIL', "鉛筆", "手で描いた線を、描きながら曲線にする", "@icons/ops.vstroke.pencil"),
    ('SHAPE', "図形", "矩形・楕円・多角形・星を作る (M: 矩形, L: 楕円)", "ops.gpencil.primitive_box"),
    ('GRADIENT', "グラデーション", "グラデーションの向きと長さをキャンバス上で決める (G)",
     "ops.paint.weight_gradient"),
    ('TEXT', "文字", "文字を入れる・打ち直す (T)", "@icons/ops.vstroke.text"),
    ('BRUSH', "ブラシ", "ペイントレイヤーにブラシで描く (他のレイヤーも見えたまま)",
     "@icons/ops.vstroke.brush"),
)

# クリックでベクター編集を始めないツール (ブラシは押しても編集に入らない)
NO_CLICK = {'BRUSH'}
VIEW_ONLY = set()      # 両方のモードに出す (ペイント中も見える方が分かりやすい)


ICON_DIR = os.path.join(os.path.dirname(__file__), "icons")


def _icon(name):
    """"@icons/..." で始まるものは、このアドオンに入っている自作アイコン。"""
    if name.startswith("@icons/"):
        return os.path.join(ICON_DIR, name[len("@icons/"):])
    return name


def _make_classes():
    out = []
    for mode in ('VIEW', 'PAINT'):
        for name, label, desc, icon in _DEFS:
            if mode != 'VIEW' and name in VIEW_ONLY:
                continue
            attrs = {
                "bl_space_type": 'IMAGE_EDITOR',
                "bl_context_mode": mode,
                "bl_idname": TOOL_IDS[name],
                "bl_label": label,
                "bl_description": desc,
                "bl_icon": _icon(icon),
                "bl_keymap": () if name in NO_CLICK else _keymap(name),
            }
            attrs["draw_settings"] = _draw_tool_settings(name)
            out.append(type("VS_WST_%s_%s" % (name.lower(), mode.lower()), (WorkSpaceTool,), attrs))
    return out


_TOOL_CLASSES = _make_classes()



# -----------------------------------------------------------------------------
# ブラシツール・モードの切り替え
# -----------------------------------------------------------------------------
# 切り替えの判断は session.py が 1 か所で受け持つ (msgbus の合図 1 本だけを使う)。
# ここに「描かれたら切り替える」「何秒ごとに確かめる」を足さないこと。
# そうやって見張りを増やした結果、同じ不具合を4回直すことになった (v0.21.4〜v0.22.2)。

def set_tool(window, area, tool_id):
    from . import session
    return session.set_tool(window, area, tool_id)


def active_tool_id(context, mode):
    from . import session
    return session.active_tool_id(context, mode)


def is_our_tool_active(context, mode):
    return active_tool_id(context, mode) in TOOL_NAMES


def on_paint_entered(win, area):
    from . import session
    return session.on_paint_entered(win, area)


def remember_current_tool(context):
    """このアドオン以外のツールが選ばれていれば覚えておく(描画のたびに呼ばれる)。
    覚えるだけで、切り替えは起こさない。"""
    sp = context.space_data
    mode = getattr(sp, "ui_mode", "")
    if not mode:
        return
    tid = active_tool_id(context, mode)
    if tid and tid not in TOOL_NAMES:
        state.prev_tools[mode] = tid


def restore_previous_tool(window, area, mode):
    prev = state.prev_tools.get(mode)
    if prev:
        set_tool(window, area, prev)


def register():
    prev = None
    for cls in _TOOL_CLASSES:
        try:
            first = cls.bl_idname == TOOL_IDS['SELECT']
            bpy.utils.register_tool(cls, separator=first,
                                    after=None if first else {prev})
        except Exception as e:
            print("[Vector Strokes] ツールバーへの登録に失敗:", cls.bl_idname,
                  cls.bl_context_mode, e)
        prev = cls.bl_idname


def unregister():
    for cls in reversed(_TOOL_CLASSES):
        try:
            bpy.utils.unregister_tool(cls)
        except Exception:
            pass

# SPDX-License-Identifier: GPL-3.0-or-later
"""手描きの点の並びを、少ない点のベジェ曲線にする (鉛筆ツール用)。

流れ:
  1. 点の間隔をそろえる (マウスの点は速さでばらつくため)  resample
  2. 角を見つける (V 字の先などは、丸めずに角のまま残す)   find_corners
  3. 滑らかさに応じて、角と端を動かさずにならす            smooth
  4. 角で区切った区間ごとに、Schneider の方法で曲線にする  fit_cubic
     (Graphics Gems「An Algorithm for Automatically Fitting Digitized Curves」)
座標はすべて画像のピクセル。ここは bpy に依存しないので、そのまま試験できる。
"""

import math

import numpy as np


def _unit(v):
    n = float(np.hypot(v[0], v[1]))
    return v / n if n > 1e-12 else np.zeros(2)


def resample(pts, spacing):
    """折れ線を、ほぼ等しい間隔の点に並べ直す (最初と最後の点は残す)。"""
    pts = np.asarray(pts, np.float64)
    if len(pts) < 2 or spacing <= 0:
        return pts
    seg = np.hypot(*np.diff(pts, axis=0).T)
    keep = np.concatenate([[True], seg > 1e-9])      # 同じ点の重なりを捨てる
    pts, seg = pts[keep], seg[seg > 1e-9]
    if len(pts) < 2:
        return pts
    total = float(seg.sum())
    n = max(int(round(total / spacing)), 1)
    cum = np.concatenate([[0.0], np.cumsum(seg)])
    at = np.linspace(0.0, total, n + 1)
    x = np.interp(at, cum, pts[:, 0])
    y = np.interp(at, cum, pts[:, 1])
    return np.stack([x, y], axis=1)


def find_corners(pts, window, angle_deg=70.0):
    """向きが大きく変わる所 (角) の番号。window は前後に見る点の数。"""
    n = len(pts)
    k = max(int(window), 1)
    if n < 2 * k + 1:
        return []
    ang = np.zeros(n)
    for i in range(k, n - k):
        a = pts[i] - pts[i - k]
        b = pts[i + k] - pts[i]
        la, lb = np.hypot(*a), np.hypot(*b)
        if la < 1e-9 or lb < 1e-9:
            continue
        c = np.clip(np.dot(a, b) / (la * lb), -1.0, 1.0)
        ang[i] = math.degrees(math.acos(c))
    out = []
    i = k
    while i < n - k:
        if ang[i] >= angle_deg:
            j = i
            while j + 1 < n - k and ang[j + 1] >= angle_deg:
                j += 1
            best = i + int(np.argmax(ang[i:j + 1]))     # いちばん曲がっている所
            out.append(best)
            i = j + 1
        else:
            i += 1
    return out


def smooth(pts, iterations):
    """端を動かさずに、となりの点との平均でならす。"""
    p = np.array(pts, np.float64)
    for _ in range(int(iterations)):
        if len(p) < 3:
            break
        p[1:-1] = 0.25 * p[:-2] + 0.5 * p[1:-1] + 0.25 * p[2:]
    return p


# --- Schneider の方法 ---------------------------------------------------------

def _bez(b, u):
    u = u[:, None]
    mu = 1.0 - u
    return (mu ** 3) * b[0] + 3 * (mu ** 2) * u * b[1] + 3 * mu * (u ** 2) * b[2] + (u ** 3) * b[3]


def _bez_d1(b, u):
    u = u[:, None]
    mu = 1.0 - u
    return 3 * (mu ** 2) * (b[1] - b[0]) + 6 * mu * u * (b[2] - b[1]) + 3 * (u ** 2) * (b[3] - b[2])


def _bez_d2(b, u):
    u = u[:, None]
    return 6 * (1.0 - u) * (b[2] - 2 * b[1] + b[0]) + 6 * u * (b[3] - 2 * b[2] + b[1])


def _chord_params(p):
    d = np.concatenate([[0.0], np.cumsum(np.hypot(*np.diff(p, axis=0).T))])
    return d / d[-1] if d[-1] > 1e-12 else np.linspace(0.0, 1.0, len(p))


def _generate(p, u, t1, t2):
    """端点と両端の向きを決めて、ハンドルの長さを最小二乗で求める。"""
    p0, p3 = p[0], p[-1]
    uu = u[:, None]
    b0, b1 = (1 - uu) ** 3, 3 * uu * (1 - uu) ** 2
    b2, b3 = 3 * uu ** 2 * (1 - uu), uu ** 3
    a1, a2 = t1 * b1, t2 * b2
    c00 = float((a1 * a1).sum())
    c01 = float((a1 * a2).sum())
    c11 = float((a2 * a2).sum())
    tmp = p - (p0 * (b0 + b1) + p3 * (b2 + b3))
    x0 = float((a1 * tmp).sum())
    x1 = float((a2 * tmp).sum())
    det = c00 * c11 - c01 * c01
    seg = float(np.hypot(*(p3 - p0)))
    if abs(det) > 1e-12:
        al = (x0 * c11 - x1 * c01) / det
        ar = (c00 * x1 - c01 * x0) / det
    else:
        al = ar = seg / 3.0
    if al < 1e-6 * seg or ar < 1e-6 * seg:
        al = ar = seg / 3.0
    return np.array([p0, p0 + t1 * al, p3 + t2 * ar, p3])


def _max_error(p, b, u):
    d = np.hypot(*(_bez(b, u) - p).T)
    i = int(np.argmax(d))
    return float(d[i]), i


def _reparameterize(p, b, u):
    q = _bez(b, u) - p
    d1, d2 = _bez_d1(b, u), _bez_d2(b, u)
    num = (q * d1).sum(axis=1)
    den = (d1 * d1).sum(axis=1) + (q * d2).sum(axis=1)
    step = np.where(np.abs(den) > 1e-12, num / np.where(np.abs(den) > 1e-12, den, 1.0), 0.0)
    return np.clip(u - step, 0.0, 1.0)


def _fit(p, t1, t2, err, depth):
    n = len(p)
    if n == 2:
        d = float(np.hypot(*(p[1] - p[0]))) / 3.0
        return [np.array([p[0], p[0] + t1 * d, p[1] + t2 * d, p[1]])]
    u = _chord_params(p)
    b = _generate(p, u, t1, t2)
    e, split = _max_error(p, b, u)
    if e < err:
        return [b]
    if e < err * 4.0:
        for _ in range(20):
            u = _reparameterize(p, b, u)
            b = _generate(p, u, t1, t2)
            e, split = _max_error(p, b, u)
            if e < err:
                return [b]
    if depth > 40:
        return [b]
    split = min(max(split, 1), n - 2)
    tc = _unit(p[split - 1] - p[split + 1])
    if not tc.any():
        tc = _unit(p[split - 1] - p[split])
    return (_fit(p[:split + 1], t1, tc, err, depth + 1)
            + _fit(p[split:], -tc, t2, err, depth + 1))


def fit_cubic(pts, err):
    """点の並びを、誤差 err 以内のベジェの区間の並びにする。[(p0, p1, p2, p3), ...]"""
    p = np.asarray(pts, np.float64)
    if len(p) < 2:
        return []
    t1 = _unit(p[1] - p[0])
    t2 = _unit(p[-2] - p[-1])
    return _fit(p, t1, t2, float(err), 0)


# --- まとめ -------------------------------------------------------------------

def fit_stroke(raw, err, spacing, smoothness, corner_window):
    """手描きの点の並びを、パスの点 [(co, handle_left, handle_right), ...] にする。

    err:           許す誤差 (画像のピクセル)。大きいほど点が少なく滑らか
    spacing:       並べ直す間隔 (画像のピクセル)
    smoothness:    ならす回数
    corner_window: 角を見つけるときに前後を見る長さ (画像のピクセル)
    """
    pts = resample(raw, spacing)
    if len(pts) < 2:
        return []
    if float(np.hypot(*(pts[-1] - pts[0]))) < 1e-6 and len(pts) < 3:
        return []
    k = max(2, int(round(corner_window / max(spacing, 1e-6))))
    corners = find_corners(smooth(pts, 1), k)
    cuts = [0] + corners + [len(pts) - 1]
    segs_by_piece = []
    for a, b in zip(cuts[:-1], cuts[1:]):
        piece = pts[a:b + 1]
        if len(piece) < 2:
            continue
        segs_by_piece.append(fit_cubic(smooth(piece, smoothness), err))
    anchors = []
    for segs in segs_by_piece:
        for j, s in enumerate(segs):
            p0, p1, p2, p3 = (tuple(float(v) for v in q) for q in s)
            if not anchors:
                anchors.append([p0, p0, p1])
            else:
                anchors[-1][2] = p1          # 区間のつなぎ目 (角なら向きが揃わない)
            anchors.append([p3, p2, p3])
    return [tuple(a) for a in anchors]

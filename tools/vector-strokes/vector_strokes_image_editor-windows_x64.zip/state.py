# SPDX-License-Identifier: GPL-3.0-or-later
"""アドオン全体で共有する実行時の状態(保存されない)。"""

import bpy

# 編集ツール実行中の画像名 / マウス位置(リージョン座標) / オーバーレイ描画ハンドル
editing_image = ""
mouse = None
# ペンの予告線: いま Shift を押しているか (押していれば8方向に固定して見せる)
mouse_shift = False
draw_handle = None

# 左ツールバーで、このアドオンのツールを選ぶ直前に使っていたツール (モード -> ツールID)
prev_tools = {}

# グループ編集モード中のグループ (画像名 -> グループの uid)
isolation = {}

# 実行中のツール (tool_base.Tool。オーバーレイ表示で使う)
current_tool = None

# 実行中の編集オペレーター と その世代番号。
# Undo などでモーダルが止まったままになっても、次の開始が世代を進めて引き継げるようにする
current_op = None
generation = 0

# 文字ツールで編集中のカーソル (画像名, オブジェクトuid, 行, 文字数)。オーバーレイ表示に使う
text_caret = None

# 選んでいる文字の範囲 (画像名, uid, (行, 文字), (行, 文字))。無ければ None
text_sel = None

# 文字のコピーの控え (パソコンのクリップボードが使えない環境用)
text_clipboard = ""

# ペイント中の情報 (キャンバス名, レイヤーuid, 下の絵の画像名, 上の絵の画像名)。
# これがあると、オーバーレイが「他のレイヤー」を正しく重ねて見せる
paint = None

# スナップで合ったときに出す目印の線 [('V', x), ('H', y)]
snap_guides = []

# 選択ツールでダブルクリックしたとき、文字ツールに「この文字を編集して」と伝える
# (uid, クリックした画像座標)
text_edit_request = None

# Undo/やり直しの直後は、Blender がツールも元に戻してしまうので、選び直す印
tool_restore_pending = False

# コピーしたオブジェクト (data.copy_objects が入れる。Blender を閉じるまで残る。
# 中身はただの辞書なので、別の画像にも、別の .blend にも貼り付けられる。
# ファイルを開いたときも消さない (reset() の対象外))
clipboard = []
# コピーした元のキャンバスの名前。別のキャンバスへ貼るときだけ、見える所へ寄せたり
# レイヤーマスクの大きさを合わせたりする (data.paste_objects)
clipboard_src = ""

HIT_RADIUS_DEFAULT = 16.0  # 当たり判定の半径(UI単位)
HANDLE_COLOR = (0x29 / 255.0, 0x80 / 255.0, 0xE6 / 255.0, 1.0)  # #2980E6
HANDLE_OUTLINE = (1.0, 1.0, 1.0, 1.0)


def ui_scale():
    """UIスケール(Retina等の高解像度ディスプレイでは2倍など)。"""
    try:
        v = float(bpy.context.preferences.system.ui_scale)
        return v if v > 0.1 else 1.0
    except Exception:
        return 1.0


def prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return None


def dblclick_pen():
    """選択ツールのダブルクリックで、パス・図形をペンの点の編集にするか (初期値はオフ。
    2026-10-12 ユーザー要望: 勝手にペンになるので、設定でオンにしたときだけ)。"""
    pr = prefs()
    return bool(getattr(pr, "dblclick_pen", False)) if pr is not None else False


def hit_radius():
    pr = prefs()
    r = pr.hit_radius if pr is not None else HIT_RADIUS_DEFAULT
    return r * ui_scale()


# キャンバスでトリミングを調整している画像 (キャンバスの画像名, uid)。無ければ None
crop_edit = None

# サイドバーの「各角の丸み」で最後に値を変えた角 (画像名, uid, si, pi, 時刻)。
# キャンバスで少しのあいだ強調する
corner_focus = None
CORNER_FOCUS_SECONDS = 1.5

# 右クリックのメニューの「ベクター編集を終了」が立てる。モーダルが次の入力で見て終える
exit_request = False


def clear_session():
    """編集セッションだけを畳む (グループ編集モードなどは残す)。"""
    global editing_image, mouse, current_tool, current_op, tool_restore_pending
    global text_caret, text_sel, text_edit_request, snap_guides, exit_request, crop_edit
    exit_request = False
    editing_image = ""
    if crop_edit is not None:
        crop_edit = None
    mouse = None
    current_tool = None
    text_caret = None
    text_sel = None
    text_edit_request = None
    snap_guides = []
    current_op = None
    tool_restore_pending = False


def reset():
    global editing_image, mouse, current_tool, current_op, tool_restore_pending
    global text_caret, text_edit_request, snap_guides
    editing_image = ""
    mouse = None
    current_tool = None
    current_op = None
    tool_restore_pending = False
    text_caret = None
    text_edit_request = None
    snap_guides = []
    isolation.clear()


def guides_visible():
    """枠線・点・ハンドルなど、編集用の表示を出すか (ヘッダーのボタンで切り替える)。"""
    try:
        return bool(bpy.context.window_manager.vstroke_tool.show_guides)
    except Exception:
        return True

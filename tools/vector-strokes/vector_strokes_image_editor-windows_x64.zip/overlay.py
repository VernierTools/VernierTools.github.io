# SPDX-License-Identifier: GPL-3.0-or-later
"""編集中にイメージエディターへ重ねて描く表示。
GPU で描くので、バックグラウンド実行(自動テスト)では動かない。

- ペン: パスの線・点・ハンドル・プレビュー線 (v0.3.2 と同じ)。図形の頂点も表示
- 選択: 選択中のオブジェクトの輪郭、選択枠と8つのハンドル、範囲選択の四角
- 図形: 選択中のオブジェクトの輪郭と選択枠
"""

import math

import bpy
import numpy as np

from . import corners, data, edit_logic, geometry as G, state, tools, transform, uv_overlay
from .tool_base import isolation

ACTIVE_COL = (1.0, 0.55, 0.1, 0.95)
PATH_COL = (0.3, 0.7, 1.0, 0.8)


class Painter:
    def __init__(self, region):
        import gpu
        self.gpu = gpu
        self.line_sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        self.flat_sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        self.vp = (float(region.width), float(region.height))

    def _batch(self, sh, kind, coords):
        from gpu_extras.batch import batch_for_shader
        return batch_for_shader(sh, kind, {"pos": [(float(x), float(y), 0.0) for x, y in coords]})

    def lines(self, coords, kind, color, width):
        if len(coords) < 2:
            return
        b = self._batch(self.line_sh, kind, coords)
        self.line_sh.bind()
        self.line_sh.uniform_float("viewportSize", self.vp)
        self.line_sh.uniform_float("lineWidth", width)
        self.line_sh.uniform_float("color", color)
        b.draw(self.line_sh)

    def tris(self, coords, color):
        if not coords:
            return
        b = self._batch(self.flat_sh, 'TRIS', coords)
        self.flat_sh.bind()
        self.flat_sh.uniform_float("color", color)
        b.draw(self.flat_sh)

    def circles(self, centers, radius, color, seg=16):
        tris = []
        angs = [2.0 * math.pi * k / seg for k in range(seg + 1)]
        for cx, cy in centers:
            for k in range(seg):
                tris += [(cx, cy),
                         (cx + radius * math.cos(angs[k]), cy + radius * math.sin(angs[k])),
                         (cx + radius * math.cos(angs[k + 1]), cy + radius * math.sin(angs[k + 1]))]
        self.tris(tris, color)

    def squares(self, centers, half, color):
        tris = []
        for cx, cy in centers:
            a, b = (cx - half, cy - half), (cx + half, cy - half)
            c, d = (cx + half, cy + half), (cx - half, cy + half)
            tris += [a, b, c, a, c, d]
        self.tris(tris, color)


def _outline(p, view, ob, col, width):
    for pts, closed in G.object_subpaths(ob):
        rp = view.to_region(G.flatten_t(pts, closed))
        if closed and len(rp) >= 2:
            rp = np.vstack([rp, rp[:1]])
        p.lines(rp, 'LINE_STRIP', col, width)


def draw_pen(p, view, vs, u):
    hc = state.HANDLE_COLOR
    visible = data.effective_editable(vs)  # ロック中・非表示は表示しない
    # 次の点がどこに繋がるかのプレビュー線(選択中の端点 -> マウス)
    src = edit_logic.source_endpoint(vs)
    if src is not None and state.mouse is not None:
        c = view.to_region(edit_logic.get_point(vs, src).co)
        m = state.mouse
        if state.mouse_shift:
            # Shift を押している間は、クリックで点が置かれる位置 (8方向に固定) まで
            q = edit_logic.constrained_from(vs, src, *view.to_image(*m))
            m = tuple(view.to_region(q))
        p.lines([tuple(c), tuple(m)], 'LINES', (hc[0], hc[1], hc[2], 0.6), 1.5 * u)

    for oi, ob in enumerate(vs.objects):
        if not visible[oi] or ob.kind not in {'PATH', 'SHAPE'}:
            continue
        col = ACTIVE_COL if oi == vs.active_index else PATH_COL
        _outline(p, view, ob, col, 1.5 * u)
        handles_lines, handle_pts, sel_pts, unsel_pts = [], [], [], []
        if ob.kind == 'SHAPE':
            for pts, _ in G.shape_subpaths(ob):
                unsel_pts += [tuple(view.to_region(co)) for co, _, _ in pts]
        for sp in ob.subpaths if ob.kind == 'PATH' else ():
            for pt in sp.points:
                c = tuple(view.to_region(pt.co))
                if pt.select:
                    sel_pts.append(c)
                    for hv in (pt.handle_left, pt.handle_right):
                        if not G.same_point(hv, pt.co):
                            h = tuple(view.to_region(hv))
                            handles_lines += [c, h]
                            handle_pts.append(h)
                else:
                    unsel_pts.append(c)
        if handles_lines:
            p.lines(handles_lines, 'LINES', state.HANDLE_OUTLINE, 4.5 * u)
            p.lines(handles_lines, 'LINES', hc, 2.0 * u)
        p.circles(handle_pts, 6.0 * u, state.HANDLE_OUTLINE)
        p.circles(handle_pts, 4.5 * u, hc)
        p.squares(unsel_pts, 4.0 * u, (0.05, 0.05, 0.05, 1.0))
        p.squares(unsel_pts, 3.0 * u, col)
        p.squares(sel_pts, 5.0 * u, (0.05, 0.05, 0.05, 1.0))
        p.squares(sel_pts, 4.0 * u, (1.0, 1.0, 1.0, 1.0))


def _layer_color(vs, uid, m):
    lay = data.layer_of(vs, uid, m)
    if lay and lay in m:
        c = m[lay].layer_color
        return (c[0], c[1], c[2], 1.0)
    return state.HANDLE_COLOR


def draw_selection(p, view, vs, u, handles=True):
    """選択中のものの輪郭と選択枠。色はレイヤーの色 (Illustrator と同じ)。"""
    items = transform.selected_items(vs)
    m = data.uid_map(vs)
    hc = _layer_color(vs, items[-1], m) if items else state.HANDLE_COLOR
    for ob in transform.leaf_objects(vs, items):
        _outline(p, view, ob, _layer_color(vs, ob.uid, m), 1.5 * u)
    fr = transform.selection_frame(vs, items) if items else None
    if fr is None:
        return
    ang, b = fr
    corners = [tuple(view.to_region(transform.frame_point(ang, b, hx, hy)))
               for hx, hy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    p.lines(corners + corners[:1], 'LINE_STRIP', (hc[0], hc[1], hc[2], 0.9), 1.0 * u)
    if not handles:
        return
    from .select_tool import HANDLES
    hp = [tuple(view.to_region(transform.frame_point(ang, b, hx, hy))) for hx, hy in HANDLES]
    p.squares(hp, 4.5 * u, hc)
    p.squares(hp, 3.0 * u, (1.0, 1.0, 1.0, 1.0))


def draw_gradient(p, view, vs, u):
    """グラデーションツールの補助線 (始点・終点と分岐点)。"""
    from .gradient_tool import stop_point, target
    ob, paint = target(vs)
    if paint is None or paint.paint_type == 'SOLID':
        return
    a = tuple(view.to_region(paint.g_start))
    b = tuple(view.to_region(paint.g_end))
    p.lines([a, b], 'LINES', (1.0, 1.0, 1.0, 0.9), 3.0 * u)
    p.lines([a, b], 'LINES', (0.1, 0.1, 0.1, 0.9), 1.5 * u)
    p.circles([a, b], 6.0 * u, state.HANDLE_OUTLINE)
    p.circles([a], 4.5 * u, (0.1, 0.1, 0.1, 1.0))
    p.circles([b], 4.5 * u, (0.95, 0.95, 0.95, 1.0))
    pts = [tuple(view.to_region(stop_point(paint, st))) for st in paint.stops]
    p.squares(pts, 5.0 * u, state.HANDLE_OUTLINE)
    for st, q in zip(paint.stops, pts):
        c = tuple(st.color)
        p.squares([q], 3.5 * u, (c[0], c[1], c[2], 1.0))


SNAP_COL = (1.0, 0.25, 0.85, 0.9)      # スナップの目印 (Illustrator のガイドに近い色)


def draw_snap_guides(p, view, img, u):
    """スナップで合った位置に線を出す。"""
    guides = getattr(state, "snap_guides", None)
    if not guides:
        return
    w, h = img.size
    for kind, v in guides:
        if kind == 'V':
            a, b = view.to_region((v, 0)), view.to_region((v, h))
        else:
            a, b = view.to_region((0, v)), view.to_region((w, v))
        p.lines([tuple(a), tuple(b)], 'LINES', SNAP_COL, 1.0 * u)


def draw_corner_widgets(p, view, vs, u):
    """角の丸印 (ライブコーナー)。選んでいるパスの尖った角に出す。"""
    items = transform.selected_items(vs)
    if not items:
        return
    try:
        ws = corners.widgets(vs, items, view.px_to_image(corners.WIDGET_MIN))
    except Exception:
        return
    pts = [tuple(view.to_region(w[3])) for w in ws]
    if not pts:
        return
    p.circles(pts, 5.0 * u, (1.0, 1.0, 1.0, 0.95))
    p.circles(pts, 3.5 * u, state.HANDLE_COLOR)


def draw_corner_labels(p, view, img, u):
    """「各角の丸み」を開いている間、選んでいるパスの角に番号を出す。
    最後に値を変えた角は少しのあいだ強調する (state.corner_focus)。
    ベクター編集中でなくても出す (サイドバーは編集していなくても使えるので)。"""
    import time
    import blf
    try:
        if not bpy.context.window_manager.vstroke_corner_list:
            return
    except AttributeError:
        return
    vs = img.vstroke
    ob = data.active_object(vs)
    if ob is None or ob.kind != 'PATH':
        return
    focus = state.corner_focus
    if focus is not None and (focus[0] != img.name or focus[1] != ob.uid
                              or time.monotonic() - focus[4] > state.CORNER_FOCUS_SECONDS):
        focus = None
    font = 0
    blf.size(font, 11.0 * u)
    for label, si, pi, co, a, b in corners.labeled_corners(ob):
        d = corners.inner_dir(co, a, b)
        if d is None:
            continue
        rc = view.to_region(co)
        # 角の外側に、角から少し離して置く (内側には丸印が出るので)
        cx, cy = rc[0] - d[0] * 16.0 * u, rc[1] - d[1] * 16.0 * u
        hot = focus is not None and focus[2] == si and focus[3] == pi
        tw, th = blf.dimensions(font, label)
        r = max(tw, th) * 0.5 + 4.0 * u
        if hot:
            p.circles([(cx, cy)], r + 2.5 * u, (1.0, 1.0, 1.0, 0.95))
            p.circles([(cx, cy)], r + 1.0 * u, ACTIVE_COL)
        else:
            p.circles([(cx, cy)], r, (0.1, 0.1, 0.1, 0.85))
        blf.position(font, cx - tw * 0.5, cy - th * 0.5, 0)
        blf.color(font, 1.0, 1.0, 1.0, 1.0)
        blf.draw(font, label)


def draw_crop(p, view, vs, u):
    """キャンバスでトリミングを調整している間: 切り取られる所を暗くし、枠と□を出す
    (Photoshop・Affinity の切り抜きツールと同じ見せ方)。"""
    cur = state.crop_edit
    if cur is None or cur[0] != vs.id_data.name:
        return
    i = data.index_of_uid(vs, cur[1])
    if i < 0:
        return
    ob = vs.objects[i]
    if ob.kind != 'IMAGE' or not ob.select:
        return
    full = [tuple(view.to_region(q)) for q in data.image_corners(ob)]
    vis = [tuple(view.to_region(q)) for q in data.image_visible_corners(ob)]
    tris = []
    for k in range(4):
        a, b = full[k], full[(k + 1) % 4]
        c, d = vis[(k + 1) % 4], vis[k]
        tris += [a, b, c, a, c, d]
    p.tris(tris, (0.0, 0.0, 0.0, 0.55))
    p.lines(full + full[:1], 'LINE_STRIP', (1.0, 1.0, 1.0, 0.35), 1.0 * u)
    p.lines(vis + vis[:1], 'LINE_STRIP', (1.0, 1.0, 1.0, 0.95), 2.0 * u)
    mids = [((vis[k][0] + vis[(k + 1) % 4][0]) / 2, (vis[k][1] + vis[(k + 1) % 4][1]) / 2)
            for k in range(4)]
    p.squares(vis + mids, 5.5 * u, (0.05, 0.05, 0.05, 1.0))
    p.squares(vis + mids, 4.0 * u, (1.0, 1.0, 1.0, 1.0))


def draw_text_frames(p, view, vs, u):
    """エリア文字の枠・パス上文字のパスを、薄い線で見せる。"""
    editable = data.effective_editable(vs)
    for i, ob in enumerate(vs.objects):
        if ob.kind != 'TEXT' or ob.text_kind == 'POINT' or not editable[i]:
            continue
        subs = G.text_frame_subpaths(ob)
        if not subs:
            continue
        # 文字がまだ入っていない枠は、はっきり見せる (図形が消えたと思わせないため)
        empty = data.text_string(ob) == ""
        col = (0.95, 0.6, 0.15, 0.9) if empty else (0.55, 0.55, 0.6, 0.55)
        for pts, closed in subs:
            rp = view.to_region(G.flatten_t(pts, closed))
            if closed and len(rp) >= 2:
                rp = np.vstack([rp, rp[:1]])
            p.lines(rp, 'LINE_STRIP', col, (1.5 if empty else 1.0) * u)
        # 入りきらないときは、右下に赤い印を出す (Illustrator と同じ)
        from . import text as text_mod
        try:
            if not text_mod.overflowing(ob):
                continue
            b = G.bounds_in_frame(G.polylines(subs))
        except Exception:
            continue
        if b is None:
            continue
        c = tuple(view.to_region((b[2], b[1])))
        p.squares([c], 5.0 * u, (1.0, 1.0, 1.0, 1.0))
        p.squares([c], 3.5 * u, (0.9, 0.15, 0.15, 1.0))


def draw_image_corners(p, view, vs, tool, u):
    """画像を1つ選んでいるとき、4隅に小さな丸を出す (⌘+ドラッグで遠近変形できる目印)。
    遠近変形している画像は、4隅を結んだ形も出す。"""
    get = getattr(tool, "distort_target", None)
    ob = get(vs) if get is not None else None
    if ob is None or data.has_crop(ob) or state.crop_edit is not None:
        # トリミングした画像では出さない (遠近変形の角は元の画像の角なので、
        # 見えていない所に丸が浮いてしまう)
        return
    pts = [tuple(view.to_region(q)) for q in data.image_corners(ob)]
    if ob.img_quad_on:
        p.lines(pts + [pts[0]], 'LINE_STRIP', (1.0, 1.0, 1.0, 0.9), 1.0 * u)
    p.circles(pts, 5.0 * u, (1.0, 1.0, 1.0, 1.0))
    p.circles(pts, 3.5 * u, state.HANDLE_COLOR)


def draw_pencil(p, view, tool, u):
    """鉛筆で描いている線 (曲線にあてはめた形) を見せる。"""
    pts = getattr(tool, "preview", None)
    if not pts or len(pts) < 2:
        return
    rp = view.to_region(np.asarray(pts, np.float64))
    p.lines(rp, 'LINE_STRIP', (1.0, 1.0, 1.0, 0.7), 3.5 * u)
    p.lines(rp, 'LINE_STRIP', PATH_COL, 1.8 * u)


def draw_text_box(p, view, tool, u):
    """文字ツールでドラッグ中の枠。"""
    d = getattr(tool, "drag", None)
    if not d or d.get("type") != 'BOX' or not d.get("moved"):
        return
    (x0, y0), (x1, y1) = d["start"], d["cur"]
    box = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    p.lines(box, 'LINE_STRIP', (1.0, 1.0, 1.0, 0.9), 1.0 * u)


def draw_text_selection(p, view, vs, img_name):
    """文字ツールで選んでいる範囲を、うっすら青く塗る。"""
    from . import text as text_mod
    sel = state.text_sel
    if sel is None or sel[0] != img_name:
        return
    _, uid, a, b = sel
    i = data.index_of_uid(vs, uid)
    if i < 0 or vs.objects[i].kind != 'TEXT':
        return
    try:
        quads = text_mod.selection_quads(vs.objects[i], a, b)
    except Exception:
        return
    tris = []
    for q in quads:
        r = [tuple(view.to_region(pt)) for pt in q]
        tris += [r[0], r[1], r[2], r[0], r[2], r[3]]
    if tris:
        p.tris(tris, (0.25, 0.55, 1.0, 0.35))


def draw_text_caret(p, view, vs, img_name, u):
    """文字ツールで打ち込み中のカーソル (縦棒)。"""
    from . import text as text_mod
    from .text_tool import caret_of
    draw_text_selection(p, view, vs, img_name)
    c = caret_of(img_name)
    if c is None:
        return
    _, uid, line, col = c
    i = data.index_of_uid(vs, uid)
    if i < 0:
        return
    ob = vs.objects[i]
    if ob.kind != 'TEXT':
        return
    try:
        seg = text_mod.caret_segment(ob, line, col)
    except Exception:
        seg = None
    if seg is None:
        return
    a = tuple(view.to_region(seg[0]))
    b = tuple(view.to_region(seg[1]))
    p.lines([a, b], 'LINES', (1.0, 1.0, 1.0, 0.9), 3.5 * u)
    p.lines([a, b], 'LINES', (0.1, 0.1, 0.1, 0.95), 1.5 * u)


def draw_isolation(p, view, vs, img_name, u):
    """グループ編集中は、そのグループの範囲を点線風の枠で示す。"""
    iso = isolation(img_name, vs)
    if not iso:
        return
    fr = transform.selection_frame(vs, [iso])
    if fr is None:
        return
    ang, b = fr
    corners = [tuple(view.to_region(transform.frame_point(ang, b, hx, hy)))
               for hx, hy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    p.lines(corners + corners[:1], 'LINE_STRIP', (0.6, 0.6, 0.6, 0.8), 1.0 * u)


def _image_quad(view, w, h):
    """画像の四隅を画面の座標にする。"""
    a = view.to_region((0.0, 0.0))
    b = view.to_region((float(w), float(h)))
    return float(a[0]), float(a[1]), float(b[0]), float(b[1])


# 画像を貼るときの色について (2026-09-21 に実測して確定):
# - 重ね描きで「書いた値」は、そのまま画面の色になる
#   (UNIFORM_COLOR で 0.25 を書くと 0.25 が読み戻せる)
# - 自前のシェーダーでは texture() が **画像に入っている値そのまま** を返す
#   -> よって **何も変換せずに出すのが正解**
# - 標準の 'IMAGE' シェーダーはリニアに変換して出すので暗くなる (最初の不具合)。
#   sRGB へ変換し直すと今度は明るくなりすぎる (2つ目の不具合)。
# そのため、変換しない自前のシェーダーを使う。
_SRGB_VERT = """
void main()
{
  uv = texCoord;
  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);
}
"""

_SRGB_FRAG = """
void main()
{
  fragColor = texture(image, uv);
}
"""

_srgb_shader = {"made": False, "sh": None}


def _image_shader(gpu):
    """画像をそのままの色で貼るシェーダー。作れなければ標準のものを使う。

    Blender 5.x では GPUShader を直接は作れないので、GPUShaderCreateInfo で組み立てる。
    """
    if not _srgb_shader["made"]:
        _srgb_shader["made"] = True
        try:
            iface = gpu.types.GPUStageInterfaceInfo("vstroke_img_iface")
            iface.smooth('VEC2', "uv")
            info = gpu.types.GPUShaderCreateInfo()
            info.push_constant('MAT4', "ModelViewProjectionMatrix")
            info.sampler(0, 'FLOAT_2D', "image")
            info.vertex_in(0, 'VEC2', "pos")
            info.vertex_in(1, 'VEC2', "texCoord")
            info.vertex_out(iface)
            info.fragment_out(0, 'VEC4', "fragColor")
            info.vertex_source(_SRGB_VERT)
            info.fragment_source(_SRGB_FRAG)
            _srgb_shader["sh"] = gpu.shader.create_from_info(info)
        except Exception as e:
            print("[Vector Strokes] 画像用シェーダーを作れません:", e)
            _srgb_shader["sh"] = None
    return _srgb_shader["sh"] or gpu.shader.from_builtin('IMAGE')


_CLIP_FRAG = """
void main()
{
  vec4 c = texture(image, uv);
  fragColor = vec4(c.rgb, c.a * texture(clipmask, uv).a);
}
"""

_clip_shader = {"made": False, "sh": None}


def _masked_shader(gpu):
    """画像に、もう1枚の画像のアルファを掛けて貼るシェーダー (クリッピングマスクの表示用)。
    作れなければ None (マスクなしで貼る)。"""
    if not _clip_shader["made"]:
        _clip_shader["made"] = True
        try:
            iface = gpu.types.GPUStageInterfaceInfo("vstroke_clip_iface")
            iface.smooth('VEC2', "uv")
            info = gpu.types.GPUShaderCreateInfo()
            info.push_constant('MAT4', "ModelViewProjectionMatrix")
            info.sampler(0, 'FLOAT_2D', "image")
            info.sampler(1, 'FLOAT_2D', "clipmask")
            info.vertex_in(0, 'VEC2', "pos")
            info.vertex_in(1, 'VEC2', "texCoord")
            info.vertex_out(iface)
            info.fragment_out(0, 'VEC4', "fragColor")
            info.vertex_source(_SRGB_VERT)
            info.fragment_source(_CLIP_FRAG)
            _clip_shader["sh"] = gpu.shader.create_from_info(info)
        except Exception as e:
            print("[Vector Strokes] マスク用シェーダーを作れません:", e)
            _clip_shader["sh"] = None
    return _clip_shader["sh"]


# レイヤーマスク: 白で見せる・黒で隠す。透明な所は白と同じ (render.mask_values と同じ式)。
# texture() はリニアの値なので、sRGB に直してから明るさを取る
_LMASK_FRAG = """
vec3 to_srgb(vec3 c)
{
  c = clamp(c, 0.0, 1.0);
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}
void main()
{
  vec4 c = texture(image, uv);
  vec4 m = texture(clipmask, uv);
  vec3 s = to_srgb(m.rgb);            // 画像の色はストレート (他の表示と同じ)
  float lum = dot(s, vec3(0.2126, 0.7152, 0.0722));
  float v = clamp(1.0 - clamp(m.a, 0.0, 1.0) * (1.0 - lum), 0.0, 1.0);
  fragColor = vec4(c.rgb, c.a * v);
}
"""

_lmask_shader = {"made": False, "sh": None}


def _lmask_shader_get(gpu):
    """画像に、レイヤーマスクの明るさを掛けて貼るシェーダー。作れなければ None。"""
    if not _lmask_shader["made"]:
        _lmask_shader["made"] = True
        try:
            iface = gpu.types.GPUStageInterfaceInfo("vstroke_lmask_iface")
            iface.smooth('VEC2', "uv")
            info = gpu.types.GPUShaderCreateInfo()
            info.push_constant('MAT4', "ModelViewProjectionMatrix")
            info.sampler(0, 'FLOAT_2D', "image")
            info.sampler(1, 'FLOAT_2D', "clipmask")
            info.vertex_in(0, 'VEC2', "pos")
            info.vertex_in(1, 'VEC2', "texCoord")
            info.vertex_out(iface)
            info.fragment_out(0, 'VEC4', "fragColor")
            info.vertex_source(_SRGB_VERT)
            info.fragment_source(_LMASK_FRAG)
            _lmask_shader["sh"] = gpu.shader.create_from_info(info)
        except Exception as e:
            print("[Vector Strokes] レイヤーマスク用シェーダーを作れません:", e)
            _lmask_shader["sh"] = None
    return _lmask_shader["sh"]


_CHECKER_VERT = """
void main()
{
  gl_Position = ModelViewProjectionMatrix * vec4(pos, 0.0, 1.0);
}
"""

_CHECKER_FRAG = """
void main()
{
  vec2 c = floor(gl_FragCoord.xy / size);
  fragColor = (mod(c.x + c.y, 2.0) < 1.0) ? color1 : color2;
}
"""

_checker_shader = {"made": False, "sh": None}


def _checker_shader_get(gpu):
    """透明な所に出す市松模様のシェーダー (画面のピクセルで模様を決める。エディターと同じ)。
    作れなければ None。"""
    if not _checker_shader["made"]:
        _checker_shader["made"] = True
        try:
            info = gpu.types.GPUShaderCreateInfo()
            info.push_constant('MAT4', "ModelViewProjectionMatrix")
            info.push_constant('VEC4', "color1")
            info.push_constant('VEC4', "color2")
            info.push_constant('FLOAT', "size")
            info.vertex_in(0, 'VEC2', "pos")
            info.fragment_out(0, 'VEC4', "fragColor")
            info.vertex_source(_CHECKER_VERT)
            info.fragment_source(_CHECKER_FRAG)
            _checker_shader["sh"] = gpu.shader.create_from_info(info)
        except Exception as e:
            print("[Vector Strokes] 市松模様のシェーダーを作れません:", e)
            _checker_shader["sh"] = None
    return _checker_shader["sh"]


def _draw_checker(gpu, rect):
    """四角を、エディターと同じ市松模様で塗りつぶす (テーマの色と大きさ)。
    描けたら True。"""
    sh = _checker_shader_get(gpu)
    if sh is None:
        return False
    try:
        prefs = bpy.context.preferences
        ui = prefs.themes[0].user_interface
        c1, c2 = ui.transparent_checker_primary, ui.transparent_checker_secondary
        size = max(float(ui.transparent_checker_size) * float(prefs.system.pixel_size), 1.0)
    except Exception:
        c1, c2, size = (0.2, 0.2, 0.2), (0.149, 0.149, 0.149), 8.0
    # テーマの色は sRGB。自前で書いた色は画面に出るときに sRGB へ変換されるので、
    # リニアにして渡す (そのまま渡すと 0.2 が 123/255 と明るく出た。実測)。
    # 画像の方は読むときにリニアに直されるので、変換せずに貼って合う (上の注意書き)
    from . import render
    c1 = tuple(render.srgb_to_linear(v) for v in tuple(c1)[:3]) + (1.0,)
    c2 = tuple(render.srgb_to_linear(v) for v in tuple(c2)[:3]) + (1.0,)
    from gpu_extras.batch import batch_for_shader
    x0, y0, x1, y1 = rect
    batch = batch_for_shader(sh, 'TRI_FAN', {"pos": ((x0, y0), (x1, y0), (x1, y1), (x0, y1))})
    gpu.state.blend_set('NONE')
    sh.bind()
    sh.uniform_float("color1", c1)
    sh.uniform_float("color2", c2)
    sh.uniform_float("size", size)
    batch.draw(sh)
    return True


# 描いている間も、色調補正をかけた見た目で見せる (2026-09-26 ユーザー要望)。
# 補正の計算は render.adjust_rgb と同じ式を、そのままシェーダーに書き写した
# (色の対応表 (3D LUT) だと、レベル補正などの折れ目で 9/255 ずれたため)。
# 補正の値は小さな画像 (1段 6 画素 x 段数) で渡す。描いているレイヤーの補正と、
# それを含むグループ・レイヤーの補正を内側から順にかける。
# 色: texture() は画面用のリニアの値を返し、書いた値は画面で sRGB に戻る (上の注意書き)。
# 補正は見た目どおりの sRGB の値でかけるので、sRGB に直してかけ、リニアに戻して書く
_ADJUST_FRAG = """
#define PI 3.14159265358979
vec3 to_srgb(vec3 c)
{
  c = clamp(c, 0.0, 1.0);
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}
vec3 to_linear(vec3 c)
{
  c = clamp(c, 0.0, 1.0);
  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));
}
vec3 adjust(vec3 rgb, int row)
{
  vec4 e0 = texelFetch(adj, ivec2(0, row), 0);
  vec4 e1 = texelFetch(adj, ivec2(1, row), 0);
  vec4 e2 = texelFetch(adj, ivec2(2, row), 0);
  rgb = clamp(rgb, 0.0, 1.0);
  if (e0.x != 0.0) {
    rgb = to_srgb(to_linear(rgb) * exp2(e0.x));
  }
  if (e0.y != 0.0 || e0.z != 1.0 || e0.w != 1.0) {
    float span = max(e0.z - e0.y, 1e-4);
    rgb = pow(clamp((rgb - e0.y) / span, 0.0, 1.0), vec3(1.0 / max(e0.w, 1e-3)));
  }
  if (e1.x != 0.0 || e1.y != 0.0) {
    float k = tan((clamp(e1.y, -0.999, 0.999) + 1.0) * PI / 4.0);
    rgb = clamp((rgb - 0.5) * k + 0.5 + e1.x, 0.0, 1.0);
  }
  if (e1.z != 0.0) {
    float t = e1.z * 0.3;
    rgb = clamp(rgb * vec3(1.0 + t, 1.0, 1.0 - t), 0.0, 1.0);
  }
  if (e2.y > 0.5) {
    vec3 r0 = texelFetch(adj, ivec2(3, row), 0).xyz;
    vec3 r1 = texelFetch(adj, ivec2(4, row), 0).xyz;
    vec3 r2 = texelFetch(adj, ivec2(5, row), 0).xyz;
    rgb = clamp(vec3(dot(r0, rgb), dot(r1, rgb), dot(r2, rgb)), 0.0, 1.0);
  }
  if (e1.w > 0.0) {
    rgb = rgb + (1.0 - rgb) * e1.w;
  }
  else if (e1.w < 0.0) {
    rgb = rgb * (1.0 + e1.w);
  }
  if (e2.x > 0.5) {
    rgb = 1.0 - rgb;
  }
  return clamp(rgb, 0.0, 1.0);
}
void main()
{
  vec4 c = texture(image, uv);
  vec3 s = to_srgb(c.rgb);
  for (int i = 0; i < int(params.x); i++) {
    s = mix(adjust(s, i), s, texelFetch(adj, ivec2(2, i), 0).z);
  }
  float a = (c.a < params.y) ? 0.0 : c.a;
  if (params.z > 0.5) {
    a *= texture(clipmask, uv).a;
  }
  fragColor = vec4(to_linear(s), a);
}
"""

_adjust_shader = {"made": False, "sh": None}
_adjust_tex = {"key": None, "tex": None}


def _adjusted_shader(gpu):
    """色調補正をかけて貼るシェーダー (マスクも掛けられる)。作れなければ None。"""
    if not _adjust_shader["made"]:
        _adjust_shader["made"] = True
        try:
            iface = gpu.types.GPUStageInterfaceInfo("vstroke_adj_iface")
            iface.smooth('VEC2', "uv")
            info = gpu.types.GPUShaderCreateInfo()
            info.push_constant('MAT4', "ModelViewProjectionMatrix")
            info.push_constant('VEC4', "params")    # 段数, アルファのしきい値, マスクを使うか
            info.sampler(0, 'FLOAT_2D', "image")
            info.sampler(1, 'FLOAT_2D', "clipmask")
            info.sampler(2, 'FLOAT_2D', "adj")
            info.vertex_in(0, 'VEC2', "pos")
            info.vertex_in(1, 'VEC2', "texCoord")
            info.vertex_out(iface)
            info.fragment_out(0, 'VEC4', "fragColor")
            info.vertex_source(_SRGB_VERT)
            info.fragment_source(_ADJUST_FRAG)
            _adjust_shader["sh"] = gpu.shader.create_from_info(info)
        except Exception as e:
            print("[Vector Strokes] 色調補正のシェーダーを作れません:", e)
            _adjust_shader["sh"] = None
    return _adjust_shader["sh"]


def _paint_adjustments(info):
    """描いているレイヤーにかかる色調補正 (内側から順。data.adjust_values の並び)。
    上にある調整レイヤーの補正も続けてかける (不透明度は "mix" で混ぜる。
    調整レイヤーのマスクは、描いている間は見せない。筆を離すと 3D ビューには正しく出る)。"""
    canvas = bpy.data.images.get(info.get("canvas", ""))
    if canvas is None:
        return ()
    vs = canvas.vstroke
    m = data.uid_map(vs)
    uid = info.get("uid", 0)
    out = []
    for u in [uid] + data.ancestors(vs, uid, m):
        v = data.adjust_values(m.get(u))
        if v is not None:
            out.append(v)
    from . import operators
    for u in operators.adjust_layers_above(vs, uid):
        ob = m[u]
        out.append(data.adjust_values(ob) + (("mix", round(float(ob.opacity), 5)),))
    return tuple(out)


def _adjust_texture(gpu, chain):
    """補正の値をシェーダーに渡す画像 (1段 6 画素)。値が変わったときだけ作り直す。"""
    if _adjust_tex["key"] == chain and _adjust_tex["tex"] is not None:
        return _adjust_tex["tex"]
    from . import render
    rows = []
    for vals in chain:
        v = dict(vals)
        huesat = bool(v["hue"] or v["saturation"])
        mat = render._hue_sat_matrix(v["hue"], v["saturation"]) if huesat else np.eye(3)
        rows.append([v["exposure"], v["black"], v["white"], v["gamma"],
                     v["brightness"], v["contrast"], v["temperature"], v["lightness"],
                     1.0 if v["invert"] else 0.0, 1.0 if huesat else 0.0,
                     1.0 - float(v.get("mix", 1.0)), 0.0]
                    + [float(x) for r in mat for x in (r[0], r[1], r[2], 0.0)])
    flat = [float(x) for r in rows for x in r]
    buf = gpu.types.Buffer('FLOAT', len(flat), flat)
    tex = gpu.types.GPUTexture((6, len(chain)), format='RGBA32F', data=buf)
    _adjust_tex.update(key=chain, tex=tex)
    return tex


def _draw_image_rect(gpu, im, rect, blend, mask=None, mirror=None, adj=None, lum=False):
    """画像を、指定した四角に貼る (色はそのまま)。
    mask (画像) を渡すと、その画像のアルファを掛けて貼る (クリッピングマスク)。
    mirror (向き) を渡すと、元の半分をそのまま、反対の半分に反転したものを貼る
    (描いている間のミラーの見え方。マスクは元の位置で読む)。"""
    if im is None:
        return
    x0, y0, x1, y1 = rect
    if mirror is None:
        _draw_image_quad(gpu, im, ((x0, y0), (x1, y0), (x1, y1), (x0, y1)),
                         ((0, 0), (1, 0), (1, 1), (0, 1)), blend, mask, adj, lum)
        return
    for pos, uv in _mirror_quads(rect, mirror):
        _draw_image_quad(gpu, im, pos, uv, blend, mask, adj, lum)


def _mirror_quads(rect, mode):
    """ミラーの見え方: (画面の四角, 画像の uv) を2つ。1つ目が元の半分、2つ目が写した半分。"""
    x0, y0, x1, y1 = rect
    xm, ym = (x0 + x1) / 2.0, (y0 + y1) / 2.0

    def quad(ax, ay, bx, by):
        return ((ax, ay), (bx, ay), (bx, by), (ax, by))
    if mode == 'L2R':
        return [(quad(x0, y0, xm, y1), quad(0, 0, 0.5, 1)),
                (quad(xm, y0, x1, y1), quad(0.5, 0, 0, 1))]
    if mode == 'R2L':
        return [(quad(xm, y0, x1, y1), quad(0.5, 0, 1, 1)),
                (quad(x0, y0, xm, y1), quad(1, 0, 0.5, 1))]
    if mode == 'T2B':        # 上 = v の大きい方 (画面でも上)
        return [(quad(x0, ym, x1, y1), quad(0, 0.5, 1, 1)),
                (quad(x0, y0, x1, ym), quad(0, 1, 1, 0.5))]
    return [(quad(x0, y0, x1, ym), quad(0, 0, 1, 0.5)),
            (quad(x0, ym, x1, y1), quad(0, 0.5, 1, 0))]


def _draw_image_quad(gpu, im, pos, uv, blend, mask=None, adj=None, lum=False):
    try:
        tex = gpu.texture.from_image(im)
        mask_tex = gpu.texture.from_image(mask) if mask is not None else None
    except Exception:
        return
    from gpu_extras.batch import batch_for_shader
    if adj:
        sh = _adjusted_shader(gpu)
        if sh is not None:
            try:
                adj_tex = _adjust_texture(gpu, adj)
                cut = max(float(dict(v).get("alpha_cut", 0.0)) for v in adj)
                batch = batch_for_shader(sh, 'TRI_FAN', {"pos": pos, "texCoord": uv})
                gpu.state.blend_set(blend)
                sh.bind()
                sh.uniform_float("params", (float(len(adj)), cut,
                                            1.0 if mask_tex is not None else 0.0, 0.0))
                sh.uniform_sampler("image", tex)
                sh.uniform_sampler("clipmask", mask_tex if mask_tex is not None else tex)
                sh.uniform_sampler("adj", adj_tex)
                batch.draw(sh)
                return
            except Exception as e:
                print("[Vector Strokes] 色調補正をかけて表示できません:", e)
                _adjust_shader["sh"] = None      # 以後は補正なしで見せる
    if mask_tex is None:
        sh = None
    elif lum:
        sh = _lmask_shader_get(gpu)       # マスクの明るさで削る (レイヤーマスク)
    else:
        sh = _masked_shader(gpu)
    if sh is None:
        sh = _image_shader(gpu)
        mask_tex = None
    batch = batch_for_shader(sh, 'TRI_FAN', {"pos": pos, "texCoord": uv})
    gpu.state.blend_set(blend)
    sh.bind()
    sh.uniform_sampler("image", tex)
    if mask_tex is not None:
        sh.uniform_sampler("clipmask", mask_tex)
    batch.draw(sh)


def _paint_mirror(info):
    """描いているレイヤー (またはそれを含むレイヤー・グループ) のミラーの向き。無ければ None。
    キャンバスにぴったり重なっていない画像 (置いた写真など) では、ミラーの軸が合わないので見せない。"""
    canvas = bpy.data.images.get(info.get("canvas", ""))
    if canvas is None or info.get("placement", 'ALIGNED') != 'ALIGNED':
        return None
    vs = canvas.vstroke
    m = data.uid_map(vs)
    uid = info.get("uid", 0)
    for u in [uid] + data.ancestors(vs, uid, m):
        ob = m.get(u)
        if ob is not None and data.has_mirror(ob):
            return ob.fx_mirror_mode
    return None


def draw_paint_backdrop():
    """ペイント中に、他のレイヤーを正しく重ねて見せる。

    イメージエディターは「表示中の画像」しか描けないので、
    下の絵 → 今描いているレイヤー → 上の絵 の順に、画面へ貼り直す。
    描いている絵そのものは触らないので、色がずれることはない。
    """
    info = state.paint
    if not info:
        return False
    ctx = bpy.context
    space, region = ctx.space_data, ctx.region
    im = getattr(space, "image", None) if space is not None else None
    if im is None or region is None or im.name != info.get("layer"):
        return False
    if not im.vstroke.paint_owner:
        return False
    adj = _paint_adjustments(info)
    if info.get("placement") == 'SOLO':
        # 拡大・回転・遠近変形して置いた画像: 周りの絵とは向きが合わないので重ねない。
        # 補正もロックも無ければ、エディターがふつうに出している画像 (市松模様つき) をそのまま見せる
        free = bpy.data.images.get(info.get("lock_free", ""))
        keep = bpy.data.images.get(info.get("lock_keep", ""))
        if adj or free is not None:
            import gpu
            view = G.View.from_region(region, im)
            rect = _image_quad(view, *im.size)
            if getattr(space, "display_channels", 'COLOR_ALPHA') != 'COLOR':
                _draw_checker(gpu, rect)
            _draw_image_rect(gpu, im, rect, 'ALPHA', mask=free, adj=adj)
            _draw_image_rect(gpu, keep, rect, 'ALPHA', adj=adj)
            gpu.state.blend_set('NONE')
        return True
    import gpu
    w, h = im.size
    if w <= 0 or h <= 0:
        return False
    view = G.View.from_region(region, im)
    rect = _image_quad(view, w, h)
    # 周りの絵 (キャンバスの大きさ) を貼る四角。動かしただけの画像なら、その分ずらす
    canvas = bpy.data.images.get(info.get("canvas", ""))
    ox, oy = info.get("offset", (0.0, 0.0))
    cw, ch = canvas.size if canvas is not None else (w, h)
    a = view.to_region((-float(ox), -float(oy)))
    b = view.to_region((float(cw) - float(ox), float(ch) - float(oy)))
    crect = (float(a[0]), float(a[1]), float(b[0]), float(b[1]))
    # 市松模様は両方を覆う四角に敷く (エディターが出している画像を隠すため)
    urect = (min(rect[0], crect[0]), min(rect[1], crect[1]),
             max(rect[2], crect[2]), max(rect[3], crect[3]))
    below = bpy.data.images.get(info.get("below", ""))
    above = bpy.data.images.get(info.get("above", ""))
    mirror = _paint_mirror(info)
    # エディターが出している絵 (描いているレイヤーそのまま) は隠す必要がある。
    # 以前は下の絵を「塗りつぶし」で貼って隠していたが、それだと透明な所が真っ黒になり、
    # 半透明の所も不透明に見えた (2026-09-25 ユーザー報告)。そこで自前の市松模様で
    # 塗りつぶしてから、下の絵を普通に重ねる。「カラーのみ」の表示では従来どおり
    if getattr(space, "display_channels", 'COLOR_ALPHA') != 'COLOR' and _draw_checker(gpu, urect):
        _draw_image_rect(gpu, below, crect, 'ALPHA')
    else:
        _draw_image_rect(gpu, below, crect, 'NONE')
    mode = info.get("mode", 'NORMAL')
    if mode == 'LMASK':
        # 今描いているのはレイヤーマスク: そのレイヤーの中身を、描いているマスクで削って見せる
        content = bpy.data.images.get(info.get("content", ""))
        _draw_image_rect(gpu, content, crect, 'ALPHA', mask=im, lum=True)
    elif mode == 'MASK':
        # 今描いているのがマスク: 切り抜かれる中身に、いま描いている絵のアルファを掛けて見せる
        content = bpy.data.images.get(info.get("content", ""))
        _draw_image_rect(gpu, content, rect, 'ALPHA', mask=im)
    elif mode == 'CLIP':
        # 今描いているレイヤーは切り抜かれている: マスクのアルファを掛けて見せる
        clip = bpy.data.images.get(info.get("clip", ""))
        free = bpy.data.images.get(info.get("lock_free", ""))
        keep = bpy.data.images.get(info.get("lock_keep", ""))
        _draw_image_rect(gpu, im, rect, 'ALPHA', mask=free or clip,   # free はクリップ込み
                         mirror=mirror, adj=adj)
        _draw_image_rect(gpu, keep, rect, 'ALPHA', mask=clip, mirror=mirror, adj=adj)
    else:
        # 今描いているレイヤー。透明部分をロックしていれば、守る所には描いた絵を見せず、
        # 覚えておいた元の絵を見せる (ベクターに戻るとき、その通りに確定する)
        free = bpy.data.images.get(info.get("lock_free", ""))
        keep = bpy.data.images.get(info.get("lock_keep", ""))
        _draw_image_rect(gpu, im, rect, 'ALPHA', mask=free, mirror=mirror, adj=adj)
        _draw_image_rect(gpu, keep, rect, 'ALPHA', mirror=mirror, adj=adj)
    _draw_image_rect(gpu, above, crect, 'ALPHA')      # 上にあるレイヤー
    gpu.state.blend_set('NONE')
    return True


def _draw_corner_labels_here(ctx):
    img = getattr(ctx.space_data, "image", None)
    if img is None or not img.vstroke.enabled or not state.guides_visible():
        return
    try:
        if not ctx.window_manager.vstroke_corner_list:
            return
    except AttributeError:
        return
    p = Painter(ctx.region)
    p.gpu.state.blend_set('ALPHA')
    try:
        draw_corner_labels(p, G.View.from_region(ctx.region, img), img, state.ui_scale())
    except Exception as e:
        print("[Vector Strokes]", e)
    p.gpu.state.blend_set('NONE')


def draw_overlay():
    ctx = bpy.context
    tools.remember_current_tool(ctx)      # 覚えるだけ (切り替えは session.py が受け持つ)
    if draw_paint_backdrop():
        return
    from . import empty_hint
    empty_hint.draw(ctx, Painter)          # 画像が無いのに描こうとしたときの知らせ
    if ctx.space_data is not None and ctx.region is not None:
        uv_overlay.draw(ctx.space_data, ctx.region, state.ui_scale())   # UV の線 (いちばん下)
        _draw_corner_labels_here(ctx)
    name = state.editing_image
    if not name:
        return
    if not state.guides_visible():
        return      # 枠線を隠して、仕上がりだけを見せる (ヘッダーのボタン)
    space = ctx.space_data
    region = ctx.region
    if space is None or region is None or getattr(space, "image", None) is None:
        return
    img = space.image
    if img.name != name:
        return
    vs = img.vstroke
    view = G.View.from_region(region, img)
    u = state.ui_scale()
    p = Painter(region)
    p.gpu.state.blend_set('ALPHA')
    tool = state.current_tool
    draw_isolation(p, view, vs, name, u)
    draw_snap_guides(p, view, img, u)
    if tool is None or tool.name == 'PEN':
        draw_pen(p, view, vs, u)
    elif tool.name == 'GRADIENT':
        draw_selection(p, view, vs, u, handles=False)
        draw_gradient(p, view, vs, u)
    elif tool.name == 'PENCIL':
        draw_selection(p, view, vs, u, handles=False)
        draw_pencil(p, view, tool, u)
    elif tool.name == 'TEXT':
        draw_selection(p, view, vs, u, handles=False)
        draw_text_frames(p, view, vs, u)
        draw_text_caret(p, view, vs, name, u)
        draw_text_box(p, view, tool, u)
    else:
        draw_text_frames(p, view, vs, u)
        cropping = state.crop_edit is not None and state.crop_edit[0] == name
        draw_selection(p, view, vs, u, handles=(tool.name == 'SELECT' and not cropping))
        if tool.name == 'SELECT':
            draw_crop(p, view, vs, u)
            draw_corner_widgets(p, view, vs, u)
            draw_image_corners(p, view, vs, tool, u)
        d = tool.drag
        if d is not None and d.get("type") == 'MARQUEE' and d.get("moved"):
            (x0, y0), (x1, y1) = d["start"], d["cur"]
            box = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
            p.lines(box, 'LINE_STRIP', (1.0, 1.0, 1.0, 0.9), 1.0 * u)
    p.gpu.state.blend_set('NONE')


def register():
    if not bpy.app.background:
        state.draw_handle = bpy.types.SpaceImageEditor.draw_handler_add(
            draw_overlay, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    if state.draw_handle is not None:
        bpy.types.SpaceImageEditor.draw_handler_remove(state.draw_handle, 'WINDOW')
        state.draw_handle = None

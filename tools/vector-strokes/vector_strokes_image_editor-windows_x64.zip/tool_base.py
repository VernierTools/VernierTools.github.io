# SPDX-License-Identifier: GPL-3.0-or-later
"""編集ツール (選択・ペン・図形) に共通の土台。

各ツールは handle(event, mx, my, inside, view) でイベントを処理し、
'RUNNING_MODAL' / 'PASS_THROUGH' / 'FINISHED' を返す。
Blender とのやりとり (再描画・Undo・ツールの切り替え・確認ダイアログ) は Host を通す。
自動テストでは Host を差し替えて、偽のイベントで操作を再現する。
"""

import time

import bpy

from . import data, render, state


class Host:
    """ツールから見た「外の世界」。既定では何もしない (テスト用)。"""

    def __init__(self):
        self.undos = []
        self.switched = []
        self.converts = []
        self.messages = []
        self.size_asks = []

    def redraw(self):
        pass

    def push_undo(self, msg):
        self.undos.append(msg)

    def switch_tool(self, name, **kw):
        """別のツールに切り替える (ダブルクリックでペンへ、など)。"""
        self.switched.append((name, kw))

    def request_convert(self, img, uid):
        """図形をパスに変換してよいか確認する。"""
        self.converts.append(uid)

    def report(self, msg):
        """ユーザーへの警告 (画面下のステータスバーに出す)。"""
        self.messages.append(msg)

    def ask_shape_size(self, img, point):
        """図形ツールでクリックだけされたとき、大きさを聞く小窓を出す。"""
        self.size_asks.append((img.name, tuple(point)))


def double_click_time():
    """二度押しとみなす間隔 (秒)。Blender の設定に合わせる。"""
    try:
        return bpy.context.preferences.inputs.mouse_double_click_time / 1000.0
    except Exception:
        return 0.35


def isolation(img_name, vs):
    """グループ編集モード中のグループ uid (無ければ 0)。"""
    uid = state.isolation.get(img_name, 0)
    if uid:
        m = data.uid_map(vs)
        if uid not in m or m[uid].kind != 'GROUP':
            state.isolation.pop(img_name, None)
            return 0
    return uid


def set_isolation(img_name, uid):
    if uid:
        state.isolation[img_name] = uid
    else:
        state.isolation.pop(img_name, None)


class Tool:
    name = ""
    header = ""
    cursor = 'CROSSHAIR'

    def __init__(self, img_name, host=None):
        self.img_name = img_name
        self.host = host or Host()
        self.drag = None
        self.next_render = 0.0

    def image(self):
        return bpy.data.images.get(self.img_name)

    def redraw(self):
        self.host.redraw()

    def push_undo(self, msg):
        self.host.push_undo(msg)

    def isolation(self, vs):
        return isolation(self.img_name, vs)

    def can_create(self, vs):
        """新しいオブジェクトを作れるか (描き込み先のレイヤーがロック・非表示なら作れない)。"""
        iso = self.isolation(vs)
        target = iso or data.current_layer(vs)
        if target and not data.is_editable(vs, target):
            self.host.report("描き込み先のレイヤー (またはグループ) がロック中か非表示です")
            return False
        return True

    def maybe_render(self, img, force=False):
        """ドラッグ中の再描画。重い画像では間引く。"""
        now = time.perf_counter()
        if not force:
            if not img.vstroke.live_update or now < self.next_render:
                self.redraw()
                return
        t0 = time.perf_counter()
        render.render_image(img)
        dt = time.perf_counter() - t0
        self.next_render = time.perf_counter() + max(0.03, dt * 1.5)

    # --- 二度押し (ダブルクリック) の検出 ---
    # Blender の DOUBLE_CLICK イベントはモーダル中に届かないことがあるため、
    # 押した時刻と場所を自分で覚えて判断する (v0.18.1。ユーザー報告で発覚)
    def double_press(self, mx, my):
        """前の押下から続けて同じ場所を押したか。押した記録も残す。"""
        now = time.perf_counter()
        last = getattr(self, "_last_press", None)
        self._last_press = (now, mx, my)
        if last is None:
            return False
        dt = now - last[0]
        near = abs(mx - last[1]) <= 6.0 * state.ui_scale() and \
            abs(my - last[2]) <= 6.0 * state.ui_scale()
        if dt <= double_click_time() and near:
            self._last_press = None      # 3回目を続けて拾わない
            return True
        return False

    def cursor_at(self, view, mx, my):
        return self.cursor

    def handle(self, event, mx, my, inside, view):
        return 'PASS_THROUGH'

# SPDX-License-Identifier: GPL-3.0-or-later
"""角ごとの丸め (Illustrator の「ライブコーナー」) の操作。

- 尖った角には小さな丸印が出る。これをドラッグすると丸みが変わる
- 角に近づけるほど丸みが小さく、離すほど大きくなる (最大は辺の長さの半分まで)
- 形のデータ (点の位置) は変わらない。丸めは描くときに反映される (geometry.apply_corners)
"""

import math

from . import data, geometry as G

WIDGET_MIN = 18.0      # 丸印を出す最小の距離 (画面上のピクセル)


def sharp_corners(ob):
    """丸められる角の一覧。[(si, pi, 角の点, 前の点, 次の点)]"""
    out = []
    if ob is None or ob.kind != 'PATH':
        return out
    for si, sp in enumerate(ob.subpaths):
        pts = sp.points
        n = len(pts)
        if n < 3:
            continue
        for pi, pt in enumerate(pts):
            if not sp.closed and pi in (0, n - 1):
                continue
            co = tuple(pt.co)
            if not (G.same_point(pt.handle_left, co) and G.same_point(pt.handle_right, co)):
                continue        # 曲線の点は対象外 (Illustrator と同じ)
            out.append((si, pi, co, tuple(pts[(pi - 1) % n].co), tuple(pts[(pi + 1) % n].co)))
    return out


def labeled_corners(ob):
    """番号付きの丸められる角。[(番号の文字, si, pi, 角の点, 前の点, 次の点)]
    番号はパスの点の順。穴あきなどでパスが2つ以上に分かれていれば「2-1」のように分ける。
    サイドバーの「各角の丸み」とキャンバスの番号で同じものを使う。"""
    sharp = sharp_corners(ob)
    multi = len({c[0] for c in sharp}) > 1
    out, count = [], {}
    for si, pi, co, a, b in sharp:
        count[si] = count.get(si, 0) + 1
        label = "%d-%d" % (si + 1, count[si]) if multi else str(count[si])
        out.append((label, si, pi, co, a, b))
    return out


def inner_dir(co, a, b):
    """角の内側へ向かう向き (単位ベクトル)。取れなければ None。"""
    d = _dirs(co, a, b)
    return d[3] if d is not None else None


def _dirs(co, a, b):
    da = G._unit((a[0] - co[0], a[1] - co[1]))
    db = G._unit((b[0] - co[0], b[1] - co[1]))
    if da == (0.0, 0.0) or db == (0.0, 0.0):
        return None
    cosang = max(min(da[0] * db[0] + da[1] * db[1], 1.0), -1.0)
    ang = math.acos(cosang)
    if ang < 1e-3 or abs(ang - math.pi) < 1e-3:
        return None
    u = G._unit((da[0] + db[0], da[1] + db[1]))      # 内側へ向かう二等分線
    if u == (0.0, 0.0):
        return None
    return da, db, ang, u


def max_radius(co, a, b):
    """その角に付けられる最大の丸み。"""
    d = _dirs(co, a, b)
    if d is None:
        return 0.0
    _da, _db, ang, _u = d
    la = math.hypot(a[0] - co[0], a[1] - co[1])
    lb = math.hypot(b[0] - co[0], b[1] - co[1])
    return math.tan(ang / 2.0) * min(la, lb) * 0.5


def widget_point(co, a, b, radius, min_dist):
    """丸印を置く位置 (画像座標)。"""
    d = _dirs(co, a, b)
    if d is None:
        return None
    _da, _db, ang, u = d
    sin_half = math.sin(ang / 2.0)
    dist = (radius / sin_half) if (radius > 0.0 and sin_half > 1e-6) else 0.0
    dist = max(dist, min_dist)
    return (co[0] + u[0] * dist, co[1] + u[1] * dist)


def radius_at(co, a, b, point):
    """丸印をその位置へ動かしたときの丸み。"""
    d = _dirs(co, a, b)
    if d is None:
        return 0.0
    _da, _db, ang, u = d
    dist = (point[0] - co[0]) * u[0] + (point[1] - co[1]) * u[1]
    r = max(dist, 0.0) * math.sin(ang / 2.0)
    return min(r, max_radius(co, a, b))


def widgets(vs, uids, min_dist):
    """表示・当たり判定に使う丸印の一覧。[(uid, si, pi, 位置, 半径)]"""
    out = []
    m = data.uid_map(vs)
    for uid in uids:
        ob = m.get(uid)
        if ob is None or ob.kind != 'PATH' or not data.is_editable(vs, uid, m):
            continue
        for si, pi, co, a, b in sharp_corners(ob):
            r = float(ob.subpaths[si].points[pi].corner_radius)
            p = widget_point(co, a, b, r, min_dist)
            if p is not None:
                out.append((uid, si, pi, p, r))
    return out


def pick(vs, view, mx, my, uids, tol):
    """画面の点 (mx, my) にある丸印。無ければ None。"""
    min_dist = view.px_to_image(WIDGET_MIN)
    best, best_d = None, tol
    for uid, si, pi, p, r in widgets(vs, uids, min_dist):
        rp = view.to_region(p)
        d = math.hypot(rp[0] - mx, rp[1] - my)
        if d <= best_d:
            best, best_d = (uid, si, pi), d
    return best


def corner_info(ob, si, pi):
    """(角の点, 前の点, 次の点)。取れなければ None。"""
    if ob is None or ob.kind != 'PATH' or si >= len(ob.subpaths):
        return None
    pts = ob.subpaths[si].points
    n = len(pts)
    if n < 3 or pi >= n:
        return None
    return (tuple(pts[pi].co), tuple(pts[(pi - 1) % n].co), tuple(pts[(pi + 1) % n].co))


def target_points(vs, uids):
    """角を変える対象。選んでいる点があればその点、無ければ全部の尖った角。
    戻り値: [(uid, si, pi)]"""
    m = data.uid_map(vs)
    chosen, all_sharp = [], []
    for uid in uids:
        ob = m.get(uid)
        if ob is None or ob.kind != 'PATH':
            continue
        for si, pi, _co, _a, _b in sharp_corners(ob):
            all_sharp.append((uid, si, pi))
            if ob.subpaths[si].points[pi].select:
                chosen.append((uid, si, pi))
    return chosen or all_sharp


def set_radius(vs, refs, radius):
    m = data.uid_map(vs)
    for uid, si, pi in refs:
        ob = m.get(uid)
        if ob is None or si >= len(ob.subpaths) or pi >= len(ob.subpaths[si].points):
            continue
        info = corner_info(ob, si, pi)
        if info is None:
            continue
        r = min(float(radius), max_radius(*info))
        ob.subpaths[si].points[pi].corner_radius = max(r, 0.0)


def set_type(vs, refs, kind):
    m = data.uid_map(vs)
    for uid, si, pi in refs:
        ob = m.get(uid)
        if ob is not None and si < len(ob.subpaths) and pi < len(ob.subpaths[si].points):
            ob.subpaths[si].points[pi].corner_type = kind


def common_radius(vs, refs):
    """対象の角の丸み (ばらばらなら最初のもの)。"""
    m = data.uid_map(vs)
    for uid, si, pi in refs:
        ob = m.get(uid)
        if ob is not None and si < len(ob.subpaths) and pi < len(ob.subpaths[si].points):
            return float(ob.subpaths[si].points[pi].corner_radius)
    return 0.0


def common_type(vs, refs):
    m = data.uid_map(vs)
    for uid, si, pi in refs:
        ob = m.get(uid)
        if ob is not None and si < len(ob.subpaths) and pi < len(ob.subpaths[si].points):
            return ob.subpaths[si].points[pi].corner_type
    return 'ROUND'

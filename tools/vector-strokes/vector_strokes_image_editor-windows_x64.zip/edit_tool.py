# SPDX-License-Identifier: GPL-3.0-or-later
"""編集モードのモーダルオペレーター(Blender とのつなぎ役)。

選択・ペン・図形の3つのツールを切り替えながら動かす。各ツールの操作ロジックは
select_tool / edit_logic (ペン) / shape_tool にある。
"""

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Operator

from . import edit_logic, geometry, render, state, tools
from .gradient_tool import GradientTool
from .pencil_tool import PencilTool
from .select_tool import SelectTool
from .shape_tool import ShapeTool
from .text_tool import TextTool
from .tool_base import Host, isolation

TOOL_CLASSES = {'SELECT': SelectTool, 'PEN': edit_logic.PenTool, 'SHAPE': ShapeTool,
                'GRADIENT': GradientTool, 'TEXT': TextTool, 'PENCIL': PencilTool}

# 編集中にツールを切り替えるキー (Illustrator と同じ)
SWITCH_KEYS = {'V': ('SELECT', None), 'P': ('PEN', None),
               'M': ('SHAPE', 'RECT'), 'L': ('SHAPE', 'ELLIPSE'),
               'G': ('GRADIENT', None), 'T': ('TEXT', None)}


def window_region(area):
    for r in area.regions:
        if r.type == 'WINDOW':
            return r
    return None


def canvas_contains(area, region, mouse_x, mouse_y, ui=1.0):
    """ウィンドウ座標のマウス位置がキャンバス上か(サイドバー等の上ではないか)。"""
    mx = mouse_x - region.x
    my = mouse_y - region.y
    if not (0 <= mx < region.width and 0 <= my < region.height):
        return False
    # リージョンの重なり(Region Overlap)が有効だと、サイドバー等が
    # キャンバスの上に重なるので、その上ではキャンバス扱いしない。
    # (表示中のサイドバー/ツールバー/ヘッダーだけを対象にする)
    sp = area.spaces.active
    shown = {
        'UI': getattr(sp, "show_region_ui", False),
        'TOOLS': getattr(sp, "show_region_toolbar", False),
        'HEADER': getattr(sp, "show_region_header", True),
        'TOOL_HEADER': getattr(sp, "show_region_tool_header", False),
    }
    for r in area.regions:
        if not shown.get(r.type, False) or r.width <= 1 or r.height <= 1:
            continue
        x0, w = r.x, r.width
        if r.type == 'TOOLS':
            # ツールバーは重なりモードでは縦長の帯。ボタンの幅だけ除外
            w = min(r.width, 60 * ui)
            if r.alignment == 'RIGHT':
                x0 = r.x + r.width - w
        if x0 <= mouse_x < x0 + w and r.y <= mouse_y < r.y + r.height:
            return False
    return True


def area_is_shown(window, area):
    """そのエリアが、いまウィンドウに出ている画面 (タブ) にあるか。

    ベクター編集のモーダルは、別のタブ (ワークスペース) に移っても動き続ける。
    そのとき画面に出ていない元のイメージエディターの位置で判断すると、そこに重なった
    別のタブのエディター (3D ビューポートなど) のクリックを横取りしてしまう
    (2026-09-22 ユーザー報告「Layout タブの 3D Viewport が操作できない」)。"""
    try:
        ptr = area.as_pointer()
        return any(a.as_pointer() == ptr for a in window.screen.areas)
    except Exception:
        return False


def set_status(window, area, text):
    """操作の説明を、画面いちばん下のステータスバーに出す。

    注意: `area.header_text_set()` を使うと、その文字が「上のバー (ツールヘッダー)」を
    占領してしまい、ツールの設定 (塗り・線・図形の種類など) が出なくなる。
    説明は下のバー、ツール設定は上のバー、と分ける。"""
    try:
        window.workspace.status_text_set(text)
    except Exception:
        pass
    try:
        area.header_text_set(None)
    except Exception:
        pass


def log(*args):
    """不具合調査用の記録。ターミナルから Blender を起動すると見える。"""
    print("[Vector Strokes]", *args, flush=True)


def begin_session(op, img_name):
    """編集セッションを開始する。前のセッション (Undo 等で止まったままのもの) は無効になる。
    戻り値: 世代番号"""
    state.generation += 1
    state.editing_image = img_name
    state.current_op = op
    state.mouse = None
    state.tool_restore_pending = False
    return state.generation


def is_stale(generation):
    """そのセッションがもう無効か (別のセッションが始まっているか)。"""
    return generation != state.generation


def end_session(op):
    """セッションを終える。すでに新しいセッションが始まっていれば何もしない。"""
    if state.current_op is not None and state.current_op is not op:
        return False

    state.clear_session()
    return True


def can_start():
    """新しい編集を始められるか (止まったままの状態があっても始められる)。"""
    return True


def modal_id():
    """モーダル一覧に出る名前 (例: VSTROKE_OT_edit)。Python のクラス名とは別物。"""
    try:
        return VS_OT_edit.bl_rna.identifier
    except Exception:
        return "VSTROKE_OT_edit"


def session_alive():
    """編集のモーダル操作が本当に動いているか。"""
    if not state.editing_image:
        return False
    name = modal_id()
    try:
        for win in bpy.context.window_manager.windows:
            for op in win.modal_operators:
                if op.bl_idname == name:
                    return True
    except Exception:
        return True   # 確認できない Blender では、生きているものとして扱う
    return False


def find_area(img_name):
    """その画像を表示しているイメージエディターを探す。戻り値: (window, area) or None"""
    try:
        wm = bpy.context.window_manager
        for win in wm.windows:
            for area in win.screen.areas:
                if area.type != 'IMAGE_EDITOR':
                    continue
                sp = area.spaces.active
                img = getattr(sp, "image", None)
                if img is not None and img.name == img_name:
                    return win, area
    except Exception:
        pass
    return None


def resume_if_needed():
    """編集中のはずなのにモーダルが落ちていたら、状態を畳んで、可能なら再開する。
    (Undo はツールや内部の参照を作り直すため、モーダルが終わってしまうことがある)
    戻り値: 'ALIVE' / 'RESUMED' / 'CLEARED'"""
    if not state.editing_image or session_alive():
        return 'ALIVE' if state.editing_image else 'CLEARED'
    img_name = state.editing_image
    tool_name = state.current_tool.name if state.current_tool is not None else 'PEN'
    found = find_area(img_name)
    state.clear_session()
    if found is None:
        return 'CLEARED'
    win, area = found
    # 左ツールバーがこのアドオンのツールのままなら、編集を再開する
    try:
        mode = getattr(area.spaces.active, "ui_mode", 'VIEW')
        tid = tools.active_tool_id(bpy.context, mode)
        if tid not in tools.TOOL_NAMES or tools.TOOL_NAMES[tid] not in TOOL_CLASSES:
            return 'CLEARED'
        region = window_region(area)
        log("モーダルが落ちていたので再開します (ツール=%s)" % tool_name)
        with bpy.context.temp_override(window=win, area=area, region=region):
            bpy.ops.vstroke.edit('INVOKE_DEFAULT', tool=tool_name)
    except Exception as e:
        log("編集を再開できませんでした:", e)
        return 'CLEARED'
    return 'RESUMED' if state.editing_image else 'CLEARED'


def restore_tool_after_undo():
    """Undo でブラシ等に戻ってしまったツールを、編集中のツールに戻す。
    Undo の後はエリアの参照が無効になっていることがあるので、探し直す。"""
    if not state.editing_image or state.current_tool is None:
        return False
    found = find_area(state.editing_image)
    if found is None:
        return False
    win, area = found
    try:
        ok = tools.set_tool(win, area, tools.TOOL_IDS[state.current_tool.name])
    except Exception:
        ok = False
    if ok:
        state.tool_restore_pending = False
    return ok



class OperatorHost(Host):
    """ツールから Blender を操作するための窓口。"""

    def __init__(self, op):
        super().__init__()
        self.op = op

    def redraw(self):
        self.op.area.tag_redraw()

    def push_undo(self, msg):
        try:
            bpy.ops.ed.undo_push(message=msg)
        except Exception:
            pass

    def switch_tool(self, name, **kw):
        self.op.switch_tool(name, sync_toolbar=True)

    def report(self, msg):
        try:
            self.op.report({'WARNING'}, msg)
        except Exception:
            print("[Vector Strokes]", msg)

    def ask_shape_size(self, img, point):
        op = self.op
        try:
            with bpy.context.temp_override(window=op.window, area=op.area,
                                           region=window_region(op.area)):
                bpy.ops.vstroke.shape_size('INVOKE_DEFAULT', image=img.name,
                                           x=float(point[0]), y=float(point[1]))
        except Exception as e:
            print("[Vector Strokes]", e)

    def request_convert(self, img, uid):
        op = self.op
        try:
            with bpy.context.temp_override(window=op.window, area=op.area,
                                           region=window_region(op.area)):
                bpy.ops.vstroke.shape_to_path('INVOKE_DEFAULT', image=img.name, uid=uid)
        except Exception as e:
            print("[Vector Strokes]", e)


class VS_OT_edit(Operator):
    """イメージエディター上でベクター図形を編集する"""
    bl_idname = "vstroke.edit"
    bl_label = "ベクター編集ツール"

    from_tool: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    tool: EnumProperty(items=(('SELECT', "選択", ""), ('PEN', "ペン", ""),
                              ('SHAPE', "図形", ""), ('GRADIENT', "グラデーション", ""),
                              ('TEXT', "文字", ""), ('PENCIL', "鉛筆", "")),
                       default='PEN', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        sp = context.space_data
        if not (context.area is not None and context.area.type == 'IMAGE_EDITOR'
                and sp is not None and getattr(sp, "image", None) is not None):
            return False
        if not render.available():
            cls.poll_message_set("描画ライブラリ(Skia)を読み込めません")
            return False
        if not sp.image.vstroke.enabled:
            # まだ有効化していない画像でも、ツールを選んでクリックすれば始められる
            # (invoke で有効化する)。始められない画像 (レンダー結果など) だけ断る
            from . import operators
            why = operators.enable_problem(sp.image, deep=False)
            if why:
                cls.poll_message_set(why)
                return False
        return True

    def invoke(self, context, event):
        # ここに来た = 実行中のモーダルがこのクリックを処理しなかった、ということ。
        # 止まったままのセッションが残っていても、新しい方を優先して始める
        img = context.space_data.image
        if not img.vstroke.enabled:
            # ツールを選んでキャンバスをクリックしたら、その画像を自動で有効化する
            # (サイドバーの「ベクター編集を有効化」を押さなくてよい)
            from . import operators
            msg = operators.enable_image(img)
            if not img.vstroke.enabled:
                self.report({'ERROR'}, msg or "ベクター編集を有効化できませんでした")
                return {'CANCELLED'}
            if msg:
                self.report({'WARNING'}, msg)
            if operators.enable_note["text"]:
                self.report({'INFO'}, operators.enable_note["text"])
            self.host_undo_note = "Enable Vector Editing"
        else:
            self.host_undo_note = ""
        self.area = context.area
        self.window = context.window
        self.img_name = img.name
        self.cursor_name = None
        self.host = OperatorHost(self)
        sp = context.space_data
        self.prev_ui_mode = getattr(sp, "ui_mode", "")
        self.prev_tool_header = getattr(sp, "show_region_tool_header", None)
        # ベクター編集中は「表示」モードにする。ペイント用の表示 (ブラシ設定・丸いカーソル) が
        # 消えて、画面がすっきりする (Affinity のモード切り替えに近い)
        mode_changed = False
        try:
            if self.prev_ui_mode != 'VIEW':
                sp.ui_mode = 'VIEW'
                mode_changed = True
        except Exception:
            pass
        # ツールの設定を出す細いバー (上のバー) を出す
        try:
            sp.show_region_tool_header = True
        except Exception:
            pass
        self.tool_mode = getattr(sp, "ui_mode", 'VIEW')
        self.tool_obj = None
        self.gen = begin_session(self, img.name)
        log("編集開始: 画像=%s ツール=%s 世代=%d ツールバー経由=%s"
            % (img.name, self.tool, self.gen, self.from_tool))
        # サイドバーのボタンから始めた場合も、左ツールバーを同じツールにする。
        # (ブラシではないツールが選ばれるので、ペイントモードの丸いカーソルが消える)
        # モードを切り替えたときは、切り替え先のツールバーでも同じツールを選び直す
        self.switch_tool(self.tool, sync_toolbar=(not self.from_tool) or mode_changed)
        context.area.tag_redraw()
        if self.host_undo_note:
            self.host.push_undo(self.host_undo_note)   # 有効化も Undo で戻せるように
        if self.from_tool:
            # ツールを選んだ状態でのクリックは、そのまま最初の操作として扱う
            res = self.modal(context, event)
            if res & {'FINISHED', 'CANCELLED'}:
                # モーダルを Blender に登録する**前に**終える。登録したあとで invoke から
                # FINISHED を返すと、Blender は操作を解放するのに登録は残り、次のイベントで
                # 解放済みの操作を触ってクラッシュする (2026-09-25 ユーザー報告
                # 「ペンでクリックしたら落ちる」。記録と同じ wm_handler_operator_call で落ちる
                # ことを tests/ui_first_brush.py の FORCE=1 で再現して確認)
                return res
        # 登録は最後に1回だけ。これより後で FINISHED / CANCELLED を返さないこと
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _open_context_menu(self):
        try:
            with bpy.context.temp_override(window=self.window, area=self.area,
                                           region=window_region(self.area)):
                bpy.ops.wm.call_menu(name="VS_MT_context")
        except Exception as e:
            log("右クリックのメニューを開けませんでした:", e)

    def _ensure_area(self):
        """自分が使っているエリアがまだ有効か確認する。
        Undo の後は参照が作り直されることがあるので、その時は探し直す。"""
        try:
            sp_img = self.area.spaces.active.image
            if sp_img is not None and sp_img.name == self.img_name:
                return True
        except Exception:
            pass
        found = find_area(self.img_name)
        if found is None:
            return False
        self.window, self.area = found
        self.tool_mode = getattr(self.area.spaces.active, "ui_mode", 'VIEW')
        return True

    # --- ツール ---
    def switch_tool(self, name, sync_toolbar=True, shape_type=None):
        if self.tool_obj is not None and self.tool_obj.name == name and shape_type is None:
            return
        if shape_type is not None:
            try:
                bpy.context.window_manager.vstroke_tool.shape_type = shape_type
            except Exception:
                pass
        if self.tool_obj is None or self.tool_obj.name != name:
            self._leave_tool()
            self.tool_obj = TOOL_CLASSES[name](self.img_name, self.host)
        state.current_tool = self.tool_obj
        self.tool = name
        self._update_header()
        if sync_toolbar:
            tools.set_tool(self.window, self.area, tools.TOOL_IDS[name])
        self.area.tag_redraw()

    def _leave_tool(self):
        """今のツールに「ここで終わり」と伝える (文字を打っている途中なら確定する)。"""
        leave = getattr(self.tool_obj, "leave", None)
        if leave is not None:
            try:
                leave()
            except Exception as e:
                log("ツールの後始末に失敗:", e)

    def _update_header(self):
        text = self.tool_obj.header
        img = bpy.data.images.get(self.img_name)
        if img is not None and isolation(self.img_name, img.vstroke):
            text = "[グループ編集中: Esc で戻る]  " + text
        set_status(self.window, self.area, text)

    def _set_cursor(self, name):
        if name == self.cursor_name:
            return
        self.cursor_name = name
        try:
            if name is None:
                self.window.cursor_modal_restore()
            else:
                self.window.cursor_modal_set(name)
        except Exception:
            pass

    def _finish(self, context, restore_tool=False, reason="ユーザー操作", keep_mode=False):
        log("編集終了: 理由=%s 世代=%d ツール=%s"
            % (reason, getattr(self, "gen", -1),
               self.tool_obj.name if self.tool_obj else "?"))
        self._leave_tool()
        if state.crop_edit is not None:
            from .select_tool import end_crop_edit
            end_crop_edit()
        end_session(self)
        set_status(self.window, self.area, None)
        try:
            sp = self.area.spaces.active
            self.area.tag_redraw()
        except Exception:
            sp = None
        self._set_cursor(None)
        if restore_tool:
            tools.restore_previous_tool(self.window, self.area, self.tool_mode)
        # ペイントに入った / 入るところで終わるときは、表示モードを戻さない
        # (戻すと、入ったばかりのペイントから追い出されてしまう)。
        # また、ベクター編集のキャンバスを Blender のペイントモードには戻さない:
        # キャンバスは合成結果なので、そこに描いても次の描き直しで消えるだけ。
        # さらにペイントモードではツールの一覧が別なので、ブラシを押しても
        # 反応しなくなる (2026-09-22 ユーザー報告「ブラシを押しても何も起きない」の原因)
        try:
            if not state.paint and not keep_mode:
                if (sp is not None and self.prev_ui_mode and self.prev_ui_mode != 'PAINT'
                        and sp.ui_mode != self.prev_ui_mode):
                    sp.ui_mode = self.prev_ui_mode
                if sp is not None and self.prev_tool_header is False:
                    sp.show_region_tool_header = False
        except Exception:
            pass
        return {'FINISHED'}

    def modal(self, context, event):
        if is_stale(self.gen):
            return {'CANCELLED'}     # 新しい編集が始まっている。静かに終わる
        img = bpy.data.images.get(self.img_name)
        if img is None or not img.vstroke.enabled:
            return self._finish(context, reason="画像が無くなった/無効になった")
        if state.paint:
            return self._finish(context, reason="ペイントに入った")   # サイドバーのボタンから入った
        if not self._ensure_area():
            # 別のテクスチャに切り替えた: この入力は捨てずに渡す。渡さないと、切り替えた先で
            # 最初に押したクリックが「前の編集を終える」だけに使われ、2回押さないと
            # 切り替えた先の編集が始まらなかった (2026-10-18 テクスチャをまたぐ貼り付けで気づいた)
            self._finish(context, reason="イメージエディターが見つからない")
            return {'FINISHED', 'PASS_THROUGH'}
        if getattr(self.area.spaces.active, "ui_mode", 'VIEW') != 'VIEW':
            # ヘッダーでペイントモードにされた。ここで終えて、その場でペイントレイヤーに描く状態に
            # する (続けるとクリックやキーをベクター編集が取ってしまう)
            self._finish(context, reason="ペイントモードになった", keep_mode=True)
            from . import session
            session.enter_paint(self.window, self.area)
            return {'FINISHED'}
        if not area_is_shown(self.window, self.area):
            # 別のタブを見ている間は何もしない (操作は全部そのタブのエディターへ渡す)。
            # 編集は終えずに待つので、元のタブに戻ればそのまま続けられる
            if self.cursor_name is not None:
                self._set_cursor(None)
            return {'PASS_THROUGH'}
        if state.exit_request:
            state.exit_request = False
            return self._finish(context, restore_tool=True, reason="右クリックのメニューから終了")
        t = self.tool_obj
        # 左ツールバーでの切り替え
        if t.drag is None:
            tid = tools.active_tool_id(context, self.tool_mode)
            if tid in tools.TOOL_NAMES and tools.TOOL_NAMES[tid] not in TOOL_CLASSES:
                # ブラシツールに切り替えられた -> ベクター編集はここで終え、その場でペイントに入る
                # (タイマーに任せると、重い場面ではそのあとの入力が先に処理されてしまう。
                #  session の「見張り役」の説明を参照)。この入力は使い切る
                self._finish(context, reason="ブラシツールに切り替わった", keep_mode=True)
                from . import session
                session.enter_paint(self.window, self.area)
                return {'FINISHED'}
            if tid in tools.TOOL_NAMES:
                if tools.TOOL_NAMES[tid] != t.name:
                    self.switch_tool(tools.TOOL_NAMES[tid], sync_toolbar=False)
                    t = self.tool_obj
                state.tool_restore_pending = False
            elif tid and state.tool_restore_pending:
                # Undo がツールも元に戻した -> 編集中のツールに戻して続ける
                restore_tool_after_undo()
            elif tid:
                # 別のツールに切り替えた
                return self._finish(context, reason="別のツールに切り替わった (%s)" % tid)

        region = window_region(self.area)
        mx = event.mouse_x - region.x
        my = event.mouse_y - region.y
        inside = canvas_contains(self.area, region, event.mouse_x, event.mouse_y,
                                 state.ui_scale())
        view = geometry.View.from_region(region, img)
        if t.drag is None:
            self._set_cursor(t.cursor_at(view, mx, my) if inside else None)

        # キーでツールを切り替え (V / P / M / L)
        grabs = getattr(t, "grabs_keys", None)
        if (inside and t.drag is None and event.value == 'PRESS' and event.type in SWITCH_KEYS
                and not (grabs is not None and grabs())
                and not (event.ctrl or event.oskey or event.alt or event.shift)):
            name, shape = SWITCH_KEYS[event.type]
            self.switch_tool(name, shape_type=shape)
            return {'RUNNING_MODAL'}

        # 右クリック: メニュー (Illustrator・Affinity・Blender と同じ)。終了はメニューの
        # いちばん下。ドラッグの途中と文字を打っている途中は、今までどおりツールに任せる
        # (ドラッグは取り消し、文字は編集をやめる)。2026-10-17 までは右クリックで終了していた
        if (inside and event.type == 'RIGHTMOUSE' and event.value == 'PRESS'
                and t.drag is None and getattr(t, "edit", None) is None):
            self._open_context_menu()
            return {'RUNNING_MODAL'}

        res = t.handle(event, mx, my, inside, view)
        if res == 'FINISHED':
            return self._finish(context, restore_tool=True, reason="Esc")
        if event.type in {'ESC', 'LEFTMOUSE'}:
            self._update_header()  # グループ編集モードの出入り
        return {res}


def register():
    bpy.utils.register_class(VS_OT_edit)


def unregister():
    bpy.utils.unregister_class(VS_OT_edit)

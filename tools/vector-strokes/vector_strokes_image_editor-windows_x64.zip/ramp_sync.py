# SPDX-License-Identifier: GPL-3.0-or-later
"""グラデーションの分岐点を、Blender のカラーランプで編集する。

カラーランプ (template_color_ramp) は単独では置けず、ID の中の ColorRamp にしか使えない。
そこで隠しブラシ (名前が "." で始まる。is_runtime_data なので保存されない) の gradient を
「表示・編集用の窓」として持ち、分岐点 (stops) と行き来させる。正しいデータは stops だけ。
2026-10-17 に別アドオン (vs_ramp_proto) で試作し、本物のクリックと Undo/Redo で確かめた。

Undo (試作で確かめたこと):
- テクスチャのランプだと、触った瞬間に Blender が Undo の段を積む。こちらが stops に
  写せるのはそのあと (タイマー) なので、その段には「ランプは新しい・stops は古い」が残る。
  しかも Blender の Undo は「前の段と同じデータは読み直さない」ので、段に入らなかった
  stops の書き換えが Undo のあとまで残り、Undo が効かないように見えた
- テクスチャを is_runtime_data にしても段は積まれる (中身の無い空の段になる)
- ブラシは Blender が Undo の対象にしない ID なので、ランプのドラッグ・数値の変更では
  段が積まれない。stops への書き写しと段積みはこちらが同時に行う (1回の編集 = 1段)
- ただしランプの「+」「−」ボタンだけは、ブラシでも空の段 (Add/Delete Color Ramp Stop) を
  積む。分岐点の数が変わったらそれと分かるので、その段の前へ戻ってから自分の段を積む
  (戻った先から上は Blender が捨てる)。中身は同じ段なので、戻っても何も変わらない
- 書き写すのは、ランプがしばらく (SETTLE 秒) 変わらなくなってから。ドラッグの途中で
  段が何個も積まれないように
- Undo・Redo のあとは stops が正しいので、ランプを stops から作り直す
  (書き写す前の触りかけのランプは捨てる)

色: ランプの色はリニア、stops は sRGB (COLOR_GAMMA)。行き来のたびに変換する。
補間: stops は直線だけなので、ランプの補間は「リニア」に戻す。
"""

import time

import bpy

PREFIX = ".VS_Ramp_"
EPS = 2e-3
MAX_ELEMENTS = 32          # Blender のカラーランプの上限
UNDO_NAME = "グラデーションを編集"
# ランプを触ったことは、どの知らせ (depsgraph・msgbus) でも届かない (使われていないテクスチャは
# depsgraph に入らない。試作で確認)。そこで、ランプが画面に出ている間だけ短い間隔で見に行く。
# 比べるのは高々 32 個の分岐点なので軽い
POLL = 0.15
SETTLE = 0.35

# 名前 -> (owner, 塗り/線を返す関数)。描くときに登録する
_wanted = {}
# 名前 -> {"owner", "ptr" (テクスチャ), "sig" (最後にそろえた中身), "dirty_since", "seen"}
_state = {}
_last_draw = [0.0]
_polling = [False]
_busy = [0]
# 書き写したあと呼ぶ (本体では描き直しに使う)。引数は塗り/線
on_commit = []


def _srgb_to_lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _lin_to_srgb(c):
    if c <= 0.0:
        return 0.0
    return c * 12.92 if c <= 0.0031308 else 1.055 * (c ** (1.0 / 2.4)) - 0.055


def _stops_sig(paint):
    return [[s.position] + [float(x) for x in s.color]
            for s in sorted(paint.stops, key=lambda s: s.position)]


def _ramp_sig(ramp):
    out = []
    for e in ramp.elements:          # Blender が位置の順に並べている
        c = e.color
        out.append([e.position, _lin_to_srgb(c[0]), _lin_to_srgb(c[1]), _lin_to_srgb(c[2]),
                    float(c[3])])
    return out


def _same(a, b):
    if a is None or b is None or len(a) != len(b):
        return False
    for ra, rb in zip(a, b):
        for x, y in zip(ra, rb):
            if abs(x - y) > EPS:
                return False
    return True


def _coll():
    return bpy.data.brushes


def ramp_of(holder):
    return holder.gradient


RAMP_PROP = "gradient"


def _holder(name, create):
    br = bpy.data.brushes.get(name)
    if br is None and create:
        br = bpy.data.brushes.new(name, mode='TEXTURE_PAINT')
    if br is not None:
        if not br.is_runtime_data:
            br.is_runtime_data = True      # 保存しない
        if br.color_type != 'GRADIENT':
            br.color_type = 'GRADIENT'     # これで gradient (カラーランプ) ができる
    return br


def _lin_color(c):
    return (_srgb_to_lin(c[0]), _srgb_to_lin(c[1]), _srgb_to_lin(c[2]), c[3])


def _update_in_place(ramp, stops):
    """数が同じなら、印を作り直さずに値だけ入れる。作り直すと「選んでいる印」が
    いちばん右に移り、開いているカラーホイールも閉じてしまう (2026-10-17 ユーザー報告)。
    位置を入れると Blender が並べ直すので、入れ終わってから合っているか確かめる。"""
    els = ramp.elements
    if len(els) != len(stops):
        return False
    for k, s in enumerate(stops):
        if abs(els[k].position - s.position) > 1e-6:
            els[k].position = s.position
    if any(abs(e.position - s.position) > 1e-6 for e, s in zip(els, stops)):
        return False
    for e, s in zip(els, stops):
        c = _lin_color(s.color)
        if any(abs(a - b) > 1e-6 for a, b in zip(e.color, c)):
            e.color = c
    return True


def stops_to_ramp(paint, ramp):
    stops = sorted(paint.stops, key=lambda s: s.position)[:MAX_ELEMENTS]
    if not stops:
        return
    if ramp.interpolation != 'LINEAR':
        ramp.interpolation = 'LINEAR'
    if ramp.color_mode != 'RGB':
        ramp.color_mode = 'RGB'
    if _update_in_place(ramp, stops):
        return
    # 数が違うときは作り直す。位置を入れるたびに Blender が並べ直す (手元の参照がずれる)
    # ので、1つだけ残して作り直す。new() は位置の順の所に入る
    els = ramp.elements
    while len(els) > 1:
        els.remove(els[-1])
    els[0].position = stops[0].position
    for s in stops[1:]:
        els.new(s.position)
    for e, s in zip(ramp.elements, stops):
        e.color = _lin_color(s.color)


def sig_to_stops(sig, paint):
    """そろえた中身 (位置と sRGB の色の並び) を stops に書く。描き直しは1回にまとめる。"""
    from . import render
    with render.suspended():
        _sig_to_stops(sig, paint)
    render.request_render(paint.id_data)


def _sig_to_stops(sig, paint):
    while len(paint.stops) > len(sig):
        paint.stops.remove(len(paint.stops) - 1)
    while len(paint.stops) < len(sig):
        paint.stops.add()
    for s, row in zip(paint.stops, sig):
        s.position = row[0]
        s.color = tuple(row[1:5])
    if paint.active_stop >= len(paint.stops):
        paint.active_stop = max(len(paint.stops) - 1, 0)


def _rebuild(name, owner, paint):
    """stops からランプを作り直す (Undo の段は積まない)。"""
    tex = _holder(name, create=True)
    stops_to_ramp(paint, ramp_of(tex))
    _state[name] = {"owner": owner, "ptr": tex.as_pointer(),
                    "sig": _ramp_sig(ramp_of(tex)), "dirty_since": None, "seen": None}


def _sync_one(name, owner, paint, now, after_undo=False):
    """1つのランプをそろえる。
    戻り値: (画面の描き直しが要るか, 書き写す中身 (無ければ None), 空の段の数)"""
    tex = _holder(name, create=False)
    st = _state.get(name)
    if (tex is None or st is None or st["owner"] != owner
            or st["ptr"] != tex.as_pointer() or after_undo):
        _rebuild(name, owner, paint)
        return True, None, 0
    ramp = ramp_of(tex)
    if ramp.interpolation != 'LINEAR' or ramp.color_mode != 'RGB':
        ramp.interpolation = 'LINEAR'      # 直線しか描けないので戻す
        ramp.color_mode = 'RGB'
    rs = _ramp_sig(ramp)
    if not _same(rs, st["sig"]):
        # 分岐点の数が変わった = ランプの「+」「−」ボタン。このボタンだけは、Undo の対象で
        # なくても Blender が段 (何も変わらない空の段) を積む。すぐ書き写し、空の段は消す
        dead = abs(len(rs) - len(st["sig"] or []))
        if dead:
            return True, rs, dead
        # ドラッグ・数値: しばらく変わらなくなってから書き写す (ドラッグ中は待つ)
        if not _same(rs, st["seen"]):
            st["seen"] = rs
            st["dirty_since"] = now
            return False, None, 0
        if now - st["dirty_since"] < SETTLE:
            return False, None, 0
        return True, rs, 0
    st["seen"] = None
    st["dirty_since"] = None
    if not _same(_stops_sig(paint), st["sig"]):
        # stops の方が変わった (数値・キャンバスのツール) → ランプを合わせる
        _rebuild(name, owner, paint)
        return True, None, 0
    return False, None, 0


_internal_undo = [False]


def internal_undo():
    return _internal_undo[0]


def _drop_dead_steps(n):
    """「+」「−」ボタンが積んだ空の段を消す: その段の前へ戻り (中身は同じなので何も
    変わらない)、続けて自分の段を積むと、戻った先から上の段は Blender が捨てる。"""
    win = bpy.context.window or next(iter(bpy.context.window_manager.windows), None)
    if win is None:
        return
    _internal_undo[0] = True
    try:
        with bpy.context.temp_override(window=win):
            for _ in range(n):
                bpy.ops.ed.undo()
    except Exception as e:
        print("[ramp_sync] undo:", e)
    finally:
        _internal_undo[0] = False


def _run(after_undo=False):
    if _busy[0]:
        return
    _busy[0] += 1
    redraw = False
    commits = []          # (名前, owner, getter, 中身, 空の段の数)
    now = time.monotonic()
    try:
        for name, (owner, getter) in list(_wanted.items()):
            try:
                paint = getter()
            except Exception:
                paint = None
            if paint is None or paint.paint_type == 'SOLID':
                continue
            try:
                r, sig, dead = _sync_one(name, owner, paint, now, after_undo)
            except Exception as e:      # 窓が壊れていても本体は止めない
                print("[ramp_sync]", e)
                continue
            redraw |= r
            if sig is not None:
                commits.append((name, owner, getter, sig, dead))
        if commits:
            dead = max(c[4] for c in commits)
            if dead:
                _drop_dead_steps(dead)
            # Undo で塗り/線の参照が変わることがあるので、取り直してから書く
            for name, owner, getter, sig, _d in commits:
                paint = getter()
                if paint is None:
                    continue
                sig_to_stops(sig, paint)
                # ランプはもう同じ中身なので作り直さない (選んでいる印・開いている
                # カラーホイールをそのままにする)。「+」「−」の空の段を消す Undo で
                # ブラシが作り直されていたときだけ作り直す
                st = _state.get(name)
                tex = _holder(name, create=False)
                if st is not None and tex is not None and st["ptr"] == tex.as_pointer()                         and st["owner"] == owner:
                    st["sig"] = sig
                    st["seen"] = None
                    st["dirty_since"] = None
                else:
                    _rebuild(name, owner, paint)
                for fn in on_commit:
                    try:
                        fn(paint)
                    except Exception as e:
                        print("[ramp_sync]", e)
            # 書き写しと段積みを同じ時に行う (1回の編集 = Undo の1段)
            try:
                bpy.ops.ed.undo_push(message=UNDO_NAME)
            except Exception as e:
                print("[ramp_sync] undo_push:", e)
            redraw = True
    finally:
        _busy[0] -= 1
    if redraw:
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                a.tag_redraw()


def is_ready(name, owner):
    """描くときに使う: そのランプがもう owner のものになっているか。"""
    tex = _coll().get(name)
    st = _state.get(name)
    return (tex is not None and st is not None and st["owner"] == owner
            and st["ptr"] == tex.as_pointer())


def holder_for_draw(name):
    return _coll().get(name)


def want(name, owner, getter):
    """描くときに呼ぶ (書き換えはしない)。getter() はその塗り/線を返す (無ければ None)。"""
    _wanted[name] = (owner, getter)
    _last_draw[0] = time.monotonic()
    if not _polling[0]:
        _polling[0] = True
        bpy.app.timers.register(_poll, first_interval=0.0)


def _sidebar_open():
    """イメージエディターのサイドバーがどこかで開いているか (見張りを続けるかの目安)。
    Blender は変化の無い所を描き直さないので、「しばらく描かれない」だけでは止められない。"""
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == 'IMAGE_EDITOR' and getattr(a.spaces.active, "show_region_ui", False):
                return True
    return False


def _poll():
    """ランプが出ている間だけ動く見張り。サイドバーが閉じて、しばらく描かれなければ止まる。"""
    if time.monotonic() - _last_draw[0] > 2.0 and not _sidebar_open():
        _polling[0] = False
        _wanted.clear()
        return None
    _run()
    return POLL


def _on_undo(*_args):
    # Undo・Redo のあとは stops が正しい。触りかけのランプは捨てて作り直す
    if _internal_undo[0]:
        return
    if _wanted:
        bpy.app.timers.register(lambda: _run(after_undo=True) and None, first_interval=0.0)


def register():
    for h in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo not in h:
            h.append(_on_undo)


def unregister():
    if bpy.app.timers.is_registered(_poll):
        bpy.app.timers.unregister(_poll)
    _polling[0] = False
    for h in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo in h:
            h.remove(_on_undo)
    _wanted.clear()
    _state.clear()

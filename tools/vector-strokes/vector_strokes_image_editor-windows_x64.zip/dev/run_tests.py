# SPDX-License-Identifier: GPL-3.0-or-later
"""dev/tests のテストを、ふだんの Blender の設定を汚さずにまとめて流す。

    python dev/run_tests.py --blender "C:/Program Files/Blender Foundation/Blender 5.2/blender.exe"
    python dev/run_tests.py --blender /Applications/Blender.app/Contents/MacOS/Blender -k b_
    python dev/run_tests.py --no-gui          # -b のテストだけ (速い。画面に何も出ない)

やること:
  1. 作業用フォルダ (--work、既定は一時フォルダ) に試験用のユーザー設定 ur/ を作り、
     このアドオンを ur/extensions/user_default/ へコピーする
  2. wheels/ から今のパソコン用の wheel を pylib/ へ展開する (テストが sys.path に足す)
  3. b_*.py は `blender -b`、gui_*.py は `blender --enable-event-simulate` (画面が出る) で
     1本ずつ流し、出力の「RESULT PASS」を見る

テストを書くときの決まりは HANDOFF.md の「テスト」を参照。
"""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON = os.path.dirname(HERE)
TESTS = os.path.join(HERE, "tests")
ID = "vector_strokes_image_editor"


def wheel_tag():
    if sys.platform == "win32":
        return "win_amd64"
    if sys.platform == "darwin":
        return "macosx"
    return "linux"


def prepare(work):
    ur = os.path.join(work, "ur")
    dst = os.path.join(ur, "extensions", "user_default", ID)
    if os.path.isdir(dst):
        shutil.rmtree(dst)
    shutil.copytree(ADDON, dst, ignore=shutil.ignore_patterns("__pycache__", "dev", "*.zip"))
    pylib = os.path.join(work, "pylib")
    if not os.path.isdir(pylib):
        os.makedirs(pylib)
        tag = wheel_tag()
        for f in sorted(os.listdir(os.path.join(ADDON, "wheels"))):
            if f.endswith(".whl") and tag in f:
                with zipfile.ZipFile(os.path.join(ADDON, "wheels", f)) as z:
                    z.extractall(pylib)
    for d in ("out", "tmp"):
        os.makedirs(os.path.join(work, d), exist_ok=True)
    return ur, pylib


def run_one(blender, work, ur, pylib, name, timeout):
    # 前のテストが保存した userpref.blend が残ると、次の -b でアドオンが
    # sys.path に wheel を足す前に読み込まれ、skia が無いまま動いてしまう
    shutil.rmtree(os.path.join(ur, "config"), ignore_errors=True)
    tmp = os.path.join(work, "tmp")
    env = dict(os.environ, BLENDER_USER_RESOURCES=ur, TEMP=tmp, TMP=tmp, TMPDIR=tmp)
    mode = ["-b"] if name.startswith("b_") else ["--enable-event-simulate"]
    cmd = [blender, *mode, "-noaudio", os.path.join(TESTS, "empty.blend"),
           "--python", os.path.join(TESTS, name + ".py"), "--",
           pylib, os.path.join(work, "out")]
    try:
        p = subprocess.run(cmd, env=env, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
        text = p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        text = (e.stdout or "") if isinstance(e.stdout, str) else ""
        text += "\nTIMEOUT"
    with open(os.path.join(work, "out", name + ".log"), "w", encoding="utf-8") as f:
        f.write(text)
    results = [ln.strip() for ln in text.splitlines() if ln.strip().startswith("RESULT")]
    return results[-1] if results else "RESULT なし (out/%s.log を見る)" % name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--blender", default=os.environ.get("BLENDER", "blender"))
    ap.add_argument("--work", default=os.path.join(tempfile.gettempdir(), "vstroke_tests"))
    ap.add_argument("-k", default="", help="名前にこの文字を含むテストだけ流す")
    ap.add_argument("--no-gui", action="store_true", help="-b のテストだけ")
    ap.add_argument("--timeout", type=int, default=300)
    a = ap.parse_args()
    names = sorted(f[:-3] for f in os.listdir(TESTS)
                   if f.endswith(".py") and (f.startswith("b_") or f.startswith("gui_")))
    names = [n for n in names if a.k in n and not (a.no_gui and n.startswith("gui_"))]
    os.makedirs(a.work, exist_ok=True)
    ur, pylib = prepare(a.work)
    print("作業フォルダ:", a.work)
    bad = 0
    for n in names:
        r = run_one(a.blender, a.work, ur, pylib, n, a.timeout)
        ok = r == "RESULT PASS"
        bad += not ok
        print("%-18s %s" % (n, r))
    print("全 %d 本、失敗 %d 本" % (len(names), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())

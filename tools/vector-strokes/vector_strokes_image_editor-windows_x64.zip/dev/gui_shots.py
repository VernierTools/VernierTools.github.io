"""GUI の Blender でサイドバーを状態ごとに撮る。
使い方: blender --enable-event-simulate empty.blend --python gui_shots.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
os.makedirs(OUT, exist_ok=True)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "log.txt"), "w", encoding="utf-8")


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def area_img():
    for a in bpy.context.screen.areas:
        if a.type == 'IMAGE_EDITOR':
            return a
    return None


def ctx():
    a = area_img()
    return dict(window=bpy.context.window, area=a,
                region=next(r for r in a.regions if r.type == 'WINDOW'))


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    pkg = sys.modules[MOD]
    ui = sys.modules[MOD + ".ui"]
    # Vector タブは選べない (active_panel_category が読み取り専用) ので、Tool タブへ付け替える
    for c in ui.classes:
        if isinstance(c, type) and issubclass(c, bpy.types.Panel) and c.bl_region_type == 'UI':
            bpy.utils.unregister_class(c)
            c.bl_category = "Tool"
            bpy.utils.register_class(c)
    # いちばん大きいエリアをイメージエディターに
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    img = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    img.generated_color = (0.9, 0.9, 0.95, 1.0)
    sp = big.spaces.active
    sp.image = img
    sp.show_region_ui = True
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.enable()
    say("enabled", img.vstroke.enabled, len(img.vstroke.objects))
    return pkg


def data_mod():
    return sys.modules[MOD + ".data"]


def vs():
    return bpy.data.images["Canvas"].vstroke


def select_only(uids):
    v = vs()
    for ob in v.objects:
        ob.select = ob.uid in uids
    d = data_mod()
    if uids:
        d.set_active(v, d.index_of_uid(v, uids[-1]))
    else:
        d.set_active(v, -1)


def make_path(name, closed=True):
    d = data_mod()
    v = vs()
    i = d.new_object(v, kind='PATH')
    ob = v.objects[i]
    ob.name = name
    sp = ob.subpaths.add()
    for x, y in ((100, 100), (300, 100), (300, 300), (100, 300)):
        p = sp.points.add()
        p.co = (x, y)
        p.handle_left = (x, y)
        p.handle_right = (x, y)
    sp.closed = closed
    return ob.uid


def make_shape(name, cx, cy):
    d = data_mod()
    v = vs()
    i = d.new_object(v, kind='SHAPE')
    ob = v.objects[i]
    ob.name = name
    ob.shape_type = 'ELLIPSE' if 'ELLIPSE' in {k for k, *_ in d.SHAPE_TYPES} else 'RECT'
    ob.center = (cx, cy)
    ob.size = (150, 150)
    return ob.uid


def ob_of(uid):
    d = data_mod()
    return vs().objects[d.index_of_uid(vs(), uid)]


S = {}


def st_empty():
    select_only([])


def st_path():
    S["p"] = make_path("四角いパス")
    select_only([S["p"]])


def st_path_complex():
    d = data_mod()
    ob = ob_of(S["p"])
    fills = [p for p in ob.paints if p.kind == 'FILL']
    fills[0].paint_type = 'LINEAR'
    d.add_paint(ob, 'STROKE', color=(1, 1, 1, 1), width=1.0)
    ob.fx_shadow_enable = True
    ob.corner_round = 12.0
    select_only([S["p"]])


def st_two_shapes():
    S["a"] = make_shape("円 A", 200, 200)
    S["b"] = make_shape("円 B", 280, 260)
    select_only([S["a"], S["b"]])


def st_base_image():
    v = vs()
    img_obs = [ob for ob in v.objects if ob.kind == 'IMAGE']
    say("images:", [o.name for o in img_obs])
    select_only([])
    d = data_mod()
    d.set_active(v, d.index_of_uid(v, img_obs[0].uid))


def st_layer_mask():
    v = vs()
    d = data_mod()
    lay = [ob for ob in v.objects if ob.kind == 'LAYER']
    select_only([])
    d.set_active(v, d.index_of_uid(v, lay[-1].uid))
    with bpy.context.temp_override(**ctx()):
        r = bpy.ops.vstroke.mask_add(fill='WHITE')
    say("mask_add", r)


def st_adjust():
    with bpy.context.temp_override(**ctx()):
        r = bpy.ops.vstroke.adjust_add()
    say("adjust_add", r)


class VSTEST_PT_menus(bpy.types.Panel):
    """メニューと操作方法の中身を、サイドバーに並べて撮る (小窓は撮れないので)。"""
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_label = "TEST"
    bl_order = 0

    def draw(self, context):
        lay = self.layout
        split = lay.split(factor=0.5)
        a = split.column()
        a.label(text="[+]")
        a.menu_contents("VS_MT_add")
        a.label(text="[fx +]")
        a.menu_contents("VS_MT_fx_add")
        a.label(text="[help]")
        ui = sys.modules[MOD + ".ui"]
        holder = type("H", (), {})()
        holder.layout = a
        ui.VS_PT_help.draw(holder, context)
        b = split.column()
        b.label(text="[...]")
        b.menu_contents("VS_MT_object")
        b.label(text="[right click]")
        b.menu_contents("VS_MT_context")


def st_paint():
    v = vs()
    d = data_mod()
    img_ob = next(o for o in v.objects if o.kind == 'IMAGE')
    select_only([])
    d.set_active(v, d.index_of_uid(v, img_ob.uid))
    with bpy.context.temp_override(**ctx()):
        r = bpy.ops.vstroke.paint_begin()
    say("paint_begin", r, area_img().spaces.active.image.name)


def st_paint_end():
    with bpy.context.temp_override(**ctx()):
        r = bpy.ops.vstroke.paint_end()
    say("paint_end", r, area_img().spaces.active.image.name)


def st_menus():
    ui = sys.modules[MOD + ".ui"]
    for c in ui.classes:
        if isinstance(c, type) and issubclass(c, bpy.types.Panel) and c.bl_region_type == 'UI':
            bpy.utils.unregister_class(c)
    bpy.utils.register_class(VSTEST_PT_menus)
    v = vs()
    d = data_mod()
    select_only([S["p"], S["a"], S["b"]])


STEPS = [("01_empty", st_empty), ("02_path", st_path), ("03_path_complex", st_path_complex),
         ("04_two_shapes", st_two_shapes), ("05_base_image", st_base_image),
         ("06_layer_mask", st_layer_mask), ("07_adjust", st_adjust), ("08_paint", st_paint), ("09_back", st_paint_end), ("10_menus", st_menus)]
queue = []


def ui_region():
    a = area_img()
    return a, next(r for r in a.regions if r.type == 'UI')


def scroll(down):
    a, r = ui_region()
    with bpy.context.temp_override(window=bpy.context.window, area=a, region=r):
        for _ in range(40):
            if down:
                bpy.ops.view2d.scroll_down()
            else:
                bpy.ops.view2d.scroll_up()


def shoot(name):
    a = area_img()
    with bpy.context.temp_override(window=bpy.context.window, area=a):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, name + ".png"))
    say("shot", name)


def shoot_win(name):
    with bpy.context.temp_override(window=bpy.context.window):
        bpy.ops.screen.screenshot(filepath=os.path.join(OUT, name + ".png"))
    say("shot", name)


def call_menu(name):
    a, r = ui_region()
    with bpy.context.temp_override(window=bpy.context.window, area=a, region=r):
        bpy.ops.wm.call_menu(name=name)


def call_help():
    a, r = ui_region()
    with bpy.context.temp_override(window=bpy.context.window, area=a, region=r):
        bpy.ops.wm.call_panel(name="VS_PT_help", keep_open=True)


def tick():
    try:
        if not queue:
            say("DONE")
            log.close()
            bpy.ops.wm.quit_blender()
            return None
        kind, name, fn = queue.pop(0)
        if kind == "scroll":
            scroll(fn)
        elif kind == "menu":
            fn()
        elif kind == "win":
            shoot_win(name)
            # 開いた小窓を閉じる (Esc)
            bpy.context.window.event_simulate(type='ESC', value='PRESS')
            bpy.context.window.event_simulate(type='ESC', value='RELEASE')
        elif kind == "do":
            fn()
            for w in bpy.context.window_manager.windows:
                for ar in w.screen.areas:
                    ar.tag_redraw()
        else:
            shoot(name)
    except Exception:
        say("ERROR", traceback.format_exc())
    return 0.6


def start():
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        bpy.ops.wm.quit_blender()
        return None
    for name, fn in STEPS:
        queue.append(("do", name, fn))
        queue.append(("shot", name, None))
        queue.append(("scroll", name, True))
        queue.append(("shot", name + "_down", None))
        queue.append(("scroll", name, False))
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

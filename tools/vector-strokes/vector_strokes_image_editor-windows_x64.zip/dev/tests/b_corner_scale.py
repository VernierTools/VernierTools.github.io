"""-b: 拡大縮小で角の丸みが同じ割合で変わるか。"""
import sys
import traceback

import bpy

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    tr = sys.modules[MOD + ".transform"]
    G = sys.modules[MOD + ".geometry"]
    img = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    ops.enable_image(img)
    vs = img.vstroke
    i = d.new_object(vs, kind='PATH')
    ob = vs.objects[i]
    sp = ob.subpaths.add()
    for x, y in ((100, 100), (300, 100), (300, 300), (100, 300)):
        p = sp.points.add()
        p.co = p.handle_left = p.handle_right = (x, y)
    sp.closed = True
    sp.points[0].corner_radius = 20.0
    pct0 = sp.points[0].corner_pct
    ob.corner_round = 5.0
    uid = ob.uid
    j = d.new_object(vs, kind='SHAPE')
    sh = vs.objects[j]
    sh.shape_type = 'RECT'
    sh.center = (250, 250)
    sh.size = (100, 100)
    sh.corner_radius = 10.0
    suid = sh.uid

    def get(u):
        return vs.objects[d.index_of_uid(vs, u)]

    M = G.about(G.scale(2.0, 2.0), 200, 200)
    tr.transform_items(vs, [uid, suid], M)
    p0 = get(uid).subpaths[0].points[0]
    check("path corner x2", abs(p0.corner_radius - 40.0) < 1e-4, p0.corner_radius)
    check("path pct kept", abs(p0.corner_pct - pct0) < 1e-3, (p0.corner_pct, pct0))
    check("corner_round x2", abs(get(uid).corner_round - 10.0) < 1e-4, get(uid).corner_round)
    check("shape corner x2", abs(get(suid).corner_radius - 20.0) < 1e-4, get(suid).corner_radius)
    check("shape size x2", abs(get(suid).size[0] - 200.0) < 1e-3, tuple(get(suid).size))
    # 縦横で違う倍率: 面積倍率の平方根 (線幅と同じ)
    tr.transform_items(vs, [uid], G.about(G.scale(2.0, 0.5), 200, 200))
    check("non-uniform -> sqrt(det)=1 keeps", abs(get(uid).subpaths[0].points[0].corner_radius - 40.0) < 1e-4,
          get(uid).subpaths[0].points[0].corner_radius)
    # 移動・回転では変わらない
    tr.transform_items(vs, [uid], G.translate(30, 0))
    check("translate keeps", abs(get(uid).subpaths[0].points[0].corner_radius - 40.0) < 1e-4)
    # オフ
    vs.scale_corners = False
    tr.transform_items(vs, [uid, suid], G.about(G.scale(0.5, 0.5), 200, 200))
    check("off -> path corner kept", abs(get(uid).subpaths[0].points[0].corner_radius - 40.0) < 1e-4,
          get(uid).subpaths[0].points[0].corner_radius)
    check("off -> shape corner kept", abs(get(suid).corner_radius - 20.0) < 1e-4, get(suid).corner_radius)
    # スナップショットから戻す (ドラッグを Esc で取り消したとき)
    vs.scale_corners = True
    snap = tr.snapshot(vs, [uid])
    tr.apply_matrix(vs, snap, G.about(G.scale(3.0, 3.0), 200, 200), False, True)
    check("drag x3", abs(get(uid).subpaths[0].points[0].corner_radius - 120.0) < 1e-3)
    tr.restore(vs, snap)
    check("restore -> back", abs(get(uid).subpaths[0].points[0].corner_radius - 40.0) < 1e-4,
          get(uid).subpaths[0].points[0].corner_radius)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

"""-b: カーニングと文字の比率の組み上がり。"""
import sys
import traceback

import bpy

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    tx = sys.modules[MOD + ".text"]
    G = sys.modules[MOD + ".geometry"]
    img = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    ops.enable_image(img)
    vs = img.vstroke
    i = d.new_object(vs, kind='TEXT')
    ob = vs.objects[i]
    ob.text_lines[0].text = "AVAV"
    ob.font_size = 100.0
    lay0 = tx.layout(ob)
    check("layout ok", lay0 is not None and len(lay0.lines) == 1)
    car0 = [c[0] for c in lay0.lines[0].carets]
    ext0 = lay0.lines[0].extent
    print("carets", [round(c, 1) for c in car0], "extent", round(ext0, 1))

    # --- カーニング: 2文字目と3文字目の間 (カーソル 2) を +200 ---
    check("kern_at middle", d.kern_at(ob, 0, 2) == 0.0)
    check("kern_at edges None", d.kern_at(ob, 0, 0) is None and d.kern_at(ob, 0, 4) is None)
    d.set_kern(ob, 0, 2, 200.0)
    tx.clear_cache()
    lay = tx.layout(ob)
    car = [c[0] for c in lay.lines[0].carets]
    print("carets", [round(c, 1) for c in car])
    check("before kern unchanged", abs(car[1] - car0[1]) < 1e-3)
    check("kern adds 20px after 2nd char", abs((car[2] - car0[2]) - 20.0) < 1e-3, car[2] - car0[2])
    check("later chars shift too", abs((car[3] - car0[3]) - 20.0) < 1e-3)
    check("extent +20", abs(lay.lines[0].extent - ext0 - 20.0) < 1e-3)
    check("kern_at reads 200", abs(d.kern_at(ob, 0, 2) - 200.0) < 1e-6)
    # 打ち込んだ字はカーニングを引き継がない
    d.insert_text(ob, 0, 3, "X")          # AVA|X|V
    check("typed char has no kern", d.kern_at(ob, 0, 3) == 0.0, d.kern_at(ob, 0, 3))
    check("existing kern kept", abs(d.kern_at(ob, 0, 2) - 200.0) < 1e-6)
    d.delete_text(ob, 0, 3, 0, 4)
    # 0 に戻すと書式が消える
    d.set_kern(ob, 0, 2, 0.0)
    check("kern 0 -> no style", d.char_style(ob, 0, 2) is None)

    # --- 比率: 全部を水平 200% ---
    d.apply_char_style(ob, [(0, 0, 4)], scale_x=200.0)
    tx.clear_cache()
    lay2 = tx.layout(ob)
    check("scale_x doubles extent", abs(lay2.lines[0].extent - ext0 * 2.0) < 0.5,
          (lay2.lines[0].extent, ext0))
    b0 = G.bounds_in_frame(G.polylines(tx.local_subpaths(ob)))
    d.apply_char_style(ob, [(0, 0, 4)], scale_x=100.0)
    tx.clear_cache()
    b1 = G.bounds_in_frame(G.polylines(tx.local_subpaths(ob)))
    w0, w1 = b0[2] - b0[0], b1[2] - b1[0]
    h0, h1 = b0[3] - b0[1], b1[3] - b1[1]
    check("glyphs twice as wide", abs(w0 / w1 - 2.0) < 0.05, (w0, w1))
    check("height same", abs(h0 - h1) < 0.5, (h0, h1))
    check("scale_x 100 -> no style", d.char_style(ob, 0, 0) is None)
    # 垂直 50%: 高さが半分
    d.apply_char_style(ob, [(0, 0, 4)], scale_y=50.0)
    tx.clear_cache()
    b2 = G.bounds_in_frame(G.polylines(tx.local_subpaths(ob)))
    check("scale_y halves height", abs((b2[3] - b2[1]) / h1 - 0.5) < 0.05, (b2[3] - b2[1], h1))
    check("common attr scale_y", d.common_char_attr(ob, [(0, 0, 4)], "scale_y") == 50.0)
    # 縦書きでも組める
    ob.text_vertical = True
    tx.clear_cache()
    check("vertical layout ok", tx.layout(ob) is not None)
    ob.text_vertical = False
    # アウトライン化 (char_subpaths) も比率込み
    check("char_subpaths ok", len(tx.char_subpaths(ob)) == 4)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

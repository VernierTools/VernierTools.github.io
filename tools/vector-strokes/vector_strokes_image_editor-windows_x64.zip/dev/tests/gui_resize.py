"""GUI: Blender の「画像 → リサイズ」でキャンバスの解像度を変える -> 自動で中身が合う / Undo。
blender --enable-event-simulate empty.blend --python gui_resize.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "resize.txt"), "w", encoding="utf-8")
fails = []
S = {}


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def ctx():
    a = area()
    return dict(window=bpy.context.window, area=a,
                region=next(r for r in a.regions if r.type == 'WINDOW'))


def canvas():
    return bpy.data.images["Canvas"]


def path_bounds():
    vs = canvas().vstroke
    ob = next(o for o in vs.objects if o.kind == 'PATH')
    G = M("geometry")
    return G.bounds_in_frame(G.polylines(G.object_subpaths(ob)))


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    im = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    im.generated_color = (0.5, 0.5, 0.55, 1)
    big.spaces.active.image = im
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.enable()
    d = M("data")
    v = im.vstroke
    i = d.new_object(v, kind='PATH')
    o = v.objects[i]
    sp = o.subpaths.add()
    for x, y in ((100, 100), (300, 100), (300, 300), (100, 300)):
        p = sp.points.add()
        p.co = p.handle_left = p.handle_right = (x, y)
    sp.closed = True
    M("render").render_image(im)
    bpy.ops.ed.undo_push(message="setup")


steps = []


def a_resize():
    with bpy.context.temp_override(**ctx()):
        r = bpy.ops.image.resize(size=(1024, 1024))
    say("resize", r, tuple(canvas().size))


def c_resized():
    cv = canvas()
    b = path_bounds()
    say("canvas_size", tuple(cv.vstroke.canvas_size), "bounds", b)
    check("synced automatically", tuple(cv.vstroke.canvas_size) == (1024, 1024))
    check("layout kept (path x2)", abs(b[0] - 200) < 1e-3 and abs(b[2] - 600) < 1e-3, b)
    L = next(o for o in cv.vstroke.objects if M("data").is_original(o))
    check("original layer 1024", tuple(L.image.size) == (1024, 1024), tuple(L.image.size))
    with bpy.context.temp_override(window=bpy.context.window, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, "resized.png"))


def a_undo():
    a = area()
    r = next(r for r in a.regions if r.type == 'WINDOW')
    win = bpy.context.window
    x, y = r.x + 20, r.y + 20
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='Z', value='PRESS', x=x, y=y, ctrl=True)
    win.event_simulate(type='Z', value='RELEASE', x=x, y=y, ctrl=True)


def c_undone():
    cv = canvas()
    b = path_bounds()
    say("after undo size", tuple(cv.size), "canvas_size", tuple(cv.vstroke.canvas_size), "bounds", b)
    w = cv.size[0]
    # どちらの大きさに戻っても、キャンバスの大きさとレイアウトが合っていること
    k = w / 512.0
    check("consistent after undo", tuple(cv.vstroke.canvas_size) == tuple(cv.size)
          and abs(b[0] - 100 * k) < 1e-3 and abs(b[2] - 300 * k) < 1e-3, (tuple(cv.size), b))
    L = next(o for o in cv.vstroke.objects if M("data").is_original(o))
    check("original layer matches canvas", tuple(L.image.size) == tuple(cv.size),
          (tuple(L.image.size), tuple(cv.size)))
    with bpy.context.temp_override(window=bpy.context.window, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, "resize_undo.png"))


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 1.5
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_resize, c_resized, a_undo, c_undone])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

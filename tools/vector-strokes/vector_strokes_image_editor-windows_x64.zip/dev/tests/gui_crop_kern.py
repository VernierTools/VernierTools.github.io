"""GUI: トリミングの枠のドラッグ・Enter、文字の Alt+→ カーニング・Undo (本物の入力で)。
blender --enable-event-simulate empty.blend --python gui_crop_kern.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "cropkern.txt"), "w", encoding="utf-8")
fails = []
S = {}


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def region():
    return next(r for r in area().regions if r.type == 'WINDOW')


def ctx():
    return dict(window=bpy.context.window, area=area(), region=region())


def img():
    return bpy.data.images["Canvas"]


def vs():
    return img().vstroke


def obj(uid):
    return vs().objects[M("data").index_of_uid(vs(), uid)]


def win_xy(pt):
    r = region()
    v = M("geometry").View.from_region(r, img())
    rx, ry = v.to_region(pt)
    return int(r.x + rx), int(r.y + ry)


win = None


def move(pt, off=12):
    x, y = win_xy(pt)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x - off, y=y - off)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)


def drag(p0, p1):
    x0, y0 = win_xy(p0)
    x1, y1 = win_xy(p1)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x0, y=y0)
    for k in range(1, 9):
        win.event_simulate(type='MOUSEMOVE', value='NOTHING',
                           x=int(x0 + (x1 - x0) * k / 8), y=int(y0 + (y1 - y0) * k / 8))
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x1, y=y1)


def key(t, **mods):
    r = region()
    x, y = r.x + 20, r.y + 20
    win.event_simulate(type=t, value='PRESS', x=x, y=y, **mods)
    win.event_simulate(type=t, value='RELEASE', x=x, y=y, **mods)


def shoot(name):
    with bpy.context.temp_override(window=bpy.context.window, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, name + ".png"))


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    for c in M("ui").classes:
        if isinstance(c, type) and issubclass(c, bpy.types.Panel) and c.bl_region_type == 'UI':
            bpy.utils.unregister_class(c)
            c.bl_category = "Tool"
            bpy.utils.register_class(c)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    im = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    im.generated_color = (0.9, 0.9, 0.95, 1)
    big.spaces.active.image = im
    big.spaces.active.show_region_ui = True
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.enable()
    d = M("data")
    v = im.vstroke
    src = bpy.data.images.new("Photo", 200, 200, alpha=True)
    src.generated_color = (0.2, 0.5, 1.0, 1)
    i = d.new_object(v, kind='IMAGE')
    o = v.objects[i]
    o.image = src
    o.img_origin = (60.0, 60.0)
    S["img"] = o.uid
    j = d.new_object(v, kind='TEXT')
    t = v.objects[j]
    t.text_lines[0].text = "AVAV"
    t.font_size = 80.0
    t.text_origin = (60.0, 400.0)
    S["txt"] = t.uid
    for x in v.objects:
        x.select = x.uid == S["img"]
    d.set_active(v, d.index_of_uid(v, S["img"]))
    bpy.ops.ed.undo_push(message="setup")


steps = []


def a_crop_on():
    # サイドバーの「キャンバスでトリミング」と同じ
    with bpy.context.temp_override(window=bpy.context.window, area=area(),
                                   region=next(r for r in area().regions if r.type == 'UI')):
        r = bpy.ops.vstroke.crop_edit()
    say("crop_edit", r, M("state").crop_edit, "editing", M("state").editing_image)


def a_dummy():
    # 最初の1クリックは届かないことがあるので、サイドバーの何もない所を押しておく
    r = next(r for r in area().regions if r.type == 'UI')
    x, y = r.x + 20, r.y + 10
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x, y=y)


def a_hover_left():
    move((60.0, 160.0))          # 左の辺の真ん中


def a_drag_left():
    drag((60.0, 160.0), (110.0, 160.0))


def c_crop():
    shoot("ck_cropping")
    o = obj(S["img"])
    check("drag left edge -> crop_left about 50px", 40.0 < o.crop_left < 60.0, o.crop_left)
    check("still crop mode", M("state").crop_edit is not None)


def a_enter():
    key('RET')


def c_enter():
    shoot("ck_cropped")
    check("Enter ends crop mode", M("state").crop_edit is None)
    o = obj(S["img"])
    check("crop kept after Enter", o.crop_left > 40.0, o.crop_left)


def a_undo():
    key('Z', ctrl=True)


def c_undo():
    o = obj(S["img"])
    check("undo -> crop gone", o.crop_left < 1e-3, o.crop_left)


def a_text_tool():
    v = vs()
    for x in v.objects:
        x.select = x.uid == S["txt"]
    M("data").set_active(v, M("data").index_of_uid(v, S["txt"]))
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.set_tool(tool='TEXT')
    move((300.0, 300.0))          # 次の入力でツールが切り替わる


def a_caret():
    v = vs()
    tool = M("state").current_tool
    # 2文字目と3文字目の間にカーソル
    tool.begin_edit(v, S["txt"], 0, 2)
    say("tool", tool.name, tool.edit)


def a_alt_right():
    key('RIGHT_ARROW', alt=True)


def c_kern():
    shoot("ck_kern")
    t = obj(S["txt"])
    k = M("data").kern_at(t, 0, 2)
    check("Alt+Right -> kern 20", k is not None and abs(k - 20.0) < 1e-6, k)


def a_alt_right2():
    key('RIGHT_ARROW', alt=True)


def c_kern2():
    t = obj(S["txt"])
    check("Alt+Right again -> 40", abs(M("data").kern_at(t, 0, 2) - 40.0) < 1e-6,
          M("data").kern_at(t, 0, 2))


def a_undo2():
    key('Z', ctrl=True)


def c_undo2():
    t = obj(S["txt"])
    check("undo -> 20", abs(M("data").kern_at(t, 0, 2) - 20.0) < 1e-6, M("data").kern_at(t, 0, 2))


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 1.0
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    global win
    win = bpy.context.window
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_crop_on, a_dummy, a_hover_left, a_drag_left, c_crop, a_enter, c_enter,
                  a_undo, c_undo, a_text_tool, a_caret, a_alt_right, c_kern, a_alt_right2, c_kern2,
                  a_undo2, c_undo2])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

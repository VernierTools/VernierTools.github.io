"""-b: 別のテクスチャ (キャンバス) への貼り付け。"""
import sys
import traceback

import bpy
import numpy as np

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    render = sys.modules[MOD + ".render"]
    G = sys.modules[MOD + ".geometry"]
    A = bpy.data.images.new("CanvasA", 512, 512, alpha=True)
    B = bpy.data.images.new("CanvasB", 256, 128, alpha=True)
    ops.enable_image(A)
    ops.enable_image(B)
    va, vb = A.vstroke, B.vstroke
    # A に: パス (マスク付き)・置いた画像・ペイントレイヤー・文字
    i = d.new_object(va, kind='PATH')
    p = va.objects[i]
    sp = p.subpaths.add()
    for x, y in ((300, 300), (480, 300), (480, 480), (300, 480)):
        q = sp.points.add()
        q.co = q.handle_left = q.handle_right = (x, y)
    sp.closed = True
    p.mask_image = bpy.data.images.new("A_mask", 512, 512, alpha=True)
    puid = p.uid
    photo = bpy.data.images.new("Photo", 64, 64, alpha=True)
    photo.generated_color = (0, 1, 0, 1)
    j = d.new_object(va, kind='IMAGE')
    im = va.objects[j]
    im.image = photo
    im.img_origin = (20.0, 20.0)
    iuid = im.uid
    t = d.new_object(va, kind='TEXT')
    va.objects[t].text_lines[0].text = "Hi"
    va.objects[t].text_origin = (20.0, 100.0)
    paint = next(o for o in va.objects if d.is_original(o))
    uids = [puid, iuid, va.objects[t].uid, paint.uid]
    n = d.copy_objects(va, uids)
    check("copied 4", n == 4, n)
    made = d.paste_objects(vb)
    check("pasted 4 roots", len(made) == 4, made)
    kinds = sorted(vb.objects[d.index_of_uid(vb, u)].kind for u in made)
    check("kinds", kinds == ['IMAGE', 'IMAGE', 'PATH', 'TEXT'], kinds)
    originals = [o for o in vb.objects if d.is_original(o)]
    check("only one original in B", len(originals) == 1, len(originals))
    pb = next(vb.objects[d.index_of_uid(vb, u)] for u in made
              if vb.objects[d.index_of_uid(vb, u)].kind == 'PATH')
    mi = pb.mask_image
    check("mask resized to B canvas", mi is not None and tuple(mi.size) == (256, 128),
          tuple(mi.size) if mi else None)
    # 4つまとめて貼ったときは、まとめて掛かっていれば動かさない (並びを保つ)
    # A のパスだけ (300..480) を B (256x128) へ -> 外なので真ん中へ寄せる
    d.copy_objects(va, [puid])
    one = d.paste_objects(vb)
    pb = vb.objects[d.index_of_uid(vb, one[0])]
    bx = G.bounds_in_frame(G.polylines(G.object_subpaths(pb)))
    check("moved mask follows (still B size)", tuple(pb.mask_image.size) == (256, 128))
    check("pasted path is visible in B", bx[0] < 256 and bx[1] < 128 and bx[2] > 0 and bx[3] > 0, bx)
    ok = True
    try:
        render.render_image(B)
    except Exception as e:
        ok = False
        print(e)
    check("render B ok", ok)
    # 同じキャンバスへの貼り付けは今まで通り同じ場所
    d.copy_objects(va, [puid])
    made2 = d.paste_objects(va)
    pa = va.objects[d.index_of_uid(va, made2[0])]
    b2 = G.bounds_in_frame(G.polylines(G.object_subpaths(pa)))
    check("same canvas paste keeps place", abs(b2[0] - 300) < 1e-3, b2)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

"""GUI: イメージエディターでペイント中に、3D ビューのテクスチャペイントで描く。
blender --enable-event-simulate empty.blend --python gui_paint3d.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy
import numpy as np

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "paint3d.txt"), "w", encoding="utf-8")
fails = []
S = {}


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def img_area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def v3d_area():
    return next(a for a in bpy.context.screen.areas if a.type == 'VIEW_3D')


def reg(a, t='WINDOW'):
    return next(r for r in a.regions if r.type == t)


def ictx():
    a = img_area()
    return dict(window=bpy.context.window, area=a, region=reg(a))


def vctx():
    a = v3d_area()
    return dict(window=bpy.context.window, area=a, region=reg(a),
                space_data=a.spaces.active)


def px(im, u, v):
    w, h = im.size
    a = np.empty(w * h * 4, np.float32)
    im.pixels.foreach_get(a)
    a = a.reshape(h, w, 4)
    return tuple(round(float(x), 2) for x in a[int(v * (h - 1)), int(u * (w - 1))])


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    areas = sorted(bpy.context.screen.areas, key=lambda a: a.width * a.height, reverse=True)
    areas[0].type = 'IMAGE_EDITOR'
    areas[1].type = 'VIEW_3D'
    canvas = bpy.data.images.new("Canvas", 256, 256, alpha=True)
    canvas.generated_color = (1, 1, 1, 1)
    areas[0].spaces.active.image = canvas
    with bpy.context.temp_override(**ictx()):
        bpy.ops.vstroke.enable()
    # 平面 (UV 付き) にキャンバスを貼る
    with bpy.context.temp_override(**vctx()):
        bpy.ops.mesh.primitive_plane_add(size=2.0)
    ob = bpy.context.view_layer.objects.active
    mat = bpy.data.materials.new("M")
    mat.use_nodes = True
    nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = canvas
    bsdf = next(n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED')
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    nt.nodes.active = tex
    ob.data.materials.append(mat)
    S["ob"] = ob.name
    bpy.ops.ed.undo_push(message="setup")


steps = []


def a_paint_begin():
    with bpy.context.temp_override(**ictx()):
        r = bpy.ops.vstroke.paint_begin(create=True)
    say("paint_begin", r, "layer", (M("state").paint or {}).get("layer"))


def c_target():
    ip = bpy.context.scene.tool_settings.image_paint
    layer = (M("state").paint or {}).get("layer")
    say("image_paint", ip.mode, ip.canvas.name if ip.canvas else None)
    check("3D target = painting layer", ip.mode == 'IMAGE' and ip.canvas is not None
          and ip.canvas.name == layer, (ip.mode, ip.canvas.name if ip.canvas else None, layer))


def a_texpaint():
    ob = bpy.data.objects[S["ob"]]
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    with bpy.context.temp_override(**vctx()):
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
        bpy.ops.view3d.view_axis(type='TOP')
        bpy.ops.view3d.view_selected()
    ts = bpy.context.scene.tool_settings
    ups = ts.image_paint.unified_paint_settings
    ups.use_unified_color = True
    ups.color = (1.0, 0.0, 0.0)
    try:
        ups.use_unified_size = True
        ups.size = 60
    except Exception:
        pass
    say("mode", ob.mode)


def a_stroke():
    r = reg(v3d_area())
    cx, cy = r.width // 2, r.height // 2
    pts = []
    for k in range(12):
        x, y = cx - 60 + k * 10, cy
        pts.append({"name": "", "location": (0, 0, 0), "mouse": (x, y), "mouse_event": (x, y),
                    "pressure": 1.0, "size": 60.0, "pen_flip": False, "time": k * 0.01,
                    "is_start": k == 0, "x_tilt": 0.0, "y_tilt": 0.0})
    keys = {pr.identifier for pr in bpy.types.OperatorStrokeElement.bl_rna.properties}
    say("stroke keys", sorted(keys))
    pts = [{k: v for k, v in d.items() if k in keys} for d in pts]
    with bpy.context.temp_override(**vctx()):
        res = bpy.ops.paint.image_paint(stroke=pts, mode='NORMAL')
    say("stroke", res)


def a_hover3d():
    r = reg(v3d_area())
    win = bpy.context.window
    x, y = r.x + r.width // 2 - 60, r.y + r.height // 2 + 30
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x - 10, y=y)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)


def a_drag3d():
    r = reg(v3d_area())
    win = bpy.context.window
    x, y = r.x + r.width // 2 - 60, r.y + r.height // 2 + 30
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y)
    for k in range(1, 13):
        win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x + k * 10, y=y)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x + 120, y=y)


def c_painted2():
    canvas = bpy.data.images["Canvas"]
    layer = bpy.data.images.get(M("state").paint["layer"])
    # ドラッグは画面の真ん中より上 (平面の上の方) を通った
    lc = [px(layer, u / 10.0, v / 20.0) for u in range(3, 8) for v in range(10, 16)]
    cc = [px(canvas, u / 10.0, v / 20.0) for u in range(3, 8) for v in range(10, 16)]
    lr = sum(1 for c in lc if c[0] > 0.8 and c[1] < 0.3 and c[3] > 0.5)
    cr = sum(1 for c in cc if c[0] > 0.8 and c[1] < 0.3)
    check("real 3D drag painted the layer", lr > 0, lr)
    check("real 3D drag shows on canvas (live)", cr > 0, cr)


def a_undo3d():
    r = reg(v3d_area())
    win = bpy.context.window
    x, y = r.x + 30, r.y + 30
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='Z', value='PRESS', x=x, y=y, ctrl=True)
    win.event_simulate(type='Z', value='RELEASE', x=x, y=y, ctrl=True)


def c_undone():
    canvas = bpy.data.images["Canvas"]
    layer = bpy.data.images.get((M("state").paint or {}).get("layer", ""))
    say("after undo: painting =", bool(M("state").paint))
    if layer is None:
        fails.append("no layer after undo")
        return
    lc = [px(layer, u / 10.0, v / 20.0) for u in range(3, 8) for v in range(10, 16)]
    cc = [px(canvas, u / 10.0, v / 20.0) for u in range(3, 8) for v in range(10, 16)]
    lr = sum(1 for c in lc if c[0] > 0.8 and c[1] < 0.3 and c[3] > 0.5)
    cr = sum(1 for c in cc if c[0] > 0.8 and c[1] < 0.3)
    check("undo removes the 3D stroke from layer", lr == 0, lr)
    check("undo removes it from canvas too", cr == 0, cr)
    ip = bpy.context.scene.tool_settings.image_paint
    check("still painting into the layer after undo", ip.mode == 'IMAGE' and ip.canvas == layer,
          (ip.mode, ip.canvas.name if ip.canvas else None))


def c_painted():
    layer = bpy.data.images.get(M("state").paint["layer"])
    c = px(layer, 0.5, 0.5)
    check("layer got red paint", c[0] > 0.8 and c[1] < 0.3 and c[3] > 0.8, c)
    S["layer_px"] = c


def a_wait():
    pass


def c_canvas():
    canvas = bpy.data.images["Canvas"]
    c = px(canvas, 0.5, 0.5)
    check("canvas shows the stroke (not overwritten)", c[0] > 0.8 and c[1] < 0.3, c)
    with bpy.context.temp_override(window=bpy.context.window):
        bpy.ops.screen.screenshot(filepath=os.path.join(OUT, "paint3d.png"))


def a_end():
    a = img_area()
    with bpy.context.temp_override(window=bpy.context.window, area=a, region=reg(a)):
        r = bpy.ops.vstroke.paint_end()
    say("paint_end", r)


def c_restored():
    ip = bpy.context.scene.tool_settings.image_paint
    check("3D target restored to material", ip.mode == 'MATERIAL', ip.mode)
    canvas = bpy.data.images["Canvas"]
    c = px(canvas, 0.5, 0.5)
    check("stroke kept after leaving paint", c[0] > 0.8 and c[1] < 0.3, c)


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 1.0
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_paint_begin, c_target, a_texpaint, c_target, a_hover3d, a_drag3d, a_wait, c_painted2, a_undo3d, a_wait, c_undone,
                  a_stroke, c_painted, a_end, c_restored])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

"""-b で、新しいボタンのオペレーターの動きを確かめる。
blender -b empty.blend --python b_ops.py -- <pylib>"""
import sys
import traceback

import bpy

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond):
    print(("OK   " if cond else "FAIL ") + name)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    # イメージエディターの文脈を作る
    win = bpy.context.window_manager.windows[0] if bpy.context.window_manager.windows else None
    img = bpy.data.images.new("Canvas", 256, 256, alpha=True)

    class Sp:
        pass

    # -b では space が無いので、オペレーターの execute を直接呼ぶ (_enabled_image を差し替え)
    ops._enabled_image = lambda context: img
    ops._active_ob = lambda context: d.active_object(img.vstroke)
    ops.enable_image(img)
    vs = img.vstroke
    i = d.new_object(vs, kind='PATH')
    ob = vs.objects[i]
    sp = ob.subpaths.add()
    for x, y in ((10, 10), (100, 10), (100, 100)):
        p = sp.points.add()
        p.co = p.handle_left = p.handle_right = (x, y)
    sp.closed = True
    d.set_active(vs, i)
    print("paints:", [(p.kind) for p in ob.paints])

    def run(cls, **kw):
        op = type("O", (), {})()
        for k, v in kw.items():
            setattr(op, k, v)
        for k in ("index", "paint"):
            if not hasattr(op, k):
                setattr(op, k, -1)
        op.report = lambda *a: print("report", a)
        return cls.execute(op, bpy.context)

    kinds = lambda: [p.kind for p in ob.paints]
    # 塗り・線をもう1つずつ
    d.add_paint(ob, 'FILL', color=(1, 0, 0, 1))
    d.add_paint(ob, 'STROKE', color=(0, 1, 0, 1), width=3.0)
    print("start", kinds())
    k0 = kinds()
    # 線 (最後) を塗りの下へ
    last = len(ob.paints) - 1
    r = run(ops.VS_OT_paint_move, direction='BELOW_FILL', index=last)
    check("BELOW_FILL moves stroke before first fill", r == {'FINISHED'} and kinds()[0] == 'STROKE')
    r = run(ops.VS_OT_paint_move, direction='BELOW_FILL', index=0)
    check("BELOW_FILL again is cancelled", r == {'CANCELLED'})
    r = run(ops.VS_OT_paint_move, direction='ABOVE_FILL', index=0)
    fl = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
    check("ABOVE_FILL moves stroke after last fill",
          r == {'FINISHED'} and ob.paints[fl[-1] + 1].kind == 'STROKE')
    # 同じ種類の中での上下
    fills = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
    c0 = tuple(ob.paints[fills[0]].color)
    r = run(ops.VS_OT_paint_move, direction='UP', index=fills[0])
    fills2 = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
    check("UP swaps among fills", r == {'FINISHED'} and tuple(ob.paints[fills2[1]].color) == c0)
    r = run(ops.VS_OT_paint_move, direction='UP', index=fills2[1])
    check("UP at the front is cancelled", r == {'CANCELLED'})
    # 絵のボタン
    s = [k for k, p in enumerate(ob.paints) if p.kind == 'STROKE'][0]
    r = run(ops.VS_OT_paint_set, index=s, prop='cap', value='SQUARE')
    check("paint_set cap", r == {'FINISHED'} and ob.paints[s].cap == 'SQUARE')
    r = run(ops.VS_OT_paint_set, index=s, prop='cap', value='SQUARE')
    check("paint_set same value cancelled", r == {'CANCELLED'})
    r = run(ops.VS_OT_paint_set, index=s, prop='align', value='INSIDE')
    check("paint_set align (closed)", ob.paints[s].align == 'INSIDE')
    f = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL'][0]
    r = run(ops.VS_OT_paint_set, index=f, prop='paint_type', value='RADIAL')
    check("paint_set paint_type", ob.paints[f].paint_type == 'RADIAL' and len(ob.paints[f].stops) >= 2)
    # 分岐点
    n0 = len(ob.paints[f].stops)
    d.set_active(vs, i)
    ob.active_paint = s     # 選んでいる行と違う塗りを指しても効くこと
    r = run(ops.VS_OT_stop_add, paint=f)
    check("stop_add on given paint", len(ob.paints[f].stops) == n0 + 1)
    r = run(ops.VS_OT_stop_remove, paint=f, index=0)
    check("stop_remove on given paint", len(ob.paints[f].stops) == n0)
    # 削除
    n = len(ob.paints)
    r = run(ops.VS_OT_paint_remove, index=0)
    check("paint_remove by index", len(ob.paints) == n - 1)
    # 効果
    r = run(ops.VS_OT_fx_set, name='fx_shadow_enable', on=True)
    check("fx on", ob.fx_shadow_enable)
    r = run(ops.VS_OT_fx_set, name='fx_shadow_enable', on=True)
    check("fx on twice cancelled", r == {'CANCELLED'})
    r = run(ops.VS_OT_fx_set, name='corner_round', on=True)
    check("corner on", ob.corner_round > 0)
    r = run(ops.VS_OT_fx_set, name='corner_round', on=False)
    check("corner off", ob.corner_round == 0)
    r = run(ops.VS_OT_fx_set, name='fx_shadow_enable', on=False)
    check("fx off", not ob.fx_shadow_enable)
    # 画像には角の丸めは付けられない
    img_ob = next(o for o in vs.objects if o.kind == 'IMAGE')
    d.set_active(vs, d.index_of_uid(vs, img_ob.uid))
    r = run(ops.VS_OT_fx_set, name='corner_round', on=True)
    check("corner not for image", r == {'CANCELLED'})
    check("description", "ドロップ" in ops.VS_OT_fx_set.description(
        bpy.context, type("P", (), {"name": "fx_shadow_enable", "on": True})()))
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

"""-b: キャンバスをリサイズしたとき、中身がレイアウトを保って合わせられるか。"""
import sys
import traceback

import bpy
import numpy as np

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    render = sys.modules[MOD + ".render"]
    G = sys.modules[MOD + ".geometry"]
    canvas = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    canvas.generated_color = (0.5, 0.5, 0.5, 1)
    ops.enable_image(canvas)
    vs = canvas.vstroke
    i = d.new_object(vs, kind='PATH')
    p = vs.objects[i]
    sp = p.subpaths.add()
    for x, y in ((100, 100), (200, 100), (200, 200), (100, 200)):
        q = sp.points.add()
        q.co = q.handle_left = q.handle_right = (x, y)
    sp.closed = True
    sp.points[0].corner_radius = 10.0
    puid = p.uid
    photo = bpy.data.images.new("Photo", 64, 64, alpha=True)
    j = d.new_object(vs, kind='IMAGE')
    im = vs.objects[j]
    im.image = photo
    im.img_origin = (300.0, 300.0)
    iuid = im.uid
    lay = next(o for o in vs.objects if d.is_original(o))
    lay.visible = True        # 新規の単色画像は背景が非表示で始まる (0.36.4)。ここでは見せる
    lay.mask_image = bpy.data.images.new("Mask", 512, 512, alpha=True)
    luid = lay.uid
    render.render_image(canvas)
    check("canvas_size remembered", tuple(vs.canvas_size) == (512, 512), tuple(vs.canvas_size))

    def get(u):
        return vs.objects[d.index_of_uid(vs, u)]

    # Blender の「リサイズ」と同じ: 画像の大きさだけ変わる
    canvas.scale(1024, 1024)
    render.render_image(canvas)
    check("canvas_size updated", tuple(vs.canvas_size) == (1024, 1024), tuple(vs.canvas_size))
    b = G.bounds_in_frame(G.polylines(G.object_subpaths(get(puid))))
    check("path doubled", abs(b[0] - 200) < 1e-3 and abs(b[2] - 400) < 1e-3, b)
    check("corner radius doubled", abs(get(puid).subpaths[0].points[0].corner_radius - 20) < 1e-3,
          get(puid).subpaths[0].points[0].corner_radius)
    vc = d.image_visible_corners(get(iuid))
    check("photo moved/scaled", abs(vc[0][0] - 600) < 1e-3 and abs(vc[2][0] - 728) < 1e-3, vc)
    L = get(luid)
    check("original layer resampled", tuple(L.image.size) == (1024, 1024), tuple(L.image.size))
    check("original layer still aligned", tuple(L.img_mat) == (1.0, 0.0, 0.0, 1.0)
          and tuple(L.img_origin) == (0.0, 0.0), (tuple(L.img_mat), tuple(L.img_origin)))
    check("mask resampled", tuple(L.mask_image.size) == (1024, 1024))
    check("paint placement aligned", d.paint_placement(L, 1024, 1024) == 'ALIGNED')
    a = np.empty(1024 * 1024 * 4, np.float32)
    canvas.pixels.foreach_get(a)
    a = a.reshape(1024, 1024, 4)
    fill = tuple(round(float(v), 2) for v in a[300, 300])
    check("path drawn at new place", fill[0] > 0.8 and fill[1] > 0.6 and fill[2] < 0.4, fill)
    bg = tuple(round(float(v), 2) for v in a[900, 100])
    check("background fills new canvas", abs(bg[0] - 0.5) < 0.05 and bg[3] > 0.9, bg)
    # 縦横で違う割合
    canvas.scale(1024, 512)
    render.render_image(canvas)
    b2 = G.bounds_in_frame(G.polylines(G.object_subpaths(get(puid))))
    check("non-uniform: y halves", abs(b2[1] - 100) < 1e-3 and abs(b2[3] - 200) < 1e-3, b2)
    check("non-uniform: x same", abs(b2[0] - 200) < 1e-3, b2)
    check("layer 1024x512", tuple(get(luid).image.size) == (1024, 512))
    # 大きさが同じなら何もしない
    before = tuple(round(v, 4) for v in b2)
    render.render_image(canvas)
    b3 = G.bounds_in_frame(G.polylines(G.object_subpaths(get(puid))))
    check("no change when same size", tuple(round(v, 4) for v in b3) == before)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

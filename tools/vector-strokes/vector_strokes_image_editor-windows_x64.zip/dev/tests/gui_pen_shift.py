"""GUI: ペンツールで Shift+クリックすると、前の点から8方向に固定して点が置かれるか。
blender --enable-event-simulate empty.blend --python gui_pen_shift.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "penshift.txt"), "w", encoding="utf-8")
fails = []


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def region():
    return next(r for r in area().regions if r.type == 'WINDOW')


def img():
    return bpy.data.images["Canvas"]


def win_xy(pt):
    r = region()
    v = M("geometry").View.from_region(r, img())
    rx, ry = v.to_region(pt)
    return int(round(r.x + rx)), int(round(r.y + ry))


win = None


def click(pt, shift=False):
    x, y = win_xy(pt)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y, shift=shift)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y, shift=shift)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x, y=y, shift=shift)


def pts():
    ob = next((o for o in img().vstroke.objects if o.kind == 'PATH'), None)
    if ob is None:
        return []
    return [tuple(round(c) for c in p.co) for sp in ob.subpaths for p in sp.points]


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    im = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    big.spaces.active.image = im
    r = next(r for r in big.regions if r.type == 'WINDOW')
    with bpy.context.temp_override(window=bpy.context.window, area=big, region=r):
        bpy.ops.vstroke.enable()
        bpy.ops.vstroke.set_tool(tool='PEN')
    ts = bpy.context.window_manager.vstroke_tool
    ts.snap_enable = False          # 吸い付きで位置が変わらないように (角度だけを見る)


steps = []


def a_dummy():
    r = region()
    x, y = r.x + 10, r.y + 10
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)


def a_p1():
    click((100, 100))


def a_p2():
    click((300, 160), shift=True)     # 右へ少し上向き -> 0° (横) に固定


def a_p3():
    click((395, 185), shift=True)     # 右上 -> 45° に固定


def a_p4():
    click((390, 400), shift=True)     # ほぼ真上 -> 90° (縦) に固定


def c_pts():
    p = pts()
    say("points", p)
    check("4 points", len(p) == 4, p)
    if len(p) == 4:
        check("2nd on horizontal", p[1][1] == p[0][1], (p[0], p[1]))
        dx, dy = p[2][0] - p[1][0], p[2][1] - p[1][1]
        check("3rd at 45 deg", abs(dx - dy) <= 1 and dx > 0, (dx, dy))
        check("4th on vertical", p[3][0] == p[2][0], (p[2], p[3]))
    with bpy.context.temp_override(window=bpy.context.window, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, "penshift.png"))


def a_plain():
    click((460, 330))                   # Shift なし -> 固定しない


def c_plain():
    p = pts()
    check("plain click not constrained", len(p) == 5 and p[4] == (460, 330), p[-1:] if p else p)


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 0.8
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    global win
    win = bpy.context.window
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_dummy, a_p1, a_p2, a_p3, a_p4, c_pts, a_plain, c_plain])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

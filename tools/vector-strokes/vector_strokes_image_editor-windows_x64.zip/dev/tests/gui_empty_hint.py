"""GUI: 画像が無いイメージエディターで描こうとしたら、上に知らせが出るか。"""
import os, sys, traceback, time
import bpy
argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "emptyhint.txt"), "w", encoding="utf-8")
fails = []
def say(*a):
    print(*a); log.write(" ".join(str(x) for x in a) + "\n"); log.flush()
def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond: fails.append(name)
def M(n): return sys.modules[MOD + "." + n]
def area(): return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')
def region(): return next(r for r in area().regions if r.type == 'WINDOW')
win = None
def click():
    r = region(); x, y = r.x + r.width // 2, r.y + r.height // 2
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x, y=y)
def settool(mode, tid):
    a = area(); sp = a.spaces.active
    with bpy.context.temp_override(window=win, area=a, region=region()):
        sp.ui_mode = mode
        bpy.ops.wm.tool_set_by_id(name=tid, space_type='IMAGE_EDITOR')
def reset(): M("empty_hint").notice = None
def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
steps = []
def a_paint0():
    a = area(); sp = a.spaces.active
    with bpy.context.temp_override(window=win, area=a, region=region()):
        sp.ui_mode = 'PAINT'
        t = bpy.context.workspace.tools.from_space_image_mode('PAINT', create=True)
        say("paint tool created", t and t.idname)
def a_paint():
    reset(); a = area(); sp = a.spaces.active
    say("mode", sp.ui_mode, "tool", M("session").active_tool_id(bpy.context, 'PAINT'))
    with bpy.context.temp_override(window=win, area=a, region=region()):
        say("hint poll", bpy.ops.vstroke.no_image_hint.poll())
    click()
def c_paint():
    check("paint mode -> notice", M("empty_hint").notice is not None)
def a_brush():
    reset(); settool('PAINT', "builtin.brush")
    say("brush tool", M("session").active_tool_id(bpy.context, 'PAINT')); click()
def c_brush(): check("default Brush tool -> notice", M("empty_hint").notice is not None)
def a_vsbrush():
    reset(); settool('VIEW', "vstroke.brush_tool")
    say("vs brush", area().spaces.active.ui_mode, M("session").active_tool_id(bpy.context, area().spaces.active.ui_mode)); click()
def c_vsbrush(): check("addon Brush tool -> notice", M("empty_hint").notice is not None)
def shot():
    with bpy.context.temp_override(window=win, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, "emptyhint.png"))
def a_pen(): reset(); settool('VIEW', "vstroke.edit_tool"); click()
def c_pen(): check("our pen tool -> notice", M("empty_hint").notice is not None)
def a_sample(): reset(); settool('VIEW', "builtin.sample"); click()
def c_sample(): check("view sample tool -> no notice", M("empty_hint").notice is None)
def a_annot(): reset(); settool('PAINT', "builtin.annotate"); click()
def c_annot(): check("annotate -> no notice", M("empty_hint").notice is None)
def a_img():
    reset(); im = bpy.data.images.new("Canvas", 256, 256, alpha=True); area().spaces.active.image = im
    settool('PAINT', M("empty_hint").__name__ and "builtin.brush" if False else M("session").active_tool_id(bpy.context,'PAINT'))
    a = area(); sp = a.spaces.active
    with bpy.context.temp_override(window=win, area=a, region=region()):
        sp.ui_mode = 'PAINT'
    say("tool with image", M("session").active_tool_id(bpy.context, 'PAINT')); click()
def c_img(): check("with image -> no notice", M("empty_hint").notice is None)
def a_wait(): pass
def c_gone():
    pass
def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails); log.close(); bpy.ops.wm.quit_blender()
def tick():
    try:
        if not steps: finish(); return None
        steps.pop(0)(); return 0.6
    except Exception:
        say("ERROR", traceback.format_exc()); fails.append("exception"); finish(); return None
def start():
    global win
    win = bpy.context.window
    try: setup()
    except Exception: say("SETUP ERROR", traceback.format_exc()); finish(); return None
    steps.extend([a_sample, c_sample, a_paint0, a_paint, c_paint, a_brush, c_brush, shot, a_vsbrush, c_vsbrush, a_pen, c_pen, a_sample, c_sample, a_annot, c_annot, a_img, c_img])
    bpy.app.timers.register(tick, first_interval=1.0)
bpy.app.timers.register(start, first_interval=1.5)

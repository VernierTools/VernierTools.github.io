"""GUI: テクスチャ A で Ctrl+C → イメージエディターを B に切り替え → キャンバスを押す → Ctrl+V。
blender --enable-event-simulate empty.blend --python gui_xpaste.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "xpaste.txt"), "w", encoding="utf-8")
fails = []
S = {}


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def region():
    return next(r for r in area().regions if r.type == 'WINDOW')


def ctx():
    return dict(window=bpy.context.window, area=area(), region=region())


win = None


def win_xy(img, pt):
    r = region()
    v = M("geometry").View.from_region(r, img)
    rx, ry = v.to_region(pt)
    return int(r.x + rx), int(r.y + ry)


def key(t, **mods):
    r = region()
    x, y = r.x + r.width // 2, r.y + r.height // 2
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type=t, value='PRESS', x=x, y=y, **mods)
    win.event_simulate(type=t, value='RELEASE', x=x, y=y, **mods)


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    A = bpy.data.images.new("TexA", 512, 512, alpha=True)
    A.generated_color = (0.9, 0.9, 0.9, 1)
    Bm = bpy.data.images.new("TexB", 512, 512, alpha=True)
    Bm.generated_color = (0.3, 0.3, 0.35, 1)
    big.spaces.active.image = A
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.enable()
    d = M("data")
    v = A.vstroke
    i = d.new_object(v, kind='PATH')
    o = v.objects[i]
    sp = o.subpaths.add()
    for x, y in ((150, 150), (350, 150), (350, 350), (150, 350)):
        p = sp.points.add()
        p.co = p.handle_left = p.handle_right = (x, y)
    sp.closed = True
    S["uid"] = o.uid
    for x in v.objects:
        x.select = x.uid == o.uid
    d.set_active(v, i)
    bpy.ops.ed.undo_push(message="setup")
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.set_tool(tool='SELECT')


steps = []


def a_copy():
    key('C', ctrl=True)


def c_copy():
    check("clipboard has 1", len(M("state").clipboard) == 1, len(M("state").clipboard))


def a_switch():
    area().spaces.active.image = bpy.data.images["TexB"]
    say("switched; editing =", M("state").editing_image)


def a_click_b():
    # B の何もない所をクリック (選択ツールのまま。B は自動でベクター編集になる)
    B = bpy.data.images["TexB"]
    x, y = win_xy(B, (40, 40))
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x - 10, y=y)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x, y=y)


def c_b():
    B = bpy.data.images["TexB"]
    say("B enabled", B.vstroke.enabled, "editing", M("state").editing_image)
    check("B is vector-enabled and edited", B.vstroke.enabled and M("state").editing_image == "TexB")


def a_paste():
    key('V', ctrl=True)


def c_paste():
    B = bpy.data.images["TexB"]
    paths = [o for o in B.vstroke.objects if o.kind == 'PATH']
    check("pasted path in B", len(paths) == 1, len(paths))
    with bpy.context.temp_override(window=bpy.context.window, area=area()):
        bpy.ops.screen.screenshot_area(filepath=os.path.join(OUT, "xpaste_b.png"))


def a_undo():
    key('Z', ctrl=True)


def c_undo():
    B = bpy.data.images["TexB"]
    paths = [o for o in B.vstroke.objects if o.kind == 'PATH']
    check("undo -> gone from B", len(paths) == 0, len(paths))
    A = bpy.data.images["TexA"]
    check("A still has its path", any(o.kind == 'PATH' for o in A.vstroke.objects))


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 1.0
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    global win
    win = bpy.context.window
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_copy, c_copy, a_switch, a_click_b, c_b, a_paste, c_paste, a_undo, c_undo])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

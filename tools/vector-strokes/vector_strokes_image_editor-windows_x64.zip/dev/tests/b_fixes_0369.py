"""-b: 0.36.9 で直した4つの不具合。
1. SVG の読み込みで、表に無い色の名前・hsl() が黒になっていた
2. 文字のまま SVG に書き出すと、グラデーションが文字の基準点の分ずれ、線幅も変形の分変わっていた
3. レイヤーを消してから足すと名前が重なり、SVG の id も重なっていた
4. float のキャンバスでも、ペイントレイヤー・レイヤーマスクが 8bit だった
"""
import importlib
import re
import sys
import traceback

import bpy
import numpy as np

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def near(a, b, eps=1e-3):
    return all(abs(x - y) < eps for x, y in zip(a, b))


def svg_matrix(s):
    v = [float(x) for x in re.split(r"[,\s]+", s.strip())]
    return np.array([[v[0], v[2], v[4]], [v[1], v[3], v[5]], [0.0, 0.0, 1.0]])


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    E = sys.modules[MOD + ".export"]
    S = importlib.import_module(MOD + ".svg_import")

    # 1. 色
    check("darkorange", near(S.parse_color("darkorange"), (1.0, 140 / 255, 0.0, 1.0)))
    check("slategray", near(S.parse_color("SlateGray"), (112 / 255, 128 / 255, 144 / 255, 1.0)))
    check("named count", len(S.NAMED) == 149, len(S.NAMED))
    check("hsl green", near(S.parse_color("hsl(120, 100%, 50%)"), (0.0, 1.0, 0.0, 1.0)))
    check("hsla", near(S.parse_color("hsla(0deg 100% 50% / 0.5)"), (1.0, 0.0, 0.0, 0.5)))
    check("hsl turn", near(S.parse_color("hsl(0.5turn,100%,25%)"), (0.0, 0.5, 0.5, 1.0)))
    check("bad hex -> black", S.parse_color("#12345") == (0.0, 0.0, 0.0, 1.0))
    check("still none", S.parse_color("none") is None and S.parse_color("transparent") is None)
    check("rgb still", near(S.parse_color("rgb(255,0,0)"), (1, 0, 0, 1)))

    # 3. レイヤー名
    A = bpy.data.images.new("CanvasA", 256, 256, alpha=True)
    ops.enable_image(A)
    va = A.vstroke
    d.new_object(va, kind='LAYER')
    d.new_object(va, kind='LAYER')
    l2 = next(o.uid for o in va.objects if o.name == "レイヤー 2")
    d.remove_objects(va, [l2])
    d.new_object(va, kind='LAYER')
    names = [o.name for o in va.objects if o.kind == 'LAYER' and not d.is_background_layer(o)]
    check("layer names unique", len(names) == len(set(names)), names)
    # ペイントレイヤーも同じ
    ops.add_paint_layer(va, A)
    ops.add_paint_layer(va, A)
    pn = [o.name for o in va.objects if d.is_paint_layer(o) and not d.is_original(o)]
    check("paint names first", pn[:1] == ["ペイント 1"], pn)
    d.remove_objects(va, [next(o.uid for o in va.objects if o.name == "ペイント 1")])
    ops.add_paint_layer(va, A)
    ops.add_paint_layer(va, A)
    pn = [o.name for o in va.objects if d.is_paint_layer(o) and not d.is_original(o)]
    check("paint names unique", len(pn) == len(set(pn)), pn)

    # 同じ名前のものが2つあっても、SVG の id は重ならない
    lays = [o for o in va.objects if o.kind == 'LAYER' and not d.is_background_layer(o)]
    for lay in lays[:2]:
        i = d.new_object(va, kind='SHAPE', parent_uid=lay.uid)
        sh = va.objects[i]
        sh.center, sh.size = (60, 60), (40, 40)
    lays = [o for o in va.objects if o.kind == 'LAYER' and not d.is_background_layer(o)]
    lays[0].name = lays[1].name = "同じ 名前"
    svg = E.svg_string(A)
    ids = re.findall(r' id="([^"]*)"', svg)
    dup = sorted({x for x in ids if ids.count(x) > 1})
    check("svg ids unique", not dup, dup)
    check("svg ids no space", not [x for x in ids if re.search(r"\s", x)], ids[:8])
    check("svg same-name ids", "同じ_名前" in ids and "同じ_名前_2" in ids, ids[:8])

    # 2. 文字のまま書き出し + グラデーション + 変形
    j = d.new_object(va, kind='TEXT')
    tx = va.objects[j]
    d.ensure_font(tx)
    tx.text_lines[0].text = "AB"
    tx.text_origin = (100.0, 100.0)
    tx.text_mat = (2.0, 0.0, 0.0, 2.0)
    fill = [p for p in tx.paints if p.kind == 'FILL'][0]
    fill.paint_type = 'LINEAR'
    fill.g_start, fill.g_end = (100.0, 100.0), (200.0, 100.0)
    stroke = [p for p in tx.paints if p.kind == 'STROKE'][0]
    stroke.enabled = True
    stroke.width = 4.0
    stroke.dash_enable = True
    stroke.dash = (12.0, 6.0, 0.0, 0.0, 0.0, 0.0)
    svg = E.svg_string(A, outline_text=False)
    g = re.search(r'<g[^>]*transform="matrix\(([^)]*)\)"[^>]*><text([^>]*)>', svg)
    check("text group found", g is not None)
    gm = svg_matrix(g.group(1))
    tattrs = g.group(2)
    gid = re.search(r'fill="url\(#([^)]*)\)"', tattrs).group(1)
    lg = re.search(r'<linearGradient id="%s"[^>]*>' % gid, svg).group(0)
    gt = re.search(r'gradientTransform="matrix\(([^)]*)\)"', lg)
    check("gradient has transform", gt is not None, lg)
    x1, y1 = float(re.search(r' x1="([^"]*)"', lg).group(1)), float(re.search(r' y1="([^"]*)"', lg).group(1))
    x2 = float(re.search(r' x2="([^"]*)"', lg).group(1))
    eff = gm @ svg_matrix(gt.group(1))
    a = eff @ np.array([x1, y1, 1.0])
    b = eff @ np.array([x2, y1, 1.0])
    # キャンバス (SVG の向き) で (100, 156) -> (200, 156) に来ていればよい
    check("gradient start in place", near(a[:2], (100.0, 156.0)), a)
    check("gradient end in place", near(b[:2], (200.0, 156.0)), b)
    sw = float(re.search(r'stroke-width="([^"]*)"', tattrs).group(1))
    check("stroke width undone by scale", abs(sw - 2.0) < 1e-3, sw)
    da = re.search(r'stroke-dasharray="([^"]*)"', tattrs).group(1)
    check("dash undone by scale", da == "6,3", da)
    # 変形なしの文字は今まで通りの線幅
    tx.text_mat = (1.0, 0.0, 0.0, 1.0)
    svg = E.svg_string(A, outline_text=False)
    t2 = re.search(r'<text([^>]*)>', svg).group(1)
    check("plain stroke width", 'stroke-width="4"' in t2, t2[:200])
    # アウトライン化した書き出しは変わらない (グラデーションに transform は付かない)
    svg = E.svg_string(A, outline_text=True)
    check("outlined no gradientTransform", "gradientTransform" not in svg)

    # 4. float のキャンバス
    F = bpy.data.images.new("CanvasF", 64, 64, alpha=True, float_buffer=True)
    ops.enable_image(F)
    pl = ops.add_paint_layer(F.vstroke, F)
    check("float paint layer", pl.image.is_float)
    # マスク (VS_OT_mask_add と同じ関数で作る)
    mk = d.new_canvas_part(F, "F_mask", 64, 64)
    check("float mask", mk.is_float)
    # 8bit のキャンバスは今まで通り 8bit
    p8 = ops.add_paint_layer(va, A)
    check("byte paint layer", not p8.image.is_float)
    check("byte mask", not d.new_canvas_part(A, "A_mask", 8, 8).is_float)
    # 描き直しで落ちない
    sys.modules[MOD + ".render"].render_image(F)
    check("render float ok", True)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

"""-b: 画像のトリミング (描き直し・見える範囲・書き出し)、複製で角の丸みが壊れないこと。"""
import os
import sys
import tempfile
import traceback

import bpy
import numpy as np

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    render = sys.modules[MOD + ".render"]
    export = sys.modules[MOD + ".export"]
    G = sys.modules[MOD + ".geometry"]
    canvas = bpy.data.images.new("Canvas", 200, 200, alpha=True)
    canvas.generated_color = (0, 0, 0, 0)
    ops.enable_image(canvas)
    vs = canvas.vstroke
    # 赤い 100x100 の画像を (50, 50) に置く
    src = bpy.data.images.new("Red", 100, 100, alpha=True)
    src.generated_color = (1, 0, 0, 1)
    i = d.new_object(vs, kind='IMAGE')
    ob = vs.objects[i]
    ob.image = src
    ob.img_origin = (50.0, 50.0)
    ob.img_mat = (1.0, 0.0, 0.0, 1.0)
    uid = ob.uid

    def px(x, y):
        a = np.empty(len(canvas.pixels), np.float32)
        canvas.pixels.foreach_get(a)
        a = a.reshape(200, 200, 4)
        return tuple(round(float(v), 2) for v in a[y, x])

    render.render_image(canvas)
    check("before crop: left part red", px(60, 100)[0] > 0.9 and px(60, 100)[3] > 0.9, px(60, 100))
    # 左を 40px 切る
    ob.crop_left = 40.0
    check("crop_left -> fraction", abs(ob.img_crop[0] - 0.4) < 1e-6, tuple(ob.img_crop))
    check("has_crop", d.has_crop(ob))
    render.render_image(canvas)
    check("after crop: cut part empty", px(60, 100)[3] < 0.05, px(60, 100))
    check("after crop: kept part red", px(120, 100)[0] > 0.9, px(120, 100))
    vc = d.image_visible_corners(ob)
    check("visible corners start at x=90", abs(vc[0][0] - 90.0) < 1e-6, vc)
    b = G.bounds_in_frame(G.polylines(G.object_subpaths(ob)))
    check("bounds follow crop", abs(b[0] - 90.0) < 1e-6 and abs(b[2] - 150.0) < 1e-6, b)
    # 上を 30px
    ob.crop_top = 30.0
    check("crop_top", abs(ob.img_crop[3] - 0.7) < 1e-5 and abs(ob.crop_top - 30.0) < 1e-3)
    # 限界: 左右がぶつからない
    ob.crop_right = 1000.0
    check("crop keeps min width", ob.img_crop[2] - ob.img_crop[0] > 0.0, tuple(ob.img_crop))
    ob.crop_right = 0.0
    # 拡大しても、切った割合は同じ (元の画素の座標で持つ)
    tr = sys.modules[MOD + ".transform"]
    tr.transform_items(vs, [uid], G.about(G.scale(2.0, 2.0), 50, 50))
    ob = vs.objects[d.index_of_uid(vs, uid)]
    check("scale keeps crop fraction", abs(ob.img_crop[0] - 0.4) < 1e-6)
    vc2 = d.image_visible_corners(ob)
    check("scaled visible x0 = 50+80", abs(vc2[0][0] - 130.0) < 1e-4, vc2)
    tr.transform_items(vs, [uid], G.about(G.scale(0.5, 0.5), 50, 50))
    # SVG 書き出し
    path = os.path.join(tempfile.gettempdir(), "vs_crop_test.svg")
    r = export.export_svg(canvas, path, include_base=False, outline_text=True,
                          selection_only=False)
    if os.path.exists(path):
        s = open(path, encoding="utf-8").read()
        check("svg has clipPath for crop", "<clipPath id=\"crop" in s and "clip-path=\"url(#crop" in s)
    else:
        print("export function:", [n for n in dir(export) if not n.startswith("_")][:30], r)
        fails.append("svg export not run")
    # 遠近変形でもトリミングが効く
    d.set_image_corners(ob, [(50, 50), (150, 60), (150, 140), (50, 150)])
    render.render_image(canvas)
    check("distorted + crop: cut part empty", px(60, 100)[3] < 0.05, px(60, 100))
    check("distorted + crop: kept part red", px(130, 100)[0] > 0.9, px(130, 100))
    vc3 = d.image_visible_corners(ob)
    check("distorted visible corners inside", 50 < vc3[0][0] < 150, vc3)
    # 元に戻す
    ob.img_crop = (0, 0, 1, 1)
    check("reset -> no crop", not d.has_crop(ob))
    # 複製しても角の丸みが壊れない (0.35.8 の % の値のコピーの不具合)
    j = d.new_object(vs, kind='PATH')
    pth = vs.objects[j]
    sp = pth.subpaths.add()
    for x, y in ((10, 10), (90, 10), (90, 90), (10, 90)):
        q = sp.points.add()
        q.co = q.handle_left = q.handle_right = (x, y)
    sp.closed = True
    sp.points[0].corner_radius = 12.0
    sp.points[2].corner_radius = 5.0
    puid = pth.uid
    new = d.duplicate(vs, [puid])
    dup = vs.objects[d.index_of_uid(vs, new[0])]
    rs = [round(p.corner_radius, 4) for p in dup.subpaths[0].points]
    check("duplicate keeps corner radii", rs == [12.0, 0.0, 5.0, 0.0], rs)
    # コピー・貼り付け (辞書を通す) でも
    d.copy_objects(vs, [puid])
    made = d.paste_objects(vs, 0)
    pasted = vs.objects[d.index_of_uid(vs, made[0])] if made else None
    rs2 = [round(p.corner_radius, 4) for p in pasted.subpaths[0].points] if pasted else None
    check("paste keeps corner radii", rs2 == [12.0, 0.0, 5.0, 0.0], rs2)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

"""-b: 有効化するとき、何も描かれていない画像は背景を非表示 (透明) にする。"""
import sys
import traceback

import bpy
import numpy as np

sys.path.insert(0, sys.argv[sys.argv.index("--") + 1])
MOD = "bl_ext.user_default.vector_strokes_image_editor"
fails = []


def check(name, cond, extra=""):
    print(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


try:
    bpy.ops.preferences.addon_enable(module=MOD)
    d = sys.modules[MOD + ".data"]
    ops = sys.modules[MOD + ".operators"]
    render = sys.modules[MOD + ".render"]

    def original(img):
        return next(o for o in img.vstroke.objects if d.is_original(o))

    def alpha_at(img, x, y):
        w, h = img.size
        a = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(a)
        return float(a.reshape(h, w, 4)[y, x, 3])

    # 1) 新規画像のまま (単色)
    a = bpy.data.images.new("Blank", 64, 64, alpha=True)
    a.generated_color = (1, 1, 1, 1)
    ops.enable_image(a)
    check("blank -> original hidden", original(a).visible is False)
    check("blank -> note", ops.enable_note["text"] == ops.BLANK_NOTE)
    render.render_image(a)
    check("blank -> transparent canvas", alpha_at(a, 10, 10) < 1e-3)
    # 2) UV グリッド (Blender が作ったまま)
    g = bpy.data.images.new("Grid", 64, 64, alpha=True)
    g.generated_type = 'UV_GRID'
    ops.enable_image(g)
    check("untouched UV grid -> hidden", original(g).visible is False)
    # 3) 何か描いてある画像
    p = bpy.data.images.new("Painted", 64, 64, alpha=True)
    p.generated_color = (1, 1, 1, 1)
    arr = np.ones((64, 64, 4), np.float32)
    arr[20:40, 20:40] = (1, 0, 0, 1)
    p.pixels.foreach_set(arr.ravel())
    p.update()
    print("painted is_dirty", p.is_dirty, "source", p.source)
    ops.enable_image(p)
    check("painted -> original visible", original(p).visible is True)
    check("painted -> no note", ops.enable_note["text"] == "")
    render.render_image(p)
    check("painted -> kept opaque", alpha_at(p, 30, 30) > 0.99)
    # 4) 単色で塗りつぶした (描いた扱いでも一色) -> 非表示
    s = bpy.data.images.new("Solid", 32, 32, alpha=True)
    s.pixels.foreach_set(np.tile(np.array([0.2, 0.3, 0.4, 1.0], np.float32), 32 * 32))
    s.update()
    ops.enable_image(s)
    check("solid filled -> hidden", original(s).visible is False)
    # 非表示を戻せば元の色
    original(s).visible = True
    render.render_image(s)
    check("show again -> opaque", alpha_at(s, 5, 5) > 0.99)
except Exception:
    traceback.print_exc()
    fails.append("exception")
print("RESULT", "PASS" if not fails else "FAIL %s" % fails)

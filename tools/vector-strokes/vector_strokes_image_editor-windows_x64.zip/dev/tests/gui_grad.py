"""キャンバスのグラデーションツールが、正しい塗り/線を動かすか (本物のドラッグで)。
blender --enable-event-simulate empty.blend --python gui_grad.py -- <pylib> <out>"""
import os
import sys
import traceback

import bpy

argv = sys.argv[sys.argv.index("--") + 1:]
PYLIB, OUT = argv[0], argv[1]
sys.path.insert(0, PYLIB)
MOD = "bl_ext.user_default.vector_strokes_image_editor"
log = open(os.path.join(OUT, "grad.txt"), "w", encoding="utf-8")
fails = []
S = {}


def say(*a):
    print(*a)
    log.write(" ".join(str(x) for x in a) + "\n")
    log.flush()


def check(name, cond, extra=""):
    say(("OK   " if cond else "FAIL ") + name, extra)
    if not cond:
        fails.append(name)


def M(n):
    return sys.modules[MOD + "." + n]


def area():
    return next(a for a in bpy.context.screen.areas if a.type == 'IMAGE_EDITOR')


def region():
    return next(r for r in area().regions if r.type == 'WINDOW')


def ctx():
    return dict(window=bpy.context.window, area=area(), region=region())


def img():
    return bpy.data.images["Canvas"]


def ob():
    return next(o for o in img().vstroke.objects if o.kind == 'PATH')


def idx(kind):
    return next(k for k, p in enumerate(ob().paints) if p.kind == kind)


def win_xy(pt):
    """画像の座標 → ウィンドウの座標。"""
    r = region()
    v = M("geometry").View.from_region(r, img())
    rx, ry = v.to_region(pt)
    return int(r.x + rx), int(r.y + ry)


def setup():
    bpy.ops.preferences.addon_enable(module=MOD)
    big = max(bpy.context.screen.areas, key=lambda a: a.width * a.height)
    big.type = 'IMAGE_EDITOR'
    im = bpy.data.images.new("Canvas", 512, 512, alpha=True)
    big.spaces.active.image = im
    big.spaces.active.show_region_ui = True
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.enable()
    d = M("data")
    v = im.vstroke
    i = d.new_object(v, kind='PATH')
    o = v.objects[i]
    sp = o.subpaths.add()
    for x, y in ((100, 100), (400, 100), (400, 400), (100, 400)):
        p = sp.points.add()
        p.co = p.handle_left = p.handle_right = (x, y)
    sp.closed = True
    for x in v.objects:
        x.select = x.uid == o.uid
    d.set_active(v, i)
    o.paints[idx('FILL')].paint_type = 'LINEAR'
    o.active_paint = idx('STROKE')          # 0.34.0 以降の「動かない active_paint」の状態
    bpy.ops.ed.undo_push(message="setup")


win = None


def drag_img(p0, p1, steps=8):
    x0, y0 = win_xy(p0)
    x1, y1 = win_xy(p1)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x0 - 15, y=y0 - 15)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x0, y=y0)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x0, y=y0)
    for k in range(1, steps + 1):
        win.event_simulate(type='MOUSEMOVE', value='NOTHING',
                           x=int(x0 + (x1 - x0) * k / steps), y=int(y0 + (y1 - y0) * k / steps))
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x1, y=y1)


steps = []


def a_tool():
    # 左ツールバーで G を選んだのと同じ (サイドバーのボタンは使わない)
    with bpy.context.temp_override(**ctx()):
        bpy.ops.vstroke.set_tool(tool='GRADIENT')
    say("editing", M("state").editing_image, "tool", M("state").current_tool.name)


def a_dummy():
    x, y = win_xy((-60, 256))           # 画像の外 (何も起きない所)
    win.event_simulate(type='MOUSEMOVE', value='NOTHING', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='PRESS', x=x, y=y)
    win.event_simulate(type='LEFTMOUSE', value='RELEASE', x=x, y=y)


def a_drag_fill_end():
    f = ob().paints[idx('FILL')]
    S["fill_end0"] = tuple(f.g_end)
    say("fill g", tuple(f.g_start), tuple(f.g_end))
    drag_img(tuple(f.g_end), (tuple(f.g_end)[0] - 80, tuple(f.g_end)[1] + 60))


def c_fill():
    f = ob().paints[idx('FILL')]
    s = ob().paints[idx('STROKE')]
    check("G without button -> fill end moved", tuple(f.g_end) != S["fill_end0"],
          (S["fill_end0"], tuple(f.g_end)))
    check("stroke stays solid", s.paint_type == 'SOLID', s.paint_type)


def a_stroke_grad():
    s = ob().paints[idx('STROKE')]
    s.paint_type = 'LINEAR'
    bpy.ops.ed.undo_push(message="stroke gradient")
    S["fill_end1"] = tuple(ob().paints[idx('FILL')].g_end)
    # サイドバーの「キャンバスで調整 (G)」(線の方) を押したのと同じ
    with bpy.context.temp_override(window=bpy.context.window, area=area(),
                                   region=next(r for r in area().regions if r.type == 'UI')):
        r = bpy.ops.vstroke.gradient_canvas(index=idx('STROKE'))
    say("gradient_canvas", r, "active_paint", ob().active_paint)


def a_drag_stroke_start():
    s = ob().paints[idx('STROKE')]
    S["stroke_start0"] = tuple(s.g_start)
    drag_img(tuple(s.g_start), (tuple(s.g_start)[0] + 50, tuple(s.g_start)[1] + 90))


def c_stroke():
    f = ob().paints[idx('FILL')]
    s = ob().paints[idx('STROKE')]
    check("button(stroke) -> stroke start moved", tuple(s.g_start) != S["stroke_start0"],
          (S["stroke_start0"], tuple(s.g_start)))
    check("fill untouched", tuple(f.g_end) == S["fill_end1"], tuple(f.g_end))


def finish():
    say("RESULT", "PASS" if not fails else "FAIL %s" % fails)
    log.close()
    bpy.ops.wm.quit_blender()


def tick():
    try:
        if not steps:
            finish()
            return None
        fn = steps.pop(0)
        fn()
        return 1.0
    except Exception:
        say("ERROR", traceback.format_exc())
        fails.append("exception")
        finish()
        return None


def start():
    global win
    win = bpy.context.window
    try:
        setup()
    except Exception:
        say("SETUP ERROR", traceback.format_exc())
        finish()
        return None
    steps.extend([a_tool, a_dummy, a_drag_fill_end, c_fill, a_stroke_grad,
                  a_drag_stroke_start, c_stroke])
    bpy.app.timers.register(tick, first_interval=1.0)
    return None


bpy.app.timers.register(start, first_interval=1.5)

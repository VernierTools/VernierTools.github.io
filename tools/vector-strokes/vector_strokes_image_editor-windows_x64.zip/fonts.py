# SPDX-License-Identifier: GPL-3.0-or-later
"""パソコンに入っているフォントを探して一覧にする。

- Mac / Windows / Linux のフォントフォルダを見て、.ttf .otf .ttc .otc を集める
- .ttc (1つのファイルに複数の書体が入っている形式) にも対応する
- 書体名は日本語名があれば日本語名 (「ヒラギノ角ゴシック」)。英語名も別名として覚えるので、
  別のパソコンで開いたときも見つかることがある
- 走査は最初に必要になったときの1回だけ (Mac の約370ファイルで 0.1 秒ほど)
"""

import os
import sys

# 書体1つ分: family=表示名 / style=スタイル名 / path=ファイル / index=ファイル内の番号
_FIELDS = ("family", "style", "path", "index", "weight", "italic")


class Face:
    __slots__ = _FIELDS

    def __init__(self, family, style, path, index, weight=400, italic=False):
        self.family, self.style = family, style
        self.path, self.index = path, index
        self.weight, self.italic = weight, italic

    @property
    def key(self):
        return (self.path, self.index)

    def __repr__(self):
        return "Face(%r, %r)" % (self.family, self.style)


_db = {
    "scanned": False,
    "faces": [],        # Face のリスト
    "families": [],     # 表示名 (並び替え済み)
    "by_family": {},    # 表示名 -> [Face]
    "alias": {},        # 別名 (英語名など) -> 表示名
    "error": "",
}
_blobs = {}     # (path, index) -> uharfbuzz の Face/Font
_EXT = (".ttf", ".otf", ".ttc", ".otc")

# よく使う日本語フォントの候補 (上から順に、見つかったものを初期値にする)
DEFAULT_CANDIDATES = (
    "ヒラギノ角ゴシック", "Hiragino Sans", "ヒラギノ角ゴ ProN", "游ゴシック", "Yu Gothic",
    "Noto Sans JP", "メイリオ", "Meiryo", "MS Pゴシック", "Helvetica", "Arial",
    "Helvetica Neue", "Segoe UI", "DejaVu Sans",
)


def font_dirs():
    """このパソコンのフォントフォルダ (存在するものだけ)。"""
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        cands = ["/System/Library/Fonts", "/System/Library/Fonts/Supplemental",
                 "/Library/Fonts", os.path.join(home, "Library", "Fonts")]
    elif sys.platform == "win32":
        win = os.environ.get("WINDIR", r"C:\Windows")
        local = os.environ.get("LOCALAPPDATA", os.path.join(home, "AppData", "Local"))
        cands = [os.path.join(win, "Fonts"),
                 os.path.join(local, "Microsoft", "Windows", "Fonts")]
    else:
        cands = ["/usr/share/fonts", "/usr/local/share/fonts",
                 os.path.join(home, ".fonts"), os.path.join(home, ".local/share/fonts")]
    return [d for d in cands if os.path.isdir(d)]


def font_files():
    out = []
    seen = set()
    for d in font_dirs():
        for root, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if not x.startswith(".")]
            for f in files:
                if f.lower().endswith(_EXT) and not f.startswith("."):
                    p = os.path.join(root, f)
                    rp = os.path.realpath(p)
                    if rp not in seen:
                        seen.add(rp)
                        out.append(p)
    return sorted(out)


# 名前の取り出し (fontTools の name テーブル)
_JA_LANGS = (1041, 0x411)      # 日本語 (Mac / Windows)
_EN_LANGS = (0, 1033, 0x409)


def _pick(name_table, ids, langs):
    for nid in ids:
        for rec in name_table.names:
            if rec.nameID == nid and rec.langID in langs:
                try:
                    s = rec.toUnicode().strip()
                except Exception:
                    continue
                if s:
                    return s
    return ""


def _names(name_table):
    """(表示する書体名, スタイル名, 別名のリスト)"""
    ja_fam = _pick(name_table, (16, 1), _JA_LANGS)
    en_fam = _pick(name_table, (16, 1), _EN_LANGS)
    ja_sty = _pick(name_table, (17, 2), _JA_LANGS)
    en_sty = _pick(name_table, (17, 2), _EN_LANGS)
    family = ja_fam or en_fam
    style = ja_sty or en_sty or "Regular"
    if ja_sty in ("Regular", "レギュラー") and en_sty:
        style = en_sty
    aliases = [a for a in (ja_fam, en_fam) if a]
    return family, style, aliases


def _faces_in_file(path):
    from fontTools.ttLib import TTFont
    out = []
    collection = path.lower().endswith((".ttc", ".otc"))
    index = 0
    while True:
        try:
            f = TTFont(path, fontNumber=index if collection else -1, lazy=True)
        except Exception:
            break
        try:
            family, style, aliases = _names(f["name"])
            weight, italic = 400, False
            try:
                os2 = f["OS/2"]
                weight = int(os2.usWeightClass)
                italic = bool(os2.fsSelection & 1)
            except Exception:
                pass
        except Exception:
            family = ""
            aliases = []
        finally:
            try:
                f.close()
            except Exception:
                pass
        if family and not family.startswith("."):
            out.append((Face(family, style, path, index, weight, italic), aliases))
        if not collection:
            break
        index += 1
        if index > 128:
            break
    return out


def scan(force=False):
    """フォントフォルダを走査して一覧を作る。すでに作ってあれば何もしない。"""
    if _db["scanned"] and not force:
        return _db["families"]
    _db["faces"], _db["by_family"], _db["alias"], _db["error"] = [], {}, {}, ""
    try:
        import fontTools  # noqa: F401
    except Exception as e:
        _db["error"] = "fontTools を読み込めません: %s" % e
        _db["scanned"] = True
        return []
    for path in font_files():
        try:
            entries = _faces_in_file(path)
        except Exception:
            continue
        for face, aliases in entries:
            _db["faces"].append(face)
            _db["by_family"].setdefault(face.family, []).append(face)
            for a in aliases:
                _db["alias"].setdefault(a, face.family)
    for fam, lst in _db["by_family"].items():
        lst.sort(key=lambda f: (f.italic, f.weight, f.style))
    _db["families"] = sorted(_db["by_family"].keys(), key=lambda s: s.lower())
    _db["scanned"] = True
    return _db["families"]


def ready():
    return _db["scanned"]


def error():
    return _db["error"]


def families():
    scan()
    return _db["families"]


def styles(family):
    scan()
    fam = resolve_family(family)
    return [f.style for f in _db["by_family"].get(fam, [])]


def resolve_family(family):
    """別名 (英語名など) も含めて、一覧にある書体名に直す。無ければ空文字。"""
    scan()
    if family in _db["by_family"]:
        return family
    alias = _db["alias"].get(family)
    if alias:
        return alias
    low = family.lower().strip()
    for f in _db["families"]:
        if f.lower() == low:
            return f
    return ""


def find(family, style=""):
    """書体名とスタイル名から Face を探す。無ければ None。"""
    scan()
    fam = resolve_family(family)
    lst = _db["by_family"].get(fam)
    if not lst:
        return None
    if style:
        for f in lst:
            if f.style == style:
                return f
        low = style.lower()
        for f in lst:
            if f.style.lower() == low:
                return f
    # 同じ名前のスタイルが無ければ、名前から読み取った太さにいちばん近いものを選ぶ
    # (FEHv3 に Bold は無く ExtraBold だけ、のような場合に Bold -> ExtraBold。
    #  前は黙って標準の太さに落ちていた。2026-10-09 ユーザー報告)
    weight, italic = style_weight(style)
    return min(lst, key=lambda f: (f.italic != italic, abs(f.weight - weight)))


# スタイル名に入っている言葉 -> 太さ (長い言葉から先に見る。"extrabold" の中の "bold" に
# 先に当たらないように)
_WEIGHT_WORDS = (
    ("extralight", 200), ("ultralight", 200), ("extrabold", 800), ("ultrabold", 800),
    ("semibold", 600), ("demibold", 600), ("hairline", 100), ("regular", 400),
    ("medium", 500), ("normal", 400), ("light", 300), ("heavy", 900), ("black", 900),
    ("thin", 100), ("book", 400), ("bold", 700),
)


def style_weight(style):
    """スタイル名から (太さ, 斜体か) を読み取る。読み取れなければ (400, False)。"""
    low = (style or "").lower().replace(" ", "").replace("-", "").replace("_", "")
    italic = "italic" in low or "oblique" in low
    for word, w in _WEIGHT_WORDS:
        if word in low:
            return w, italic
    return 400, italic


def default_family():
    """初期値にする書体名。"""
    scan()
    for name in DEFAULT_CANDIDATES:
        fam = resolve_family(name)
        if fam:
            return fam
    return _db["families"][0] if _db["families"] else ""


def default_style(family):
    f = find(family)
    return f.style if f is not None else ""


def hb_font(face):
    """uharfbuzz のフォント (文字の並べ方と字形を取り出すのに使う)。"""
    import uharfbuzz as hb
    key = face.key
    got = _blobs.get(key)
    if got is not None:
        return got
    with open(face.path, "rb") as fp:
        raw = fp.read()
    hb_face = hb.Face(raw, face.index)
    font = hb.Font(hb_face)
    upem = hb_face.upem or 1000
    font.scale = (upem, upem)
    try:
        hb.ot_font_set_funcs(font)
    except Exception:
        pass
    _blobs[key] = font
    return font


def clear_cache():
    _blobs.clear()


def available():
    """文字を扱えるか (uharfbuzz と fontTools が読み込めるか)。"""
    try:
        import uharfbuzz  # noqa: F401
        import fontTools  # noqa: F401
    except Exception:
        return False
    return True

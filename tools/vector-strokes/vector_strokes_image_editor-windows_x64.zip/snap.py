# SPDX-License-Identifier: GPL-3.0-or-later
"""スナップ (吸い付き)。

合わせる相手:
- キャンバス (画像) の左端・中央・右端 / 下端・中央・上端
- 他のオブジェクトの 左端・中央・右端 / 下端・中央・上端

動かしているものの「端と中央」が相手に近づくと、ぴたりと合う。
合ったときは、その位置に目印の線 (ガイド) を出す (state.snap_guides)。
オン/オフは上のバーの右端にあるボタン (window_manager.vstroke_tool.snap_enable)。
"""

import math

import bpy

from . import data, geometry as G, state

DEFAULT_DISTANCE = 8.0      # 吸い付く距離 (画面上のピクセル)


def settings():
    try:
        return bpy.context.window_manager.vstroke_tool
    except Exception:
        return None


def enabled():
    ts = settings()
    return bool(ts is not None and ts.snap_enable)


def distance_px():
    pr = state.prefs()
    return float(getattr(pr, "snap_distance", DEFAULT_DISTANCE)) if pr else DEFAULT_DISTANCE


def tolerance(view):
    """画像の座標でみた「吸い付く距離」。"""
    return view.px_to_image(distance_px() * state.ui_scale())


def set_guides(guides):
    state.snap_guides = guides


def clear_guides():
    state.snap_guides = []


def targets(vs, img, exclude=()):
    """吸い付き先の候補 (xs, ys)。exclude は動かしているもの (その子孫も外す)。"""
    w, h = img.size
    xs = [0.0, w / 2.0, float(w)]
    ys = [0.0, h / 2.0, float(h)]
    ch = data.children_map(vs)
    ex = set()
    for u in exclude or ():
        ex.add(u)
        ex.update(data.descendants(vs, u, ch))
    vis = data.effective_visibility(vs)
    for i, ob in enumerate(vs.objects):
        if ob.kind in {'GROUP', 'LAYER'} or ob.uid in ex or not vis[i]:
            continue
        subs = G.object_subpaths(ob) + G.text_frame_subpaths(ob)
        b = G.bounds_in_frame(G.polylines(subs))
        if b is None:
            continue
        xs += [b[0], (b[0] + b[2]) / 2.0, b[2]]
        ys += [b[1], (b[1] + b[3]) / 2.0, b[3]]
    return xs, ys


def _best(values, cands, tol):
    """values のどれかが cands のどれかに近ければ (ずらす量, 合わせた値)。"""
    best = None
    for v in values:
        for c in cands:
            d = c - v
            if abs(d) <= tol and (best is None or abs(d) < abs(best[0])):
                best = (d, c)
    return best


def box_delta(bounds, tgt, tol):
    """枠 (x0, y0, x1, y1) を吸い付かせるための (dx, dy)。ガイドも覚える。"""
    if bounds is None or tgt is None:
        clear_guides()
        return (0.0, 0.0)
    xs, ys = tgt
    bx = [bounds[0], (bounds[0] + bounds[2]) / 2.0, bounds[2]]
    by = [bounds[1], (bounds[1] + bounds[3]) / 2.0, bounds[3]]
    gx = _best(bx, xs, tol)
    gy = _best(by, ys, tol)
    guides = []
    if gx:
        guides.append(('V', gx[1]))
    if gy:
        guides.append(('H', gy[1]))
    set_guides(guides)
    return (gx[0] if gx else 0.0, gy[0] if gy else 0.0)


def point_delta(p, tgt, tol):
    """1点を吸い付かせるための (dx, dy)。"""
    if tgt is None:
        clear_guides()
        return (0.0, 0.0)
    xs, ys = tgt
    gx = _best([p[0]], xs, tol)
    gy = _best([p[1]], ys, tol)
    guides = []
    if gx:
        guides.append(('V', gx[1]))
    if gy:
        guides.append(('H', gy[1]))
    set_guides(guides)
    return (gx[0] if gx else 0.0, gy[0] if gy else 0.0)


def point_targets(vs, img, exclude=()):
    """点のスナップの候補: キャンバスの4隅と中心、他のものの頂点 (パスの点・図形の角・画像の隅)。"""
    w, h = img.size
    out = [(0.0, 0.0), (float(w), 0.0), (float(w), float(h)), (0.0, float(h)),
           (w / 2.0, h / 2.0)]
    ch = data.children_map(vs)
    ex = set()
    for u in exclude or ():
        ex.add(u)
        ex.update(data.descendants(vs, u, ch))
    vis = data.effective_visibility(vs)
    for i, ob in enumerate(vs.objects):
        if ob.kind in {'GROUP', 'LAYER', 'TEXT'} or ob.uid in ex or not vis[i]:
            continue
        for pts, _closed in G.object_subpaths(ob):
            out.extend(tuple(float(v) for v in co) for co, _hl, _hr in pts)
    return out


def place_point(p, pts, lines, view):
    """点を置くとき: 近くに頂点があればそこへぴったり。無ければ縦横のガイドに合わせる。"""
    if not enabled():
        clear_guides()
        return tuple(p)
    tol = tolerance(view)
    best, bd = None, tol
    for q in pts or ():
        d = math.hypot(q[0] - p[0], q[1] - p[1])
        if d <= bd:
            best, bd = q, d
    if best is not None:
        set_guides([('V', best[0]), ('H', best[1])])
        return tuple(best)
    return place(p, lines, view)


def along(dx, dy, corr):
    """Shift で向きを固定したまま吸い付かせる。

    (dx, dy) は固定した向きの移動量、corr はその位置で普通に吸い付かせたときのずらす量。
    固定した線の上から外れないよう、縦のガイド (x) か横のガイド (y) の**どちらか**に
    合う所まで線に沿って動かす。横固定なら縦のガイドだけ、縦固定なら横のガイドだけ、
    斜めなら近い方のガイドと交わる所。ガイドの表示も、使った方だけ残す。
    それまでは Shift 中はスナップを切っていた (2026-09-22 ユーザー要望で変更)。"""
    L = math.hypot(dx, dy)
    cx, cy = corr
    if L < 1e-9:
        clear_guides()
        return dx, dy
    ux, uy = dx / L, dy / L
    opts = []
    if abs(cx) > 1e-9 and abs(ux) > 1e-6:
        opts.append((abs(cx / ux), cx / ux, 'V'))
    if abs(cy) > 1e-9 and abs(uy) > 1e-6:
        opts.append((abs(cy / uy), cy / uy, 'H'))
    if not opts:
        clear_guides()
        return dx, dy
    opts.sort()
    _, t, kind = opts[0]
    keep = {kind}
    if len(opts) > 1 and abs(opts[1][1] - t) < 1e-6:
        keep.add(opts[1][2])                 # どちらのガイドにも合っている
    set_guides([g for g in state.snap_guides if g[0] in keep])
    return dx + t * ux, dy + t * uy


# -----------------------------------------------------------------------------
# ツールから使う入口
# -----------------------------------------------------------------------------

def make(vs, img, exclude=()):
    """ドラッグの初めに候補を作っておく (毎回作ると重いため)。"""
    if not enabled():
        return None
    return targets(vs, img, exclude)


def move(bounds, tgt, view):
    """移動のときのずらす量。"""
    if not enabled() or tgt is None:
        clear_guides()
        return (0.0, 0.0)
    return box_delta(bounds, tgt, tolerance(view))


def place(p, tgt, view):
    """点を置くときの吸い付き後の位置。"""
    if not enabled() or tgt is None:
        clear_guides()
        return tuple(p)
    d = point_delta(p, tgt, tolerance(view))
    return (p[0] + d[0], p[1] + d[1])

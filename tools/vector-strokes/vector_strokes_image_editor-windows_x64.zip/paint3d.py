# SPDX-License-Identifier: GPL-3.0-or-later
"""3D ビューのテクスチャペイントで、いま描いているレイヤーに直接描けるようにする。

2026-10-18 ユーザー要望「テクスチャペイントをオブジェクトに直接もできるようにしたい。
イメージエディターでペイントモードの時だけ」。

**それまで何が起きていたか**
3D ビューのテクスチャペイントは、マテリアルが使っている画像 (= キャンバス。アドオンが
レイヤーを重ねて作る完成形) に直接描く。ところがペイント中は、paint_preview が
「描いているレイヤー」の変化をキャンバスに書き戻すので、3D ビューで描いた分はすぐ
上書きされ、キャンセルされたように見えた。

**どうするか**
イメージエディターでブラシで描いている間 (state.paint があるあいだ) だけ、
テクスチャペイントの描き先を「単一画像」(tool_settings.image_paint.mode = 'IMAGE') にして、
画像を「いま描いているレイヤー (マスクに描いているならそのマスク)」にする。
描いた絵は、筆を離すたびに paint_preview がキャンバスへ反映するので、3D ビューにも出る。
ペイントをやめたら、元の設定 (マテリアルの画像に描く等) に戻す。

- レイヤーがキャンバスにぴったり重なっていないとき (動かした・拡大した写真など) は、
  UV の位置と合わないので描かせない (画像なしにする。描いても何も起きない)
- 状態は見回り (paint_preview.tick から) で合わせる。入る・切り替える・Undo・やめる、の
  どの道を通っても、ここだけ見ればよいように
"""

import bpy

from . import state

# ペイントに入る前の設定 (シーン名, 描き先の種類, 画像名)。戻すときに使う
_prev = {"saved": None}


def _target():
    """3D ビューで描かせる画像。描かせないなら None。ペイントしていなければ False。"""
    info = state.paint
    if not info:
        return False
    layer = bpy.data.images.get(info.get("layer", ""))
    canvas = bpy.data.images.get(info.get("canvas", ""))
    if layer is None or canvas is None:
        return None
    # マスクはいつもキャンバスと同じ大きさで重なっている (placement は 'ALIGNED')。
    # 動かした・拡大した画像 ('OFFSET' / 'SOLO') は UV の位置と合わないので描かせない
    if info.get("placement", 'ALIGNED') != 'ALIGNED' or tuple(layer.size) != tuple(canvas.size):
        return None
    return layer


def can_paint_3d():
    """いま 3D ビューから描けるか (サイドバーの案内に使う)。"""
    t = _target()
    return t is not None and t is not False


def sync():
    """3D ビューの描き先を、今の状態に合わせる。"""
    scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return
    ip = scene.tool_settings.image_paint
    t = _target()
    if t is False:
        _restore()
        return
    if _prev["saved"] is None:
        canvas = ip.canvas
        _prev["saved"] = (scene.name, ip.mode, canvas.name if canvas is not None else "")
    want = t if t is not None else None
    if ip.mode != 'IMAGE':
        ip.mode = 'IMAGE'
    if ip.canvas != want:
        ip.canvas = want


def _restore():
    saved = _prev["saved"]
    if saved is None:
        return
    _prev["saved"] = None
    scene = bpy.data.scenes.get(saved[0])
    if scene is None:
        return
    ip = scene.tool_settings.image_paint
    try:
        ip.mode = saved[1]
        ip.canvas = bpy.data.images.get(saved[2]) if saved[2] else None
    except Exception as e:
        print("[Vector Strokes] テクスチャペイントの設定を戻せませんでした:", e)


def register():
    pass


def unregister():
    _restore()

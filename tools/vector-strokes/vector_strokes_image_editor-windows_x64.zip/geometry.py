# SPDX-License-Identifier: GPL-3.0-or-later
"""ベジェ曲線の計算、図形の生成、アフィン変換、画面座標との変換、当たり判定。

ここの関数は bpy の PropertyGroup でも、同じ属性を持つ普通の Python
オブジェクトでも動く(テストしやすくするため)。

「点列」は [(co, handle_left, handle_right), ...] のタプルのリスト、
「サブパス」は (点列, closed) のタプル。座標は画像ピクセル座標 (原点左下)。
"""

import math

import numpy as np

EPS = 1e-6
KAPPA = 0.5522847498307936  # 円弧をベジェで近似する係数


def same_point(a, b):
    return abs(a[0] - b[0]) <= EPS and abs(a[1] - b[1]) <= EPS


def is_straight(p0, p1, p2, p3):
    return same_point(p0, p1) and same_point(p2, p3)


# -----------------------------------------------------------------------------
# サブパス (タプル形式)
# -----------------------------------------------------------------------------

def corner_list(sp):
    """点ごとの (角の半径, 角の形)。角の丸めを使っていなければ None。"""
    out = []
    used = False
    for pt in sp.points:
        r = float(getattr(pt, "corner_radius", 0.0))
        used = used or r > 0.0
        out.append((r, getattr(pt, "corner_type", 'ROUND')))
    return out if used else None


def _unit(v):
    n = math.hypot(v[0], v[1])
    return (0.0, 0.0) if n < EPS else (v[0] / n, v[1] / n)


def _corner_arc(p, a, b, radius, kind):
    """点 p の角を丸める / 面取りする。
    a, b は隣の点。戻り値: [(co, handle_left, handle_right), ...] (2点) または None
    (p を置き換える点列。角が作れないときは None)"""
    da = _unit((a[0] - p[0], a[1] - p[1]))
    db = _unit((b[0] - p[0], b[1] - p[1]))
    if da == (0.0, 0.0) or db == (0.0, 0.0):
        return None
    cosang = max(min(da[0] * db[0] + da[1] * db[1], 1.0), -1.0)
    ang = math.acos(cosang)                      # 角の内角
    if ang < 1e-3 or abs(ang - math.pi) < 1e-3:  # まっすぐ / 折り返し
        return None
    half = ang / 2.0
    la = math.hypot(a[0] - p[0], a[1] - p[1])
    lb = math.hypot(b[0] - p[0], b[1] - p[1])
    cut = radius / math.tan(half)                # 角から端までの距離
    cut = min(cut, la * 0.5, lb * 0.5)
    if cut <= EPS:
        return None
    p1 = (p[0] + da[0] * cut, p[1] + da[1] * cut)
    p2 = (p[0] + db[0] * cut, p[1] + db[1] * cut)
    if kind == 'BEVEL':
        return [(p1, p1, p1), (p2, p2, p2)]
    if kind == 'INVERTED':
        # p を中心にした、内側にえぐれる円弧
        d = (4.0 / 3.0) * math.tan(ang / 4.0) * cut
        # 接線 = 半径 (p->p1) に垂直で、p2 の側へ向く向き
        n1 = (-da[1], da[0])
        if n1[0] * (p2[0] - p1[0]) + n1[1] * (p2[1] - p1[1]) < 0:
            n1 = (-n1[0], -n1[1])
        n2 = (-db[1], db[0])
        if n2[0] * (p1[0] - p2[0]) + n2[1] * (p1[1] - p2[1]) < 0:
            n2 = (-n2[0], -n2[1])
        h1 = (p1[0] + n1[0] * d, p1[1] + n1[1] * d)
        h2 = (p2[0] + n2[0] * d, p2[1] + n2[1] * d)
        return [(p1, p1, h1), (p2, h2, p2)]
    # 丸: 2辺に接する円弧
    r = cut * math.tan(half)
    sweep = math.pi - ang
    d = (4.0 / 3.0) * math.tan(sweep / 4.0) * r
    h1 = (p1[0] - da[0] * d, p1[1] - da[1] * d)   # p の方へ伸ばす
    h2 = (p2[0] - db[0] * d, p2[1] - db[1] * d)
    return [(p1, p1, h1), (p2, h2, p2)]


def apply_corners(pts, closed, corners):
    """角の丸め (ライブコーナー) を形に反映した点列を返す。"""
    n = len(pts)
    if not corners or n < 3:
        return pts
    out = []
    for i, (co, hl, hr) in enumerate(pts):
        r, kind = corners[i] if i < len(corners) else (0.0, 'ROUND')
        sharp = same_point(hl, co) and same_point(hr, co)
        prev_i, next_i = i - 1, i + 1
        if not closed and (i == 0 or i == n - 1):
            out.append((co, hl, hr))
            continue
        if r <= 0.0 or not sharp:
            out.append((co, hl, hr))
            continue
        a = pts[prev_i % n][0]
        b = pts[next_i % n][0]
        made = _corner_arc(co, a, b, r, kind)
        out.extend(made if made else [(co, hl, hr)])
    return out


def subpath_tuple(sp):
    """VS_Subpath -> (点列, closed)"""
    return ([(tuple(p.co), tuple(p.handle_left), tuple(p.handle_right)) for p in sp.points],
            bool(sp.closed))


def iter_segments_t(pts, closed):
    n = len(pts)
    if n < 2:
        return
    count = n if closed else n - 1
    for i in range(count):
        a = pts[i]
        b = pts[(i + 1) % n]
        yield (a[0], a[2], b[1], b[0])


def iter_segments(sp):
    """VS_Subpath の各区間を (p0, p1, p2, p3) で返す。閉じていれば最後→最初の区間も含む。"""
    pts, closed = subpath_tuple(sp)
    return iter_segments_t(pts, closed)


def flatten_t(pts, closed):
    """点列を折れ線 (N,2) に変換。閉じていても始点は繰り返さない。"""
    n = len(pts)
    if n == 0:
        return np.zeros((0, 2), np.float64)
    if n == 1:
        return np.array([pts[0][0]], np.float64)
    out = []
    for i, (p0, p1, p2, p3) in enumerate(iter_segments_t(pts, closed)):
        if is_straight(p0, p1, p2, p3):
            c = np.array([p0, p3], np.float64)
        else:
            p0, p1, p2, p3 = (np.array(v, np.float64) for v in (p0, p1, p2, p3))
            L = (np.linalg.norm(p1 - p0) + np.linalg.norm(p2 - p1)
                 + np.linalg.norm(p3 - p2))
            steps = int(min(max(math.ceil(L / 6.0), 4), 256))
            t = np.linspace(0.0, 1.0, steps + 1)[:, None]
            mt = 1.0 - t
            c = (mt ** 3) * p0 + 3 * (mt ** 2) * t * p1 \
                + 3 * mt * (t ** 2) * p2 + (t ** 3) * p3
        out.append(c if i == 0 else c[1:])
    poly = np.concatenate(out, axis=0)
    if closed and len(poly) > 1:
        poly = poly[:-1]  # 最後の区間の終点 = 始点
    return poly


def flatten_subpath(sp):
    return flatten_t(*subpath_tuple(sp))


# -----------------------------------------------------------------------------
# 図形 (パラメーターから点列を作る)
# -----------------------------------------------------------------------------

def _rect_local(w, h, r):
    """中心原点・幅 w 高さ h・角の半径 r の矩形 (反時計回り、左下の辺から)。"""
    hw, hh = w / 2.0, h / 2.0
    r = max(0.0, min(r, hw, hh))
    if r <= EPS:
        return [((x, y), (x, y), (x, y)) for x, y in
                ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))]
    k = r * KAPPA
    pts = []
    # 各角: (角の中心x符号, y符号) と、入ってくる辺の向き
    corners = (((hw, -hh), (1, 0), (0, 1)),    # 右下: 下辺(→)から右辺(↑)へ
               ((hw, hh), (0, 1), (-1, 0)),    # 右上
               ((-hw, hh), (-1, 0), (0, -1)),  # 左上
               ((-hw, -hh), (0, -1), (1, 0)))  # 左下
    for (cx, cy), (ix, iy), (ox, oy) in corners:
        # 角に入る手前の点と、角を出た後の点
        a = (cx - ix * r, cy - iy * r)
        b = (cx + ox * r, cy + oy * r)
        pts.append((a, a, (a[0] + ix * k, a[1] + iy * k)))
        pts.append((b, (b[0] - ox * k, b[1] - oy * k), b))
    return pts


def _ellipse_local(w, h):
    rx, ry = w / 2.0, h / 2.0
    kx, ky = rx * KAPPA, ry * KAPPA
    return [((rx, 0.0), (rx, -ky), (rx, ky)),
            ((0.0, ry), (kx, ry), (-kx, ry)),
            ((-rx, 0.0), (-rx, ky), (-rx, -ky)),
            ((0.0, -ry), (-kx, -ry), (kx, -ry))]


def _polygon_local(w, h, sides):
    """正多角形。Illustrator と同じく底辺が水平。"""
    n = max(3, int(sides))
    rx, ry = w / 2.0, h / 2.0
    pts = []
    for k in range(n):
        a = -math.pi / 2 + math.pi / n + k * 2 * math.pi / n
        p = (rx * math.cos(a), ry * math.sin(a))
        pts.append((p, p, p))
    return pts


def _star_local(w, h, points, inner_ratio):
    """星形。Illustrator と同じく1つの頂点が真上。"""
    n = max(3, int(points))
    rx, ry = w / 2.0, h / 2.0
    pts = []
    for k in range(2 * n):
        a = math.pi / 2 + k * math.pi / n
        f = 1.0 if k % 2 == 0 else inner_ratio
        p = (rx * f * math.cos(a), ry * f * math.sin(a))
        pts.append((p, p, p))
    return pts


def shape_local_points(ob):
    """図形の点列 (図形の中心が原点、回転前)。"""
    w, h = abs(ob.size[0]), abs(ob.size[1])
    t = ob.shape_type
    if t == 'RECT':
        pts = _rect_local(w, h, ob.corner_radius)
    elif t == 'ELLIPSE':
        pts = _ellipse_local(w, h)
    elif t == 'POLYGON':
        pts = _polygon_local(w, h, ob.sides)
    else:
        pts = _star_local(w, h, ob.star_points, ob.inner_ratio)
    # 幅・高さが負 = 反転
    sx = -1.0 if ob.size[0] < 0 else 1.0
    sy = -1.0 if ob.size[1] < 0 else 1.0
    if sx < 0 or sy < 0:
        pts = [tuple((q[0] * sx, q[1] * sy) for q in p) for p in pts]
    return pts


def shape_matrix(ob):
    """図形のローカル座標 -> 画像座標 (回転 + 移動)。"""
    return compose(translate(*ob.center), rotate(ob.rotation))


def shape_subpaths(ob):
    return [(transform_points(shape_local_points(ob), shape_matrix(ob)), True)]


def object_subpaths(ob):
    """オブジェクトの形を [(点列, closed), ...] で返す (グループは空)。
    角の丸め (ライブコーナー) は、ここで形に反映する。
    点そのもの (ob.subpaths) は元のまま残るので、角はあとから変えられる。"""
    if ob.kind == 'PATH':
        out = []
        for sp in ob.subpaths:
            if len(sp.points) == 0:
                continue
            pts, closed = subpath_tuple(sp)
            corners = corner_list(sp)
            if corners:
                pts = apply_corners(pts, closed, corners)
            out.append((pts, closed))
        return out
    if ob.kind == 'SHAPE':
        return shape_subpaths(ob)
    if ob.kind == 'IMAGE':
        from . import data
        w, h = data.image_size(ob)
        if w <= 0 or h <= 0:
            return []
        # 見えている範囲の4隅 (遠近変形していればその形、トリミングしていればその範囲)
        pts = data.image_visible_corners(ob)
        return [([(p, p, p) for p in pts], True)]
    if ob.kind == 'TEXT':
        from . import text
        try:
            return text.text_subpaths(ob)
        except Exception as e:
            print("[Vector Strokes] 文字を組めませんでした:", e)
            return []
    return []


def text_frame_subpaths(ob):
    """エリア文字の枠 / パス上文字のパス (画像座標)。それ以外は []。"""
    if getattr(ob, "kind", "") != 'TEXT' or ob.text_kind == 'POINT':
        return []
    from . import text
    try:
        return text.frame_image_subpaths(ob)
    except Exception:
        return []


# -----------------------------------------------------------------------------
# アフィン変換 (3x3 行列)
# -----------------------------------------------------------------------------

def identity():
    return np.eye(3)


def translate(x, y):
    m = np.eye(3)
    m[0, 2], m[1, 2] = x, y
    return m


def rotate(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def scale(sx, sy):
    return np.diag([sx, sy, 1.0])


def compose(*ms):
    out = np.eye(3)
    for m in ms:
        out = out @ m
    return out


def about(m, px, py):
    """点 (px, py) を中心に m を適用する行列。"""
    return compose(translate(px, py), m, translate(-px, -py))


def apply(m, p):
    return (m[0, 0] * p[0] + m[0, 1] * p[1] + m[0, 2],
            m[1, 0] * p[0] + m[1, 1] * p[1] + m[1, 2])


def apply_vec(m, v):
    return (m[0, 0] * v[0] + m[0, 1] * v[1], m[1, 0] * v[0] + m[1, 1] * v[1])


def transform_points(pts, m):
    return [(apply(m, co), apply(m, hl), apply(m, hr)) for co, hl, hr in pts]


def linear_scale_factor(m):
    """線幅などに掛ける倍率 (面積倍率の平方根)。"""
    return math.sqrt(abs(m[0, 0] * m[1, 1] - m[0, 1] * m[1, 0]))


# -----------------------------------------------------------------------------
# 範囲 (バウンディングボックス)
# -----------------------------------------------------------------------------

def polylines(subpaths):
    return [(flatten_t(pts, closed), closed) for pts, closed in subpaths if pts]


def bounds_in_frame(polys, angle=0.0):
    """折れ線群を角度 angle の座標系で見た範囲 (x0, y0, x1, y1)。無ければ None。"""
    arrs = [p for p, _ in polys if len(p)]
    if not arrs:
        return None
    a = np.concatenate(arrs, axis=0)
    if angle:
        c, s = math.cos(-angle), math.sin(-angle)
        a = a @ np.array([[c, s], [-s, c]])
    return (float(a[:, 0].min()), float(a[:, 1].min()),
            float(a[:, 0].max()), float(a[:, 1].max()))


def frame_to_world(angle, p):
    c, s = math.cos(angle), math.sin(angle)
    return (c * p[0] - s * p[1], s * p[0] + c * p[1])


def world_to_frame(angle, p):
    return frame_to_world(-angle, p)


# -----------------------------------------------------------------------------
# 画面(リージョン)座標 <-> 画像ピクセル座標
# -----------------------------------------------------------------------------

class View:
    """画像ピクセル座標 -> リージョン座標 のアフィン変換 (origin + p * scale)。"""

    def __init__(self, origin, scale_):
        self.o = np.asarray(origin, np.float64)
        self.s = np.asarray(scale_, np.float64)

    @classmethod
    def from_region(cls, region, img):
        w, h = img.size
        ox, oy = region.view2d.view_to_region(0.0, 0.0, clip=False)
        ex, ey = region.view2d.view_to_region(1.0, 1.0, clip=False)
        return cls((ox, oy), ((ex - ox) / w, (ey - oy) / h))

    def to_region(self, p):
        return self.o + np.asarray(p, np.float64) * self.s

    def to_image(self, rx, ry):
        v = (np.array([rx, ry], np.float64) - self.o) / self.s
        return (float(v[0]), float(v[1]))

    def px_to_image(self, d):
        """画面上の長さ d を画像ピクセルの長さに。"""
        return d / max(abs(float(self.s[0])), 1e-9)


# -----------------------------------------------------------------------------
# 当たり判定
# -----------------------------------------------------------------------------

def dist_to_polyline(poly, closed, m):
    """点 m から折れ線までの最短距離。"""
    if len(poly) == 0:
        return float("inf")
    if len(poly) == 1:
        return float(np.hypot(*(poly[0] - m)))
    if closed:
        poly = np.vstack([poly, poly[:1]])
    a = poly[:-1]
    d = poly[1:] - a
    dd = np.maximum((d * d).sum(axis=1), 1e-12)
    t = np.clip(((m - a) * d).sum(axis=1) / dd, 0.0, 1.0)
    q = a + d * t[:, None] - m
    return float(np.sqrt((q * q).sum(axis=1)).min())


def point_in_polys(polys, p, rule='EVENODD'):
    """点 p が塗りの内側か (開いたパスも閉じたものとして扱う)。
    rule='NONZERO' なら重なりを塗る規則、'EVENODD' なら偶奇規則。"""
    x, y = p
    inside = False
    wind = 0
    for poly, _ in polys:
        n = len(poly)
        if n < 3:
            continue
        xs, ys = poly[:, 0], poly[:, 1]
        xj, yj = np.roll(xs, 1), np.roll(ys, 1)   # 直前の点
        cond = (ys > y) != (yj > y)
        with np.errstate(divide='ignore', invalid='ignore'):
            xint = (xj - xs) * (y - ys) / (yj - ys) + xs
        cross = cond & (x < xint)
        if rule == 'NONZERO':
            # 上向きに横切れば +1、下向きなら -1
            wind += int(np.count_nonzero(cross & (yj <= y))) - \
                int(np.count_nonzero(cross & (yj > y)))
        else:
            inside ^= bool(np.count_nonzero(cross) % 2)
    return wind != 0 if rule == 'NONZERO' else inside


def polyline_hits_rect(poly, closed, r):
    """折れ線が矩形 r=(x0,y0,x1,y1) に一部でもかかるか。"""
    x0, y0, x1, y1 = r
    if len(poly) == 0:
        return False
    inside = ((poly[:, 0] >= x0) & (poly[:, 0] <= x1) & (poly[:, 1] >= y0) & (poly[:, 1] <= y1))
    if inside.any():
        return True
    if len(poly) < 2:
        return False
    pts = np.vstack([poly, poly[:1]]) if closed else poly
    for (ax, ay), (bx, by) in zip(pts[:-1], pts[1:]):
        # Liang-Barsky
        dx, dy = bx - ax, by - ay
        t0, t1 = 0.0, 1.0
        ok = True
        for p, q in ((-dx, ax - x0), (dx, x1 - ax), (-dy, ay - y0), (dy, y1 - ay)):
            if abs(p) < 1e-12:
                if q < 0:
                    ok = False
                    break
            else:
                t = q / p
                if p < 0:
                    t0 = max(t0, t)
                else:
                    t1 = min(t1, t)
                if t0 > t1:
                    ok = False
                    break
        if ok:
            return True
    return False


def hit_test(view, vs, mx, my, radius, visible=None):
    """ペンツール用: 点・ハンドルの当たり判定 (パスのみ)。
    戻り値: (kind, (oi, si, qi))  kind in {'POINT','HL','HR'}、または None"""
    best = None
    best_d = radius
    for oi, ob in enumerate(vs.objects):
        if ob.kind != 'PATH' or (visible is not None and not visible[oi]) or not ob.visible:
            continue
        for si, sp in enumerate(ob.subpaths):
            for qi, pt in enumerate(sp.points):
                co = tuple(pt.co)
                cands = [('POINT', co)]
                if pt.select:
                    cands += [('HL', tuple(pt.handle_left)), ('HR', tuple(pt.handle_right))]
                for kind, v in cands:
                    if kind != 'POINT' and same_point(v, co):
                        continue
                    r = view.to_region(v)
                    d = math.hypot(r[0] - mx, r[1] - my)
                    # 同距離ならアンカー優先
                    if d < best_d - (0.5 if kind != 'POINT' else 0.0):
                        best_d = d
                        best = (kind, (oi, si, qi))
    return best


def hit_test_shape_points(view, vs, mx, my, radius, visible=None):
    """図形の頂点に当たったか。戻り値: オブジェクト番号 or None"""
    best = None
    best_d = radius
    for oi, ob in enumerate(vs.objects):
        if ob.kind != 'SHAPE' or (visible is not None and not visible[oi]) or not ob.visible:
            continue
        for pts, _ in shape_subpaths(ob):
            for co, _, _ in pts:
                r = view.to_region(co)
                d = math.hypot(r[0] - mx, r[1] - my)
                if d < best_d:
                    best_d = d
                    best = oi
    return best


def _cubic_at(p0, p1, p2, p3, t):
    mt = 1.0 - t
    return (mt ** 3 * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0]
            + t ** 3 * p3[0],
            mt ** 3 * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1]
            + t ** 3 * p3[1])


def closest_on_path(view, vs, mx, my, tol, visible=None, kinds=('PATH',)):
    """線の上のいちばん近い場所。戻り値: (オブジェクト番号, サブパス, 区間, t) or None。
    t は区間の中の位置 (0〜1)。点を足すときに使う。"""
    best, best_d = None, float(tol)
    for oi, ob in enumerate(vs.objects):
        if ob.kind not in kinds or not ob.visible:
            continue
        if visible is not None and not visible[oi]:
            continue
        for si, sp in enumerate(ob.subpaths):
            pts, closed = subpath_tuple(sp)
            if len(pts) < 2:
                continue
            for seg, (p0, p1, p2, p3) in enumerate(iter_segments_t(pts, closed)):
                steps = 24
                for k in range(steps + 1):
                    t = k / steps
                    q = view.to_region(np.array([_cubic_at(p0, p1, p2, p3, t)],
                                                np.float64))[0]
                    d = math.hypot(q[0] - mx, q[1] - my)
                    if d < best_d:
                        best_d, best = d, (oi, si, seg, t)
    if best is None:
        return None
    # 見つかった区間のまわりをもう少し細かく探す
    oi, si, seg, t0 = best
    pts, closed = subpath_tuple(vs.objects[oi].subpaths[si])
    p0, p1, p2, p3 = list(iter_segments_t(pts, closed))[seg]
    lo, hi = max(t0 - 1.0 / 24, 0.0), min(t0 + 1.0 / 24, 1.0)
    for k in range(21):
        t = lo + (hi - lo) * k / 20.0
        q = view.to_region(np.array([_cubic_at(p0, p1, p2, p3, t)], np.float64))[0]
        d = math.hypot(q[0] - mx, q[1] - my)
        if d < best_d:
            best_d, best = d, (oi, si, seg, t)
    return best


def split_cubic(p0, p1, p2, p3, t):
    """3次ベジェを t で2つに分ける。戻り値: (手前のハンドル, 新しい点の左右, 奥のハンドル)"""
    lerp = lambda a, b: (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)  # noqa: E731
    a, b, c = lerp(p0, p1), lerp(p1, p2), lerp(p2, p3)
    d, e = lerp(a, b), lerp(b, c)
    f = lerp(d, e)
    return a, (d, f, e), c


def hit_test_curve(view, vs, mx, my, tol, visible=None):
    """線の近くをクリックしたか (パスと図形)。戻り値: オブジェクト番号 or None"""
    m = np.array([mx, my], np.float64)
    best = None
    best_d = tol
    for oi, ob in enumerate(vs.objects):
        if ob.kind == 'GROUP' or (visible is not None and not visible[oi]) or not ob.visible:
            continue
        for pts, closed in object_subpaths(ob):
            if len(pts) < 2:
                continue
            dist = dist_to_polyline(view.to_region(flatten_t(pts, closed)), closed, m)
            if dist < best_d:
                best_d = dist
                best = oi
    return best


def constrain_45(dx, dy):
    """移動量・向きを 0/45/90° の方向に制限する (Shift を押しながらのドラッグ)。
    選択ツールのオブジェクト移動・ペンの点とハンドルで共通に使う。"""
    L = math.hypot(dx, dy)
    if L < 1e-12:
        return dx, dy
    a = round(math.atan2(dy, dx) / (math.pi / 4)) * (math.pi / 4)
    proj = dx * math.cos(a) + dy * math.sin(a)
    return proj * math.cos(a), proj * math.sin(a)

# SPDX-License-Identifier: GPL-3.0-or-later
"""画像が開かれていないイメージエディターで描こうとしたとき、キャンバスの上に
「先に画像を開くか作ってください」と少しのあいだ出す。

Blender は、画像が無いとペイントもこのアドオンのツールも黙って何もしない。
確認のポップアップは邪魔で、画面下の通知は気づきにくい (2026-10-19 ユーザー要望) ので、
キャンバスの上の方に重ねて描き、数秒で消す。

クリックは「Screen Editing」キーマップ (ツールやペイントのキーマップより先に見られる)
で拾い、PASS_THROUGH で返すので、ほかの操作の邪魔はしない。
「Image」キーマップでは間に合わない: 標準の Brush ツールのときは、画像が無くても
「Image Paint」の paint.image_paint がクリックを受け取って捨ててしまう (実測で確認)。
"""

import time

import bpy
from bpy.types import Operator

from . import keys, state

SHOW_SECONDS = 3.0
FADE_SECONDS = 0.6

# 出している所 (エリアのポインタ, 出した時刻)。無ければ None
notice = None

_addon_keymaps = []


def _wants_hint(context):
    """画像が無いのに「描こう」としているか。注釈ツールは画像が無くても描けるので除く。
    表示モードの既定のツール (サンプルなど) も、描くつもりではないので出さない。"""
    from . import tools
    sp = context.space_data
    mode = getattr(sp, "ui_mode", "")
    tid = tools.active_tool_id(context, mode) or ""
    if tid in tools.TOOL_NAMES:
        return True
    return mode == 'PAINT' and not tid.startswith("builtin.annotate")


class VS_OT_no_image_hint(Operator):
    """画像が無いときに、画像を開くか作るよう知らせる"""
    bl_idname = "vstroke.no_image_hint"
    bl_label = "画像がありません"
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        sp = context.space_data
        return (context.area is not None and context.area.type == 'IMAGE_EDITOR'
                and context.region is not None and context.region.type == 'WINDOW'
                and sp is not None and getattr(sp, "image", True) is None
                and _wants_hint(context))

    def invoke(self, context, event):
        show(context.area)
        return {'CANCELLED', 'PASS_THROUGH'}


def show(area):
    global notice
    notice = (area.as_pointer(), time.monotonic())
    area.tag_redraw()
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.05)


def _alpha():
    if notice is None:
        return 0.0
    t = time.monotonic() - notice[1]
    if t >= SHOW_SECONDS:
        return 0.0
    return min(1.0, (SHOW_SECONDS - t) / FADE_SECONDS)


def _tick():
    """消えていく間だけ描き直す (隠れたウィンドウでも止まらないようタイマーで)。"""
    global notice
    try:
        for win in bpy.context.window_manager.windows:
            for a in win.screen.areas:
                if a.type == 'IMAGE_EDITOR':
                    a.tag_redraw()
    except Exception:
        pass
    if _alpha() <= 0.0:
        notice = None
        return None
    return 0.05


def _rounded_rect(p, x0, y0, x1, y1, r, color):
    import math
    r = min(r, (x1 - x0) * 0.5, (y1 - y0) * 0.5)
    tris = []

    def rect(a, b, c, d):
        tris.extend([(a, b), (c, b), (c, d), (a, b), (c, d), (a, d)])

    rect(x0 + r, y0, x1 - r, y1)
    rect(x0, y0 + r, x0 + r, y1 - r)
    rect(x1 - r, y0 + r, x1, y1 - r)
    seg = 8
    for cx, cy, a0 in ((x1 - r, y1 - r, 0.0), (x0 + r, y1 - r, 0.5 * math.pi),
                       (x0 + r, y0 + r, math.pi), (x1 - r, y0 + r, 1.5 * math.pi)):
        for k in range(seg):
            t0 = a0 + 0.5 * math.pi * k / seg
            t1 = a0 + 0.5 * math.pi * (k + 1) / seg
            tris += [(cx, cy), (cx + r * math.cos(t0), cy + r * math.sin(t0)),
                     (cx + r * math.cos(t1), cy + r * math.sin(t1))]
    p.tris(tris, color)


def draw(ctx, painter_cls):
    """overlay.draw_overlay から毎回呼ばれる。出していなければ何もしない。"""
    if notice is None or ctx.area is None or ctx.region is None:
        return
    if ctx.area.as_pointer() != notice[0]:
        return
    if getattr(ctx.space_data, "image", None) is not None:
        return          # もう画像を開いた
    a = _alpha()
    if a <= 0.0:
        return
    import blf
    u = state.ui_scale()
    region = ctx.region
    title = "画像がありません"
    body = keys.fmt("先に画像を開くか、新しく作成してください  (新規 {A}N ・ 開く {A}O)")
    font = 0
    blf.size(font, 14.0 * u)
    tw, th = blf.dimensions(font, title)
    blf.size(font, 12.0 * u)
    bw, bh = blf.dimensions(font, body)
    pad_x, pad_y, gap = 18.0 * u, 12.0 * u, 7.0 * u
    w = max(tw, bw) + pad_x * 2
    h = th + bh + gap + pad_y * 2
    cx = region.width * 0.5
    top = region.height - 28.0 * u
    x0, x1 = cx - w * 0.5, cx + w * 0.5
    y0, y1 = top - h, top
    p = painter_cls(region)
    p.gpu.state.blend_set('ALPHA')
    _rounded_rect(p, x0, y0, x1, y1, 8.0 * u, (0.10, 0.10, 0.10, 0.92 * a))
    _rounded_rect(p, x0, y1 - 3.0 * u, x1, y1, 1.5 * u, (0.95, 0.60, 0.15, a))   # 上の色の帯
    blf.size(font, 14.0 * u)
    blf.color(font, 1.0, 1.0, 1.0, a)
    blf.position(font, cx - tw * 0.5, y1 - pad_y - th, 0)
    blf.draw(font, title)
    blf.size(font, 12.0 * u)
    blf.color(font, 0.85, 0.85, 0.85, a)
    blf.position(font, cx - bw * 0.5, y0 + pad_y, 0)
    blf.draw(font, body)
    p.gpu.state.blend_set('NONE')


def register():
    bpy.utils.register_class(VS_OT_no_image_hint)
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc is None:
        return
    km = kc.keymaps.new(name="Screen Editing", space_type='EMPTY')
    kmi = km.keymap_items.new(VS_OT_no_image_hint.bl_idname, 'LEFTMOUSE', 'PRESS', any=True)
    _addon_keymaps.append((km, kmi))


def unregister():
    global notice
    for km, kmi in _addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _addon_keymaps.clear()
    notice = None
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    bpy.utils.unregister_class(VS_OT_no_image_hint)

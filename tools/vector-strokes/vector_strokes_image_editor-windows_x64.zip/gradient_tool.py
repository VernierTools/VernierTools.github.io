# SPDX-License-Identifier: GPL-3.0-or-later
"""グラデーションツール (Illustrator のグラデーションツール = G)。

選んでいるオブジェクトの「今選んでいる塗り/線」のグラデーションを、キャンバス上で調整する。

- 何もない所からドラッグ: 方向と長さを決め直す (Shift: 45°刻み)
- 始点・終点の丸をドラッグ: その端だけ動かす
- 途中の四角 (分岐点) をドラッグ: 色の位置を変える
- 単色のままなら、ドラッグした時点で線形グラデーションにする
"""

import math

from . import data, geometry as G, render, state, transform
from .select_tool import select_only
from .tool_base import Tool

HEADER_TEXT = ("グラデーション | ドラッグ: 方向と長さ (Shift: 45°刻み) | "
               "端の丸: 位置 | 途中の四角: 分岐点の位置 | "
               "線の上を二度押し: 分岐点を足す | サイドバーで色を編集 | V: 選択 P: ペン | Esc: 終了 | 右クリック: メニュー")


def target_index(vs):
    """調整する対象 (オブジェクト, 塗り/線の番号)。無ければ (None, -1)。

    対象は「選んでいる塗り/線」(active_paint)。ただしそれが単色なら、グラデーションの
    塗り/線 (手前のもの) を使う。どれもグラデーションでなければ、手前の塗り
    (Illustrator と同じく、塗りをグラデーションにする)。
    0.34.0 でサイドバーの塗り/線の一覧をなくしてから active_paint が動かなくなり、
    単色の線を触ってしまうことがあった (2026-10-17 ユーザー報告「キャンバスで位置調整が
    正しく動いていない」)。今はサイドバーの「キャンバスで調整」とカラーランプの編集で決まる"""
    items = transform.selected_items(vs)
    ob = None
    if items:
        i = data.index_of_uid(vs, items[-1])
        ob = vs.objects[i] if i >= 0 else None
    if ob is None:
        ob = data.active_object(vs)
    if ob is None or ob.kind not in {'PATH', 'SHAPE', 'TEXT'} or len(ob.paints) == 0:
        return None, -1
    i = min(max(ob.active_paint, 0), len(ob.paints) - 1)
    if ob.paints[i].paint_type == 'SOLID':
        grads = [k for k, p in enumerate(ob.paints) if p.paint_type != 'SOLID']
        fills = [k for k, p in enumerate(ob.paints) if p.kind == 'FILL']
        if grads:
            i = grads[-1]
        elif fills:
            i = fills[-1]
    return ob, i


def target(vs):
    """調整する対象 (オブジェクト, 塗り/線)。無ければ (None, None)。"""
    ob, i = target_index(vs)
    return (ob, ob.paints[i]) if ob is not None else (None, None)


def stop_point(paint, stop):
    """分岐点の画像座標 (始点と終点のあいだ)。"""
    a, b = tuple(paint.g_start), tuple(paint.g_end)
    t = float(stop.position)
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


def make_gradient(ob, paint, kind='LINEAR'):
    """単色ならグラデーションにする。"""
    if paint.paint_type == 'SOLID':
        with render.suspended():
            paint.paint_type = kind      # 分岐点と位置は update 側で用意される
        b = G.bounds_in_frame(G.polylines(G.object_subpaths(ob)))
        data.ensure_gradient_stops(paint, b)


class GradientTool(Tool):
    name = 'GRADIENT'
    header = HEADER_TEXT
    cursor = 'CROSSHAIR'

    def _hit(self, view, paint, mx, my):
        """('START'|'END'|('STOP', i)) または None"""
        tol = max(8.0 * state.ui_scale(), state.hit_radius() * 0.6)
        if paint.paint_type == 'SOLID':
            return None
        ends = (('START', tuple(paint.g_start)), ('END', tuple(paint.g_end)))
        for name, p in ends:
            r = view.to_region(p)
            if math.hypot(r[0] - mx, r[1] - my) <= tol:
                return name
        for i, st in enumerate(paint.stops):
            r = view.to_region(stop_point(paint, st))
            if math.hypot(r[0] - mx, r[1] - my) <= tol:
                return ('STOP', i)
        return None

    def _line_t(self, view, paint, mx, my):
        """グラデーションの線の上か。上なら位置 (0〜1)、違えば None。"""
        if paint.paint_type == 'SOLID':
            return None
        a = view.to_region(tuple(paint.g_start))
        b = view.to_region(tuple(paint.g_end))
        vx, vy = b[0] - a[0], b[1] - a[1]
        L2 = vx * vx + vy * vy
        if L2 < 1e-9:
            return None
        t = ((mx - a[0]) * vx + (my - a[1]) * vy) / L2
        if not (0.0 <= t <= 1.0):
            return None
        px, py = a[0] + vx * t, a[1] + vy * t
        tol = max(8.0 * state.ui_scale(), state.hit_radius() * 0.6)
        return t if math.hypot(px - mx, py - my) <= tol else None

    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke

        if self.drag is not None:
            if event.type == 'MOUSEMOVE':
                self._update(img, view, mx, my, event)
                return 'RUNNING_MODAL'
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                d, self.drag = self.drag, None
                if not self._changed(d):
                    return 'RUNNING_MODAL'      # 押しただけ (Undo の空の段を積まない)
                render.render_image(img)
                self.push_undo("Edit Gradient")
                return 'RUNNING_MODAL'
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._cancel(img)
                return 'RUNNING_MODAL'
            return 'RUNNING_MODAL'

        if not inside or event.type == 'MOUSEMOVE':
            return 'PASS_THROUGH'

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if event.type == 'ESC' and transform.selected_items(vs):
                select_only(vs, [])
                self.redraw()
                return 'RUNNING_MODAL'
            return 'FINISHED'

        if event.type == 'LEFTMOUSE' and event.value in {'PRESS', 'DOUBLE_CLICK'}:
            return self._press(img, view, mx, my)
        return 'PASS_THROUGH'

    def _press(self, img, view, mx, my):
        vs = img.vstroke
        ob, index = target_index(vs)
        paint = ob.paints[index] if ob is not None else None
        if paint is None:
            self.host.report("グラデーションにするオブジェクトを選んでください")
            return 'RUNNING_MODAL'
        hit = self._hit(view, paint, mx, my)
        # 線の上を二度押し -> その場所に分岐点を足す (よくあるグラデーションの操作)
        if hit is None and self.double_press(mx, my):
            t = self._line_t(view, paint, mx, my)
            if t is not None:
                data.insert_stop(paint, t)
                render.render_image(img)
                self.push_undo("Add Gradient Stop")
                self.host.report("分岐点を足しました")
                self.redraw()
                return 'RUNNING_MODAL'
        was = paint.paint_type          # 単色だったかどうかも覚える (Esc で戻すため)
        make_gradient(ob, paint)
        self.drag = {"uid": ob.uid, "index": index, "hit": hit,
                     "start_img": view.to_image(mx, my), "was": was,
                     "orig": (tuple(paint.g_start), tuple(paint.g_end),
                              [s.position for s in paint.stops])}
        return 'RUNNING_MODAL'

    def _changed(self, d):
        """ドラッグで何か変わったか (押しただけなら False。単色をグラデーションにしたら True)。"""
        img = self.image()
        if img is None:
            return False
        paint = self._paint(img.vstroke, d)
        if paint is None:
            return False
        a0, b0, positions = d["orig"]
        if d.get("was") != paint.paint_type:
            return True
        if tuple(paint.g_start) != tuple(a0) or tuple(paint.g_end) != tuple(b0):
            return True
        return any(st.position != pos for st, pos in zip(paint.stops, positions))

    def _paint(self, vs, d=None):
        d = d or self.drag
        i = data.index_of_uid(vs, d["uid"])
        if i < 0:
            return None
        ob = vs.objects[i]
        return ob.paints[d["index"]] if 0 <= d["index"] < len(ob.paints) else None

    def _update(self, img, view, mx, my, event):
        vs = img.vstroke
        paint = self._paint(vs)
        if paint is None:
            return
        d = self.drag
        a0, b0, positions = d["orig"]
        p = view.to_image(mx, my)
        hit = d["hit"]
        with render.suspended():
            if hit == 'START':
                paint.g_start = p
            elif hit == 'END':
                paint.g_end = self._constrain(a0, p, event)
            elif isinstance(hit, tuple):           # 分岐点
                i = hit[1]
                if i < len(paint.stops):
                    a, b = tuple(paint.g_start), tuple(paint.g_end)
                    vx, vy = b[0] - a[0], b[1] - a[1]
                    L2 = vx * vx + vy * vy
                    t = 0.0 if L2 < 1e-9 else ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / L2
                    paint.stops[i].position = min(max(t, 0.0), 1.0)
            else:                                   # 新しく引き直す
                paint.g_start = d["start_img"]
                paint.g_end = self._constrain(d["start_img"], p, event)
        self.maybe_render(img)

    @staticmethod
    def _constrain(a, p, event):
        if not event.shift:
            return p
        dx, dy = p[0] - a[0], p[1] - a[1]
        ang = round(math.atan2(dy, dx) / (math.pi / 4)) * (math.pi / 4)
        L = math.hypot(dx, dy)
        return (a[0] + L * math.cos(ang), a[1] + L * math.sin(ang))

    def _cancel(self, img):
        vs = img.vstroke
        paint = self._paint(vs)
        d = self.drag
        self.drag = None
        if paint is not None:
            a0, b0, positions = d["orig"]
            with render.suspended():
                paint.g_start, paint.g_end = a0, b0
                for st, pos in zip(paint.stops, positions):
                    st.position = pos
                # ドラッグで単色からグラデーションにした場合は、単色に戻す
                if d.get("was") == 'SOLID':
                    paint.paint_type = 'SOLID'
        render.render_image(img)

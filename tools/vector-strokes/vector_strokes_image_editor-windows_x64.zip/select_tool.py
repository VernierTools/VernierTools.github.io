# SPDX-License-Identifier: GPL-3.0-or-later
"""選択ツール (Illustrator の選択ツール = 黒矢印)。

オブジェクト単位で選び、移動・拡大縮小・回転する。グループは丸ごと選ばれる。
ダブルクリックでグループの中に入って編集する (グループ編集モード)。
"""

import math

import bpy

import numpy as np

from . import corners, data, geometry as G, keys, render, snap, state, transform
from .tool_base import Tool, set_isolation

HEADER_TEXT = keys.fmt("選択 | クリック: 選択 (Shift: 追加) | ドラッグ: 移動 (Shift: 45°, Alt: 複製) | "
               "四隅・辺: 拡大縮小 (Shift: 縦横比, Alt: 中心から) | 角の外側: 回転 (Shift: 45°) | "
               "ダブルクリック: グループの中へ / 文字を打ち直し | {C}G / {C}{S}G: グループ化 / 解除 | "
               "{C}7 / {C}{A}7: マスク作成 / 解除 | {C}] {C}[: 前面へ / 背面へ | "
               "{C}{S}O: 文字をアウトライン化 | {CMD}+画像の角をドラッグ: 遠近変形 | "
               "矢印: 1px 移動 | X/Delete: 削除 | P: ペン M/L: 図形 | Esc: 終了 | 右クリック: メニュー")

HANDLES = [(-1, -1), (0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0)]
ARROWS = {'LEFT_ARROW': (-1, 0), 'RIGHT_ARROW': (1, 0),
          'UP_ARROW': (0, 1), 'DOWN_ARROW': (0, -1)}


def selectable_item(vs, uid, iso, m=None):
    """uid のオブジェクトをクリックしたとき実際に選ばれるもの。
    グループ編集中はそのグループの直接の子、そうでなければレイヤー直下の祖先。
    範囲外・ロック中なら None。"""
    m = m or data.uid_map(vs)
    if not data.is_editable(vs, uid, m):
        return None

    def is_top(a):
        p = m[a].parent_uid
        if iso:
            return p == iso
        return p == 0 or p not in m or m[p].kind == 'LAYER'
    a = uid
    seen = set()
    while a in m and not is_top(a):
        if a in seen:
            return None
        seen.add(a)
        a = m[a].parent_uid
        if a == 0 or a not in m:
            return None
    if a not in m or m[a].kind == 'LAYER':
        return None
    return a


def _clip_ancestors(vs, uid, m, ch):
    """uid を切り抜いているマスクの形 (祖先のクリップグループ) の uid。自分がマスクの形なら除く。"""
    out = []
    child = uid
    for a in data.ancestors(vs, uid, m):
        g = m[a]
        if g.clip:
            cp = data.clip_path_uid(vs, a, ch)
            if cp and cp != child:
                out.append(cp)
        child = a
    return out


def mask_covers(vs, view, uid, p, m, ch):
    """画面上の点 p が、マスクの形 uid の「中身を通す部分」の上か。
    塗りのアルファが 0 なら塗りの中は通さない。線だけなら線の上だけ通す
    (画像・ペイントレイヤーは、置かれた四角の内側を通すとみなす。細かい透明度までは見ない)。"""
    ob = m[uid]
    if not ob.visible:
        return False
    if ob.kind in {'GROUP', 'LAYER'}:
        kids = ch.get(uid, [])
        if ob.clip and kids:
            return mask_covers(vs, view, kids[-1], p, m, ch)
        return any(mask_covers(vs, view, k, p, m, ch) for k in kids)
    polys = [(view.to_region(poly), closed)
             for poly, closed in G.polylines(G.object_subpaths(ob))]
    if not polys:
        return False
    inside = G.point_in_polys(polys, p, ob.fill_rule)
    if ob.kind == 'IMAGE' or data.mask_fill(ob):
        if inside:
            return True
    sc = abs(float(view.s[0]))
    near = None
    for width, align in data.mask_strokes(ob):
        if near is None:
            near = min((G.dist_to_polyline(poly, closed, p) for poly, closed in polys),
                       default=1e9)
        if align == 'CENTER':
            hit = near <= width * 0.5 * sc
        elif align == 'INSIDE':
            hit = inside and near <= width * sc
        else:
            hit = (not inside) and near <= width * sc
        if hit:
            return True
    return False


def pick_leaf(vs, view, mx, my, iso, tol):
    """画面上の点 (mx, my) にある、いちばん前面のパス/図形そのものの uid。無ければ None。
    (グループ単位ではなく、実際に描かれているもの)"""
    m = data.uid_map(vs)
    ch = data.children_map(vs)
    editable = data.effective_editable(vs)
    p = np.array([mx, my], np.float64)
    sc = abs(float(view.s[0]))

    def region_polys(ob):
        return [(view.to_region(poly), closed)
                for poly, closed in G.polylines(G.object_subpaths(ob))]

    def frame_polys(ob):
        return [(view.to_region(poly), closed)
                for poly, closed in G.polylines(G.text_frame_subpaths(ob))]
    for i in range(len(vs.objects) - 1, -1, -1):
        ob = vs.objects[i]
        if ob.kind in {'GROUP', 'LAYER'} or not editable[i]:
            continue
        polys = region_polys(ob)
        frames = frame_polys(ob)      # エリア文字の枠・パス上文字のパス
        if not polys and not frames:
            continue
        is_mask = data.is_clip_path(vs, ob.uid, m, ch)
        # 画像は面全体がクリックの的になる
        solid = data.has_fill(ob) or ob.kind == 'IMAGE'
        hit = (not is_mask) and solid and G.point_in_polys(polys, p, ob.fill_rule)
        # エリア文字は枠の中ならどこでも的になる (Illustrator と同じ。字の上だけだと
        # 空いている所をクリックしても選べず、ダブルクリックで編集に入れない)
        if not hit and not is_mask and ob.kind == 'TEXT' and ob.text_kind == 'AREA':
            hit = G.point_in_polys(frames, p, 'NONZERO')
        if not hit:
            t = tol + (data.stroke_extent(ob) * sc if not is_mask else 0.0)
            hit = any(G.dist_to_polyline(poly, closed, p) <= t
                      for poly, closed in polys + frames)
        # マスクで隠れている部分はクリックできない
        if hit and any(not mask_covers(vs, view, c, p, m, ch)
                       for c in _clip_ancestors(vs, ob.uid, m, ch)):
            hit = False
        if hit and selectable_item(vs, ob.uid, iso, m) is not None:
            return ob.uid
    return None


def pick(vs, view, mx, my, iso, tol):
    """クリックで選ばれる単位 (グループならグループ全体) の uid。無ければ None。"""
    leaf = pick_leaf(vs, view, mx, my, iso, tol)
    return None if leaf is None else selectable_item(vs, leaf, iso)


def end_crop_edit():
    """キャンバスでのトリミングを終える (外側を暗くした表示をやめ、切った形で描き直す)。"""
    cur = state.crop_edit
    state.crop_edit = None
    if cur is None:
        return
    img = bpy.data.images.get(cur[0])
    if img is not None:
        render.render_image(img)


def pick_for_click(vs, view, mx, my, iso, tol):
    """クリックしたときに対象になる uid。
    すでに選択されているもの (一覧で選んだグループの中の1つなど) の上を押した場合は、
    グループ全体に広げずにそれを返す (Illustrator と同じ)。"""
    leaf = pick_leaf(vs, view, mx, my, iso, tol)
    if leaf is None:
        return None
    m = data.uid_map(vs)
    selected = {ob.uid for ob in vs.objects if ob.select}
    for u in [leaf] + data.ancestors(vs, leaf, m):
        if u in selected:
            return u
    return selectable_item(vs, leaf, iso, m)


def select_only(vs, uids):
    s = set(uids)
    for ob in vs.objects:
        ob.select = ob.uid in s
    if uids:
        data.set_active(vs, data.index_of_uid(vs, uids[-1]))


constrain_45 = G.constrain_45     # 共通 (geometry.py)。ペンの点・ハンドルでも使う


class SelectTool(Tool):
    name = 'SELECT'
    header = HEADER_TEXT
    cursor = 'DEFAULT'

    def _tol(self):
        return max(5.0 * state.ui_scale(), state.hit_radius() * 0.35)

    def _handle_tol(self):
        return max(6.0 * state.ui_scale(), state.hit_radius() * 0.6)

    def frame(self, vs):
        items = transform.selected_items(vs)
        if not items:
            return items, None
        return items, transform.selection_frame(vs, items)

    def distort_target(self, vs):
        """遠近変形できる画像を1つだけ選んでいれば、その画像。"""
        items = transform.selected_items(vs)
        if len(items) != 1:
            return None
        ob = vs.objects[data.index_of_uid(vs, items[0])]
        return ob if data.can_distort(ob) and data.is_editable(vs, ob.uid) else None

    def crop_target(self, vs):
        """キャンバスでトリミングを調整している画像 (選んでいるときだけ)。無ければ None。"""
        cur = state.crop_edit
        if cur is None or cur[0] != self.img_name:
            return None
        i = data.index_of_uid(vs, cur[1])
        if i < 0:
            return None
        ob = vs.objects[i]
        if ob.kind != 'IMAGE' or not ob.select or not data.is_editable(vs, ob.uid):
            return None
        return ob

    def hit_crop(self, vs, view, mx, my):
        """トリミングの枠のつかめる所。(画像, (横の辺, 縦の辺)) または None。
        横の辺は -1 = 左 / 1 = 右 / 0 = 動かさない (縦も同じ。-1 = 下 / 1 = 上)。
        角・辺の真ん中の□に加えて、辺そのものもつかめる。"""
        ob = self.crop_target(vs)
        if ob is None:
            return None
        cs = data.image_visible_corners(ob)      # 左下・右下・右上・左上
        p = np.array([mx, my], np.float64)
        tol = self._handle_tol()
        r = [view.to_region(q) for q in cs]
        cands = [((-1, -1), r[0]), ((1, -1), r[1]), ((1, 1), r[2]), ((-1, 1), r[3]),
                 ((0, -1), (r[0] + r[1]) / 2), ((1, 0), (r[1] + r[2]) / 2),
                 ((0, 1), (r[2] + r[3]) / 2), ((-1, 0), (r[3] + r[0]) / 2)]
        best, bd = None, tol
        for side, q in cands:
            d = float(np.hypot(*(np.asarray(q) - p)))
            if d <= bd:
                best, bd = side, d
        if best is None:
            for side, (a, b) in (((0, -1), (r[0], r[1])), ((1, 0), (r[1], r[2])),
                                 ((0, 1), (r[2], r[3])), ((-1, 0), (r[3], r[0]))):
                if G.dist_to_polyline(np.array([a, b]), False, p) <= tol * 0.6:
                    best = side
                    break
        return None if best is None else (ob, best)

    def hit_image_corner(self, vs, view, mx, my):
        """選んでいる画像の、押した所に近い角 (画像, 番号)。無ければ None。"""
        ob = self.distort_target(vs)
        if ob is None or data.has_crop(ob):
            return None     # トリミングした画像は遠近変形しない (角が見えていないため)
        p = np.array([mx, my], np.float64)
        best, bd = None, self._handle_tol()
        for i, q in enumerate(data.image_corners(ob)):
            d = float(np.hypot(*(view.to_region(q) - p)))
            if d <= bd:
                best, bd = i, d
        return None if best is None else (ob, best)

    def hit_handle(self, vs, view, mx, my):
        """('SCALE', (hx, hy)) / ('ROTATE', (hx, hy)) / None"""
        if self.crop_target(vs) is not None:
            return None
        items, fr = self.frame(vs)
        if fr is None:
            return None
        ang, b = fr
        tol = self._handle_tol()
        best, best_d = None, tol
        for hx, hy in HANDLES:
            r = view.to_region(transform.frame_point(ang, b, hx, hy))
            d = math.hypot(r[0] - mx, r[1] - my)
            if d < best_d:
                best, best_d = ('SCALE', (hx, hy)), d
        if best is not None:
            return best
        # 角のすぐ外側 -> 回転
        f = G.world_to_frame(ang, view.to_image(mx, my))
        inside = b[0] <= f[0] <= b[2] and b[1] <= f[1] <= b[3]
        if not inside:
            for hx, hy in HANDLES:
                if hx == 0 or hy == 0:
                    continue
                r = view.to_region(transform.frame_point(ang, b, hx, hy))
                d = math.hypot(r[0] - mx, r[1] - my)
                if d < tol * 3.0:
                    return ('ROTATE', (hx, hy))
        return None

    def cursor_at(self, view, mx, my):
        img = self.image()
        if img is None:
            return self.cursor
        if self.hit_crop(img.vstroke, view, mx, my) is not None:
            return 'CROSSHAIR'
        h = self.hit_handle(img.vstroke, view, mx, my)
        if h is None:
            return 'DEFAULT'
        if h[0] == 'ROTATE':
            return 'HAND'
        return 'SCROLL_XY'

    # --- イベント ---
    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke

        if self.drag is not None:
            if event.type == 'MOUSEMOVE':
                self._update_drag(img, view, mx, my, event)
                return 'RUNNING_MODAL'
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                return self._release(img, view)
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._cancel(img)
                return 'RUNNING_MODAL'
            return 'RUNNING_MODAL'

        if not inside:
            return 'PASS_THROUGH'
        if event.type == 'MOUSEMOVE':
            return 'PASS_THROUGH'

        if (state.crop_edit is not None and event.value == 'PRESS'
                and event.type in {'ESC', 'RET', 'NUMPAD_ENTER'}):
            end_crop_edit()             # トリミングを終える (選択はそのまま)
            self.redraw()
            return 'RUNNING_MODAL'
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if event.type == 'ESC':
                if transform.selected_items(vs):
                    select_only(vs, [])
                    self.redraw()
                    return 'RUNNING_MODAL'
                if self.isolation(vs):
                    set_isolation(self.img_name, 0)
                    self.redraw()
                    return 'RUNNING_MODAL'
            return 'FINISHED'

        if event.type == 'LEFTMOUSE' and event.value == 'DOUBLE_CLICK':
            self._last_press = None
            self._dbl = False
            return self._double_click(img, view, mx, my)
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            # Blender の DOUBLE_CLICK はモーダル中に届かないことがあるので、自分でも数える。
            # ただし「二度目を押した瞬間」ではなく「動かさずに離したとき」に効かせる
            # (押してすぐドラッグした場合は、ふつうの移動として扱うため)
            self._dbl = (self.double_press(mx, my)
                         and not (event.shift or keys.command_mod(event)))
            return self._press(img, view, mx, my, event)

        if event.value == 'PRESS':
            return self._key(img, event)
        return 'PASS_THROUGH'

    def _press(self, img, view, mx, my, event):
        vs = img.vstroke
        ix, iy = view.to_image(mx, my)
        # トリミング中: 枠の角・辺をつかむ
        k = self.hit_crop(vs, view, mx, my)
        if k is not None:
            ob, side = k
            self.drag = {"type": 'CROP', "uid": ob.uid, "side": side,
                         "crop0": tuple(ob.img_crop), "start": (mx, my), "moved": False}
            return 'RUNNING_MODAL'
        if state.crop_edit is not None and self.crop_target(vs) is not None:
            # トリミング中に、枠の外の別のものを押した -> トリミングを終えて、いつもの選択へ
            item = pick_for_click(vs, view, mx, my, self.isolation(vs), self._tol())
            if item != state.crop_edit[1]:
                end_crop_edit()
        elif state.crop_edit is not None:
            end_crop_edit()
        # 角の丸印 (ライブコーナー) を先に見る
        c = corners.pick(vs, view, mx, my, transform.selected_items(vs), self._tol())
        if c is not None:
            self.drag = {"type": 'CORNER', "ref": c, "start": (mx, my), "moved": False,
                         "r0": corners.common_radius(vs, [c])}
            return 'RUNNING_MODAL'
        # ⌘(Ctrl)+画像の角のドラッグ: 遠近変形 (Photoshop の自由変形と同じ操作)
        if keys.command_mod(event):
            k = self.hit_image_corner(vs, view, mx, my)
            if k is not None:
                ob, idx = k
                self.drag = {"type": 'DISTORT', "uid": ob.uid, "corner": idx,
                             "q0": data.image_corners(ob), "on0": bool(ob.img_quad_on),
                             "quad0": tuple(ob.img_quad),
                             "pts": snap.point_targets(vs, img, [ob.uid]),
                             "lines": snap.make(vs, img, [ob.uid]),
                             "start": (mx, my), "moved": False}
                return 'RUNNING_MODAL'
        h = self.hit_handle(vs, view, mx, my)
        if h is not None:
            items, (ang, b) = self.frame(vs)
            snapshot = transform.snapshot(vs, items)
            if h[0] == 'SCALE':
                self.drag = {"type": 'SCALE', "snap": snapshot, "ang": ang, "b": b,
                             "h": h[1], "start": (mx, my), "moved": False,
                             "targets": snap.make(vs, img, items)}
            else:
                c = transform.frame_point(ang, b, 0, 0)
                self.drag = {"type": 'ROTATE', "snap": snapshot, "center": c,
                             "a0": math.atan2(iy - c[1], ix - c[0]),
                             "start": (mx, my), "moved": False}
            return 'RUNNING_MODAL'

        iso = self.isolation(vs)
        item = pick_for_click(vs, view, mx, my, iso, self._tol())
        if item is not None:
            ob = vs.objects[data.index_of_uid(vs, item)]
            if event.shift:
                ob.select = not ob.select
                self.redraw()
                if not ob.select:
                    return 'RUNNING_MODAL'
            elif not ob.select:
                select_only(vs, [item])
            data.set_active(vs, data.index_of_uid(vs, item))
            items = transform.selected_items(vs)
            self.drag = {"type": 'MOVE', "items": items, "snap": transform.snapshot(vs, items),
                         "start_img": (ix, iy), "start": (mx, my), "moved": False,
                         "dup": None, "targets": snap.make(vs, img, items),
                         "box0": G.bounds_in_frame(transform.items_polylines(vs, items))}
            self.redraw()
            return 'RUNNING_MODAL'

        if not event.shift:
            select_only(vs, [])
        self.drag = {"type": 'MARQUEE', "start": (mx, my), "cur": (mx, my), "moved": False}
        self.redraw()
        return 'RUNNING_MODAL'

    def _double_click(self, img, view, mx, my):
        vs = img.vstroke
        iso = self.isolation(vs)
        item = pick(vs, view, mx, my, iso, self._tol())
        if item is None:
            if iso:
                set_isolation(self.img_name, 0)
                select_only(vs, [])
                self.redraw()
            return 'RUNNING_MODAL'
        ob = vs.objects[data.index_of_uid(vs, item)]
        if ob.kind == 'GROUP':
            set_isolation(self.img_name, item)
            select_only(vs, [])
        elif ob.kind == 'TEXT':
            # 文字 -> 文字ツールで打ち直す (Illustrator と同じ)
            select_only(vs, [item])
            state.text_edit_request = (item, view.to_image(mx, my))
            self.host.switch_tool('TEXT')
        else:
            # パス・図形 -> ペンツールで点を編集 (アドオンの設定でオンにしたときだけ。
            # オフなら選ぶだけ)
            select_only(vs, [item])
            if state.dblclick_pen():
                self.host.switch_tool('PEN')
        self.redraw()
        return 'RUNNING_MODAL'

    def _clipboard_key(self, img, t):
        """⌘C コピー / ⌘X 切り取り / ⌘V 貼り付け。"""
        vs = img.vstroke
        if t == 'V':
            made = data.paste_objects(vs, self.isolation(vs))
            if not made:
                self.host.report("貼り付けるものがありません")
            else:
                render.render_image(img)
                self.push_undo("Paste")
            self.redraw()
            return 'RUNNING_MODAL'
        items = transform.selected_items(vs)
        if not items:
            self.host.report("コピーするものを選んでください")
            return 'RUNNING_MODAL'
        data.copy_objects(vs, items)
        if t == 'X':
            data.remove_objects(vs, items)
            render.render_image(img)
            self.push_undo("Cut")
            self.redraw()
        return 'RUNNING_MODAL'

    def _key(self, img, event):
        vs = img.vstroke
        t = event.type
        cmd = keys.command_mod(event)
        if cmd and t == 'SEVEN':
            items = transform.selected_items(vs)
            if event.alt:
                done = []
                for u in items:
                    ob = vs.objects[data.index_of_uid(vs, u)]
                    if ob.clip:
                        ob.clip = False
                        done.append(u)
                if done:
                    self.push_undo("Release Clipping Mask")
            else:
                g = data.make_clip(vs, items)
                if isinstance(g, str):
                    self.host.report(g)
                else:
                    select_only(vs, [g])
                    render.render_image(img)
                    self.push_undo("Make Clipping Mask")
            self.redraw()
            return 'RUNNING_MODAL'
        if cmd and t in {'RIGHT_BRACKET', 'LEFT_BRACKET'}:
            items = transform.selected_items(vs)
            fwd = t == 'RIGHT_BRACKET'
            mode = ('FRONT' if fwd else 'BACK') if event.shift else ('FORWARD' if fwd else 'BACKWARD')
            if items and data.arrange(vs, items, mode):
                render.render_image(img)
                self.push_undo("Arrange")
            return 'RUNNING_MODAL'
        if cmd and t == 'O' and event.shift:
            from . import operators
            made = operators.outline_selection(vs)
            if made:
                render.render_image(img)
                self.push_undo("Create Outlines")
            else:
                self.host.report("アウトライン化する文字を選んでください")
            self.redraw()
            return 'RUNNING_MODAL'
        if cmd and t in {'C', 'V', 'X'}:
            return self._clipboard_key(img, t)
        if cmd and t == 'G':
            items = transform.selected_items(vs)
            if event.shift:
                kids = []
                for u in items:
                    if vs.objects[data.index_of_uid(vs, u)].kind == 'GROUP':
                        kids += data.ungroup(vs, u)
                    else:
                        kids.append(u)
                if kids != items:
                    select_only(vs, kids)
                    self.push_undo("Ungroup")
            elif items:
                g = data.group(vs, items)
                select_only(vs, [g])
                self.push_undo("Group")
            self.redraw()
            return 'RUNNING_MODAL'
        if cmd:
            return 'PASS_THROUGH'
        if t in keys.CONFIRM_KEYS:
            select_only(vs, [])
            self.redraw()
            return 'RUNNING_MODAL'
        if t in keys.DELETE_KEYS:
            items = transform.selected_items(vs)
            if items:
                data.remove_objects(vs, items)
                render.render_image(img)
                self.push_undo("Delete Objects")
            return 'RUNNING_MODAL'
        if t == 'A':
            if event.alt:
                select_only(vs, [])
            else:
                select_only(vs, self.all_items(vs))
            self.redraw()
            return 'RUNNING_MODAL'
        if t in ARROWS:
            items = transform.selected_items(vs)
            if items:
                step = 10.0 if event.shift else 1.0
                dx, dy = ARROWS[t]
                transform.transform_items(vs, items, G.translate(dx * step, dy * step), False)
                render.render_image(img)
                self.push_undo("Nudge")
            return 'RUNNING_MODAL'
        return 'PASS_THROUGH'

    def all_items(self, vs):
        """A で選ばれるもの: グループ編集中はその中身、それ以外は編集できるレイヤーの中身。"""
        iso = self.isolation(vs)
        ch = data.children_map(vs)
        m = data.uid_map(vs)
        if iso:
            tops = ch.get(iso, [])
        else:
            tops = [u for lay in ch.get(0, []) if m[lay].kind == 'LAYER'
                    for u in ch.get(lay, [])]
        return [u for u in tops if data.is_editable(vs, u, m)]

    # --- ドラッグ ---
    def _update_drag(self, img, view, mx, my, event):
        vs = img.vstroke
        d = self.drag
        if not d["moved"]:
            sx, sy = d["start"]
            if math.hypot(mx - sx, my - sy) < 3 * state.ui_scale():
                return
            d["moved"] = True
        t = d["type"]
        ix, iy = view.to_image(mx, my)
        if t == 'DISTORT':
            # 角を動かす。頂点に近ければぴったり合わせる (点のスナップ)
            ob = vs.objects[data.index_of_uid(vs, d["uid"])]
            p = snap.place_point((ix, iy), d["pts"], d["lines"], view)
            q = list(d["q0"])
            q[d["corner"]] = p
            data.set_image_corners(ob, q)
            self.maybe_render(img)
            return
        if t == 'CROP':
            ob = vs.objects[data.index_of_uid(vs, d["uid"])]
            q = data.image_to_source(ob, (ix, iy), data.source_matrix(ob))
            if q is not None:
                w, h = data.image_size(ob)
                c = list(d["crop0"])
                sx, sy = d["side"]
                mw, mh = data.CROP_MIN_PX / max(w, 1), data.CROP_MIN_PX / max(h, 1)
                u = min(max(q[0] / max(w, 1), 0.0), 1.0)
                v = min(max(q[1] / max(h, 1), 0.0), 1.0)
                if sx < 0:
                    c[0] = min(u, c[2] - mw)
                elif sx > 0:
                    c[2] = max(u, c[0] + mw)
                if sy < 0:
                    c[1] = min(v, c[3] - mh)
                elif sy > 0:
                    c[3] = max(v, c[1] + mh)
                ob.img_crop = c
            self.redraw()
            return
        if t == 'CORNER':
            uid, si, pi = d["ref"]
            ob = vs.objects[data.index_of_uid(vs, uid)]
            info = corners.corner_info(ob, si, pi)
            if info is not None:
                corners.set_radius(vs, [d["ref"]], corners.radius_at(*info, (ix, iy)))
            self.maybe_render(img)
            return
        if t == 'MARQUEE':
            d["cur"] = (mx, my)
            self.redraw()
            return
        if t == 'MOVE':
            if event.alt and d["dup"] is None and d["items"]:
                # Alt+ドラッグ: 複製して、複製の方を動かす
                transform.restore(vs, d["snap"])
                new = data.duplicate(vs, d["items"])
                select_only(vs, new)
                d["dup"] = (d["items"], new)
                d["items"] = new
                d["snap"] = transform.snapshot(vs, new)
                d["box0"] = G.bounds_in_frame(transform.items_polylines(vs, new))
                d["targets"] = snap.make(vs, img, new)
            sx, sy = d["start_img"]
            dx, dy = ix - sx, iy - sy
            if event.shift:
                dx, dy = constrain_45(dx, dy)
            # スナップ: 動かした先の枠を、キャンバスや他のものに合わせる
            # (Shift で向きを固定しているときは、その線の上で合わせる)
            base = d.get("box0")
            if base is not None:
                moved = (base[0] + dx, base[1] + dy, base[2] + dx, base[3] + dy)
                ddx, ddy = snap.move(moved, d.get("targets"), view)
                if event.shift:
                    dx, dy = snap.along(dx, dy, (ddx, ddy))
                else:
                    dx, dy = dx + ddx, dy + ddy
            transform.apply_matrix(vs, d["snap"], G.translate(dx, dy))
        elif t == 'SCALE':
            ang, b = d["ang"], d["b"]
            hx, hy = d["h"]
            cen = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            hpos = (cen[0] + hx * (b[2] - b[0]) / 2, cen[1] + hy * (b[3] - b[1]) / 2)
            anc = cen if event.alt else (cen[0] - hx * (b[2] - b[0]) / 2,
                                         cen[1] - hy * (b[3] - b[1]) / 2)
            if not event.shift and abs(ang) < 1e-9:
                # スナップ: つかんでいる角・辺を、キャンバスや他のものに合わせる
                pt = snap.place((ix, iy), d.get("targets"), view)
                ix = pt[0] if hx else ix
                iy = pt[1] if hy else iy
            mf = G.world_to_frame(ang, (ix, iy))
            sx = sy = 1.0
            if hx and abs(hpos[0] - anc[0]) > 1e-9:
                sx = (mf[0] - anc[0]) / (hpos[0] - anc[0])
            if hy and abs(hpos[1] - anc[1]) > 1e-9:
                sy = (mf[1] - anc[1]) / (hpos[1] - anc[1])
            if event.shift:
                if hx and hy:
                    s = sx if abs(sx) >= abs(sy) else sy
                else:
                    s = sx if hx else sy
                sx = sy = s
            M = transform.scale_matrix(ang, G.frame_to_world(ang, anc), sx, sy)
            transform.apply_matrix(vs, d["snap"], M, vs.scale_strokes, vs.scale_corners)
        elif t == 'ROTATE':
            c = d["center"]
            a = math.atan2(iy - c[1], ix - c[0]) - d["a0"]
            if event.shift:
                a = round(a / (math.pi / 4)) * (math.pi / 4)
            transform.apply_matrix(vs, d["snap"], G.about(G.rotate(a), *c))
        self.maybe_render(img)

    def _release(self, img, view):
        vs = img.vstroke
        d = self.drag
        self.drag = None
        snap.clear_guides()
        if getattr(self, "_dbl", False):
            self._dbl = False
            if not d["moved"]:      # 動かさずに離した二度押し = ダブルクリック
                mx, my = d["cur"] if "cur" in d else d["start"]
                return self._double_click(img, view, mx, my)
        if d["type"] == 'CROP':
            if d["moved"]:
                render.render_image(img)
                self.push_undo("Crop Image")
            self.redraw()
            return 'RUNNING_MODAL'
        if d["type"] == 'CORNER':
            if d["moved"]:
                render.render_image(img)
                self.push_undo("Corner Radius")
            self.redraw()
            return 'RUNNING_MODAL'
        if d["type"] == 'DISTORT':
            if d["moved"]:
                render.render_image(img)
                self.push_undo("Perspective")
            self.redraw()
            return 'RUNNING_MODAL'
        if d["type"] == 'MARQUEE':
            if d["moved"]:
                self._marquee_select(vs, view, d["start"], d["cur"])
            self.redraw()
            return 'RUNNING_MODAL'
        if not d["moved"]:
            return 'RUNNING_MODAL'
        render.render_image(img)
        msg = {'MOVE': "Move", 'SCALE': "Scale", 'ROTATE': "Rotate"}[d["type"]]
        if d.get("dup"):
            msg = "Duplicate"
        self.push_undo(msg)
        return 'RUNNING_MODAL'

    def _cancel(self, img):
        vs = img.vstroke
        d = self.drag
        self.drag = None
        snap.clear_guides()
        if d["type"] == 'CROP':
            ob = vs.objects[data.index_of_uid(vs, d["uid"])]
            ob.img_crop = d["crop0"]
            self.redraw()
            return
        if d["type"] == 'CORNER':
            corners.set_radius(vs, [d["ref"]], d["r0"])
            render.render_image(img)
            self.redraw()
            return
        if d["type"] == 'DISTORT':
            ob = vs.objects[data.index_of_uid(vs, d["uid"])]
            with render.suspended():
                ob.img_quad = d["quad0"]
                ob.img_quad_on = d["on0"]
            render.render_image(img)
            self.redraw()
            return
        if d["type"] in {'MOVE', 'SCALE', 'ROTATE'}:
            transform.restore(vs, d["snap"])
            if d.get("dup"):
                orig, new = d["dup"]
                data.remove_objects(vs, new)
                select_only(vs, orig)
        render.render_image(img)

    def _marquee_select(self, vs, view, a, b):
        p0 = view.to_image(*a)
        p1 = view.to_image(*b)
        rect = (min(p0[0], p1[0]), min(p0[1], p1[1]), max(p0[0], p1[0]), max(p0[1], p1[1]))
        iso = self.isolation(vs)
        m = data.uid_map(vs)
        editable = data.effective_editable(vs)
        hits = []
        for i, ob in enumerate(vs.objects):
            if ob.kind in {'GROUP', 'LAYER'} or not editable[i]:
                continue
            # 「触れたら選ぶ」(Illustrator・Affinity と同じ)。
            # 以前は「枠の中心が塗りの内側」でも選んでいたが、大きな背景の中で
            # 小さくドラッグしただけで背景が選ばれてしまうため、やめた
            polys = G.polylines(G.object_subpaths(ob)) + \
                G.polylines(G.text_frame_subpaths(ob))
            if any(G.polyline_hits_rect(p, c, rect) for p, c in polys):
                it = selectable_item(vs, ob.uid, iso, m)
                if it is not None and it not in hits:
                    hits.append(it)
        for u in hits:
            m[u].select = True
        if hits:
            data.set_active(vs, data.index_of_uid(vs, hits[-1]))

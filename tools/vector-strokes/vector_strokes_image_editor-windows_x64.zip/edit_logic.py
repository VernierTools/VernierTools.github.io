# SPDX-License-Identifier: GPL-3.0-or-later
"""ペンツールの操作ロジック (点単位の編集。v0.3.2 の操作仕様をそのまま引き継ぐ)。

点の指定は ref = (オブジェクト番号, サブパス番号, 点番号) のタプル。
"""

import math

from . import snap, data, geometry, keys, render, state
from .tool_base import Tool

HEADER_TEXT = keys.fmt("ペン | クリック: 点を追加(選択中の端点に繋がる / 未選択なら新しいパス) | "
               "端点を選択→別の端点をクリック: 接続・閉じる | ドラッグ: 移動 "
               "(ドラッグ中に Shift: 横・縦・45°) | Shift+クリック: 前の点から8方向に固定 | "
               "{ALT}+ドラッグ: ハンドル | Shift+クリック: 追加選択 | "
               "Enter/Esc: 選択解除 | C: 開閉 | F: 塗り | X/Delete: 削除 | "
               "V: 選択 M/L: 図形 | 何も選択していない時にEsc: 終了 | 右クリック: メニュー")


# -----------------------------------------------------------------------------
# データ操作ヘルパー
# -----------------------------------------------------------------------------

def get_sub(vs, oi, si):
    return vs.objects[oi].subpaths[si]


def get_point(vs, ref):
    oi, si, qi = ref
    return vs.objects[oi].subpaths[si].points[qi]


def ref_valid(vs, ref):
    oi, si, qi = ref
    return (0 <= oi < len(vs.objects) and 0 <= si < len(vs.objects[oi].subpaths)
            and 0 <= qi < len(vs.objects[oi].subpaths[si].points))


def iter_points(vs):
    for oi, ob in enumerate(vs.objects):
        if ob.kind != 'PATH':
            continue
        for si, sp in enumerate(ob.subpaths):
            for qi, p in enumerate(sp.points):
                yield (oi, si, qi), p


def single_selected(vs):
    found = None
    for ref, p in iter_points(vs):
        if p.select:
            if found is not None:
                return None
            found = ref
    return found


def any_selected(vs):
    return any(p.select for _, p in iter_points(vs))


def deselect_all(vs):
    for _, p in iter_points(vs):
        p.select = False


def is_open_end(vs, ref):
    if not ref_valid(vs, ref):
        return False
    oi, si, qi = ref
    sp = get_sub(vs, oi, si)
    n = len(sp.points)
    return (not sp.closed) and n > 0 and (qi == 0 or qi == n - 1)


def source_endpoint(vs):
    """「次の点を繋げる先」= 選択中の唯一の点で、開いたサブパスの端点。"""
    src = single_selected(vs)
    if src is not None and is_open_end(vs, src):
        return src
    return None


def reverse_subpath(sp):
    pts = [(tuple(p.co), tuple(p.handle_left), tuple(p.handle_right), p.select)
           for p in sp.points]
    pts.reverse()
    for p, (co, hl, hr, sel) in zip(sp.points, pts):
        p.co = co
        p.handle_left = hr
        p.handle_right = hl
        p.select = sel


def insert_point(vs, oi, si, seg, t):
    """パスの区間の途中に点を足す (形は変わらない)。戻り値: 新しい点の ref"""
    sp = get_sub(vs, oi, si)
    if sp is None:
        return None
    pts = list(sp.points)
    n = len(pts)
    if n < 2:
        return None
    count = n if sp.closed else n - 1
    if not (0 <= seg < count):
        return None
    i, j = seg, (seg + 1) % n
    a, b = pts[i], pts[j]
    h_left, (nl, co, nr), h_right = geometry.split_cubic(
        tuple(a.co), tuple(a.handle_right), tuple(b.handle_left), tuple(b.co), float(t))
    from . import render
    with render.suspended():
        sp.points.add()                      # いったん末尾に足してから、間へずらす
        new_i = len(sp.points) - 1
        while new_i > i + 1:
            sp.points.move(new_i, new_i - 1)
            new_i -= 1
        pts = list(sp.points)
        pts[i].handle_right = h_left
        pts[i + 1].co, pts[i + 1].handle_left, pts[i + 1].handle_right = co, nl, nr
        pts[i + 1].corner_radius = 0.0
        tail = (i + 2) % len(pts)
        pts[tail].handle_left = h_right
        for k, pt in enumerate(pts):
            pt.select = (k == i + 1)
    return (oi, si, i + 1)


def split_at(vs, oi, si, pi):
    """その点でパスを切る。閉じていれば開き、開いていれば2本に分ける。
    切れたら True。"""
    sp = get_sub(vs, oi, si)
    if sp is None:
        return False
    pts = [(tuple(p.co), tuple(p.handle_left), tuple(p.handle_right)) for p in sp.points]
    n = len(pts)
    if n < 2 or not (0 <= pi < n):
        return False
    ob = vs.objects[oi]
    from . import render
    if sp.closed:
        # 切った点を両端にして、1本の開いたパスにする
        order = [(pi + k) % n for k in range(n)] + [pi]
        with render.suspended():
            sp.closed = False
            while len(sp.points) < len(order):
                sp.points.add()
            for pt, k in zip(sp.points, order):
                pt.co, pt.handle_left, pt.handle_right = pts[k]
                pt.select = False
            sp.points[0].select = True
            sp.points[len(order) - 1].select = True
        return True
    if pi in (0, n - 1):
        return False                      # 端では切れない
    with render.suspended():
        head, tail = pts[:pi + 1], pts[pi:]
        while len(sp.points) > len(head):
            sp.points.remove(len(sp.points) - 1)
        for pt, v in zip(sp.points, head):
            pt.co, pt.handle_left, pt.handle_right = v
            pt.select = False
        sp.points[len(head) - 1].select = True
        sp2 = ob.subpaths.add()
        sp2.closed = False
        for v in tail:
            pt = sp2.points.add()
            pt.co, pt.handle_left, pt.handle_right = v
            pt.select = False
        sp2.points[0].select = True
    return True


def set_point_type(vs, ref, kind):
    """点を「角」(ハンドル無し) か「滑らか」(左右対称のハンドル) にする。"""
    pt = get_point(vs, ref)
    if pt is None:
        return False
    oi, si, pi = ref
    sp = get_sub(vs, oi, si)
    co = tuple(pt.co)
    if kind == 'CORNER':
        pt.handle_left = co
        pt.handle_right = co
        return True
    pts = sp.points
    n = len(pts)
    if n < 2:
        return False
    if sp.closed:
        a, b = tuple(pts[(pi - 1) % n].co), tuple(pts[(pi + 1) % n].co)
    else:
        a = tuple(pts[pi - 1].co) if pi > 0 else co
        b = tuple(pts[pi + 1].co) if pi < n - 1 else co
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy)
    if L < 1e-9:
        return False
    ux, uy = dx / L, dy / L
    la = math.hypot(co[0] - a[0], co[1] - a[1]) / 3.0
    lb = math.hypot(b[0] - co[0], b[1] - co[1]) / 3.0
    pt.handle_left = (co[0] - ux * la, co[1] - uy * la)
    pt.handle_right = (co[0] + ux * lb, co[1] + uy * lb)
    return True


def join_ends(vs, a, b):
    """端点 a から端点 b へ接続。同じサブパスの両端なら閉じる。
    別オブジェクトなら a 側のスタイルを残す。
    戻り値: ('CLOSED' / 'JOINED' / None, 繋ぎ目の点の ref)"""
    oa, sa, qa = a
    ob_, sb, qb = b
    A = get_sub(vs, oa, sa)
    if (oa, sa) == (ob_, sb):
        n = len(A.points)
        if n >= 2 and {qa, qb} == {0, n - 1}:
            A.closed = True
            deselect_all(vs)
            data.set_active(vs, oa)
            return 'CLOSED', (oa, sa, qb)
        return None, None
    B = get_sub(vs, ob_, sb)
    # A は選択端が末尾、B はクリック端が先頭になるよう向きを揃える
    if qa == 0 and len(A.points) > 1:
        reverse_subpath(A)
    if qb == len(B.points) - 1 and len(B.points) > 1:
        reverse_subpath(B)
    deselect_all(vs)
    seam = len(A.points)              # 繋ぎ目 (B の先頭が入る位置)
    for p in B.points:
        q = A.points.add()
        q.co = p.co
        q.handle_left = p.handle_left
        q.handle_right = p.handle_right
        q.select = False
    # 繋いだ先のもう一方の端を選択しておく(続けて描ける)
    A.points[len(A.points) - 1].select = True
    uid_a = vs.objects[oa].uid
    obB = vs.objects[ob_]
    obB.subpaths.remove(sb)
    if len(obB.subpaths) == 0:
        data.remove_objects(vs, [obB.uid])
    oi = data.index_of_uid(vs, uid_a)
    data.set_active(vs, oi)
    return 'JOINED', (oi, sa, seam)


def new_path(vs, parent_uid=0):
    """新しいパスを作る(アクティブが空のパスならそれを使う)。戻り値: (oi, si)"""
    ob = data.active_object(vs)
    if ob is not None and data.object_is_empty(ob):
        if len(ob.subpaths) == 0:
            ob.subpaths.add()
        return vs.active_index, 0
    oi = data.new_object(vs, style_from=data.style_source(vs), parent_uid=parent_uid)
    vs.objects[oi].subpaths.add()
    data.set_active(vs, oi)
    return oi, 0


def delete_selected(vs):
    # 端点を1つだけ消した場合は、隣の点を選択して続けて描けるようにする
    single = single_selected(vs)
    reselect = None
    if single is not None and is_open_end(vs, single):
        oi, si, qi = single
        n = len(get_sub(vs, oi, si).points)
        if n > 1:
            reselect = (vs.objects[oi].uid, si, qi - 1 if qi == n - 1 else 0)
    empty = []
    with render.suspended():
        for ob in vs.objects:
            if ob.kind != 'PATH':
                continue
            for si in range(len(ob.subpaths) - 1, -1, -1):
                sp = ob.subpaths[si]
                for qi in range(len(sp.points) - 1, -1, -1):
                    if sp.points[qi].select:
                        sp.points.remove(qi)
                if len(sp.points) == 0:
                    ob.subpaths.remove(si)
                elif len(sp.points) < 2:
                    sp.closed = False
            if len(ob.subpaths) == 0:
                empty.append(ob.uid)
    if empty:
        data.remove_objects(vs, empty)
    if reselect is not None:
        ref = (data.index_of_uid(vs, reselect[0]), reselect[1], reselect[2])
        if ref[0] >= 0 and ref_valid(vs, ref):
            get_point(vs, ref).select = True
    data.set_active(vs, min(vs.active_index, max(len(vs.objects) - 1, 0)))


# -----------------------------------------------------------------------------
# ペンツール
# -----------------------------------------------------------------------------

def constrained_from(vs, src, ix, iy):
    """Shift+クリックで置く点の位置: 選んでいる端点 src から、0/45/90°… の8方向に固定する
    (Illustrator のペンツールと同じ。2026-10-19 ユーザー要望)。"""
    ax, ay = get_point(vs, src).co
    dx, dy = geometry.constrain_45(ix - ax, iy - ay)
    return ax + dx, ay + dy


def _shift_handle(event, cx, cy, ix, iy):
    """Shift を押している間は、ハンドルの向きを 0/45/90° に固定する。"""
    if not getattr(event, "shift", False):
        return ix, iy
    dx, dy = geometry.constrain_45(ix - cx, iy - cy)
    return cx + dx, cy + dy


class PenTool(Tool):
    name = 'PEN'
    header = HEADER_TEXT
    cursor = 'CROSSHAIR'

    def _start_move(self, vs, ix, iy, mx, my, moved=False):
        orig = [(ref, tuple(p.co), tuple(p.handle_left), tuple(p.handle_right))
                for ref, p in iter_points(vs) if p.select]
        img = self.image()
        act = data.active_object(vs)
        self.drag = {"type": 'MOVE', "start_img": (ix, iy), "orig": orig,
                     "start": (mx, my), "moved": moved,
                     "targets": snap.make(vs, img, [act.uid] if act else [])
                     if img is not None else None}

    def handle(self, event, mx, my, inside, view):
        img = self.image()
        vs = img.vstroke

        # ---- ドラッグ中 ----
        if self.drag is not None:
            if event.type == 'MOUSEMOVE':
                state.mouse = (mx, my)
                self._update_drag(view, img, mx, my, event)
                if self.drag is not None and self.drag["type"] != 'PENDING':
                    self.maybe_render(img)
                return 'RUNNING_MODAL'
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                return self._release(img)
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._cancel_drag(img)
                self.drag = None
                render.render_image(img)
                return 'RUNNING_MODAL'
            return 'RUNNING_MODAL'

        if not inside:
            if state.mouse is not None:
                state.mouse = None
                self.redraw()
            return 'PASS_THROUGH'

        if event.type == 'MOUSEMOVE':
            state.mouse = (mx, my)
            state.mouse_shift = bool(event.shift)
            if source_endpoint(vs) is not None:
                self.redraw()
            return 'PASS_THROUGH'
        if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
            # Shift を押した・離した: 次の点への予告線の向きを、動かさなくても切り替える
            state.mouse_shift = event.value == 'PRESS'
            if source_endpoint(vs) is not None:
                self.redraw()
            return 'PASS_THROUGH'

        # ---- 選択解除 / 終了 ----
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if event.type == 'ESC' and any_selected(vs):
                deselect_all(vs)
                self.redraw()
                return 'RUNNING_MODAL'
            return 'FINISHED'

        # ---- クリック ----
        if event.type == 'LEFTMOUSE' and event.value in {'PRESS', 'DOUBLE_CLICK'}:
            return self._click(img, view, mx, my, event)

        # ---- キー ----
        if event.value == 'PRESS' and not keys.command_mod(event):
            return self._key(img, event)

        return 'PASS_THROUGH'

    def _click(self, img, view, mx, my, event):
        vs = img.vstroke
        ix, iy = view.to_image(mx, my)
        visible = data.effective_editable(vs)  # ロック中・非表示のものは触れない
        hit = geometry.hit_test(view, vs, mx, my, state.hit_radius(), visible)
        src = source_endpoint(vs)
        # 何も無い所に点を置くときは、キャンバスや他のものに吸い付かせる
        act = data.active_object(vs)
        targets = snap.make(vs, img, [act.uid] if act else [])
        if event.shift and src is not None and hit is None:
            # Shift: 前の点から8方向に固定。吸い付きは、固定した線の上で効かせる
            p0 = constrained_from(vs, src, ix, iy)
            ax, ay = get_point(vs, src).co
            dx, dy = p0[0] - ax, p0[1] - ay
            q = snap.place(p0, targets, view)
            dx, dy = snap.along(dx, dy, (q[0] - p0[0], q[1] - p0[1]))
            ix, iy = ax + dx, ay + dy
        else:
            ix, iy = snap.place((ix, iy), targets, view)

        if hit is None:
            so = geometry.hit_test_shape_points(view, vs, mx, my, state.hit_radius(), visible)
            if so is not None:
                # 図形の頂点 -> パスに変換してよいか確認 (Illustrator と同じ)
                data.set_active(vs, so)
                self.host.request_convert(img, vs.objects[so].uid)
                self.redraw()
                return 'RUNNING_MODAL'
            # 何もない場所 (Shift+クリックも同じ。位置は上で8方向に固定してある)
            if src is not None:
                # 選択中の端点から線を延ばす
                oi, si, qi = src
                sp = get_sub(vs, oi, si)
                if qi == 0 and len(sp.points) > 1:
                    reverse_subpath(sp)
                return self._add_point(img, oi, si, ix, iy, mx, my)
            if any_selected(vs):
                # 端点以外が選択されている -> 選択解除のみ
                deselect_all(vs)
                self.redraw()
                return 'RUNNING_MODAL'
            tol = max(6.0 * state.ui_scale(), state.hit_radius() * 0.5)
            # 線の上をクリック -> そこに点を足す (Illustrator のペンツールと同じ)
            spot = geometry.closest_on_path(view, vs, mx, my, tol, visible)
            if spot is not None and data.is_editable(vs, vs.objects[spot[0]].uid):
                ref = insert_point(vs, *spot)
                if ref is not None:
                    data.set_active(vs, ref[0])
                    render.render_image(img)
                    self.push_undo("Insert Point")
                    self.redraw()
                    return 'RUNNING_MODAL'
            cp = geometry.hit_test_curve(view, vs, mx, my, tol, visible)
            if cp is not None:
                # 図形の線の上: そのままでは点を足せないので、アクティブにして知らせる
                data.set_active(vs, cp)
                if vs.objects[cp].kind == 'SHAPE':
                    self.host.report("図形に点を足すには、先にパスに変換してください "
                                     "(頂点をクリック)")
                self.redraw()
                return 'RUNNING_MODAL'
            # 何も選択されていない -> 新しいパス
            if not self.can_create(vs):
                return 'RUNNING_MODAL'
            oi, si = new_path(vs, self.isolation(vs))
            return self._add_point(img, oi, si, ix, iy, mx, my)

        kind, ref = hit
        pt = get_point(vs, ref)
        data.set_active(vs, ref[0])

        if kind == 'POINT':
            if event.alt:
                deselect_all(vs)
                pt.select = True
                self.drag = {"type": 'PULL', "ref": ref,
                             "orig": (tuple(pt.handle_left), tuple(pt.handle_right))}
                return 'RUNNING_MODAL'
            if event.shift:
                pt.select = not pt.select
                self.redraw()
                if not pt.select:
                    return 'RUNNING_MODAL'
                self._start_move(vs, ix, iy, mx, my)
                return 'RUNNING_MODAL'
            # 選択中の端点から、別の端点をクリック -> (離した時に)接続 / 閉じる
            if src is not None and src != ref and is_open_end(vs, ref):
                self.drag = {"type": 'PENDING', "src": src, "dst": ref,
                             "start": (mx, my), "start_img": (ix, iy)}
                return 'RUNNING_MODAL'
            if not pt.select:
                deselect_all(vs)
                pt.select = True
            self._start_move(vs, ix, iy, mx, my)
            if src == ref:
                # 選択中の端点をもう一度クリック -> (離した時に)延長方向側のハンドルを消す
                self.drag["cusp"] = ref
            self.redraw()
            return 'RUNNING_MODAL'

        self.drag = {"type": 'HANDLE', "side": kind, "ref": ref,
                     "orig": (tuple(pt.handle_left), tuple(pt.handle_right))}
        return 'RUNNING_MODAL'

    def _key(self, img, event):
        vs = img.vstroke
        t = event.type
        if t in keys.CONFIRM_KEYS:
            deselect_all(vs)
            self.redraw()
            return 'RUNNING_MODAL'
        if t in keys.DELETE_KEYS:
            if any_selected(vs):
                delete_selected(vs)
                render.render_image(img)
                self.push_undo("Delete Points")
            return 'RUNNING_MODAL'
        ob = data.active_object(vs)
        if t == 'C' and ob is not None:
            if ob.kind == 'PATH' and len(ob.subpaths) > 0:
                # 選択点を含むサブパスが対象。無ければオブジェクトの全サブパス
                targets = [sp for sp in ob.subpaths
                           if any(p.select for p in sp.points)] or list(ob.subpaths)
                new = not targets[0].closed
                with render.suspended():
                    for sp in targets:
                        sp.closed = new
                render.render_image(img)
                self.push_undo("Toggle Closed")
            return 'RUNNING_MODAL'
        if t == 'F' and ob is not None:
            if ob.kind in {'PATH', 'SHAPE'}:
                fs = data.fills(ob)
                if fs:
                    for f in fs:
                        f.enabled = not fs[0].enabled
                else:
                    data.add_paint(ob, 'FILL', color=(1.0, 0.8, 0.2, 1.0))
                render.render_image(img)
                self.push_undo("Toggle Fill")
            return 'RUNNING_MODAL'
        if t == 'A':
            if event.alt:
                deselect_all(vs)
            else:
                any_unsel = any(not p.select for _, p in iter_points(vs))
                for _, p in iter_points(vs):
                    p.select = any_unsel
            self.redraw()
            return 'RUNNING_MODAL'
        return 'PASS_THROUGH'

    def _release(self, img):
        vs = img.vstroke
        d = self.drag
        self.drag = None
        if d["type"] == 'PENDING':
            # 動かさずに離した -> 接続 / 閉じる
            result, _ref = join_ends(vs, d["src"], d["dst"])
            if result is not None:
                render.render_image(img)
                self.push_undo("Close Path" if result == 'CLOSED' else "Join Paths")
            self.redraw()
            return 'RUNNING_MODAL'
        if d["type"] == 'MOVE' and not d.get("moved", True):
            ref = d.get("cusp")
            if ref is not None and ref_valid(vs, ref):
                oi, si, qi = ref
                sp = get_sub(vs, oi, si)
                pt = sp.points[qi]
                # 延長方向(次に点が付く側)のハンドルを点の位置に戻す
                if qi == len(sp.points) - 1:
                    pt.handle_right = pt.co
                else:
                    pt.handle_left = pt.co
                render.render_image(img)
                self.push_undo("Remove Handle")
            self.redraw()
            return 'RUNNING_MODAL'
        if d["type"] in {'HANDLE', 'PULL'} and ref_valid(vs, d["ref"]):
            p = get_point(vs, d["ref"])
            if (tuple(p.handle_left), tuple(p.handle_right)) == tuple(d["orig"]):
                return 'RUNNING_MODAL'       # ハンドルを押しただけ (Undo の空の段を積まない)
        render.render_image(img)
        self.push_undo("Vector Stroke Edit")
        return 'RUNNING_MODAL'

    def _add_point(self, img, oi, si, ix, iy, mx, my):
        vs = img.vstroke
        sp = get_sub(vs, oi, si)
        data.set_active(vs, oi)
        deselect_all(vs)
        pt = sp.points.add()
        pt.co = (ix, iy)
        pt.handle_left = (ix, iy)
        pt.handle_right = (ix, iy)
        pt.select = True
        self.drag = {"type": 'NEW', "ref": (oi, si, len(sp.points) - 1),
                     "start": (mx, my), "moved": False}
        self.maybe_render(img, force=True)
        return 'RUNNING_MODAL'

    # --- ドラッグ ---
    def _update_drag(self, view, img, mx, my, event):
        vs = img.vstroke
        d = self.drag
        ix, iy = view.to_image(mx, my)
        if d.get("type") in {'MOVE', 'PENDING'} and not event.shift:
            ix, iy = snap.place((ix, iy), d.get("targets"), view)
        u = state.ui_scale()
        t = d["type"]
        if t == 'PENDING':
            sx, sy = d["start"]
            if math.hypot(mx - sx, my - sy) < 4 * u:
                return
            # ドラッグした -> その場で繋いで (閉じて)、その点のハンドルを引き出す
            # (Illustrator と同じ。一周して閉じるとき、そのまま曲線にできる)
            result, ref = join_ends(vs, d["src"], d["dst"])
            if result is not None and ref is not None and ref_valid(vs, ref):
                p = get_point(vs, ref)
                p.select = True
                render.render_image(img)
                self.push_undo("Close Path" if result == 'CLOSED' else "Join Paths")
                self.drag = {"type": 'PULL', "ref": ref,
                             "orig": (tuple(p.handle_left), tuple(p.handle_right))}
                d, t = self.drag, 'PULL'
            else:
                # 繋げなかった -> 今までどおり、その点の移動に切替え
                deselect_all(vs)
                get_point(vs, d["dst"]).select = True
                sxi, syi = d["start_img"]
                self._start_move(vs, sxi, syi, sx, sy, moved=True)
                d = self.drag
                t = 'MOVE'
        if t == 'MOVE':
            if not d.get("moved", True):
                sx0, sy0 = d["start"]
                if math.hypot(mx - sx0, my - sy0) < 3 * u:
                    return
                d["moved"] = True
            sx, sy = d["start_img"]
            dx, dy = ix - sx, iy - sy
            if event.shift:
                # Shift: 0/45/90° の方向にだけ動かす (選択ツール・Illustrator と同じ。
                # 2026-09-22 ユーザー要望)。スナップは、固定した線の上で効かせる
                dx, dy = geometry.constrain_45(dx, dy)
                p0 = (sx + dx, sy + dy)
                q = snap.place(p0, d.get("targets"), view)
                dx, dy = snap.along(dx, dy, (q[0] - p0[0], q[1] - p0[1]))
            for ref, co, hl, hr in d["orig"]:
                if not ref_valid(vs, ref):
                    continue
                p = get_point(vs, ref)
                p.co = (co[0] + dx, co[1] + dy)
                p.handle_left = (hl[0] + dx, hl[1] + dy)
                p.handle_right = (hr[0] + dx, hr[1] + dy)
        elif t in {'NEW', 'PULL'}:
            if t == 'NEW' and not d["moved"]:
                sx, sy = d["start"]
                if math.hypot(mx - sx, my - sy) < 3 * u:
                    return
                d["moved"] = True
            p = get_point(vs, d["ref"])
            cx, cy = p.co
            ix, iy = _shift_handle(event, cx, cy, ix, iy)
            p.handle_right = (ix, iy)
            p.handle_left = (2 * cx - ix, 2 * cy - iy)
        elif t == 'HANDLE':
            p = get_point(vs, d["ref"])
            cx, cy = p.co
            ix, iy = _shift_handle(event, cx, cy, ix, iy)
            if d["side"] == 'HR':
                p.handle_right = (ix, iy)
                other = "handle_left"
            else:
                p.handle_left = (ix, iy)
                other = "handle_right"
            if not event.alt:
                ox, oy = getattr(p, other)
                olen = math.hypot(ox - cx, oy - cy)
                vx, vy = ix - cx, iy - cy
                vlen = math.hypot(vx, vy)
                if olen > 1e-6 and vlen > 1e-6:
                    setattr(p, other, (cx - vx / vlen * olen, cy - vy / vlen * olen))

    def _cancel_drag(self, img):
        vs = img.vstroke
        d = self.drag
        t = d["type"]
        if t == 'MOVE':
            for ref, co, hl, hr in d["orig"]:
                if ref_valid(vs, ref):
                    p = get_point(vs, ref)
                    p.co, p.handle_left, p.handle_right = co, hl, hr
        elif t in {'HANDLE', 'PULL'}:
            p = get_point(vs, d["ref"])
            p.handle_left, p.handle_right = d["orig"]
        elif t == 'NEW':
            p = get_point(vs, d["ref"])
            p.handle_left = p.co
            p.handle_right = p.co


EditSession = PenTool  # 旧名 (段階1のテスト互換)

# SPDX-License-Identifier: GPL-3.0-or-later
"""SVG と PDF への書き出し。

- PDF: Skia の PDF 書き出しに、画面と同じ描画処理をそのまま流し込む
  (元の画像・グラデーション・透明・描画モード・効果まで、見た目どおりに出る)
- SVG: このアドオン専用に組み立てる。Skia の SVG 書き出しは saveLayer を使った部分
  (不透明度・描画モード・効果) が丸ごと消えてしまうため使わない。
  自前で組み立てると、Illustrator で開いたときも編集しやすい形になる

座標: 画像は「下が 0」、SVG と PDF は「上が 0」。書き出すときに上下をひっくり返す。
色: 保存している値は sRGB なので、そのまま書き出す (linear=False)。
"""

import base64
import math
import re

import numpy as np

from . import data, geometry as G, pathops, render, transform

try:
    import skia
except Exception:
    skia = None

FORMATS = (('SVG', "SVG", "Illustrator などで開ける図形データ"),
           ('PDF', "PDF", "そのまま印刷・共有できる図形データ"))

# 描画モード -> CSS の mix-blend-mode
CSS_BLEND = {
    'NORMAL': "normal", 'DARKEN': "darken", 'MULTIPLY': "multiply",
    'COLOR_BURN': "color-burn", 'LIGHTEN': "lighten", 'SCREEN': "screen",
    'COLOR_DODGE': "color-dodge", 'OVERLAY': "overlay", 'SOFT_LIGHT': "soft-light",
    'HARD_LIGHT': "hard-light", 'DIFFERENCE': "difference", 'EXCLUSION': "exclusion",
    'HUE': "hue", 'SATURATION': "saturation", 'COLOR': "color",
    'LUMINOSITY': "luminosity",
}
SVG_CAPS = {'BUTT': "butt", 'ROUND': "round", 'SQUARE': "square"}
SVG_JOINS = {'MITER': "miter", 'ROUND': "round", 'BEVEL': "bevel"}


# -----------------------------------------------------------------------------
# 共通
# -----------------------------------------------------------------------------

def available():
    return skia is not None


def targets(vs, selection_only, include_base=True):
    """書き出す uid の集合。None なら全部。
    include_base=False なら、元の画像のレイヤー (data.is_original) を外す。"""
    only = _selected(vs, selection_only)
    if include_base:
        return only
    originals = {ob.uid for ob in vs.objects if data.is_original(ob)}
    if not originals:
        return only
    if only is None:
        only = {ob.uid for ob in vs.objects}
    return only - originals


def _selected(vs, selection_only):
    if not selection_only:
        return None
    items = transform.selected_items(vs)
    if not items:
        return None
    m = data.uid_map(vs)
    ch = data.children_map(vs)
    out = set()
    for u in items:
        out.add(u)
        out.update(data.descendants(vs, u, ch))
        out.update(data.ancestors(vs, u, m))
    return out


def linear_to_srgb(c):
    c = float(max(min(c, 1.0), 0.0))
    return c * 12.92 if c <= 0.0031308 else 1.055 * (c ** (1.0 / 2.4)) - 0.055


def base_rgba8(img, flip=False):
    """下地画像 (v0.28.3 までの形式) を 8bit の sRGB 配列にする。flip=True で上下をひっくり返す。"""
    base = img.vstroke.base_image
    if base is None:
        return None
    w, h = base.size
    arr = np.empty(w * h * 4, np.float32)
    base.pixels.foreach_get(arr)
    arr = arr.reshape(h, w, 4)
    if img.is_float:
        # float 画像は「リニア・乗算済み」なので、ストレートの sRGB に直す
        a = arr[..., 3:4]
        rgb = np.divide(arr[..., :3], a, out=np.zeros_like(arr[..., :3]), where=a > 1e-8)
        lut = np.array([linear_to_srgb(i / 1023.0) for i in range(1024)], np.float32)
        rgb = lut[np.clip(rgb * 1023.0, 0, 1023).astype(np.int32)]
        arr = np.concatenate([rgb, a], axis=2)
    out = (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
    # skia は連続した配列しか受け取れないので、反転したらコピーを作る
    return np.ascontiguousarray(out[::-1]) if flip else out


def _image_rgba8(im, adj=None):
    """Blender の画像を 8bit sRGB の配列にする (上下は PNG の向き)。
    adj (画像補正の値) があれば、補正した色にする (画面と同じ見た目で書き出す)。"""
    try:
        w, h = im.size
        if w <= 0 or h <= 0:
            return None
        arr = np.empty(w * h * 4, np.float32)
        im.pixels.foreach_get(arr)
        arr = arr.reshape(h, w, 4)
        if im.is_float:
            a = arr[..., 3:4]
            rgb = np.divide(arr[..., :3], a, out=np.zeros_like(arr[..., :3]), where=a > 1e-8)
            lut = np.array([linear_to_srgb(i / 1023.0) for i in range(1024)], np.float32)
            rgb = lut[np.clip(rgb * 1023.0, 0, 1023).astype(np.int32)]
            arr = np.concatenate([rgb, a], axis=2)
        if adj is not None:
            arr = np.concatenate([render.adjust_rgb(arr[..., :3], adj),
                                  render.adjust_alpha(arr[..., 3:4], adj)], axis=2)
        out = (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
        return np.ascontiguousarray(out[::-1])
    except Exception:
        return None


def _png_bytes(arr):
    im = skia.Image.fromarray(arr, skia.ColorType.kRGBA_8888_ColorType)
    return bytes(im.encodeToData(skia.EncodedImageFormat.kPNG, 100))


# -----------------------------------------------------------------------------
# PDF (Skia にまかせる)
# -----------------------------------------------------------------------------

def export_pdf(img, path, include_base=True, selection_only=False):
    """PDF を書き出す。戻り値: エラーの文言 (成功なら空文字)"""
    if skia is None:
        return "描画ライブラリ(Skia)を読み込めません"
    vs = img.vstroke
    w, h = img.size
    only = targets(vs, selection_only, include_base)
    # いったんメモリに書いてから Python で保存する。skia.FILEWStream は開けないファイル
    # (ほかのアプリで開いている PDF・書き込めないフォルダ) でもエラーにならず、
    # そのまま描くと Blender ごと落ちていた (2026-09-25 Windows で確認)
    stream = skia.DynamicMemoryWStream()
    doc = skia.PDF.MakeDocument(stream)
    canvas = doc.beginPage(w, h)
    canvas.save()
    canvas.translate(0, h)
    canvas.scale(1, -1)          # 画像座標 (下が 0) -> PDF 座標 (上が 0)
    if include_base:
        arr = base_rgba8(img)
        if arr is not None:
            im = skia.Image.fromarray(arr, skia.ColorType.kRGBA_8888_ColorType)
            canvas.drawImageRect(im, skia.Rect.MakeXYWH(0, 0, w, h))
    render.draw_objects(canvas, vs, linear=False, only=only)
    canvas.restore()
    doc.endPage()
    doc.close()
    raw = bytes(stream.detachAsData())
    if not raw:
        return "PDF を書き出せませんでした"
    try:
        with open(path, "wb") as f:
            f.write(raw)
    except PermissionError:
        return "PDF を保存できません (ほかのアプリで開いているか、書き込めない場所です)"
    except OSError as e:
        return "PDF を保存できません: %s" % e
    return ""


# -----------------------------------------------------------------------------
# SVG (自前で組み立てる)
# -----------------------------------------------------------------------------

def _num(v):
    """短い数値表記 (小数第3位まで)。"""
    s = "%.3f" % float(v)
    s = s.rstrip("0").rstrip(".")
    return s if s not in ("", "-0") else "0"


def _hex(c):
    return "#%02x%02x%02x" % tuple(int(round(max(min(float(v), 1.0), 0.0) * 255))
                                   for v in c[:3])


def _esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def _attrs(d):
    return "".join(' %s="%s"' % (k, v) for k, v in d.items() if v is not None)


def _with_attrs(element, attrs):
    """1つだけの要素なら、<g> で包まずにその要素へ属性を足す (SVG を簡潔にする)。"""
    if not attrs:
        return element
    m = re.match(r"<([A-Za-z]+)", element)
    if m is None:
        return element
    i = m.end()
    return element[:i] + _attrs(attrs) + element[i:]


class SvgWriter:
    """ベクターデータから SVG の文字列を組み立てる。"""

    def __init__(self, img, include_base=True, outline_text=True, selection_only=False):
        self.img = img
        self.vs = img.vstroke
        self.w, self.h = img.size
        self.include_base = include_base
        self.outline_text = outline_text
        self.only = targets(self.vs, selection_only, include_base)
        self.m = data.uid_map(self.vs)
        self.ch = data.children_map(self.vs)
        self.defs = []
        self.body = []
        self.n = 0
        self.used_ids = set()   # 書いた id (オブジェクトの名前の id と、定義の id が重ならないように)
        self.in_mask = 0        # クリッピングマスクの形を書いている間
        self._white = None      # 「色を白にしてアルファだけ残す」フィルターの id

    # --- 座標 (上下をひっくり返す) ---
    def fy(self, y):
        return self.h - float(y)

    def uid(self, prefix):
        while True:
            self.n += 1
            out = "%s%d" % (prefix, self.n)
            if out not in self.used_ids:
                self.used_ids.add(out)
                return out

    def name_id(self, name):
        """オブジェクトの名前を id にする。id は1つの SVG の中で重なってはいけないので、
        重なったら「_2」などを付ける。空白は使えないので「_」に、数字などで始まるなら頭に「_」。
        (0.36.8 までは名前をそのまま使い、同じ名前のレイヤーがあると id が重なっていた)"""
        base = re.sub(r"\s+", "_", name.strip())
        base = re.sub(r"[\"'<>&#]", "_", base)
        if not base:
            return None
        if not (base[0].isalpha() or base[0] == "_"):
            base = "_" + base
        out, k = base, 1
        while out in self.used_ids:
            k += 1
            out = "%s_%d" % (base, k)
        self.used_ids.add(out)
        return out

    # --- パス ---
    def subpaths(self, ob):
        """書き出す形 (「角を丸くする」は形に焼き込む)。"""
        subs = G.object_subpaths(ob)
        r = float(getattr(ob, "corner_round", 0.0))
        if r > 0.0 and subs and skia is not None:
            try:
                src = render.skia_path(ob)
                paint = skia.Paint()
                paint.setPathEffect(skia.CornerPathEffect.Make(r))
                dst = skia.Path()
                if paint.getFillPath(src, dst):
                    subs = pathops.from_skia(dst)
            except Exception:
                pass
        return subs

    def path_data(self, subs):
        out = []
        for pts, closed in subs:
            if len(pts) < 2:
                continue
            out.append("M%s,%s" % (_num(pts[0][0][0]), _num(self.fy(pts[0][0][1]))))
            for p0, p1, p2, p3 in G.iter_segments_t(pts, closed):
                if G.is_straight(p0, p1, p2, p3):
                    out.append("L%s,%s" % (_num(p3[0]), _num(self.fy(p3[1]))))
                else:
                    out.append("C%s,%s %s,%s %s,%s" % (
                        _num(p1[0]), _num(self.fy(p1[1])),
                        _num(p2[0]), _num(self.fy(p2[1])),
                        _num(p3[0]), _num(self.fy(p3[1]))))
            if closed:
                out.append("Z")
        return "".join(out)

    # --- 定義 (グラデーション・クリップ・効果) ---
    def gradient_def(self, p, gt=None):
        """gt: gradientTransform (変形した <g> の中で使うときに、その変形を打ち消す行列)。"""
        gid = self.uid("grad")
        a, b = tuple(p.g_start), tuple(p.g_end)
        gt_attr = ' gradientTransform="%s"' % gt if gt else ""
        stops = "".join(
            '<stop offset="%s" stop-color="%s" stop-opacity="%s"/>'
            % (_num(st.position), _hex(st.color), _num(st.color[3]))
            for st in data.sorted_stops(p))
        if p.paint_type == 'RADIAL':
            r = math.hypot(b[0] - a[0], b[1] - a[1])
            self.defs.append(
                '<radialGradient id="%s" gradientUnits="userSpaceOnUse"%s '
                'cx="%s" cy="%s" r="%s">%s</radialGradient>'
                % (gid, gt_attr, _num(a[0]), _num(self.fy(a[1])), _num(r), stops))
        else:
            self.defs.append(
                '<linearGradient id="%s" gradientUnits="userSpaceOnUse"%s '
                'x1="%s" y1="%s" x2="%s" y2="%s">%s</linearGradient>'
                % (gid, gt_attr, _num(a[0]), _num(self.fy(a[1])),
                   _num(b[0]), _num(self.fy(b[1])), stops))
        return gid

    def clip_def(self, ob):
        cid = self.uid("clip")
        rule = "evenodd" if ob.fill_rule == 'EVENODD' else "nonzero"
        self.defs.append('<clipPath id="%s"><path d="%s" clip-rule="%s"/></clipPath>'
                         % (cid, self.path_data(self.subpaths(ob)), rule))
        return cid

    def white_filter(self):
        """どんな色も白にして、アルファだけを残すフィルター (マスクで使う)。"""
        if self._white is None:
            self._white = self.uid("white")
            self.defs.append(
                '<filter id="%s" filterUnits="userSpaceOnUse" x="0" y="0" '
                'width="%s" height="%s" color-interpolation-filters="sRGB">'
                '<feColorMatrix type="matrix" '
                'values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0"/></filter>'
                % (self._white, self.w, self.h))
        return self._white

    def clip_mask_def(self, mask_uid):
        """クリッピングマスク用の <mask>。マスクの形の見た目 (塗り・線の透明度) をそのまま使う。
        色は白にしてアルファだけを残す (見た目のアルファで切り抜く画面と同じ結果になる)。
        何も描かれない (空・非表示・塗りも線も無い) なら None。"""
        self.in_mask += 1
        try:
            inner = self.node(mask_uid)
        finally:
            self.in_mask -= 1
        if not inner:
            return None
        mid = self.uid("mask")
        self.defs.append(
            '<mask id="%s" maskUnits="userSpaceOnUse" x="0" y="0" width="%s" height="%s" '
            'style="mask-type:alpha"><g filter="url(#%s)">%s</g></mask>'
            % (mid, self.w, self.h, self.white_filter(), inner))
        return mid

    def layer_mask_def(self, ob):
        """レイヤーマスクの <mask> (明るさで見せる。白 = 見える、黒 = 隠れる)。無ければ None。"""
        if not data.has_mask(ob) or skia is None:
            return None
        v = render.mask_values(ob.mask_image, self.w, self.h)
        if v is None:
            return None
        g = (np.clip(v, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)[::-1]   # PNG は上から
        rgba = np.ascontiguousarray(np.stack([g, g, g, np.full_like(g, 255)], axis=2))
        b64 = base64.b64encode(_png_bytes(rgba)).decode("ascii")
        mid = self.uid("lmask")
        self.defs.append(
            '<mask id="%s" maskUnits="userSpaceOnUse" x="0" y="0" width="%s" height="%s" '
            'color-interpolation="sRGB"><image x="0" y="0" width="%s" height="%s" '
            'xlink:href="data:image/png;base64,%s"/></mask>'
            % (mid, self.w, self.h, self.w, self.h, b64))
        return mid

    def wrap(self, attrs, parts, lm):
        """要素をまとめて、属性 (不透明度・描画モード・効果など) を付ける。
        レイヤーマスクは内側でかける (効果や描画モードは、マスクで削った形にかかる。画面と同じ)。"""
        if lm:
            return '<g%s><g mask="url(#%s)">%s</g></g>' % (_attrs(attrs), lm, "".join(parts))
        if len(parts) == 1:
            return _with_attrs(parts[0], attrs)
        return "<g%s>%s</g>" % (_attrs(attrs), "".join(parts))

    def adjust_layer(self, ob):
        """調整レイヤー: ここまでに書いたもの全体に、色調補正のフィルターをかける。
        強さ (不透明度) やマスクがあれば、補正したものを元の上に重ねる。"""
        if not ob.visible or ob.opacity <= 0.0:
            return
        if self.only is not None and ob.uid not in self.only:
            return
        vals = data.adjust_values(ob)
        below = "".join(x for x in self.body if x)
        if vals is None or not below:
            return
        fid = self.uid("adj")
        self.defs.append(
            '<filter id="%s" filterUnits="userSpaceOnUse" x="0" y="0" width="%s" height="%s" '
            'color-interpolation-filters="sRGB">%s</filter>'
            % (fid, self.w, self.h, "".join(self.adjust_prims(vals))))
        lm = self.layer_mask_def(ob)
        if ob.opacity >= 1.0 and lm is None:
            self.body = ['<g filter="url(#%s)">%s</g>' % (fid, below)]
            return
        copy = re.sub(r' id="[^"]*"', "", below)          # 同じ id が2つにならないように
        attrs = {"opacity": _num(ob.opacity) if ob.opacity < 1.0 else None}
        self.body = [below, self.wrap(attrs, ['<g filter="url(#%s)">%s</g>' % (fid, copy)], lm)]

    def outside_mask_def(self, d_attr, rule):
        """線の「外側」用: 形の外だけを残すマスク。"""
        mid = self.uid("mask")
        self.defs.append(
            '<mask id="%s" maskUnits="userSpaceOnUse" x="0" y="0" width="%s" height="%s">'
            '<rect x="0" y="0" width="%s" height="%s" fill="#ffffff"/>'
            '<path d="%s" fill="#000000" fill-rule="%s"/></mask>'
            % (mid, self.w, self.h, self.w, self.h, d_attr, rule))
        return mid

    def adjust_prims(self, adj):
        """レイヤー・グループの色調補正 (画面と同じ計算を、表と行列で書く)。"""
        tables, mat, post = render.adjust_parts(adj)

        def funcs(ts):
            return "".join('<feFunc%s type="table" tableValues="%s"/>'
                           % (c, " ".join("%.4f" % float(v) for v in t))
                           for c, t in zip("RGB", ts))
        cut = float(dict(adj).get("alpha_cut", 0.0))
        alpha = ""
        if cut > 0.0:
            # アルファのしきい値: それより薄い所を 0 に (表の細かさ 1/256 で切り替わる)
            xs = np.linspace(0.0, 1.0, 257)
            alpha = '<feFuncA type="table" tableValues="%s"/>' % " ".join(
                "%.4f" % (x if x >= cut else 0.0) for x in xs)
        out = ['<feComponentTransfer>%s%s</feComponentTransfer>' % (funcs(tables), alpha)]
        if mat is not None:
            rows = ["%s 0 0" % " ".join("%.5f" % float(x) for x in r) for r in mat]
            out.append('<feColorMatrix type="matrix" values="%s  0 0 0 1 0"/>'
                       % "  ".join(rows))
        if post is not None:
            out.append('<feComponentTransfer>%s</feComponentTransfer>'
                       % funcs([post] * 3))
        return out

    def grain_prims(self, grain, n):
        """粒子 (見た目が近いだけ。粒の模様は画面と同じにはならない)。"""
        amount, size, mono, seed = grain
        k = self.uid("gr")
        prev = "%s_in" % k
        if mono:
            m = "0.8 0.8 0.8 0 -0.7  0.8 0.8 0.8 0 -0.7  0.8 0.8 0.8 0 -0.7  0 0 0 0 1"
        else:
            m = "2.4 0 0 0 -0.7  0 2.4 0 0 -0.7  0 0 2.4 0 -0.7  0 0 0 0 1"
        return [
            '<feMerge result="%s"><feMergeNode/></feMerge>' % prev,     # ここまでの結果
            '<feTurbulence type="fractalNoise" baseFrequency="%s" numOctaves="2" seed="%d" '
            'result="%s_n"/>' % (_num(0.9 / max(size, 1.0)), seed % 1000, k),
            '<feColorMatrix in="%s_n" type="matrix" values="%s" result="%s_g"/>' % (k, m, k),
            '<feComposite in="%s" in2="%s_g" operator="arithmetic" k1="0" k2="1" k3="%s" '
            'k4="%s" result="%s_a"/>' % (prev, k, _num(amount), _num(-0.5 * amount), k),
            '<feComposite in="%s_a" in2="%s" operator="in"/>' % (k, prev),
        ]

    def filter_def(self, ob):
        """色調補正・粒子・影・ぼかし・光彩を SVG のフィルターにする。無ければ None。"""
        prims = []
        adj, grain, _mirror = render.post_settings(ob)
        if adj is not None:
            prims += self.adjust_prims(adj)
        if grain is not None:
            prims += self.grain_prims(grain, len(prims))
        srgb = bool(prims)       # 補正・粒子は見た目どおりの sRGB の値で計算する
        if ob.fx_blur_enable and ob.fx_blur_amount > 0.0:
            prims.append('<feGaussianBlur stdDeviation="%s"/>'
                         % _num(float(ob.fx_blur_amount) * 0.5))
        if ob.fx_glow_enable and ob.fx_glow_size > 0.0:
            sg = _num(float(ob.fx_glow_size) * 0.5)
            col, alpha = _hex(ob.fx_glow_color), _num(ob.fx_glow_color[3])
            if ob.fx_glow_kind == 'OUTER':
                prims.append('<feDropShadow dx="0" dy="0" stdDeviation="%s" '
                             'flood-color="%s" flood-opacity="%s"/>' % (sg, col, alpha))
            else:
                # 内側の光彩: 形の内側だけに、ぼかした縁を描く
                prims.append(
                    '<feComponentTransfer in="SourceAlpha" result="vsInvA">'
                    '<feFuncA type="table" tableValues="1 0"/></feComponentTransfer>'
                    '<feGaussianBlur in="vsInvA" stdDeviation="%s" result="vsInvBlur"/>'
                    '<feFlood flood-color="%s" flood-opacity="%s" result="vsGlowCol"/>'
                    '<feComposite in="vsGlowCol" in2="vsInvBlur" operator="in" '
                    'result="vsGlow"/>'
                    '<feComposite in="vsGlow" in2="SourceAlpha" operator="in" '
                    'result="vsGlowIn"/>'
                    '<feMerge><feMergeNode in="SourceGraphic"/>'
                    '<feMergeNode in="vsGlowIn"/></feMerge>' % (sg, col, alpha))
        if ob.fx_shadow_enable:
            prims.append('<feDropShadow dx="%s" dy="%s" stdDeviation="%s" '
                         'flood-color="%s" flood-opacity="%s"/>'
                         % (_num(ob.fx_shadow_offset[0]),
                            _num(-float(ob.fx_shadow_offset[1])),   # SVG は下が +
                            _num(float(ob.fx_shadow_blur) * 0.5),
                            _hex(ob.fx_shadow_color), _num(ob.fx_shadow_color[3])))
        if not prims:
            return None
        fid = self.uid("fx")
        self.defs.append(
            '<filter id="%s" x="-50%%" y="-50%%" width="200%%" height="200%%"%s>%s</filter>'
            % (fid, ' color-interpolation-filters="sRGB"' if srgb else "", "".join(prims)))
        return fid

    # --- 塗りと線 ---
    def fill_attrs(self, ob, p, gt=None):
        if p.paint_type == 'SOLID':
            return {"fill": _hex(p.color),
                    "fill-opacity": (_num(p.color[3]) if p.color[3] < 1.0 else None)}
        return {"fill": "url(#%s)" % self.gradient_def(p, gt)}

    def stroke_attrs(self, ob, p, width=None, gt=None, k=1.0):
        """k: 変形した <g> の中で使うときの、その変形の拡大率 (線幅と破線を割り戻す)。"""
        a = {}
        if p.paint_type == 'SOLID':
            a["stroke"] = _hex(p.color)
            if p.color[3] < 1.0:
                a["stroke-opacity"] = _num(p.color[3])
        else:
            a["stroke"] = "url(#%s)" % self.gradient_def(p, gt)
        a["stroke-width"] = _num((width if width is not None else p.width) / k)
        if p.cap != 'BUTT':
            a["stroke-linecap"] = SVG_CAPS.get(p.cap, "round")
        if p.join != 'MITER':
            a["stroke-linejoin"] = SVG_JOINS.get(p.join, "round")
        elif abs(float(p.miter_limit) - 4.0) > 1e-6:
            a["stroke-miterlimit"] = _num(p.miter_limit)
        if p.dash_enable:
            vals = [float(v) for v in p.dash]
            dash = []
            for i in range(0, 6, 2):
                if vals[i] > 0.0:
                    dash += [vals[i], max(vals[i + 1], 0.01)]
            if dash:
                a["stroke-dasharray"] = ",".join(_num(v / k) for v in dash)
                if abs(float(p.dash_offset)) > 1e-6:
                    a["stroke-dashoffset"] = _num(float(p.dash_offset) / k)
        return a

    def leaf_elements(self, ob, d_attr, rule):
        """1つのオブジェクトを、塗り・線ごとの要素にする。"""
        paints = [p for p in ob.paints
                  if p.enabled and not (p.kind == 'STROKE' and p.width <= 0.0)]
        if not paints:
            return []
        fills = [p for p in paints if p.kind == 'FILL']
        strokes = [p for p in paints if p.kind == 'STROKE']
        common = {"d": d_attr, "fill-rule": (rule if rule != "nonzero" else None)}
        # よくある「塗り1つ + 中央の線1つ」は、1つの要素にまとめる
        if (len(fills) == 1 and len(strokes) == 1 and len(paints) == 2
                and paints[0].kind == 'FILL' and strokes[0].align == 'CENTER'):
            a = dict(common)
            a.update(self.fill_attrs(ob, fills[0]))
            a.update(self.stroke_attrs(ob, strokes[0]))
            return ["<path%s/>" % _attrs(a)]
        out = []
        for p in paints:
            if p.kind == 'FILL':
                a = dict(common)
                a.update(self.fill_attrs(ob, p))
                a["stroke"] = "none"
                out.append("<path%s/>" % _attrs(a))
                continue
            if p.align == 'CENTER':
                a = dict(common)
                a["fill"] = "none"
                a.update(self.stroke_attrs(ob, p))
                out.append("<path%s/>" % _attrs(a))
                continue
            # 内側 / 外側の線: 2倍の太さで描いて、内か外だけを残す (画面と同じやり方)
            a = dict(common)
            a["fill"] = "none"
            a.update(self.stroke_attrs(ob, p, width=float(p.width) * 2.0))
            inner = "<path%s/>" % _attrs(a)
            if p.align == 'INSIDE':
                out.append('<g clip-path="url(#%s)">%s</g>'
                           % (self.clip_def(ob), inner))
            else:
                out.append('<g mask="url(#%s)">%s</g>'
                           % (self.outside_mask_def(d_attr, rule), inner))
        return out

    # --- 置いた画像 ---
    def distorted_image_elements(self, ob):
        """遠近変形した画像: SVG には遠近変形の書き方が無いので、変形済みの絵を描いて埋め込む
        (4隅を囲む四角の大きさ・キャンバスの 2 倍の細かさ)。見た目は画面と同じ。"""
        w, h = data.image_size(ob)
        im = render.placed_image(ob.image, False, data.adjust_values(ob))
        if im is None or w <= 0 or h <= 0:
            return []
        cs = data.image_visible_corners(ob)      # トリミングしていれば、見えている範囲だけ
        x0, x1 = min(c[0] for c in cs), max(c[0] for c in cs)
        y0, y1 = min(c[1] for c in cs), max(c[1] for c in cs)
        k = 2.0
        bw = max(1, min(int(math.ceil((x1 - x0) * k)), 8192))
        bh = max(1, min(int(math.ceil((y1 - y0) * k)), 8192))
        surf = skia.Surface(bw, bh)
        cv = surf.getCanvas()
        cv.clear(skia.Color4f(0, 0, 0, 0))
        # 画像座標 (上が +) -> PNG の向き (上が 0)
        cv.concat(skia.Matrix.MakeAll(k, 0, -x0 * k, 0, -k, y1 * k, 0, 0, 1))
        cv.concat(render.image_skia_matrix(ob, w, h))
        if data.has_crop(ob):
            cx0, cy0, cx1, cy1 = data.crop_rect_px(ob)
            cv.clipRect(skia.Rect.MakeLTRB(cx0, cy0, cx1, cy1), True)
        cv.drawImageRect(im, skia.Rect.MakeXYWH(0, 0, w, h),
                         skia.SamplingOptions(skia.FilterMode.kLinear), skia.Paint(AntiAlias=True))
        png = bytes(surf.makeImageSnapshot().encodeToData(skia.EncodedImageFormat.kPNG, 100))
        b64 = base64.b64encode(png).decode("ascii")
        return ['<image x="%s" y="%s" width="%s" height="%s" preserveAspectRatio="none" '
                'xlink:href="data:image/png;base64,%s"/>'
                % (_num(x0), _num(self.fy(y1)), _num(x1 - x0), _num(y1 - y0), b64)]

    def image_elements(self, ob):
        """読み込んだ画像を <image> にする (画像は base64 で埋め込む)。"""
        if skia is None or ob.image is None:
            return []
        if ob.img_quad_on:
            return self.distorted_image_elements(ob)
        w, h = data.image_size(ob)
        if w <= 0 or h <= 0:
            return []
        arr = _image_rgba8(ob.image, data.adjust_values(ob))
        if arr is None:
            return []
        b64 = base64.b64encode(_png_bytes(arr)).decode("ascii")
        m = data.image_matrix(ob)
        # ローカル (左下が原点・上が +) -> SVG (左上が原点・下が +)
        # 画像の左上が local(0, h) に当たるので、そこを基準にする
        a, b = float(m[0, 0]), float(m[1, 0])
        c, d = float(m[0, 1]), float(m[1, 1])
        ox, oy = float(m[0, 2]), float(m[1, 2])
        tx = ox + c * h
        ty = self.fy(oy + d * h)
        mat = "matrix(%s,%s,%s,%s,%s,%s)" % (_num(a), _num(-b), _num(-c), _num(d),
                                             _num(tx), _num(ty))
        if data.has_crop(ob):
            # トリミング: 画像の中の座標 (左上が原点・下が +) で切り抜く。
            # 画素は全部埋め込むので、開いた先 (Illustrator など) でも切り抜きを外せる
            cx0, cy0, cx1, cy1 = data.crop_rect_px(ob)
            cid = self.uid("crop")
            return ['<g transform="%s"><clipPath id="%s"><rect x="%s" y="%s" width="%s" '
                    'height="%s"/></clipPath><image width="%d" height="%d" '
                    'clip-path="url(#%s)" xlink:href="data:image/png;base64,%s"/></g>'
                    % (mat, cid, _num(cx0), _num(h - cy1), _num(cx1 - cx0), _num(cy1 - cy0),
                       w, h, cid, b64)]
        return ['<image width="%d" height="%d" transform="%s" '
                'xlink:href="data:image/png;base64,%s"/>' % (w, h, mat, b64)]

    # --- 文字を「文字のまま」書き出す ---
    def text_elements(self, ob):
        from . import fonts, text as text_mod
        lay = text_mod.layout(ob)
        if lay is None or not lay.lines:
            return []
        paints = [p for p in ob.paints if p.enabled]
        fills = [p for p in paints if p.kind == 'FILL']
        strokes = [p for p in paints if p.kind == 'STROKE' and p.width > 0]
        # 文字は下の matrix で変形した <g> の中に書く。グラデーションの位置 (キャンバスの座標) と
        # 線幅 (画面では変形したあとの形に引く) は、その変形の分を打ち消しておく
        # (0.36.8 までは文字の基準点の分だけグラデーションがずれていた)
        mx = ob.text_mat
        tx, ty = ob.text_origin
        sm = np.array([[float(mx[0]), -float(mx[2]), float(tx)],
                       [-float(mx[1]), float(mx[3]), self.fy(ty)],
                       [0.0, 0.0, 1.0]])
        try:
            inv = np.linalg.inv(sm)
            gt = "matrix(%s)" % ",".join(_num(v) for v in (inv[0, 0], inv[1, 0], inv[0, 1],
                                                          inv[1, 1], inv[0, 2], inv[1, 2]))
        except np.linalg.LinAlgError:
            gt = None
        k = math.sqrt(abs(float(np.linalg.det(sm[:2, :2])))) or 1.0
        a = {"font-family": "'%s'" % _esc(ob.font_family),
             "font-size": _num(ob.font_size)}
        if fills:
            a.update(self.fill_attrs(ob, fills[0], gt))
        else:
            a["fill"] = "none"
        if strokes:
            a.update(self.stroke_attrs(ob, strokes[0], gt=gt, k=k))
        face = fonts.find(ob.font_family, ob.font_style)
        if face is not None and face.weight not in (0, 400):
            a["font-weight"] = str(int(face.weight))
        if face is not None and face.italic:
            a["font-style"] = "italic"
        # ローカル座標 (下が +) を、SVG の向き (下が -) に直す行列 (上の sm と同じ)
        mat = "matrix(%s,%s,%s,%s,%s,%s)" % (
            _num(mx[0]), _num(-mx[1]), _num(-mx[2]), _num(mx[3]),
            _num(tx), _num(self.fy(ty)))
        out = []
        for ln in lay.lines:
            if not ln.text.strip():
                continue
            xs, ys, rot = [], [], []
            for i in range(len(ln.text)):
                x, y, ang = ln.carets[i]
                xs.append(_num(x))
                ys.append(_num(-y))
                rot.append(_num(-math.degrees(ang)))
            ta = dict(a)
            ta["x"] = " ".join(xs)
            ta["y"] = " ".join(ys)
            if any(r not in ("0", "-0") for r in rot):
                ta["rotate"] = " ".join(rot)
            ta["xml:space"] = "preserve"
            out.append("<text%s>%s</text>" % (_attrs(ta), _esc(ln.text)))
        return ['<g transform="%s">%s</g>' % (mat, "".join(out))] if out else []

    # --- 木をたどる ---
    def node(self, uid):
        out = self._node(uid)
        ob = self.m.get(uid)
        if not out or ob is None or self.in_mask or not data.has_mirror(ob):
            return out
        return self.mirror_wrap(out, ob.fx_mirror_mode)

    def mirror_wrap(self, out, mode):
        """ミラー: 元の半分を切り抜いたものと、それを反転したものを並べる
        (SVG は下が +。「上」は y の小さい方)。"""
        W, H = self.w, self.h
        if mode in {'L2R', 'R2L'}:
            x = 0.0 if mode == 'L2R' else W / 2.0
            rect = (x, 0.0, W / 2.0, float(H))
            tf = "matrix(-1 0 0 1 %s 0)" % _num(W)
        else:
            y = 0.0 if mode == 'T2B' else H / 2.0
            rect = (0.0, y, float(W), H / 2.0)
            tf = "matrix(1 0 0 -1 0 %s)" % _num(H)
        cid = self.uid("mirror")
        self.defs.append('<clipPath id="%s" clipPathUnits="userSpaceOnUse">'
                         '<rect x="%s" y="%s" width="%s" height="%s"/></clipPath>'
                         % ((cid,) + tuple(_num(v) for v in rect)))
        copy = re.sub(r' id="[^"]*"', "", out)          # 同じ id が2つにならないように
        return ('<g><g clip-path="url(#%s)">%s</g><g transform="%s">'
                '<g clip-path="url(#%s)">%s</g></g></g>' % (cid, out, tf, cid, copy))

    def _node(self, uid):
        ob = self.m.get(uid)
        if ob is None or not ob.visible:
            return ""
        if self.only is not None and not self.in_mask and uid not in self.only:
            return ""
        attrs = {}
        if ob.opacity < 1.0:
            attrs["opacity"] = _num(ob.opacity)
        # マスクの形はアルファだけが要る。描画モードや影は関係ない
        if ob.blend_mode != 'NORMAL' and not self.in_mask:
            attrs["style"] = "mix-blend-mode:%s" % CSS_BLEND.get(ob.blend_mode, "normal")
        fid = None if self.in_mask else self.filter_def(ob)
        if fid:
            attrs["filter"] = "url(#%s)" % fid
        if ob.name:
            attrs["id"] = self.name_id(ob.name)
        lm = self.layer_mask_def(ob)

        if ob.kind in {'GROUP', 'LAYER'}:
            kids = self.ch.get(uid, [])
            if ob.clip and kids:
                mid = self.clip_mask_def(kids[-1])
                if mid is None:
                    return ""       # マスクが何も通さない = 何も見えない
                attrs["mask"] = "url(#%s)" % mid
                kids = kids[:-1]
            inner = "".join(self.node(k) for k in kids)
            if not inner:
                return ""
            if lm:
                inner = '<g mask="url(#%s)">%s</g>' % (lm, inner)
            return "<g%s>%s</g>" % (_attrs(attrs), inner)

        if ob.kind == 'IMAGE':
            parts = self.image_elements(ob)
            if not parts:
                return ""
            return self.wrap(attrs, parts, lm)

        # 文字ごとに書体や大きさを変えている場合は、<text> では表せないので
        # アウトライン (パス) で書き出す。見た目はまったく同じになる
        if ob.kind == 'TEXT' and not self.outline_text and not len(ob.text_styles):
            parts = self.text_elements(ob)
        else:
            subs = self.subpaths(ob)
            if not subs:
                return ""
            d_attr = self.path_data(subs)
            if not d_attr:
                return ""
            rule = "evenodd" if (ob.kind != 'TEXT' and ob.fill_rule == 'EVENODD') \
                else "nonzero"
            parts = self.leaf_elements(ob, d_attr, rule)
        if not parts:
            return ""
        return self.wrap(attrs, parts, lm)

    def build(self):
        for uid in self.ch.get(0, []):
            ob = self.m.get(uid)
            if ob is not None and ob.kind == 'ADJUST':
                self.adjust_layer(ob)
                continue
            self.body.append(self.node(uid))
        head = ('<?xml version="1.0" encoding="UTF-8"?>\n'
                '<svg xmlns="http://www.w3.org/2000/svg" '
                'xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" '
                'width="%dpx" height="%dpx" viewBox="0 0 %d %d">\n'
                % (self.w, self.h, self.w, self.h))
        image = ""
        if self.include_base:
            arr = base_rgba8(self.img, flip=True)
            if arr is not None and skia is not None:
                b64 = base64.b64encode(_png_bytes(arr)).decode("ascii")
                image = ('<image x="0" y="0" width="%d" height="%d" '
                         'xlink:href="data:image/png;base64,%s"/>\n'
                         % (self.w, self.h, b64))
        defs = ("<defs>\n%s\n</defs>\n" % "\n".join(self.defs)) if self.defs else ""
        return head + defs + image + "\n".join(x for x in self.body if x) + "\n</svg>\n"


def svg_string(img, include_base=True, outline_text=True, selection_only=False):
    return SvgWriter(img, include_base, outline_text, selection_only).build()


def export_svg(img, path, include_base=True, outline_text=True, selection_only=False):
    """SVG を書き出す。戻り値: エラーの文言 (成功なら空文字)"""
    try:
        s = svg_string(img, include_base, outline_text, selection_only)
    except Exception as e:
        return "SVG を組み立てられませんでした: %s" % e
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(s)
    except PermissionError:
        return "SVG を保存できません (ほかのアプリで開いているか、書き込めない場所です)"
    except OSError as e:
        return "SVG を保存できません: %s" % e
    return ""


def export_file(img, path, fmt='SVG', include_base=True, outline_text=True,
                selection_only=False):
    if fmt == 'PDF':
        return export_pdf(img, path, include_base, selection_only)
    return export_svg(img, path, include_base, outline_text, selection_only)
